 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SEQUENCE#									   NUMBER
 ID										   NUMBER
 NAME										   VARCHAR2(30)
 START_TIME									   DATE
 END_TIME									   DATE
 ENABLED_BY_SCHEDULER								   VARCHAR2(5)
 WINDOW_NAME									   VARCHAR2(30)
 ALLOWED_AUTOMATED_SWITCHES							   VARCHAR2(5)
 CPU_MANAGED									   VARCHAR2(3)

