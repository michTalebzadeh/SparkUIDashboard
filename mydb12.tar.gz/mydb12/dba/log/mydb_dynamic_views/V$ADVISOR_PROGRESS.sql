 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 SERIAL#									   NUMBER
 USERNAME									   VARCHAR2(30)
 OPNAME 									   VARCHAR2(64)
 ADVISOR_NAME									   VARCHAR2(64)
 TASK_ID									   NUMBER
 TARGET_DESC									   VARCHAR2(32)
 SOFAR										   NUMBER
 TOTALWORK									   NUMBER
 UNITS										   VARCHAR2(32)
 BENEFIT_SOFAR									   NUMBER
 BENEFIT_MAX									   NUMBER
 FINDINGS									   NUMBER
 RECOMMENDATIONS								   NUMBER
 TIME_REMAINING 								   NUMBER
 START_TIME									   DATE
 LAST_UPDATE_TIME								   DATE
 ELAPSED_SECONDS								   NUMBER
 ADVISOR_METRIC1								   NUMBER
 METRIC1_DESC									   VARCHAR2(64)
 EXECUTION_TYPE 								   VARCHAR2(64)

