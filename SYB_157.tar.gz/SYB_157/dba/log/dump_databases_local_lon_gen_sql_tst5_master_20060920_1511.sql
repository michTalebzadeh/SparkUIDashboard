use master
go
dump database master to 'compress::4::/apps/sybase/dump/lon_gen_sql_tst5/lon_gen_sql_tst5.master.20060920_1511.01.cdmp' 
go
exit
