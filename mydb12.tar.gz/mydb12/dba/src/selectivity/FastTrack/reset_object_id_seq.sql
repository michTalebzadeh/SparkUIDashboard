COLUMN inc NEW_VAL INC;
SELECT object_id_seq.nextval+1 inc FROM ( SELECT MAX(object_id) max_object_id FROM t);
ALTER SEQUENCE object_id_seq INCREMENT BY &inc;
SELECT object_id_seq.nextval FROM dual;
ALTER SEQUENCE object_id_seq INCREMENT BY 1;
SELECT object_id_seq.nextval FROM dual;
exit
