ALTER SESSION SET STATISTICS_LEVEL='ALL';
--ALTER SESSION SET STATISTICS_LEVEL='TYPICAL';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE( waits=>true );
--alter session set events '10949 trace name context forever, level 1';
--ALTER SESSION SET TRACEFILE_IDENTIFIER = 'query_T1_no_index_no_direct_path';
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'query_T1_index';
SELECT count(1)
FROM T1
where   n1 <= 8
and	ind_pad <= rpad('x',39)||'x'
and     n2      < 15;
EXEC DBMS_MONITOR.SESSION_TRACE_DISABLE;
exit
