-- accept v_name prompt "Enter the parameter name to view: "
Set linesize 150 pagesize 40
column name format a40 heading name
column value format a20 heading value
column isdefault format a20 heading isdefault
column description format a55 heading description word_wrap
select 
  	  a.ksppinm name
  	, b.ksppstvl value 
  	, b.ksppstdf isdefault
	, a.ksppdesc description
from 
  x$ksppi a, 
  x$ksppcv b 
where 
  a.indx=b.indx and 
  substr(ksppinm,1,1) = '_'
and ksppinm like '_&v_name%' escape'|'
order by 1
/
exit
