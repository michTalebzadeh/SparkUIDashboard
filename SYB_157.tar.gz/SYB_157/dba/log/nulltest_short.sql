use imdb1
go
set switch on 3604
go
dbcc proc_cache(free_unused)
go
--set statement_cache off
go
set showplan on
go
select count(*) from nulltest where ISNULL(OBJECT_ID,-10) = -10
go
exit
