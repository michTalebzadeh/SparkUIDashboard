 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ADDR										   RAW(4)
 KADDR										   RAW(4)
 SID										   NUMBER
 TYPE										   VARCHAR2(2)
 ID1										   NUMBER
 ID2										   NUMBER
 LMODE										   NUMBER
 REQUEST									   NUMBER
 CTIME										   NUMBER
 BLOCK										   NUMBER

