 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 BEGIN_TIME									   DATE
 END_TIME									   DATE
 INTSIZE_CSEC									   NUMBER
 WAIT_CLASS#									   NUMBER
 WAIT_CLASS_ID									   NUMBER
 AVERAGE_WAITER_COUNT								   NUMBER
 DBTIME_IN_WAIT 								   NUMBER
 TIME_WAITED									   NUMBER
 WAIT_COUNT									   NUMBER
 TIME_WAITED_FG 								   NUMBER
 WAIT_COUNT_FG									   NUMBER

