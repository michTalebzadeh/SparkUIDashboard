 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 OLDEST_FLASHBACK_SCN								   NUMBER
 OLDEST_FLASHBACK_TIME								   DATE
 RETENTION_TARGET								   NUMBER
 FLASHBACK_SIZE 								   NUMBER
 ESTIMATED_FLASHBACK_SIZE							   NUMBER

