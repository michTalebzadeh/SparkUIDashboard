use master
go
set nocount on
go
checkpoint
go
declare @msg char(100), @errorno int
dump tran model with truncate_only
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Sun Jan 13 00:42:24 GMT 2002 db_dump_adsm.ksh Dump of model log failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go
declare @msg char(100), @errorno int
dump database model to "/apps/sybase/dump/lon_gedimg_sql_prd/model.dmp.stripe1"
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Sun Jan 13 00:42:24 GMT 2002 db_dump_adsm.ksh Dump of model failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go

