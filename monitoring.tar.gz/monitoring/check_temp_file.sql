sqlplus / << EOF
set line 130
set pagesize 100
set feedback off
column tablespace format a10 
select user, session_num, sqlhash, extents, blocks, tablespace from v\$sort_usage
/
EOF


echo "Enter hash value"
read HASH
sqlplus / << EOF
set line 130
set pagesize 100
set feedback off
column tablespace format a10 
select osuser, process from v\$session where sql_hash_value like '%$HASH%'
/
EOF
