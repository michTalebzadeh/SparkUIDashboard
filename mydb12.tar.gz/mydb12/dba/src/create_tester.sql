create user tester identified by oracle
default tablespace app1_HDD temporary tablespace temp2;
grant dba to tester;
exit

