set pagesize 9999
SELECT
OWNER||'.'||OBJECT_NAME "Object",
OS_USER_NAME "Terminal",
ORACLE_USERNAME "Locker",
PROGRAM "Program",
NVL(lockwait,'ACTIVE') "Wait",
DECODE(LOCKED_MODE,
2, 'ROW SHARE',
3, 'ROW EXCLUSIVE',
4, 'SHARE',
5, 'SHARE ROW EXCLUSIVE',
6, 'EXCLUSIVE', 'UNKNOWN') "Lockmode",
OBJECT_TYPE "Object Type",
SESSION_ID "Session ID",
SERIAL# "Serial",
c.SID
FROM
SYS.V_$LOCKED_OBJECT A,
SYS.ALL_OBJECTS B,
SYS.V_$SESSION c
WHERE
A.OBJECT_ID = B.OBJECT_ID AND
C.SID = A.SESSION_ID
ORDER BY 1 ASC, 5 Desc;
--
prompt
prompt user session locks from dba_locks, V_$SESSION and v$lock_type 
SELECT SUBSTR(TO_CHAR(l.session_id),1,5) "SID",
       c.username "Locker",
       SUBSTR(l.lock_type,1,15) "Lock Type",
       SUBSTR(t.description,1,40) "Lock description",
       SUBSTR(l.mode_held,1,15) "Mode Held",
       SUBSTR(l.blocking_others,1,15) "Blocking?"
FROM 
  dba_locks l,
  SYS.V_$SESSION c,
  v$lock_type t
WHERE
  l.SESSION_ID = c.sid
  AND l.lock_type = t.type
  AND c.username is not null
  AND c.sid not in (select distinct sid from v$mystat)
 order by c.username, l.blocking_others;
exit

