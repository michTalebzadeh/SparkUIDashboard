@$HOME/abc
select 	sid,
	schemaname,
	osuser,
	substr(machine,1,20) AS Machine
FROM
	v$session
WHERE
	serial# > 1
ORDER BY
	schemaname
/
exit
	
	

