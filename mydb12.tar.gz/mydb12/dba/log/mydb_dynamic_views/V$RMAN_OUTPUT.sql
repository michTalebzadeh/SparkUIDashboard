 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 RECID										   NUMBER
 STAMP										   NUMBER
 SESSION_RECID									   NUMBER
 SESSION_STAMP									   NUMBER
 OUTPUT 									   VARCHAR2(130)
 RMAN_STATUS_RECID								   NUMBER
 RMAN_STATUS_STAMP								   NUMBER
 SESSION_KEY									   NUMBER

