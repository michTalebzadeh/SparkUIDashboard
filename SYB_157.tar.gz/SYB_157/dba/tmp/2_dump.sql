use master
go
set nocount on
go
checkpoint
go
declare @msg char(100), @errorno int
dump tran 2 with truncate_only
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Tue Mar 20 11:36:05 GMT 2001 db_dump_adsm.ksh Dump of 2 log failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go
declare @msg char(100), @errorno int
dump database 2 to 2_dump
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Tue Mar 20 11:36:05 GMT 2001 db_dump_adsm.ksh Dump of 2 failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go

