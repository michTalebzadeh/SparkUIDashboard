/********************************************/
/*------------ HIVEUSER -------------*/
/********************************************/
select 'Started creating HIVEUSER tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE TABLESPACE "HIVEUSER" DATAFILE '/ssddata5/oracle/mydb12/oradata/MYDB12/datafile/HIVEUSER.dbf' SIZE 100M AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED LOGGING
 EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO; 
select 'Finished  creating HIVEUSER tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
