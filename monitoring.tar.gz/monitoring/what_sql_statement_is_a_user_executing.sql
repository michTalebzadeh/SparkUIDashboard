@login
SELECT sql_text 
FROM v$sqlarea
WHERE (address, hash_value) IN
(SELECT sql_address, sql_hash_value
 FROM v$SESSION
 WHERE sid = &sid_number)
/
