declare
	v_lname varchar2(30);
v_regdate date;
v_pctincr CONSTANT number (4,2) := 1.50;
v_counter number := 0;
v_new_cost course.cost%type;
v_YorN BOOLEAN := TRUE;
begin
  v_counter := nvl(v_counter,0) + 1;
  v_new_cost := 800 * v_pctincr;
  dbms_output.put_line (v_counter);
  dbms_output.put_line (v_new_cost);
end;
/
