/********************************************/
/*------------ sysaux -------------*/
/********************************************/
select 'Started altering sysaux tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
ALTER TABLESPACE "SYSAUX" ADD DATAFILE '/ssddata2/oracle/mydb/sysaux02.dbf' SIZE 1000M REUSE AUTOEXTEND ON NEXT 10M MAXSIZE 32767M;
select 'Finished  altering sysaux tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
