 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FILENAME									   VARCHAR2(513)
 FILESIZE									   NUMBER
 PNUM										   NUMBER
 SVR_ID 									   NUMBER

