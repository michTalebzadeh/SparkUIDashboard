 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 NAME										   VARCHAR2(513)
 SPACE_LIMIT									   NUMBER
 SPACE_USED									   NUMBER
 SPACE_RECLAIMABLE								   NUMBER
 NUMBER_OF_FILES								   NUMBER

