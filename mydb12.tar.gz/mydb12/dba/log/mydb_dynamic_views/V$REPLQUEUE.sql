 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 TXNS_ENQUEUED									   NUMBER
 CALLS_ENQUEUED 								   NUMBER
 TXNS_PURGED									   NUMBER
 LAST_ENQUEUE_TIME								   DATE
 LAST_PURGE_TIME								   DATE

