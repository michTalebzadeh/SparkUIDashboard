 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 GROUP_NUMBER									   NUMBER
 VOLUME_NAME									   VARCHAR2(30)
 COMPOUND_INDEX 								   NUMBER
 SIZE_MB									   NUMBER
 VOLUME_NUMBER									   NUMBER
 REDUNDANCY									   VARCHAR2(6)
 STRIPE_COLUMNS 								   NUMBER
 STRIPE_WIDTH_K 								   NUMBER
 STATE										   VARCHAR2(8)
 FILE_NUMBER									   NUMBER
 INCARNATION									   NUMBER
 DRL_FILE_NUMBER								   NUMBER
 RESIZE_UNIT_MB 								   NUMBER
 USAGE										   VARCHAR2(30)
 VOLUME_DEVICE									   VARCHAR2(256)
 MOUNTPATH									   VARCHAR2(1024)

