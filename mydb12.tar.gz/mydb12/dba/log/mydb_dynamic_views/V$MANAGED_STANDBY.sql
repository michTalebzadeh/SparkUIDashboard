 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 PROCESS									   VARCHAR2(9)
 PID										   NUMBER
 STATUS 									   VARCHAR2(12)
 CLIENT_PROCESS 								   VARCHAR2(8)
 CLIENT_PID									   VARCHAR2(40)
 CLIENT_DBID									   VARCHAR2(40)
 GROUP# 									   VARCHAR2(40)
 RESETLOG_ID									   NUMBER
 THREAD#									   NUMBER
 SEQUENCE#									   NUMBER
 BLOCK# 									   NUMBER
 BLOCKS 									   NUMBER
 DELAY_MINS									   NUMBER
 KNOWN_AGENTS									   NUMBER
 ACTIVE_AGENTS									   NUMBER

