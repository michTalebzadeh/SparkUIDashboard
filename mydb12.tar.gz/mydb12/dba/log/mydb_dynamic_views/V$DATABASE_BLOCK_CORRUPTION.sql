 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FILE#										   NUMBER
 BLOCK# 									   NUMBER
 BLOCKS 									   NUMBER
 CORRUPTION_CHANGE#								   NUMBER
 CORRUPTION_TYPE								   VARCHAR2(9)

