 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 SERIAL#									   NUMBER
 OPNAME 									   VARCHAR2(64)
 TARGET 									   VARCHAR2(64)
 TARGET_DESC									   VARCHAR2(32)
 SOFAR										   NUMBER
 TOTALWORK									   NUMBER
 UNITS										   VARCHAR2(32)
 START_TIME									   DATE
 LAST_UPDATE_TIME								   DATE
 TIMESTAMP									   DATE
 TIME_REMAINING 								   NUMBER
 ELAPSED_SECONDS								   NUMBER
 CONTEXT									   NUMBER
 MESSAGE									   VARCHAR2(512)
 USERNAME									   VARCHAR2(30)
 SQL_ADDRESS									   RAW(4)
 SQL_HASH_VALUE 								   NUMBER
 SQL_ID 									   VARCHAR2(13)
 SQL_PLAN_HASH_VALUE								   NUMBER
 SQL_EXEC_START 								   DATE
 SQL_EXEC_ID									   NUMBER
 SQL_PLAN_LINE_ID								   NUMBER
 SQL_PLAN_OPERATION								   VARCHAR2(30)
 SQL_PLAN_OPTIONS								   VARCHAR2(30)
 QCSID										   NUMBER

