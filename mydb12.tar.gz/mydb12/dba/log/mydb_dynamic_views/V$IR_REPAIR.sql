 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 REPAIR_ID									   NUMBER
 ADVISE_ID									   NUMBER
 SUMMARY									   VARCHAR2(32)
 RANK										   NUMBER
 TIME_DETECTED									   DATE
 EXECUTED									   DATE
 ESTIMATED_DATA_LOSS								   VARCHAR2(20)
 DETAILED_DESCRIPTION								   VARCHAR2(1024)
 REPAIR_SCRIPT									   VARCHAR2(512)
 ESTIMATED_REPAIR_TIME								   NUMBER
 ACTUAL_REPAIR_TIME								   NUMBER
 STATUS 									   VARCHAR2(7)

