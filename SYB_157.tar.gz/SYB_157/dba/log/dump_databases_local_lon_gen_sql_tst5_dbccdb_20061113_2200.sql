use master
go
dump database dbccdb to 'compress::4::/dbdumps/lon_gen_sql_tst5/dumps/lon_gen_sql_tst5.dbccdb.20061113_2200.01.cdmp' 
go
exit
