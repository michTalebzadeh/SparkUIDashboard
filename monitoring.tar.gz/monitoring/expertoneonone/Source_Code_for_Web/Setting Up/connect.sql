set termout off
connect &1
@login
set termout on