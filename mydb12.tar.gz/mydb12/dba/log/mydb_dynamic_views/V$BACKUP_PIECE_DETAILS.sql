 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SESSION_KEY									   NUMBER
 SESSION_RECID									   NUMBER
 SESSION_STAMP									   NUMBER
 BS_KEY 									   NUMBER
 BP_KEY 									   NUMBER
 RECID										   NUMBER
 STAMP										   NUMBER
 SET_STAMP									   NUMBER
 SET_COUNT									   NUMBER
 PIECE# 									   NUMBER
 COPY#										   NUMBER
 DEVICE_TYPE									   VARCHAR2(17)
 HANDLE 									   VARCHAR2(513)
 COMMENTS									   VARCHAR2(64)
 MEDIA										   VARCHAR2(65)
 MEDIA_POOL									   NUMBER
 CONCUR 									   VARCHAR2(3)
 TAG										   VARCHAR2(32)
 STATUS 									   VARCHAR2(1)
 START_TIME									   DATE
 COMPLETION_TIME								   DATE
 ELAPSED_SECONDS								   NUMBER
 DELETED									   VARCHAR2(3)
 BYTES										   NUMBER
 IS_RECOVERY_DEST_FILE								   VARCHAR2(3)
 RMAN_STATUS_RECID								   NUMBER
 RMAN_STATUS_STAMP								   NUMBER
 COMPRESSED									   VARCHAR2(3)
 BACKED_BY_VSS									   VARCHAR2(3)
 ENCRYPTED									   VARCHAR2(3)
 BACKED_BY_OSB									   VARCHAR2(3)
 PIECES_PER_SET 								   NUMBER
 SIZE_BYTES_DISPLAY								   VARCHAR2(4000)

