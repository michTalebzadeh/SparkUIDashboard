 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ADVISE_ID									   NUMBER
 RANK										   NUMBER
 REQUIRED									   VARCHAR2(3)
 MESSAGE									   VARCHAR2(1024)

