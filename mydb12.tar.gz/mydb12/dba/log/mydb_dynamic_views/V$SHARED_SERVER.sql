 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 NAME										   VARCHAR2(4)
 PADDR										   RAW(4)
 STATUS 									   VARCHAR2(16)
 MESSAGES									   NUMBER
 BYTES										   NUMBER
 BREAKS 									   NUMBER
 CIRCUIT									   RAW(4)
 IDLE										   NUMBER
 BUSY										   NUMBER
 IN_NET 									   NUMBER
 OUT_NET									   NUMBER
 REQUESTS									   NUMBER

