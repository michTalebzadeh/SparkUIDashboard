 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ID										   NUMBER
 NAME										   VARCHAR2(20)
 BLOCK_SIZE									   NUMBER
 RESIZE_STATE									   VARCHAR2(10)
 CURRENT_SIZE									   NUMBER
 BUFFERS									   NUMBER
 TARGET_SIZE									   NUMBER
 TARGET_BUFFERS 								   NUMBER
 PREV_SIZE									   NUMBER
 PREV_BUFFERS									   NUMBER
 LO_BNUM									   NUMBER
 HI_BNUM									   NUMBER
 LO_SETID									   NUMBER
 HI_SETID									   NUMBER
 SET_COUNT									   NUMBER

