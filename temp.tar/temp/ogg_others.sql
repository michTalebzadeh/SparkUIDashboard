exec DBMS_GOLDENGATE_AUTH.GRANT_ADMIN_PRIVILEGE('ogg_user');
ALTER SYSTEM SET enable_goldengate_replication=TRUE;
exit
