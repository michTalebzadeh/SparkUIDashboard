drop table mytable;
set autotrace traceonly explain statistics
set timing on
create table mytable as select n1,padding from T1 where rownum <=5;
SELECT count(1)
	FROM
     (
       SELECT
                T1.n1
              , T1.small_vc
              , mytable.padding
        FROM
               mytable
              , T1
       WHERE
             mytable.n1 = T1.n1
    );
/
exit 
