ALTER SESSION SET TRACEFILE_IDENTIFIER = 't2_index';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true );
INSERT INTO T2
SELECT * FROM T1
where   n1 = 2
and     ind_pad <= rpad('x',39)||'x'
and     n2      < 4;
exit
