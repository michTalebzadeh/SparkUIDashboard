 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 RECID										   NUMBER
 STAMP										   NUMBER
 FILE#										   NUMBER
 OFFLINE_CHANGE#								   NUMBER
 ONLINE_CHANGE# 								   NUMBER
 ONLINE_TIME									   DATE
 RESETLOGS_CHANGE#								   NUMBER
 RESETLOGS_TIME 								   DATE

