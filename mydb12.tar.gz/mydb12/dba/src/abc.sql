select to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
select count(1) from mich.unpart;
select to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
