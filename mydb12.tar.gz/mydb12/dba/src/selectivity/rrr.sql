set timing on
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_with_tdash_tester';
ALTER SESSION SET EVENTS '10046 TRACE NAME CONTEXT FOREVER, LEVEL 8';
DECLARE
        type array is table of tdash%ROWTYPE index by binary_integer;
        l_data array;
        l_rec tdash%rowtype;
        b1 NUMBER;
        b2 NUMBER;
        e1 NUMBER;
        e2 NUMBER;
        e3 NUMBER;

BEGIN
        b1 := DBMS_UTILITY.GET_TIME();
        b2 := DBMS_UTILITY.GET_CPU_TIME();
        SELECT
                a.*
                ,RPAD('*',4000,'*') AS PADDING1
                ,RPAD('*',4000,'*') AS PADDING2
        BULK COLLECT INTO
        l_data
        FROM ALL_OBJECTS a;
        e1 := (DBMS_UTILITY.GET_TIME() - b1)/100;
        e2 := (DBMS_UTILITY.GET_CPU_TIME() - b2)/100;
        e3 := e1 - e2;
        DBMS_OUTPUT.PUT_LINE('bulk load stats ==> elapsed/cpu/wait  ' ||e1||'/'||e2||'/'||e3 ||'  sec.' );

	DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true );
        b1 := DBMS_UTILITY.GET_TIME();
        b2 := DBMS_UTILITY.GET_CPU_TIME();
        FOR rs IN 1 .. l_data.count
        LOOP
                BEGIN
                        SELECT * INTO l_rec FROM tdash WHERE object_id = l_data(rs).object_id;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN NULL;
                END;
        END LOOP;
        e1 := (DBMS_UTILITY.GET_TIME() - b1)/100;
        e2 := (DBMS_UTILITY.GET_CPU_TIME() - b2)/100;
        e3 := e1 - e2;
        DBMS_OUTPUT.PUT_LINE( 'Stats after loop for elapsed/cpu/wait ==> '|| e1 || '/'||e2||'/'||e3 ||'  sec.' );
END;
/
exit
