select distinct tablespace_name from dba_tables where owner = 'HR'
union
select distinct tablespace_name from dba_indexes where owner = 'HR'
/
