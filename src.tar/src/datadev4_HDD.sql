/********************************************/
/*------------ datadev04_HDD -------------*/
/********************************************/
use master
go
select " Started creating datadev04_HDD device at " +convert(char(30),getdate(),9)
go
disk init
name = "datadev04_HDD",
physname = "/apps/sybase/SYB_157/data/datadev04_HDD.dat",
size = '200G',
directio = false
go
select " Finished creating datadev04_HDD device at " +convert(char(30),getdate(),9)
go
exit
