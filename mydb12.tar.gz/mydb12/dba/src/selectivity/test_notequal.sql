alter system flush buffer_cache;
alter system flush shared_pool;
--EXEC DBMS_STATS.SET_SYSTEM_STATS('MBRC',32)
--ALTER SESSION SET OPTIMIZER_INDEX_COST_ADJ=10;
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_notequal_default';
--ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_notequal_fts_hint';
--ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_notequal_INDEX_COST_ADJ';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
ALTER SESSION SET EVENTS '10053 TRACE NAME CONTEXT FOREVER, LEVEL 1';
--select /*+ FULL(notequal) */ c1, c2 from notequal where c2 !=0
select c1, c2 from notequal where c2 !=0
/
exit
