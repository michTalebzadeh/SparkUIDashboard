 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SADDR										   RAW(4)
 SID										   NUMBER
 SERIAL#									   NUMBER
 QCSID										   NUMBER
 QCSERIAL#									   NUMBER
 QCINST_ID									   NUMBER
 SERVER_GROUP									   NUMBER
 SERVER_SET									   NUMBER
 SERVER#									   NUMBER
 DEGREE 									   NUMBER
 REQ_DEGREE									   NUMBER
 STATISTIC#									   NUMBER
 VALUE										   NUMBER

