SELECT 		a.tablespace_name,
		ROUND(SUM(a.bytes)/1024/1024) AS "Total/MB",
		(SELECT ROUND(SUM(b.bytes)/1024/1024)
		 FROM dba_segments B
		 WHERE b.tablespace_name = a.tablespace_name
		 GROUP BY b.tablespace_name) AS "Used/MB",
		(SELECT ROUND(SUM(c.bytes)/1024/1024)
		 FROM dba_free_space c
	   	 WHERE c.tablespace_name = a.tablespace_name	
		 GROUP BY c.tablespace_name) AS "Free/MB"
FROM		dba_data_files a
GROUP BY 	a.tablespace_name
/
