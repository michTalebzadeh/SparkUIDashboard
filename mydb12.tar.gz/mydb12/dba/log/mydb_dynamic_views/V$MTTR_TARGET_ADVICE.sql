 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 MTTR_TARGET_FOR_ESTIMATE							   NUMBER
 ADVICE_STATUS									   VARCHAR2(5)
 DIRTY_LIMIT									   NUMBER
 ESTD_CACHE_WRITES								   NUMBER
 ESTD_CACHE_WRITE_FACTOR							   NUMBER
 ESTD_TOTAL_WRITES								   NUMBER
 ESTD_TOTAL_WRITE_FACTOR							   NUMBER
 ESTD_TOTAL_IOS 								   NUMBER
 ESTD_TOTAL_IO_FACTOR								   NUMBER

