                       
 --------------------- 
 use sybsystemprocs
go 

	                                                                                                                                                                    
 
	------------------------------------------------------------------------------------------------------------------------------------------------------------------ 

	 sp_recompile "dbo.spt_datatype_info"
go
update statistics dbo.spt_datatype_info
go                                                                                 

	 sp_recompile "dbo.spt_datatype_info_ext"
go
update statistics dbo.spt_datatype_info_ext
go                                                                         

	 sp_recompile "dbo.spt_jdatatype_info"
go
update statistics dbo.spt_jdatatype_info
go                                                                               

	 sp_recompile "dbo.spt_server_info"
go
update statistics dbo.spt_server_info
go                                                                                     
