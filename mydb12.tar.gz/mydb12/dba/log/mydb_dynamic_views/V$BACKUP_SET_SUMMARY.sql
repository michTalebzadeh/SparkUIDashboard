 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 NUM_BACKUPSETS 								   NUMBER
 OLDEST_BACKUP_TIME								   DATE
 NEWEST_BACKUP_TIME								   DATE
 OUTPUT_BYTES									   NUMBER
 ORIGINAL_INPUT_BYTES								   NUMBER
 ORIGINAL_INPRATE_BYTES 							   NUMBER
 OUTPUT_RATE_BYTES								   NUMBER
 COMPRESSION_RATIO								   NUMBER
 ORIGINAL_INPUT_BYTES_DISPLAY							   VARCHAR2(4000)
 OUTPUT_BYTES_DISPLAY								   VARCHAR2(4000)
 ORIGINAL_INPRATE_BYTES_DISPLAY 						   VARCHAR2(4000)
 OUTPUT_RATE_BYTES_DISPLAY							   VARCHAR2(4000)

