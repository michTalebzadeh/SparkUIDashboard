begin
for x in (select i.index_name from dba_indexes i where i.owner = 'HR'
	  and i.index_type <> 'IOT - TOP')
loop
  dbms_output.put_line('Starting coalerscing index HR.' || x.index_name||' at '||to_char(sysdate, 'yyyy/mm/dd hh24:mm:ss'));
  execute immediate 'alter index HR.'||x.index_name||' coalesce';
end loop;
end;
/
