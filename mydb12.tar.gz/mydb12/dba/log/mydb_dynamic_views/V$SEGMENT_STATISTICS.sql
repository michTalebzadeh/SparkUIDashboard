 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 OWNER										   VARCHAR2(30)
 OBJECT_NAME									   VARCHAR2(30)
 SUBOBJECT_NAME 								   VARCHAR2(30)
 TABLESPACE_NAME								   VARCHAR2(30)
 TS#										   NUMBER
 OBJ#										   NUMBER
 DATAOBJ#									   NUMBER
 OBJECT_TYPE									   VARCHAR2(18)
 STATISTIC_NAME 								   VARCHAR2(64)
 STATISTIC#									   NUMBER
 VALUE										   NUMBER

