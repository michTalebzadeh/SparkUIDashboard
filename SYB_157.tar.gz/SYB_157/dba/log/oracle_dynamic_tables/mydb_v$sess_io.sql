use imdb1_template
go
set quoted_identifier on
go
if exists(select 1 from sysobjects where type = 'U' and name = 'MYDB_V$SESS_IO')
  drop table MYDB_V$SESS_IO
go
create existing table MYDB_V$SESS_IO
(
 SID                                                                               bigint NULL,
 BLOCK_GETS                                                                        bigint NULL,
 CONSISTENT_GETS                                                                   bigint NULL,
 PHYSICAL_READS                                                                    bigint NULL,
 BLOCK_CHANGES                                                                     bigint NULL,
 CONSISTENT_CHANGES                                                                bigint NULL,
 OPTIMIZED_PHYSICAL_READS                                                          bigint NULL
)
at 'DCORACLE..sys.v_$sess_io'
go
sp_help MYDB_V$SESS_IO
go
