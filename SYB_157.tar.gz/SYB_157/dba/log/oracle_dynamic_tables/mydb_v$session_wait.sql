use imdb1_template
go
set quoted_identifier on
go
if exists(select 1 from sysobjects where type = 'U' and name = 'MYDB_V$SESSION_WAIT')
  drop table MYDB_V$SESSION_WAIT
go
create existing table MYDB_V$SESSION_WAIT
(
 SID                                                                               BIGINT NULL,
 SEQ#                                                                              BIGINT NULL,
 EVENT                                                                             VARCHAR(64) NULL,
 P1TEXT                                                                            VARCHAR(64) NULL,
 P1                                                                                BIGINT NULL,
 P1RAW                                                                             VARBINARY(8) NULL,
 P2TEXT                                                                            VARCHAR(64) NULL,
 P2                                                                                BIGINT NULL,
 P2RAW                                                                             VARBINARY(8) NULL,
 P3TEXT                                                                            VARCHAR(64) NULL,
 P3                                                                                BIGINT NULL,
 P3RAW                                                                             VARBINARY(8) NULL,
 WAIT_CLASS_ID                                                                     BIGINT NULL,
 WAIT_CLASS#                                                                       BIGINT NULL,
 WAIT_CLASS                                                                        VARCHAR(64) NULL,
 WAIT_TIME                                                                         BIGINT NULL,
 SECONDS_IN_WAIT                                                                   BIGINT NULL,
 STATE                                                                             VARCHAR(19) NULL,
 WAIT_TIME_MICRO                                                                   BIGINT NULL,
 TIME_REMAINING_MICRO                                                              BIGINT NULL,
 TIME_SINCE_LAST_WAIT_MICRO                                                        BIGINT NULL
)
at 'DCORACLE..sys.v_$session_wait'
go
sp_help MYDB_V$SESSION_WAIT
go
