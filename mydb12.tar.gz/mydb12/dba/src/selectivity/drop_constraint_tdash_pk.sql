ALTER TABLE tdash drop CONSTRAINT tdash_pk;
DROP INDEX tdash_pk;
exit
