CREATE or REPLACE function Find_Length (i_id int)
RETURN number
AS
long_var varchar2(4000);
counter INT;
BEGIN
    SELECT description into long_var
    FROM agency_charges
    WHERE id = i_id;
    return length(long_var);
exception
when value_error then
return -1; --more than 4000, data loss expected
END;
