ALTER DATABASE   ADD LOGFILE GROUP 1 ('/ssddata6/oracle/mydb/redo1a.log','/ssddata5/oracle/mydb/redo1b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 2 ('/ssddata6/oracle/mydb/redo2a.log','/ssddata5/oracle/mydb/redo2b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 3 ('/ssddata6/oracle/mydb/redo3a.log','/ssddata5/oracle/mydb/redo3b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 4 ('/ssddata6/oracle/mydb/redo4a.log','/ssddata5/oracle/mydb/redo4b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 5 ('/ssddata6/oracle/mydb/redo5a.log','/ssddata5/oracle/mydb/redo5b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 6 ('/ssddata6/oracle/mydb/redo6a.log','/ssddata5/oracle/mydb/redo6b.log')      SIZE 1000M REUSE;
