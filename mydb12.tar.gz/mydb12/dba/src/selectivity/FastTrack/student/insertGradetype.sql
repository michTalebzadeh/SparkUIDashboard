REM ******************************************************************
REM   file: insertGradetype.sql
REM  description: used for loading Grade_type data
REM  created January 30, 2000
REM ******************************************************************

ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MON-RR';
SET DEFINE OFF

SPOOL insertGradetype.log

INSERT INTO grade_type VALUES ('FI','Final','MCAFFREY','31-DEC-98','MCAFFREY','31-DEC-98');                                                                                                             
INSERT INTO grade_type VALUES ('HM','Homework','MCAFFREY','31-DEC-98','MCAFFREY','31-DEC-98');                                                                                                          
INSERT INTO grade_type VALUES ('MT','Midterm','MCAFFREY','31-DEC-98','MCAFFREY','31-DEC-98');                                                                                                           
INSERT INTO grade_type VALUES ('PA','Participation','MCAFFREY','31-DEC-98','MCAFFREY','31-DEC-98');                                                                                                     
INSERT INTO grade_type VALUES ('PJ','Project','MCAFFREY','31-DEC-98','MCAFFREY','31-DEC-98');                                                                                                           
INSERT INTO grade_type VALUES ('QZ','Quiz','MCAFFREY','31-DEC-98','MCAFFREY','31-DEC-98');                                                                                                              

COMMIT;

SPOOL OFF

