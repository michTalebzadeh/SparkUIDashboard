ALTER SESSION SET NLS_DATE_FORMAT = 'dd/mm/yyyy hh24:mi:ss';

drop function mybug;
--
SELECT sysdate FROM DUAL;
--
CREATE OR REPLACE FUNCTION mybug
RETURN NUMBER
AS
BEGIN
	RETURN 33;
END MYBUG;
/
SELECT sysdate, last_ddl_time FROM user_objects WHERE object_name = 'MYBUG';
--
-- Wait for 2 seconds
--
exec dbms_lock.sleep(2)
--
CREATE OR REPLACE FUNCTION mybug
RETURN NUMBER
AS
BEGIN
	RETURN 33;
END MYBUG;
/
SELECT sysdate, last_ddl_time FROM user_objects WHERE object_name = 'MYBUG';
--
ALTER FUNCTION mybug COMPILE;
--
SELECT sysdate, last_ddl_time FROM user_objects WHERE object_name = 'MYBUG';
exit
