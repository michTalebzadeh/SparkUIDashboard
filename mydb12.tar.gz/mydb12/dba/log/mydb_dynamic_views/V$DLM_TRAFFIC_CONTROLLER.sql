 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 LOCAL_NID									   NUMBER
 REMOTE_NID									   NUMBER
 REMOTE_RID									   NUMBER
 REMOTE_INC									   NUMBER
 TCKT_AVAIL									   NUMBER
 TCKT_LIMIT									   NUMBER
 TCKT_RCVD									   NUMBER
 TCKT_WAIT									   VARCHAR2(10)
 SND_SEQ_NO									   NUMBER
 RCV_SEQ_NO									   NUMBER
 SND_Q_LEN									   NUMBER
 SND_Q_MAX									   NUMBER
 SND_Q_TOT									   NUMBER
 SND_Q_TM_BASE									   NUMBER
 SND_Q_TM_WRAP									   NUMBER
 STATUS 									   NUMBER
 SND_PROXY									   NUMBER

