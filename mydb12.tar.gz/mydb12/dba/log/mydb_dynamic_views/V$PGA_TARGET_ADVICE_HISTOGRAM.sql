 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 PGA_TARGET_FOR_ESTIMATE							   NUMBER
 PGA_TARGET_FACTOR								   NUMBER
 ADVICE_STATUS									   VARCHAR2(3)
 LOW_OPTIMAL_SIZE								   NUMBER
 HIGH_OPTIMAL_SIZE								   NUMBER
 ESTD_OPTIMAL_EXECUTIONS							   NUMBER
 ESTD_ONEPASS_EXECUTIONS							   NUMBER
 ESTD_MULTIPASSES_EXECUTIONS							   NUMBER
 ESTD_TOTAL_EXECUTIONS								   NUMBER
 IGNORED_WORKAREAS_COUNT							   NUMBER

