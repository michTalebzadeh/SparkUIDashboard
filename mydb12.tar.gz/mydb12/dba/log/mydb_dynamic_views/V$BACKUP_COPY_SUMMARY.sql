 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 NUM_COPIES									   NUMBER
 NUM_DISTINCT_COPIES								   NUMBER
 MIN_CHECKPOINT_CHANGE# 							   NUMBER
 MAX_CHECKPOINT_CHANGE# 							   NUMBER
 MIN_CHECKPOINT_TIME								   DATE
 MAX_CHECKPOINT_TIME								   DATE
 OUTPUT_BYTES									   NUMBER
 OUTPUT_BYTES_DISPLAY								   VARCHAR2(4000)

