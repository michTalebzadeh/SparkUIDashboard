select name from V$FIXED_TABLE where name like 'V$%ADVICE%'
order by 1;
exit
