 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SADDR										   RAW(4)
 SID										   NUMBER
 USER_NAME									   VARCHAR2(30)
 ADDRESS									   RAW(4)
 HASH_VALUE									   NUMBER
 SQL_ID 									   VARCHAR2(13)
 SQL_TEXT									   VARCHAR2(60)
 LAST_SQL_ACTIVE_TIME								   DATE
 SQL_EXEC_ID									   NUMBER
 CURSOR_TYPE									   VARCHAR2(64)

