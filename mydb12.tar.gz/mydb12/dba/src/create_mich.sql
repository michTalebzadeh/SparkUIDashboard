create user mich identified by oracle
default tablespace app1 temporary tablespace temp2;
grant dba to mich;
exit

