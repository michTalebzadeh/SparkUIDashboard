prompt
Prompt +------------------------------+
Prompt | Parsing ratio from V$SYSSTAT |
Prompt +------------------------------+

select s1.value/s2.value*100 "parsing ratio%" 
from v$sysstat s1, v$sysstat s2
where s1.name = 'parse time cpu'
    and s2.name = 'cpu used by this session';
prompt
Prompt +-----------------------------------------------+
Prompt | Frequently reparsed statements from V$SQLAREA |
Prompt | with executions > 100 and parse_calls > 100   |
Prompt +-----------------------------------------------+

COLUMN ratio FORMAT 999999999.99 HEADING "executions/parse_calls"
select substr(sql_text,1,80) "ShortSQL", parse_calls, executions, executions/parse_calls ratio
	from v$sqlarea
        where   executions > 100
        and parse_calls > 100
	order by parse_calls desc;
exit
