 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 USN										   NUMBER
 SLT										   NUMBER
 SEQ										   NUMBER
 STATE										   VARCHAR2(16)
 UNDOBLOCKSDONE 								   NUMBER
 UNDOBLOCKSTOTAL								   NUMBER
 PID										   NUMBER
 CPUTIME									   NUMBER
 PARENTUSN									   NUMBER
 PARENTSLT									   NUMBER
 PARENTSEQ									   NUMBER
 XID										   RAW(8)
 PXID										   RAW(8)
 RCVSERVERS									   NUMBER

