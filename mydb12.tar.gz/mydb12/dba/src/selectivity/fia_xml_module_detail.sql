drop table  fia_xml_module_detail;
create table fia_xml_module_detail
(
	  module varchar2(30)
        , level_num number
        , sequence number
	, tag number
        , parent_tag number
	, parent_sequence number
	, lvel number
);
CREATE UNIQUE INDEX fia_xml_module_detail_module ON fia_xml_module_detail (module);

WITH h (module, level_num, sequence, tag, parent_tag, parent_sequence, lvl) AS
((SELECT d1.module, d1.level_num, d1.sequence, d1.tag, d1.parent_tag, d1.parent_sequence, 1 lvl
  FROM fia_xml_module_detail d1
  WHERE d1.module='Portfolio'  )
 UNION ALL
  (SELECT d1.module, d1.level_num, d1.sequence, d1.tag, d1.parent_tag, d1.parent_sequence, h.lvl + 1 lvl
   FROM fia_xml_module_detail d1
  JOIN h
    ON h.module = d1.module AND
      d1.tag=h.parent_tag AND
      d1.sequence=h.parent_sequence AND
      h.lvl < 100
    ) )
SELECT * from h;
exit
