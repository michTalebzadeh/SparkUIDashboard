ALTER SESSION SET STATISTICS_LEVEL='ALL';
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_with_iobound';
alter session set events '10949 trace name context forever, level 1';

DECLARE
    b1 PLS_INTEGER;
    b2 PLS_INTEGER;
    e1 PLS_INTEGER;
    e2 PLS_INTEGER;
 CURSOR c IS 
 SELECT	  n1
         ,ind_pad
	 ,n2
 FROM T1
 WHERE   n1 <= 8
 AND     ind_pad <= rpad('x',39)||'x'
 AND     n2      < 15;
 BEGIN
    --b1 := DBMS_UTILITY.GET_TIME();
    --b2 := DBMS_UTILITY.GET_CPU_TIME();
    DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true );
    FOR r IN c
    LOOP
       NULL;
    END LOOP;
    --e1 := DBMS_UTILITY.GET_TIME() - b1;
    --e2 := DBMS_UTILITY.GET_CPU_TIME() - b2;
    DBMS_OUTPUT.PUT_LINE( 'GET_TIME elapsed = ' || e1 || ' hsecs.' );
    DBMS_OUTPUT.PUT_LINE( 'GET_CPU_TIME elapsed = ' || e2 || ' hsecs.' );
 END;
/
exit
