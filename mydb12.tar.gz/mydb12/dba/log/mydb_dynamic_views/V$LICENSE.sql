 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SESSIONS_MAX									   NUMBER
 SESSIONS_WARNING								   NUMBER
 SESSIONS_CURRENT								   NUMBER
 SESSIONS_HIGHWATER								   NUMBER
 USERS_MAX									   NUMBER
 CPU_COUNT_CURRENT								   NUMBER
 CPU_CORE_COUNT_CURRENT 							   NUMBER
 CPU_SOCKET_COUNT_CURRENT							   NUMBER
 CPU_COUNT_HIGHWATER								   NUMBER
 CPU_CORE_COUNT_HIGHWATER							   NUMBER
 CPU_SOCKET_COUNT_HIGHWATER							   NUMBER

