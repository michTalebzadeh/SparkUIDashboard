               
 ------------- 
 use master
go 

	                                                                                                                                                                    
 
	------------------------------------------------------------------------------------------------------------------------------------------------------------------ 

	 sp_recompile "dbo.jdbc_function_escapes"
go
update statistics dbo.jdbc_function_escapes
go                                                                         

	 sp_recompile "dbo.spt_committab"
go
update statistics dbo.spt_committab
go                                                                                         

	 sp_recompile "dbo.spt_datatype_info"
go
update statistics dbo.spt_datatype_info
go                                                                                 

	 sp_recompile "dbo.spt_datatype_info_ext"
go
update statistics dbo.spt_datatype_info_ext
go                                                                         

	 sp_recompile "dbo.spt_jdbc_conversion"
go
update statistics dbo.spt_jdbc_conversion
go                                                                             

	 sp_recompile "dbo.spt_jdbc_table_types"
go
update statistics dbo.spt_jdbc_table_types
go                                                                           

	 sp_recompile "dbo.spt_jtext"
go
update statistics dbo.spt_jtext
go                                                                                                 

	 sp_recompile "dbo.spt_limit_types"
go
update statistics dbo.spt_limit_types
go                                                                                     

	 sp_recompile "dbo.spt_mda"
go
update statistics dbo.spt_mda
go                                                                                                     

	 sp_recompile "dbo.spt_monitor"
go
update statistics dbo.spt_monitor
go                                                                                             

	 sp_recompile "dbo.spt_server_info"
go
update statistics dbo.spt_server_info
go                                                                                     

	 sp_recompile "dbo.spt_values"
go
update statistics dbo.spt_values
go                                                                                               
