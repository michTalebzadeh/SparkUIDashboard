ALTER TABLE tdash ADD CONSTRAINT tdash_pk PRIMARY KEY (object_id);
EXEC DBMS_STATS.GATHER_TABLE_STATS(user,'TDASH',cascade=>true);
select count(1) from tdash;
exit
