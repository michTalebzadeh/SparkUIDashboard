set nocount on
go
use sybsyntax
go
select 'use sybsyntax
go'
go
if exists
(select value from master..sysconfigures where config = 122 and value >= 11920)
begin
select 'sp_recompile "' + user_name(uid) + '.' + name + '"
go' + '
update index statistics ' + user_name(uid) + '.' + name + '
go'
from sysobjects where type = 'U'
and name not in ( select object_cinfo from sysattributes where class=9 and attribute=1)
order by name
end
else
begin
select 'sp_recompile "' + user_name(uid) + '.' + name + '"
go' + '
update statistics ' + user_name(uid) + '.' + name + '
go'
from sysobjects where type = 'U'
and name not in ( select object_cinfo from sysattributes where class=9 and attribute=1)
order by name
end
go
	
