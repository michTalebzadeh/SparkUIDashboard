//slocal -i <(echo 'val ticker = "tsco"' ; cat stock.scala)
import org.apache.spark.sql.functions._
import java.util.Calendar
import org.joda.time._
import java.util.Calendar
import org.joda.time._

val ticker = System.getenv("TICKER")

//val ticker = "SBRY"
val location="hdfs://rhes564:9000/data/stocks/"+ticker.toLowerCase+".csv"
val today = new DateTime()
val df1 = spark.read.option("header", false).csv(location)
case class columns(Stock: String, Ticker: String, TradeDate: String, Open: String, High: String, Low: String, Close: String, Volume: String)
val df2 = df1.map(p => columns(p(0).toString,p(1).toString, p(2).toString,p(3).toString, p(4).toString, p(5).toString, p(6).toString, p(7).toString))

def changeToDate (TradeDate : String) : org.apache.spark.sql.Column =  {
    to_date(unix_timestamp($"TradeDate","dd-MMM-yy").cast("timestamp"))
}

val rs = df2.filter($"Volume".cast("Integer") > 0).
select((round(($"Low".cast("Float")+$"High".cast("Float"))/2,2)).as("AverageDailyPrice")).
orderBy(changeToDate("TradeDate"))
val textFile = "hdfs://rhes564:9000/tmp/"+ticker.toLowerCase+".txt"
// clean up the file in HDFS directory first if exist
//val hadoopConf = new org.apache.hadoop.conf.Configuration()
//val hdfs = org.apache.hadoop.fs.FileSystem.get(new java.net.URI("hdfs://rhes564:9000"), hadoopConf)
//try { hdfs.delete(new org.apache.hadoop.fs.Path(textFile), true) } catch { case _ : Throwable => { } }
//rs.rdd.saveAsTextFile(textFile)
rs.rdd.collect.foreach(println)
sys.exit
