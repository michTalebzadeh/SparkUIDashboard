select name, hint
from user_outline_hints
where hint like 'INDEX%EMP_PK%'
/
