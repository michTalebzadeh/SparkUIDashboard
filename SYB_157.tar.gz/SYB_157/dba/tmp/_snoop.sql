select hostname,suser_name(suid),hostprocess from sysprocesses
go
