 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 STATUS 									   VARCHAR2(7)
 NAME										   VARCHAR2(513)
 IS_RECOVERY_DEST_FILE								   VARCHAR2(3)
 BLOCK_SIZE									   NUMBER
 FILE_SIZE_BLKS 								   NUMBER

