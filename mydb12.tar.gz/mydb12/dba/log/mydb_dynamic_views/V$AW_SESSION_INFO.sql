 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SESSION_ID									   NUMBER
 CLIENT_TYPE									   VARCHAR2(64)
 SESSION_STATE									   VARCHAR2(64)
 SESSION_HANDLE 								   NUMBER
 USERID 									   VARCHAR2(64)
 TOTAL_TRANSACTION								   NUMBER
 TRANSACTION_TIME								   NUMBER
 TOTAL_TRANSACTION_TIME 							   NUMBER
 AVERAGE_TRANSACTION_TIME							   NUMBER
 TRANSACTION_CPU_TIME								   NUMBER
 TOTAL_TRANSACTION_CPU_TIME							   NUMBER
 AVERAGE_TRANSACTION_CPU_TIME							   NUMBER

