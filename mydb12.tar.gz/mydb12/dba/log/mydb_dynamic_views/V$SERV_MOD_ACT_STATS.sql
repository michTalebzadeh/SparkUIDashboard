 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 AGGREGATION_TYPE								   VARCHAR2(21)
 SERVICE_NAME									   VARCHAR2(64)
 MODULE 									   VARCHAR2(49)
 ACTION 									   VARCHAR2(33)
 STAT_ID									   NUMBER
 STAT_NAME									   VARCHAR2(64)
 VALUE										   NUMBER

