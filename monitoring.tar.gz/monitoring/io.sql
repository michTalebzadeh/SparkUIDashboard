SELECT name, phyrds, phywrts      
  FROM v$filestat a, v$datafile b    
  WHERE a.file# = b.file#
/
SELECT name, phyrds, phyblkrd, phywrts 
  FROM v$filestat a, v$datafile b 
  WHERE a.file# = b.file#   
  AND phyrds != phyblkrd
/
exit
