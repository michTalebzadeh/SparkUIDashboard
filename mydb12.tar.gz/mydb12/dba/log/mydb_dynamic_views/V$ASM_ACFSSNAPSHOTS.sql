 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FS_NAME									   VARCHAR2(1024)
 VOL_DEVICE									   VARCHAR2(256)
 SNAP_NAME									   VARCHAR2(1024)
 CREATE_TIME									   DATE

