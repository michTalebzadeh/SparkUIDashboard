BEGIN
  FOR F IN (SELECT file_name FROM dba_data_files WHERE autoextensible = 'YES') LOOP
    BEGIN
       EXECUTE IMMEDIATE 'ALTER DATABASE DATAFILE '''||F.file_name||''' AUTOEXTEND OFF';
       EXCEPTION
       WHEN OTHERS THEN DBMS_OUTPUT.PUT_LINE(F.file_name||':'||SQLERRM);
     END;
  END LOOP;
END;
/
