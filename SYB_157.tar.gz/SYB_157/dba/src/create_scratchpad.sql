use master
go
CREATE DATABASE scratchpad
      ON datadev04_HDD = 2924
       , datadev04_HDD = 2076
     LOG ON logdev06_HDD = 500
       , logdev06_HDD = 500
       , logdev06_HDD = 100
       , logdev06_HDD = 900
       , logdev06_HDD = 100
       , logdev06_HDD = 400
       , logdev06_HDD = 500
FOR LOAD
go
ALTER DATABASE scratchpad
     ON datadev04_HDD = 848
       , datadev04_HDD = 300
       , datadev04_HDD = 90
       , datadev04_HDD = 442
       , datadev04_HDD = 90
       , datadev04_HDD = 300
       , datadev04_HDD = 90
       , datadev04_HDD = 910
       , datadev04_HDD = 1168
       , datadev04_HDD = 30832
     LOG ON logdev06_HDD = 1000
       , logdev06_HDD = 16000
       , logdev06_HDD = 16000
FOR LOAD
go
ALTER DATABASE scratchpad
     ON datadev04_HDD = 1686
FOR LOAD
go


