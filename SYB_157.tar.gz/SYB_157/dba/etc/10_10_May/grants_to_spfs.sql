grant execute on get_COUNTER to spfs
go
grant execute on get_basket_id to spfs
go
grant execute on insert_trade_input to spfs
go
grant all on dbs_COUNTER to spfs
go
grant all on dbStar_Input to spfs
go
