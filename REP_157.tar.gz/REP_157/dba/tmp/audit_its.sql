set nocount on
go
use master
go
select "use master " + "
go"
select "use audit_its " + " 
go"
select "update statistics " + name + " 
go" + " 
sp_recompile " + name + " 
go" 
from audit_its..sysobjects 
where type = "U" 
order by name 
go 

 
