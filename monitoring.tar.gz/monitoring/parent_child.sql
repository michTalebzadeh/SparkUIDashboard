@$HOME/abc
set echo off
set feedback off
drop table uc
/
create table uc as
select table_name, constraint_name,
r_constraint_name from user_constraints
where constraint_type in ('P','R')
/
drop table pk_fk
/
create table pk_fk as
select decode(table_name,prior table_name,'(recursive)',table_name) detail,
prior table_name master
from uc
where prior table_name is not null
connect by prior constraint_name =
r_constraint_name
union
select
table_name detail, '' master
from uc
where not exists
 (select 'x' from user_constraints
 where uc.table_name = table_name
   and constraint_type = 'R')
/
set pagesize 0
select
lpad(' ',(level-1)*3) ||
detail
from pk_fk
where master <> detail or master is null
connect by prior detail = master
start with master is null
/
exit

