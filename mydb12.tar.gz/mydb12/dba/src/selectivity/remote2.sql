DECLARE
        TYPE array IS TABLE OF "testview"@syb_157%ROWTYPE INDEX BY BINARY_INTEGER;
        l_data array;
BEGIN
        SELECT
		*
        BULK COLLECT INTO
        l_data
	FROM "testview"@syb_157
        WHERE ROWNUM <=5;

        FOR rs IN 1 .. l_data.COUNT
        LOOP
              BEGIN
			dbms_output.put_line('build_vc is '||l_data(rs)."build_vc" ||', probe_vc is '||l_data(rs)."probe_vc");
              EXCEPTION
                WHEN NO_DATA_FOUND THEN NULL;
              END;
	END LOOP;
END;
/
exit
