use master
go
CREATE DATABASE ASEIMDB_template
      ON datadev03_HDD = 4000
     LOG ON logdev04_HDD = 1000
FOR LOAD
go
sp_helpdb ASEIMDB_template
go

