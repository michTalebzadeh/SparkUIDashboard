/********************************************/
/*------------ app1 -------------*/
/********************************************/
select 'Started creating app1 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE TABLESPACE "APP1" DATAFILE '/ssddata6/oracle/mydb12/datafile/app01.dbf' SIZE 100M AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED LOGGING
 EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO; 
select 'Finished  creating app1 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
