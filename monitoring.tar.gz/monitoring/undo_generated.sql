select s.username, t.used_urec from v$session s, v$transaction t
    where  s.saddr     = t.ses_addr
          and s.taddr = t.addr
order by t.used_urec, s.username
/
exit
