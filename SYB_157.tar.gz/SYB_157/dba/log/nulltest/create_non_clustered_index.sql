create index ori_index on nulltest(OBJECT_ID)
go
update index statistics nulltest
go
exit
