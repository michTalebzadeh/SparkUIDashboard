 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SESSION_ID									   NUMBER
 CURSOR_NAME									   VARCHAR2(64)
 COMMAND									   VARCHAR2(17)
 STATUS 									   VARCHAR2(9)
 ROWS_PROCESSED 								   NUMBER
 SEQ_NUMBER									   NUMBER
 SQL_ID 									   VARCHAR2(13)
 TARGET 									   VARCHAR2(64)
 TARGET_DESC									   VARCHAR2(64)
 START_TIME									   DATE
 LAST_UPDATE_TIME								   DATE
 ELAPSED_SECONDS								   NUMBER
 SOFAR										   NUMBER
 TOTALWORK									   NUMBER
 UNITS										   VARCHAR2(6)
 MESSAGE									   VARCHAR2(512)
 USERNAME									   VARCHAR2(32)

