 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ADDRESS									   RAW(4)
 HASH_VALUE									   NUMBER
 SQL_ID 									   VARCHAR2(13)
 CHILD_NUMBER									   NUMBER
 BUCKET_ID									   NUMBER
 COUNT										   NUMBER

