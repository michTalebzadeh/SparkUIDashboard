alter system flush buffer_cache;
alter system flush shared_pool;
--ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_t1_tester';
--EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
--set autotrace on
--set timing on
EXEC DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT(); 
update testme
set   padding1 = RPAD('x',4000,'x') 
where object_id > 3766000;
commit;
EXEC DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT(); 
exit
