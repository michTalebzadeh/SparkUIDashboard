COLUMN name FORMAT A30
COLUMN value FORMAT 999,999,999

SELECT name, round(value/1024/1024) AS "Value/MB"
FROM   v$parameter
WHERE  name IN ('pga_aggregate_target', 'sga_target')
UNION
SELECT 'maximum PGA allocated' AS name, round(value/1024/1024) AS "value/MB"
FROM   v$pgastat
WHERE  name = 'maximum PGA allocated';

-- Calculate MEMORY_TARGET
SELECT round(sga.value + GREATEST(pga.value, max_pga.value)/1024/1024) AS "memory_target/MB"
FROM (SELECT TO_NUMBER(value) AS value FROM v$parameter WHERE name = 'sga_target') sga,
     (SELECT TO_NUMBER(value) AS value FROM v$parameter WHERE name = 'pga_aggregate_target') pga,
     (SELECT round(value) AS value FROM v$pgastat WHERE name = 'maximum PGA allocated') max_pga;
exit
