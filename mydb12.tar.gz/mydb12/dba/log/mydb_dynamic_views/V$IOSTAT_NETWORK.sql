 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 CLIENT 									   VARCHAR2(32)
 READS# 									   NUMBER
 WRITES#									   NUMBER
 KBYTES_READ									   NUMBER
 KBYTES_WRITTEN 								   NUMBER
 READ_LATENCY									   NUMBER
 WRITE_LATENCY									   NUMBER

