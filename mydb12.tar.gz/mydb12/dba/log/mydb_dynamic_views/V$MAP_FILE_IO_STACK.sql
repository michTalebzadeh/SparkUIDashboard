 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FILE_MAP_IDX									   NUMBER
 DEPTH										   NUMBER
 ELEM_IDX									   NUMBER
 CU_SIZE									   NUMBER
 STRIDE 									   NUMBER
 NUM_CU 									   NUMBER
 ELEM_OFFSET									   NUMBER
 FILE_OFFSET									   NUMBER
 DATA_TYPE									   VARCHAR2(15)
 PARITY_POS									   NUMBER
 PARITY_PERIOD									   NUMBER
 ID										   NUMBER
 PARENT_ID									   NUMBER

