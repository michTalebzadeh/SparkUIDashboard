var v_table_name varchar2(30)
exec :v_table_name:='TDASH'
SELECT owner, blocks as BLOCKS_USED, empty_blocks
FROM dba_tables
WHERE table_name= :v_table_name;

SELECT owner, chain_cnt AS CHAINED_BLOCKS
FROM dba_tables
WHERE table_name=:v_table_name;

select owner, COUNT(*) AS EXTENT_COUNT from dba_extents
where segment_name = 'TDASH'
group by owner, segment_name;
exit
