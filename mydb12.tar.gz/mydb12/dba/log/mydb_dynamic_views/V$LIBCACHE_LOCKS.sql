 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 TYPE										   VARCHAR2(4)
 ADDR										   RAW(4)
 HOLDING_USER_SESSION								   RAW(4)
 HOLDING_SESSION								   RAW(4)
 OBJECT_HANDLE									   RAW(4)
 LOCK_HELD									   RAW(4)
 REFCOUNT									   NUMBER
 MODE_HELD									   NUMBER
 MODE_REQUESTED 								   NUMBER
 SAVEPOINT_NUMBER								   NUMBER

