REM ******************************************************************
REM   file: insertGradeconversion.sql
REM  description: used for loading Grade_conversion data
REM  created January 30, 2000
REM ******************************************************************

ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MON-RR';
SET DEFINE OFF

SPOOL insertGradeconversion.log

INSERT INTO grade_conversion VALUES ('A ',4,96,93,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                       
INSERT INTO grade_conversion VALUES ('A+',4.3,100,97,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                    
INSERT INTO grade_conversion VALUES ('A-',3.7,92,90,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                     
INSERT INTO grade_conversion VALUES ('AU',0,1,1,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                         
INSERT INTO grade_conversion VALUES ('B ',3,86,83,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                       
INSERT INTO grade_conversion VALUES ('B+',3.3,89,87,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                     
INSERT INTO grade_conversion VALUES ('B-',2.7,82,80,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                     
INSERT INTO grade_conversion VALUES ('C ',2,76,73,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                       
INSERT INTO grade_conversion VALUES ('C+',2.3,79,77,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                     
INSERT INTO grade_conversion VALUES ('C-',1.7,72,70,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                     
INSERT INTO grade_conversion VALUES ('D ',1,66,63,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                       
INSERT INTO grade_conversion VALUES ('D+',1.3,69,67,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                     
INSERT INTO grade_conversion VALUES ('D-',.7,62,60,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                      
INSERT INTO grade_conversion VALUES ('F ',0,59,2,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                        
INSERT INTO grade_conversion VALUES ('IN',0,0,0,'BMOTIVAL','01-JAN-93','BMOTIVAL','01-JAN-93');                                                                                                         

COMMIT;

SPOOL OFF

