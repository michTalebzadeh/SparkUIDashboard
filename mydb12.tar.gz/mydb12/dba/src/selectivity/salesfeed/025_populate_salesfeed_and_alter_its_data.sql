TRUNCATE TABLE salesfeed;
prompt ==> poulating salesfeed from sales
INSERT INTO salesfeed SELECT * FROM sales 
WHERE ROWNUM <=500000;
prompt ==> updating salesfeed data
UPDATE salesfeed
SET 
	  amount_sold = amount_sold * (2.0 + dbms_random.value(-1,2))
 	, time_id = time_id + trunc(dbms_random.value(-14,14));
	  -- amount_sold = amount_sold * (1.0 + dbms_random.value(-1,2))
 	 --, time_id = time_id + trunc(dbms_random.value(-7,7));
commit;
prompt ==> updating stats on salesfeed
exec dbms_stats.gather_table_stats(user, 'SALESFEED',cascade=>true);
exit
