truncate table T2;
exit
