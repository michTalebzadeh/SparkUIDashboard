--
------> Creating Database replication definition reptest_pd <------
--
DROP DATABASE REPLICATION DEFINITION reptest_pd
WITH PRIMARY AT SYB_157.reptest
go
CREATE DATABASE REPLICATION DEFINITION reptest_pd
WITH PRIMARY AT SYB_157.reptest
REPLICATE DDL
NOT REPLICATE TABLES IN (
			   'dba__rep_delay'
			 , 'next_rowid'
)
go
exit
