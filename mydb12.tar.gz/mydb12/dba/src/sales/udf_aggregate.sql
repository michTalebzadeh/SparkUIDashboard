CREATE OR REPLACE TYPE stddev_agg AS OBJECT (
   factor   NUMBER,
   STATIC FUNCTION odciaggregateinitialize (sctx IN OUT stddev_agg)
      RETURN NUMBER,
   MEMBER FUNCTION odciaggregateiterate (SELF IN OUT stddev_agg, VALUE IN NUMBER)
      RETURN NUMBER,
   MEMBER FUNCTION odciaggregateterminate (
      SELF          IN       stddev_agg,
      returnvalue   OUT      NUMBER,
      flags         IN       NUMBER
   )
      RETURN NUMBER,
   MEMBER FUNCTION odciaggregatemerge (SELF IN OUT stddev_agg, ctx2 IN stddev_agg)
      RETURN NUMBER
);
/
show error

CREATE OR REPLACE TYPE BODY stddev_agg
AS
   STATIC FUNCTION odciaggregateinitialize (sctx IN OUT stddev_agg)
      RETURN NUMBER
   IS
   BEGIN
      sctx := stddev_agg (TO_NUMBER (NULL));
      RETURN (odciconst.success);
   END odciaggregateinitialize;
   MEMBER FUNCTION odciaggregateiterate (SELF IN OUT stddev_agg, VALUE IN NUMBER)
      RETURN NUMBER
   IS
      l_value          POSITIVE;
      l_return_value   NUMBER;
   BEGIN
      BEGIN
         l_value := ABS (TRUNC (VALUE));

         IF (SELF.factor IS NULL OR SELF.factor <= 0)
         THEN
            SELF.factor := l_value;
         ELSE
            WHILE NOT (SELF.factor = l_value)
            LOOP
               CASE SIGN (SELF.factor - l_value)
                  WHEN +1
                  THEN
                     SELF.factor := SELF.factor - l_value;
                  ELSE
                     l_value := l_value - SELF.factor;
               END CASE;
            END LOOP;
         END IF;

         l_return_value := odciconst.success;
      EXCEPTION
         WHEN VALUE_ERROR
         THEN
            l_return_value := odciconst.error;
      END;

      RETURN (l_return_value);
   END odciaggregateiterate;
   MEMBER FUNCTION odciaggregateterminate (
      SELF          IN       stddev_agg,
      returnvalue   OUT      NUMBER,
      flags         IN       NUMBER
   )
      RETURN NUMBER
   IS
   BEGIN
      returnvalue := SELF.factor;
      RETURN (odciconst.success);
   END odciaggregateterminate;
   MEMBER FUNCTION odciaggregatemerge (SELF IN OUT stddev_agg, ctx2 IN stddev_agg)
      RETURN NUMBER
   IS
      l_value_1   POSITIVE := SELF.factor;
      l_value_2   POSITIVE := ctx2.factor;
   BEGIN
      IF (l_value_1 IS NULL OR l_value_1 <= 0)
      THEN
         l_value_1 := l_value_2;
      ELSE
         WHILE NOT (l_value_1 = l_value_2)
         LOOP
            CASE SIGN (l_value_1 - l_value_2)
               WHEN +1
               THEN
                  l_value_1 := l_value_1 - l_value_2;
               ELSE
                  l_value_2 := l_value_2 - l_value_1;
            END CASE;
         END LOOP;
      END IF;

      RETURN (odciconst.success);
   END odciaggregatemerge;
END;
/
show error

CREATE OR REPLACE FUNCTION mystddev (input NUMBER)
   RETURN NUMBER PARALLEL_ENABLE
   AGGREGATE USING stddev_agg;
/
show error
drop table t;
 CREATE TABLE t (id VARCHAR2(2), n INT);
 INSERT INTO t VALUES ('A',25);
 INSERT INTO t VALUES ('A',30);
 INSERT INTO t VALUES ('A',55);
 INSERT INTO t VALUES ('B',77);
 INSERT INTO t VALUES ('C',7176);
 INSERT INTO t VALUES ('C',5428);
 INSERT INTO t VALUES ('C',7820);
SELECT id, mystddev(t.n) FROM t GROUP BY id;
exit
