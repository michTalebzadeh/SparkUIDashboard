select s.username,q.sql_text, 'alter system kill session ''' || s.SID || ',' || s.SERIAL# || ''';'
from v$session s, v$sql q
where s.sql_address = q.address
 and s.sql_hash_value = q.hash_value
   and s.serial# > 1
/
