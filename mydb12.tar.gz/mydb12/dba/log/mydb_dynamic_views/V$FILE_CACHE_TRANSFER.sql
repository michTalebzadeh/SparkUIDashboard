 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FILE_NUMBER									   NUMBER
 X_2_NULL									   NUMBER
 X_2_NULL_FORCED_WRITE								   NUMBER
 X_2_NULL_FORCED_STALE								   NUMBER
 X_2_S										   NUMBER
 X_2_S_FORCED_WRITE								   NUMBER
 S_2_NULL									   NUMBER
 S_2_NULL_FORCED_STALE								   NUMBER
 RBR										   NUMBER
 RBR_FORCED_WRITE								   NUMBER
 RBR_FORCED_STALE								   NUMBER
 NULL_2_X									   NUMBER
 S_2_X										   NUMBER
 NULL_2_S									   NUMBER
 CR_TRANSFERS									   NUMBER
 CUR_TRANSFERS									   NUMBER

