 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FROM_ADDRESS									   RAW(4)
 FROM_HASH									   NUMBER
 TO_OWNER									   VARCHAR2(64)
 TO_NAME									   VARCHAR2(1000)
 TO_ADDRESS									   RAW(4)
 TO_HASH									   NUMBER
 TO_TYPE									   NUMBER

