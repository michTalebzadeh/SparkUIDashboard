 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 RECID										   NUMBER
 STAMP										   NUMBER
 SET_STAMP									   NUMBER
 SET_COUNT									   NUMBER
 PIECE# 									   NUMBER
 FILE#										   NUMBER
 BLOCK# 									   NUMBER
 BLOCKS 									   NUMBER
 CORRUPTION_CHANGE#								   NUMBER
 MARKED_CORRUPT 								   VARCHAR2(3)
 CORRUPTION_TYPE								   VARCHAR2(9)

