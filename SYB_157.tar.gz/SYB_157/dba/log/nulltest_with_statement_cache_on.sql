use imdb1
go
set switch on 3604
go
dbcc proc_cache(free_unused)
go
set showplan on
go
set option show on -- get index selectivity
go
set statistics plancost, resource, time, io on
go
select count(*) from nulltest where ISNULL(OBJECT_ID,-10) = -10
go
exit
