--
------> Creating Database replication definition test_pd <------
--
DROP DATABASE REPLICATION DEFINITION test_pd
WITH PRIMARY AT lon_gen_sql_tst5.test
go
CREATE DATABASE REPLICATION DEFINITION test_pd
WITH PRIMARY AT lon_gen_sql_tst5.test
REPLICATE DDL
NOT REPLICATE TABLES IN (
			   'dba__rep_delay'
			 , 'next_rowid'
)
go
exit
