set nocount on
go
use master
go
--
-- MDA table monCachePool
-- Provides statistics for all pools allocated for all caches
--
INSERT INTO h_monCachePool
SELECT 	  *
	, @timestamp
FROM master..monCachePool
--
-- MDA table monDataCache
-- Provides statistics relating to data cache usage
--
INSERT INTO h_monDataCache
SELECT 	  *
	, @timestamp
FROM master..monDataCache
--
-- MDA table monDeviceIO
-- Provides statistical information about devices
--
INSERT INTO h_monDeviceIO
SELECT 	  *
	, @timestamp
FROM master..monDeviceIO
--
-- MDA table monErrorLog
-- Provides the most recent error messages raised by ASE. The maximum number of messages returned can be tuned by use of the 'errorlog pipe max messages' configuration option
--
INSERT INTO h_monErrorLog
SELECT 	  *
	, @timestamp
FROM master..monErrorLog
--
-- MDA table monIOQueue
-- Provides device IO statistics broken down into data and log IO, for normal and temporary databases on each device.
--
INSERT INTO h_monIOQueue
SELECT 	  *
	, @timestamp
FROM master..monIOQueue
--
-- MDA table monNetworkIO
-- Provides server-wide statistics about network I/O
--
INSERT INTO h_monNetworkIO
SELECT 	  *
	, @timestamp
FROM master..monNetworkIO
--
-- MDA table monProcedureCache
-- Provides server wide information related to cached procedures
--
INSERT INTO h_monProcedureCache
SELECT 	  *
	, @timestamp
FROM master..monProcedureCache
--
-- MDA table monState
-- Provides information regarding the overall state of the ASE
--
INSERT INTO h_monState
SELECT 	  *
	, @timestamp
FROM master..monState
--
-- MDA table monSysWaits
-- Provides a server-wide view of events that processes are waiting for
--
INSERT INTO h_monSysWaits
SELECT 	  *
	, @timestamp
FROM master..monSysWaits
