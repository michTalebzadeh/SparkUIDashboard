DROP TABLE T5;
CREATE TABLE T5
                (
                        n1 NUMBER(5)    NOT NULL,
                        ind_pad VARCHAR2(40) NOT NULL,
                        n2 NUMBER(5)    NOT NULL,
                        small_vc VARCHAR2(10) NOT NULL,
                        padding  VARCHAR2(200) NOT NULL
                 );

create index t5_i1 on t5(n1, ind_pad, n2);
desc t5;
exit


