set feedback off
set linesize 1000
set pagesize 0
set verify off
set timing off
select '"'||OWNER||'","'||OBJECT_NAME||'","'||SUBOBJECT_NAME||'",'||OBJECT_ID||','||DATA_OBJECT_ID||',"'||OBJECT_TYPE||'",'||to_char(CREATED,'YYYY-MM-DD')
||','||to_char(LAST_DDL_TIME,'YYYY-MM-DD')||',"'||TIMESTAMP||'","'||STATUS||'","'||TEMPORARY||'","'||GENERATED||'","'||SECONDARY||'",'||NAMESPACE||',"'||EDITION_NAME||'"'
from mich.nulltest;
exit
