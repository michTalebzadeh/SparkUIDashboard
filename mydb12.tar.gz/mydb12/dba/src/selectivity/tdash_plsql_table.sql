drop type t_TDASHtype;
CREATE OR REPLACE TYPE TDASHtype AS OBJECT (
        object_name	varchar2(30),
	object_type	varchar2(19)
);
/
CREATE OR REPLACE TYPE t_TDASHtype AS TABLE OF TDASHtype;
/
CREATE OR REPLACE FUNCTION populate_tdash(p_owner in tdash.owner%TYPE := NULL)
RETURN t_TDASHtype
AS
  v_tdashtype t_TDASHtype := t_TDASHtype();
  v_cnt number := 0;
  v_rc sys_refcursor;
  v_object_name     tdash.object_name%TYPE;
  v_object_type     tdash.object_type%TYPE;
BEGIN
  v_rc := get_tdash_data_fn(p_owner);
  LOOP
    FETCH v_rc INTO v_object_name, v_object_type;
    EXIT WHEN v_rc%NOTFOUND;
    v_tdashtype.extend;
    v_cnt := v_cnt + 1;
    v_tdashtype(v_cnt) := TDASHtype(v_object_name, v_object_type);
  END LOOP;
  CLOSE v_rc;
  RETURN v_tdashtype;
END;
/
show error
exit
