 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 BEGIN_TIME									   DATE
 END_TIME									   DATE
 INTSIZE_CSEC									   NUMBER
 SEQUENCE#									   NUMBER
 CONSUMER_GROUP_ID								   NUMBER
 CONSUMER_GROUP_NAME								   VARCHAR2(30)
 CPU_CONSUMED_TIME								   NUMBER
 CPU_WAIT_TIME									   NUMBER
 CPU_DECISIONS									   NUMBER
 CPU_DECISIONS_EXCLUSIVE							   NUMBER
 CPU_DECISIONS_WON								   NUMBER
 IO_REQUESTS									   NUMBER
 IO_MEGABYTES									   NUMBER

