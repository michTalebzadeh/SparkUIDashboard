select r.*
from
 (
select a."OWNER", b."OBJECT_NAME"
from "t"@syb_157 a, "t"@DBSSD b
where a."OBJECT_ID" = b."OBJECT_ID"
)r
where rownum <= 10;
exit
