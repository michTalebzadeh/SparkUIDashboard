CREATE OR REPLACE PROCEDURE populate_bigdata_sp
(
	p_rows	IN		NUMBER
)
AS
  v_id				bigdata.id%TYPE;
  v_rowcount			NUMBER := 0;
  e_rows			EXCEPTION;	
  e_v_id_bigdata   	        EXCEPTION;
  e_insert_bigdata		EXCEPTION;
BEGIN
  BEGIN			-- Input parameter validation
    -- Check for inputs
    IF p_rows <= 0
    THEN
      RAISE e_rows;
    END IF;
  EXCEPTION
    WHEN e_rows THEN
      DBMS_OUTPUT.PUT_LINE('Cannot have null value for number of records to generate!');
  END; 
  BEGIN
    dbms_random.seed(0);
    SELECT NVL(MAX(id),0)+1 INTO v_id from bigdata;
    for v_records IN 1..p_rows
    LOOP
      IF v_id < 0
      THEN
        RAISE e_v_id_bigdata;
      END IF;
      INSERT INTO bigdata
      (
        id,
        clustered,
	scattered,
	randomised,
	random_string,
	small_vc,
	padding,
	padding2
      )
      VALUES
      (
	v_id,
	trunc(v_id -1)/p_rows,
	mod(v_id - 1,p_rows),
        trunc(dbms_random.value(0,p_rows)),
	dbms_random.string('A',15),
        lpad(v_id,10),
        rpad('x',4000,'x') ,
        rpad('x',4000,'x') 
       );
      IF SQL%ROWCOUNT = 0 OR SQLCODE <> 0
      THEN
        RAISE e_insert_bigdata;
      END IF;
      v_id := v_id + 1;
      v_rowcount := v_rowcount + 1;
      IF MOD(v_rowcount, 10000) = 0 THEN
        --dbms_output.put_line('v_rowcount = '|| v_rowcount ||' ,committing!');
        COMMIT;
      END IF;
    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN e_v_id_bigdata THEN
      DBMS_OUTPUT.PUT_LINE('Could not get next_rowid value for table bigdata');
    WHEN e_insert_bigdata THEN
      DBMS_OUTPUT.PUT_LINE('Could not insert into bigdata');
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(to_char(SQLCODE) || ' - ' || substr(SQLERRM,1,200));
  END;
END populate_bigdata_sp;
/
show errors
exit
