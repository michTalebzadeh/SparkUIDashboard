/********************************************/
/*------------ system -------------*/
/********************************************/
select 'Started altering system tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
ALTER TABLESPACE "SYSTEM" ADD DATAFILE '/ssddata2/oracle/mydb/system02.dbf' SIZE 1000M REUSE AUTOEXTEND ON NEXT 10M MAXSIZE 32767M;
select 'Finished  altering system tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
