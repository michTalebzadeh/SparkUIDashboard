 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 GROUP# 									   NUMBER
 THREAD#									   NUMBER
 SEQUENCE#									   NUMBER
 BYTES										   NUMBER
 BLOCKSIZE									   NUMBER
 MEMBERS									   NUMBER
 ARCHIVED									   VARCHAR2(3)
 STATUS 									   VARCHAR2(16)
 FIRST_CHANGE#									   NUMBER
 FIRST_TIME									   DATE
 NEXT_CHANGE#									   NUMBER
 NEXT_TIME									   DATE

