alter system flush buffer_cache;
--ALTER SESSION SET EVENTS '10949 trace name context forever, level 1'  -- No Direct path read ;
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'count';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
--set autotrace on stat
 select count(*) from tdash2;
--set autotrace off;
exit
