ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_with_tdash_tester';
DECLARE
	type array is table of tdash.object_id%TYPE index by binary_integer;
	l_data array;
	l_rec tdash%rowtype;
BEGIN
	SELECT
         	object_id
	BULK COLLECT INTO
	l_data
  	FROM tdash;

	DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true );
	FOR rs IN 1 .. l_data.count
	LOOP
		BEGIN
			SELECT * INTO l_rec FROM tdash WHERE object_id = l_data(rs);
		EXCEPTION
		  WHEN NO_DATA_FOUND THEN NULL;
		END;
	END LOOP;
END;
/
exit
