DROP TABLE testwrites purge;
exit
