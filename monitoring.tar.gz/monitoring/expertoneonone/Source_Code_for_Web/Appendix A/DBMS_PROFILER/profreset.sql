delete from plsql_profiler_data;
delete from plsql_profiler_units;
delete from plsql_profiler_runs;