select tch, count(tch)
from x$bh
where obj = (select object_id from all_objects where owner = 'SSDTESTER' and object_name = 'TDASH')
group by tch
order by count(tch)
/
exit
/
