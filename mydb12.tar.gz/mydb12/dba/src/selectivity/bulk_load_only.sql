set timing on
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_bulkload';
ALTER SESSION SET EVENTS '10046 TRACE NAME CONTEXT FOREVER, LEVEL 8';
DECLARE
        type array is table of tdash%ROWTYPE index by binary_integer;
        l_data array;

BEGIN
        SELECT
                a.*
                ,RPAD('*',4000,'*') AS PADDING1
                ,RPAD('*',4000,'*') AS PADDING2
        BULK COLLECT INTO
        l_data
        FROM ALL_OBJECTS a;
END;
/
exit
