 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 INST_ID									   NUMBER
 EQ_TYPE									   VARCHAR2(2)
 TOTAL_REQ#									   NUMBER
 TOTAL_WAIT#									   NUMBER
 SUCC_REQ#									   NUMBER
 FAILED_REQ#									   NUMBER
 CUM_WAIT_TIME									   NUMBER

