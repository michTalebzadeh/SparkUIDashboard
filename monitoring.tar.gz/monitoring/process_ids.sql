column spid heading "O/S Process ID" format a30
column process heading "Client Process ID" format a30
select a.spid, b.process
from v$process a, v$session b
where a.addr = b.paddr
and b.audsid = userenv('sessionid');
