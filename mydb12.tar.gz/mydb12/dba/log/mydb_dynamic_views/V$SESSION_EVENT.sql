 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 EVENT										   VARCHAR2(64)
 TOTAL_WAITS									   NUMBER
 TOTAL_TIMEOUTS 								   NUMBER
 TIME_WAITED									   NUMBER
 AVERAGE_WAIT									   NUMBER
 MAX_WAIT									   NUMBER
 TIME_WAITED_MICRO								   NUMBER
 EVENT_ID									   NUMBER
 WAIT_CLASS_ID									   NUMBER
 WAIT_CLASS#									   NUMBER
 WAIT_CLASS									   VARCHAR2(64)

