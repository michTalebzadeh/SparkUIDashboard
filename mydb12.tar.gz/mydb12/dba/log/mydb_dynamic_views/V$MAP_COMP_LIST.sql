 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ELEM_IDX									   NUMBER
 NUM_COMP									   NUMBER
 COMP1_NAME									   VARCHAR2(256)
 COMP1_VAL									   VARCHAR2(256)
 COMP2_NAME									   VARCHAR2(256)
 COMP2_VAL									   VARCHAR2(256)
 COMP3_NAME									   VARCHAR2(256)
 COMP3_VAL									   VARCHAR2(256)
 COMP4_NAME									   VARCHAR2(256)
 COMP4_VAL									   VARCHAR2(256)
 COMP5_NAME									   VARCHAR2(256)
 COMP5_VAL									   VARCHAR2(256)

