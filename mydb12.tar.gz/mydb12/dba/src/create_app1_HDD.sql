/********************************************/
/*------------ APP1_HDD -------------*/
/********************************************/
select 'Started creating APP1 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE TABLESPACE "APP1_HDD" DATAFILE '/data6/oracle/mydb12/oradata/MYDB12/datafile/APP01_HDD.dbf' SIZE 30G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED LOGGING
 EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO; 
select 'Finished  creating APP1_HDD tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
