 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 BLOCK_GETS									   NUMBER
 CONSISTENT_GETS								   NUMBER
 PHYSICAL_READS 								   NUMBER
 BLOCK_CHANGES									   NUMBER
 CONSISTENT_CHANGES								   NUMBER
 OPTIMIZED_PHYSICAL_READS							   NUMBER

