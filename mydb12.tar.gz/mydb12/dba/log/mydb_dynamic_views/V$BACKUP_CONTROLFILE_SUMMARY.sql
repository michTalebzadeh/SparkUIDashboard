 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 NUM_FILES_BACKED								   NUMBER
 NUM_DISTINCT_FILES_BACKED							   NUMBER
 MIN_CHECKPOINT_CHANGE# 							   NUMBER
 MAX_CHECKPOINT_CHANGE# 							   NUMBER
 MIN_CHECKPOINT_TIME								   DATE
 MAX_CHECKPOINT_TIME								   DATE
 INPUT_BYTES									   NUMBER
 OUTPUT_BYTES									   NUMBER
 COMPRESSION_RATIO								   NUMBER
 INPUT_BYTES_DISPLAY								   VARCHAR2(4000)
 OUTPUT_BYTES_DISPLAY								   VARCHAR2(4000)

