/********************************************/
/*------------ APP1_SSDUSER -------------*/
/********************************************/
select 'Started altering APP1 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
ALTER TABLESPACE "APP1_SSDUSER" ADD DATAFILE '/data6/oracle/mydb12/oradata/MYDB12/datafile//APP02_SSDUSER.dbf' SIZE 30G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE "APP1_SSDUSER" ADD DATAFILE '/data6/oracle/mydb12/oradata/MYDB12/datafile//APP03_SSDUSER.dbf' SIZE 30G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE "APP1_SSDUSER" ADD DATAFILE '/data6/oracle/mydb12/oradata/MYDB12/datafile//APP04_SSDUSER.dbf' SIZE 5G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
select 'Finished  altering APP1_SSDUSER tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
