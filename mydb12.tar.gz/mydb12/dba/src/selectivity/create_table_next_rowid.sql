drop table next_rowid;
 CREATE TABLE  next_rowid
 (
  nxr_name        VARCHAR2(30)              NOT NULL,
  nxr_next_rowid  NUMBER                    NOT NULL
 )
/
create unique index nxr_name_ind on next_rowid (nxr_name);
exit
