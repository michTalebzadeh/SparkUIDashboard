 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 NAME										   VARCHAR2(30)
 OBJECT_ID									   NUMBER
 TYPE										   VARCHAR2(5)
 TABLE_NUM									   NUMBER

