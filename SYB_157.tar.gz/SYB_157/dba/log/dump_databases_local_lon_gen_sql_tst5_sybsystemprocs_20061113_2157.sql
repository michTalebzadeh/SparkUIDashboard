use master
go
dump database sybsystemprocs to 'compress::4::/dbdumps/lon_gen_sql_tst5/dumps/lon_gen_sql_tst5.sybsystemprocs.20061113_2157.01.cdmp' 
go
exit
