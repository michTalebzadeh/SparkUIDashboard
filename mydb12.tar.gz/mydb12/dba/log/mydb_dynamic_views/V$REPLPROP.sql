 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 SERIAL#									   NUMBER
 NAME										   VARCHAR2(71)
 DBLINK 									   VARCHAR2(128)
 STATE										   VARCHAR2(12)
 XID										   VARCHAR2(22)
 SEQUENCE									   NUMBER

