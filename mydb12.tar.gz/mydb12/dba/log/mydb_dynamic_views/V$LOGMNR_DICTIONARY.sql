 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 DB_NAME									   VARCHAR2(9)
 DB_ID										   NUMBER
 DB_CREATED									   DATE
 TIMESTAMP									   DATE
 RESET_SCN									   NUMBER
 RESET_SCN_TIME 								   DATE
 DB_VERSION_TIME								   DATE
 DB_CHARACTER_SET								   VARCHAR2(30)
 DB_VERSION									   VARCHAR2(64)
 DB_STATUS									   VARCHAR2(64)
 DICTIONARY_SCN 								   NUMBER
 ENABLED_THREAD_MAP								   RAW(16)
 DB_TXN_SCN									   NUMBER
 FILENAME									   VARCHAR2(512)
 INFO										   VARCHAR2(32)
 STATUS 									   NUMBER

