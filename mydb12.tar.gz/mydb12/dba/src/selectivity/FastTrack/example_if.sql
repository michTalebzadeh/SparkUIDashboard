DECLARE v_total number;
BEGIN
  select count(1)
  into v_total
  from enrollment e
join section s using (section_id)
where s.course_no = 25
and s.section_no = 1;
if v_total >= 15
then
  dbms_output.put_line('CPC 1');
elsif v_total between 15 and 20
then
  dbms_output.put_line('CPC 4');
else
  dbms_output.put_line('CPC 2');
end if;
EXCEPTION
  WHEN OTHERS
  THEN
        DBMS_OUTPUT.PUT('Exception encountered! (');
        DBMS_OUTPUT.PUT_LINE(SQLCODE || '): ' || SQLERRM);
END;
/
exit
