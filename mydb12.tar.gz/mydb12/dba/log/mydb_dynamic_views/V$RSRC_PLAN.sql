 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ID										   NUMBER
 NAME										   VARCHAR2(32)
 IS_TOP_PLAN									   VARCHAR2(5)
 CPU_MANAGED									   VARCHAR2(3)

