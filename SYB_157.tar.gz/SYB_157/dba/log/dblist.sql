set nocount on
select name from master..sysdatabases order by 1
go
