declare myexception exception;
begin
  if to_char(sysdate, 'DY') = 'THU' then
    dbms_output.put_line(chr(10));
    raise myexception;
  else
    dbms_output.put_line ('hello there');
  end if;
exception
  when myexception then
    dbms_output.put_line('No transaction today');
end;
/
end
