 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 THREAD#									   NUMBER
 SEQUENCE#									   NUMBER
 TIME										   DATE
 ARCHIVE_NAME									   VARCHAR2(513)

