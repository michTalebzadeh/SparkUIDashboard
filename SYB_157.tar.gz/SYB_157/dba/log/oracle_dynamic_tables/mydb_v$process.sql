use imdb1_template
go
set quoted_identifier on
go
if exists(select 1 from sysobjects where type = 'U' and name = 'MYDB_V_$PROCESS')
  drop table MYDB_V_$PROCESS
go
create existing table MYDB_V_$PROCESS
(
ADDR										 varbinary(4)  NULL,
PID										BIGINT  NULL,
SPID										varchar(24)  NULL,
PNAME										varchar(5)  NULL,
USERNAME									varchar(15)  NULL,
SERIAL#										BIGINT  NULL,
 TERMINAL                                                                          varchar(30)  NULL,
 PROGRAM                                                                           varchar(48)  NULL,
 TRACEID                                                                           varchar(255)  NULL,
"TRACEFILE"                                                                         varchar(513)  NULL,
 BACKGROUND                                                                        varchar(1)  NULL,
 LATCHWAIT                                                                         varchar(8)  NULL,
 LATCHSPIN                                                                         varchar(8)  NULL,
 PGA_USED_MEM                                                                      BIGINT  NULL,
 PGA_ALLOC_MEM                                                                     BIGINT  NULL,
 PGA_FREEABLE_MEM                                                                  BIGINT  NULL,
 PGA_MAX_MEM                                                                       BIGINT NULL
)
at 'DCORACLE..sys.v_$process'
go
sp_help MYDB_V_$PROCESS
go
