 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SESSION_ID									   NUMBER
 PERFORMANCE_CLASS								   VARCHAR2(32)
 WORK_REQUEST_CLASS								   VARCHAR2(32)
 HOP_COUNT									   NUMBER
 PC_UNKNOWN									   NUMBER
 SERVICE_NAME									   VARCHAR2(64)
 MODULE 									   VARCHAR2(48)
 ACTION 									   VARCHAR2(32)
 USERNAME									   VARCHAR2(30)
 PROGRAM									   VARCHAR2(48)

