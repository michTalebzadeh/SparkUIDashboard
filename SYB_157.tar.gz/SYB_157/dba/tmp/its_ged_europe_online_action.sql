online database its_ged_europe
go
use its_ged_europe
go
dbcc settrunc(ltm,ignore)
go
