 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 CURNO										   NUMBER
 FLAG										   NUMBER
 STATUS 									   VARCHAR2(9)
 PARENT_HANDLE									   RAW(4)
 PARENT_LOCK									   RAW(4)
 CHILD_LOCK									   RAW(4)
 CHILD_PIN									   RAW(4)
 PERS_HEAP_MEM									   NUMBER
 WORK_HEAP_MEM									   NUMBER
 BIND_VARS									   NUMBER
 DEFINE_VARS									   NUMBER
 BIND_MEM_LOC									   VARCHAR2(64)
 INST_FLAG									   VARCHAR2(64)
 INST_FLAG2									   VARCHAR2(64)
 CHILD_HANDLE									   RAW(4)

