 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 NUM										   NUMBER
 NAME										   VARCHAR2(80)
 TYPE										   NUMBER
 VALUE										   VARCHAR2(4000)
 DISPLAY_VALUE									   VARCHAR2(4000)
 ISDEFAULT									   VARCHAR2(9)
 ISSES_MODIFIABLE								   VARCHAR2(5)
 ISSYS_MODIFIABLE								   VARCHAR2(9)
 ISINSTANCE_MODIFIABLE								   VARCHAR2(5)
 ISMODIFIED									   VARCHAR2(8)
 ISADJUSTED									   VARCHAR2(5)
 ISDEPRECATED									   VARCHAR2(5)
 ISBASIC									   VARCHAR2(5)
 DESCRIPTION									   VARCHAR2(255)
 UPDATE_COMMENT 								   VARCHAR2(255)
 HASH										   NUMBER

