--
------> table its_ged_prod.dbGED_usereq_acctconf_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_acctconf_tb_ld
go
CREATE REPLICATION DEFINITION dbGED_usereq_acctconf_tb_ld
WITH PRIMARY AT lon_gen_sql_tst1.its_ged_prod
WITH ALL TABLES NAMED "dbGED_usereq_acctconf_tb"
(
  "configtype" varchar (100) 
, "configlable" varchar (100) 
, "trader_default" varchar (100) 
, "other_default" varchar (200) 
, "default_id" varchar (3) 
)
PRIMARY KEY (
  "configtype"                     
)
--REPLICATE MINIMAL COLUMNS
go
--
------> table its_ged_prod.dbGED_usereq_accttype_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_accttype_tb_ld
go
CREATE REPLICATION DEFINITION dbGED_usereq_accttype_tb_ld
WITH PRIMARY AT lon_gen_sql_tst1.its_ged_prod
WITH ALL TABLES NAMED "dbGED_usereq_accttype_tb"
(
  "selectOrder" varchar (12) 
, "accttype" varchar (50) 
)
PRIMARY KEY (
  "accttype"                       
)
--REPLICATE MINIMAL COLUMNS
go
--
------> table its_ged_prod.dbGED_usereq_bizarea_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_bizarea_tb_ld
go
CREATE REPLICATION DEFINITION dbGED_usereq_bizarea_tb_ld
WITH PRIMARY AT lon_gen_sql_tst1.its_ged_prod
WITH ALL TABLES NAMED "dbGED_usereq_bizarea_tb"
(
  "bizarea" varchar (50) 
)
PRIMARY KEY (
  "bizarea"                        
)
--REPLICATE MINIMAL COLUMNS
go
--
------> table its_ged_prod.dbGED_usereq_confdef_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_confdef_tb_ld
go
CREATE REPLICATION DEFINITION dbGED_usereq_confdef_tb_ld
WITH PRIMARY AT lon_gen_sql_tst1.its_ged_prod
WITH ALL TABLES NAMED "dbGED_usereq_confdef_tb"
(
  "unique_id" numeric  
, "id" varchar (3) 
, "value" varchar (200) 
)
PRIMARY KEY (
  "unique_id"                      
)
--REPLICATE MINIMAL COLUMNS
go
--
------> table its_ged_prod.dbGED_usereq_groups_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_groups_tb_ld
go
CREATE REPLICATION DEFINITION dbGED_usereq_groups_tb_ld
WITH PRIMARY AT lon_gen_sql_tst1.its_ged_prod
WITH ALL TABLES NAMED "dbGED_usereq_groups_tb"
(
  "ur_groupname" varchar (100) 
, "ur_imaglogin" varchar (100) 
, "ur_realname" varchar (100) 
, "ur_groupemail" varchar (100) 
, "ur_groupdisplay" varchar (100) 
, "ur_close_account" varchar (12) 
, "ur_location" varchar (12) 
)
PRIMARY KEY (
  "ur_imaglogin"                   
)
--REPLICATE MINIMAL COLUMNS
go
--
------> table its_ged_prod.dbGED_usereq_location_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_location_tb_ld
go
CREATE REPLICATION DEFINITION dbGED_usereq_location_tb_ld
WITH PRIMARY AT lon_gen_sql_tst1.its_ged_prod
WITH ALL TABLES NAMED "dbGED_usereq_location_tb"
(
  "ur_location" varchar (50) 
)
PRIMARY KEY (
  "ur_location"                    
)
--REPLICATE MINIMAL COLUMNS
go
--
------> table its_ged_prod.dbGED_usereq_super_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_super_tb_ld
go
CREATE REPLICATION DEFINITION dbGED_usereq_super_tb_ld
WITH PRIMARY AT lon_gen_sql_tst1.its_ged_prod
WITH ALL TABLES NAMED "dbGED_usereq_super_tb"
(
  "ur_location" varchar (50) 
, "ur_firstname" varchar (50) 
, "ur_lastname" varchar (50) 
, "ur_display" varchar (50) 
