use scratchpad
go
UPDATE t set OBJECT_NAME=OBJECT_NAME
go
exit

