--ALTER SESSION SET STATISTICS_LEVEL='ALL';
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_table_function_pipe';
alter session set events '10949 trace name context forever, level 1';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true );
SELECT *
FROM
(
       SELECT
               T1.n1,
	       count(T1.n2),
	       sum(T1.n2),
	       avg(T1.n2),
	       stddev(T1.n2)
        FROM
                -- table(regular_array) t,
                table(array) t,
                T1
        WHERE
                t.n1 = T1.n1
        AND     t.padding > 'x'
	GROUP by T1.n1
        ORDER by 3
)
WHERE
	ROWNUM <=1000;
exit
