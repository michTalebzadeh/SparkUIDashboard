--
------> Database test <------
--
CREATE SUBSCRIPTION test_pd
FOR DATABASE REPLICATION DEFINITION test_pd
WITH PRIMARY AT lon_gen_sql_tst6.test
WITH REPLICATE AT lon_gen_sql_tst7.test
WITHOUT MATERIALIZATION
go
