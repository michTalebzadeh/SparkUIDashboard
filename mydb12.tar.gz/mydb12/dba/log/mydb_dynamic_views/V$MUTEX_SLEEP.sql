 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 MUTEX_TYPE									   VARCHAR2(32)
 LOCATION									   VARCHAR2(40)
 SLEEPS 									   NUMBER
 WAIT_TIME									   NUMBER

