online database tradetech
go
use tradetech
go
dbcc settrunc(ltm,ignore)
go
