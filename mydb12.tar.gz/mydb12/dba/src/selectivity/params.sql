show parameter;
exit
