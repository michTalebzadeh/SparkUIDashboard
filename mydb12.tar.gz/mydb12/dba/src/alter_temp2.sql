/********************************************/
/*------------ temp2 -------------*/
/********************************************/
select 'Started altering temp2 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
ALTER TABLESPACE "TEMP2" ADD TEMPFILE '/ssdsdc1/oracle/mydb12/MYDB12/datafile/temp202.dbf' SIZE 3000M REUSE AUTOEXTEND ON NEXT 640K MAXSIZE 32767M;
select 'Finished  altering temp2 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
