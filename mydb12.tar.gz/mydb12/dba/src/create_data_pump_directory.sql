create or replace directory data_pump_dir as '/data6/oracle/data_pump_dir';
