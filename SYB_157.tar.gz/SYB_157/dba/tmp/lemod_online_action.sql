online database lemod
go
use lemod
go
dbcc settrunc(ltm,ignore)
go
