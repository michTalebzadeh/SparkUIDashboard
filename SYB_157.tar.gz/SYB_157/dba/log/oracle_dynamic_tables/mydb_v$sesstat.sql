use imdb1_template
go
set quoted_identifier on
go
if exists(select 1 from sysobjects where type = 'U' and name = 'MYDB_V$SESSTAT')
  drop table MYDB_V$SESSTAT
go
create existing table MYDB_V$SESSTAT
(
 SID                                                                               BIGINT NULL,
 STATISTIC#                                                                        BIGINT NULL,
 VALUE                                                                             BIGINT NULL
)
at 'DCORACLE..sys.v_$sesstat'
go
sp_help MYDB_V$SESSTAT
go
