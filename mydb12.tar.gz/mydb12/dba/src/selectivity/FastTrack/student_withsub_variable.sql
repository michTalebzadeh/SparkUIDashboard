set verify off;
declare
v_temp number := 10;
v_student_id number := &sv_student_id;
v_first_name varchar2(35);
v_last_name varchar2(35);
begin
  select first_name, last_name
  into v_first_name, v_last_name
  from student
  where student_id = v_student_id;
exception
  when no_data_found then
  dbms_output.put_line('no data exists');
end;
/
exit
