set timing on
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'testme';
--ALTER SESSION SET EVENTS '10949 trace name context forever, level 1'  -- No Direct path read ;
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
SELECT * FROM tdash2 WHERE object_id = 1;
exit
