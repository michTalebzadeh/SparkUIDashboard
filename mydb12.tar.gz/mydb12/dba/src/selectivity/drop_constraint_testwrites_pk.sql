truncate table testwrites;
commit;
ALTER TABLE testwrites drop CONSTRAINT testwrites_pk;
DROP INDEX testwrites_pk;
exit
