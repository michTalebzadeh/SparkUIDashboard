 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 LOG_ID 									   NUMBER
 FILENAME									   VARCHAR2(512)
 LOW_TIME									   DATE
 HIGH_TIME									   DATE
 DB_ID										   NUMBER
 DB_NAME									   VARCHAR2(8)
 RESET_SCN									   NUMBER
 RESET_SCN_TIME 								   DATE
 COMPATIBLE									   VARCHAR2(17)
 THREAD_ID									   NUMBER
 THREAD_SQN									   NUMBER
 LOW_SCN									   NUMBER
 NEXT_SCN									   NUMBER
 DICTIONARY_BEGIN								   VARCHAR2(3)
 DICTIONARY_END 								   VARCHAR2(3)
 TYPE										   VARCHAR2(7)
 BLOCKSIZE									   NUMBER
 FILESIZE									   NUMBER
 INFO										   VARCHAR2(32)
 STATUS 									   NUMBER

