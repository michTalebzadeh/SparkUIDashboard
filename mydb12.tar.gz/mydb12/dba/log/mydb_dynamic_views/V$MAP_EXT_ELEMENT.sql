 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ELEM_IDX									   NUMBER
 NUM_ATTRB									   NUMBER
 ATTRB1_NAME									   VARCHAR2(256)
 ATTRB1_VAL									   VARCHAR2(256)
 ATTRB2_NAME									   VARCHAR2(256)
 ATTRB2_VAL									   VARCHAR2(256)
 ATTRB3_NAME									   VARCHAR2(256)
 ATTRB3_VAL									   VARCHAR2(256)
 ATTRB4_NAME									   VARCHAR2(256)
 ATTRB4_VAL									   VARCHAR2(256)
 ATTRB5_NAME									   VARCHAR2(256)
 ATTRB5_VAL									   VARCHAR2(256)

