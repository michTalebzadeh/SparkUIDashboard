use master
go
CREATE DATABASE DBSSD
      ON datadev03_HDD = 4000
     LOG ON logdev05_HDD = 1000
FOR LOAD
go
ALTER DATABASE DBSSD
     ON datadev03_HDD = 6000
     LOG ON logdev05_HDD = 1000
       , logdev05_HDD = 750
       , logdev05_HDD = 1000
       , logdev05_HDD = 940
FOR LOAD
go
ALTER DATABASE DBSSD
     ON datadev03_HDD = 400
       , datadev03_HDD = 600
       , datadev03_HDD = 3000
     LOG ON logdev05_HDD = 1000
       , logdev05_HDD = 3000
FOR LOAD
go
ALTER DATABASE DBSSD
     ON datadev03_HDD = 5000
FOR LOAD
go
exit
