break on table;
select table_name, column_name
, DECODE(nullable,'Y','','NOT NULL')
from user_tab_columns
order by table_name, column_id
/
