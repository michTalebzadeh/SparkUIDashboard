impdp scratchpad/oracle tables=dummy directory=data_pump_dir  dumpfile=dummy.dmp logfile=dummy.log
