 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 GC_ELEMENT_ADDR								   RAW(4)
 INDX										   NUMBER
 CLASS										   NUMBER
 GC_ELEMENT_NAME								   NUMBER
 MODE_HELD									   NUMBER
 BLOCK_COUNT									   NUMBER
 RELEASING									   NUMBER
 ACQUIRING									   NUMBER
 WRITING									   NUMBER
 RECOVERING									   NUMBER
 LOCAL										   NUMBER
 FLAGS										   NUMBER

