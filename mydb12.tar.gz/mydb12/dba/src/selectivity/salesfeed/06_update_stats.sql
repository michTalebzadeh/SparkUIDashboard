exec dbms_stats.gather_table_stats(user, 'SALESFEED',cascade=>true);
exec dbms_stats.gather_table_stats(user, 'SALES',cascade=>true);
exit
