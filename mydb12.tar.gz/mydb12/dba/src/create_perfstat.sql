/********************************************/
/*------------ create_perfstat -------------*/
/********************************************/
select 'Started creating create_perfstat tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE SMALLFILE TABLESPACE "PERFSTAT" DATAFILE '+ORACLE_DG' SIZE 1000M
 REUSE EXTENT MANAGEMENT LOCAL UNIFORM SIZE 512K 
 SEGMENT SPACE MANAGEMENT AUTO
 PERMANENT
 ONLINE;
select 'Finished  creating create_perfstat tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
