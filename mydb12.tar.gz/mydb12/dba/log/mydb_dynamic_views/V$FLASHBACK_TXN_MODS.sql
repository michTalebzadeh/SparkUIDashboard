 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 COMPENSATING_XID								   RAW(8)
 COMPENSATING_TXN_NAME								   VARCHAR2(255)
 XID										   RAW(8)
 TXN_NAME									   VARCHAR2(255)
 PARENT_XID									   RAW(8)
 INTERESTING									   NUMBER
 ORIGINAL									   NUMBER
 BACKOUT_SEQ									   NUMBER
 UNDO_SQL									   VARCHAR2(4000)
 UNDO_SQL_SQN									   NUMBER
 UNDO_SQL_SUB_SQN								   NUMBER
 BACKOUT_SQL_ID 								   NUMBER
 OPERATION									   VARCHAR2(30)
 BACKEDOUT									   NUMBER
 CONFLICT_MOD									   NUMBER
 MODS_PER_LCR									   NUMBER

