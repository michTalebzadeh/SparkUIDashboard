 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 RULE_SET_OBJECT_ID								   NUMBER
 EVALUATION_CONTEXT_OBJECT_ID							   NUMBER
 RULE_OWNER									   VARCHAR2(30)
 RULE_NAME									   VARCHAR2(30)
 RULE_CONDITION 								   VARCHAR2(200)
 TRUE_HITS									   NUMBER
 MAYBE_HITS									   NUMBER
 SQL_EVALUATIONS								   NUMBER

