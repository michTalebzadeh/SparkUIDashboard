use lon_gen_rep_tst5_RSSD
go
IF OBJECT_ID('dbo.RINF_COLUMNS') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_COLUMNS
    IF OBJECT_ID('dbo.RINF_COLUMNS') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_COLUMNS >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_COLUMNS >>>'
END
go
CREATE VIEW RINF_COLUMNS
AS
-- CREATED BY RYAN PUTNAM, MEIJER.
SELECT
      C.name            AS "CONTROL_REP_SRVNAME"
    , B.objname         AS 'REPDEFNAME'
    , B.phys_tablename  AS 'PHYS_OBJNAME'
    , B.deliver_as_name AS 'DELIVER_OBJNAME'
    , A.colname         AS 'COLNAME'
    , A.repl_colname    AS 'DELIVER_COLNAME'
    , A.colnum          AS 'COLID'
    , CASE WHEN F1.name = 'numeric' THEN 'decimal'
           WHEN F1.name IN ('char', 'longchar', 'varchar', 'binary', 'varbinay')
                THEN F1.name + '(' + CONVERT(VARCHAR(10), A.length) + ')'
           ELSE F1.name
      END AS 'DATATYPE'
    , CASE WHEN F2.name = 'numeric' THEN 'decimal'
           WHEN F2.name IN ('char', 'longchar', 'varchar', 'binary', 'varbinay')
                THEN F2.name + '(' + CONVERT(VARCHAR(10), A.publ_length) + ')'
           ELSE F2.name
      END AS 'PUBL_DATATYPE'
    , A.length          AS 'DATALENGTH'
    , A.publ_length     AS 'PUBL_DATALENGTH'
    , A.searchable      AS 'SEARCHABLE'
    , A.primary_col     AS 'PRIMARY_COL'
    , D.dsname          AS 'SOURCE_DS'
    , D.dbname          AS 'SOURCE_DB'
    , B.objid           AS 'REPOBJID'
    , CASE WHEN B.objtype = "R" THEN "REPDEF" ELSE "FUNCTION" END AS "REPL_TYPE"
    , CASE WHEN B.ownertype = "U" THEN "USER" ELSE "SYSTEM" END AS "OWN_TYPE"
    , CASE WHEN A.status & 1 = 1 THEN "YES" ELSE "NO" END AS "IDENT"
    , CASE WHEN A.status & 4 = 4 THEN "YES" ELSE "NO" END AS "RS_ADD_DT"
    , CASE WHEN A.status & 8 = 8 THEN "YES" ELSE "NO" END AS "REP_IF_CHGD"
    , CASE WHEN A.status & 16 = 16 THEN "YES" ELSE "NO" END AS "ALLOW_NULLS"
    , CASE WHEN A.status & 32 = 32 THEN "YES" ELSE "NO" END AS "SND_COL_STDBY"
    , CASE WHEN A.status & 64 = 64 THEN "YES" ELSE "NO" END AS "DROP_PNDG"
    , CASE WHEN A.status & 512 = 512 THEN "YES" ELSE "NO" END AS "PUBL_IDENT"
    , CASE WHEN A.status & 4096 = 4096 THEN "YES" ELSE "NO" END AS "JAVA_COL"
    , CASE WHEN A.status & 8192 = 8192 THEN "YES" ELSE "NO" END AS "PUBL_JAVA_COL"
    , CASE WHEN A.publ_dtid = A.declared_dtid THEN "NO" ELSE "YES" END AS "HAS_PUBL_DT"
    , CASE WHEN A.coltype = A.publ_base_coltype THEN "NO" ELSE "YES" END AS "HAS_PUBL_CT"
  FROM rs_columns A
    , rs_objects B
    , rs_sites C
    , rs_databases D
    , rs_tvalues F1
    , rs_tvalues F2
 WHERE A.objid = B.objid
   AND B.objtype IN ("F","R")
   AND B.dbid = D.dbid
   AND A.coltype = F1.value
   AND F1.type = 'DT'
   AND A.publ_base_coltype = F2.value
   AND F2.type = 'DT'
   AND C.id = D.prsid
   AND B.ownertype IN ("U", "S")
go
IF OBJECT_ID('dbo.RINF_COLUMNS') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_COLUMNS >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_COLUMNS >>>'
go

IF OBJECT_ID('dbo.RINF_CONNS') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_CONNS
    IF OBJECT_ID('dbo.RINF_CONNS') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_CONNS >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_CONNS >>>'
END
go
CREATE VIEW RINF_CONNS
AS
-- AUTHOR: Ryan Putnam
SELECT CASE
         WHEN rq.number IS NULL
           THEN "REMOTE"
         ELSE "LOCAL"
       END AS "SITE_LOCATION"
     , rd.dsname AS "SOURCE_DS"
     , rd.dbname AS "SOURCE_DB"
     , CASE
         WHEN rd.dist_status & 2 = 2
           THEN "SUSPENDED"
         WHEN rd.dist_status & 4 = 4
           THEN "SUSPENDED BY STANDBY"
         ELSE "ACTIVE"
       END AS "CONN_STATE"
     , CASE
         WHEN rd.src_status & 2 = 2
           THEN "SUSPENDED"
         WHEN rd.src_status & 4 = 4
           THEN "SUSPENDED BY STANDBY"
         ELSE "ACTIVE"
       END AS "SOURCE_STATE"
FROM rs_databases rd
   , rs_sites rs
   , rs_queues rq
WHERE rd.prsid  = rs.id
  AND rd.dbid  *= rq.number
  AND rq.type = 0
go
IF OBJECT_ID('dbo.RINF_CONNS') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_CONNS >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_CONNS >>>'
go

IF OBJECT_ID('dbo.RINF_CONN_PASSWORDS') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_CONN_PASSWORDS
    IF OBJECT_ID('dbo.RINF_CONN_PASSWORDS') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_CONN_PASSWORDS >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_CONN_PASSWORDS >>>'
END
go

CREATE VIEW RINF_CONN_PASSWORDS
AS
-- AUTHOR: Ryan Putnam
SELECT rd.dsname AS "DEST_RDS_SRVNAME",
       rd.dbname AS "DEST_RDS_DBNAME",
       rm.username AS "DEST_RDS_USERNAME",
       rm.password AS "DEST_RDS_PASSWORD"
  FROM rs_maintusers rm,
       rs_databases rd
 WHERE rm.destid = rd.dbid
go
IF OBJECT_ID('dbo.RINF_CONN_PASSWORDS') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_CONN_PASSWORDS >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_CONN_PASSWORDS >>>'
go

IF OBJECT_ID('dbo.RINF_DB_CLASSES') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_DB_CLASSES
    IF OBJECT_ID('dbo.RINF_DB_CLASSES') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_DB_CLASSES >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_DB_CLASSES >>>'
END
go
CREATE VIEW RINF_DB_CLASSES
AS
SELECT RD.dsname AS "DSNAME",
       RD.dbname AS "DBNAME",
       RD.dbid AS "DBID",
       RC2.classname AS "FC_CLASS_NM",
       RC2.classid AS "FC_CLASS_ID",
       ( SELECT RC3.classname
           FROM rs_classes RC3
          WHERE RC2.parent_classid = RC3.classid ) AS "PAR_CLASS_NM",
       RC2.parent_classid AS "PAR_CLASS_ID",
       RC1.classname AS "ERR_CLASS_NM",
       RC1.classid AS "ERR_CLASS_ID"
  FROM rs_databases RD,
       rs_classes RC1,
       rs_classes RC2
WHERE RD.errorclassid = RC1.classid
  AND RD.funcclassid = RC2.classid
go
IF OBJECT_ID('dbo.RINF_DB_CLASSES') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_DB_CLASSES >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_DB_CLASSES >>>'
go

IF OBJECT_ID('dbo.RINF_DISKSPACE') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_DISKSPACE
    IF OBJECT_ID('dbo.RINF_DISKSPACE') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_DISKSPACE >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_DISKSPACE >>>'
END
go
CREATE VIEW RINF_DISKSPACE
AS
-- Author: Ryan Putnam
SELECT rd.name         AS "PHYSICAL_NAME"
     , rd.logical_name AS "LOGICAL_NAME"
     , SUM(rd.num_segs) AS 'SIZE_MB'
     , SUM(rd.allocated_segs) AS 'ALLOCATED_MB'
     , (SUM(rd.allocated_segs)*100)/SUM(rd.num_segs) AS 'PCT_USD'
  FROM rs_diskpartitions rd
 GROUP
    BY rd.id
go
IF OBJECT_ID('dbo.RINF_DISKSPACE') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_DISKSPACE >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_DISKSPACE >>>'
go

IF OBJECT_ID('dbo.RINF_DSI_CONFIG') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_DSI_CONFIG
    IF OBJECT_ID('dbo.RINF_DSI_CONFIG') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_DSI_CONFIG >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_DSI_CONFIG >>>'
END
go
CREATE VIEW RINF_DSI_CONFIG
AS
-- AUTHOR: Ryan Putnam
SELECT rs.name        AS "CONTROL_REP_SRVNAME"
     , rd.dsname      AS "DELIVER_DS"
     , rd.dbname      AS "DELIVER_DB"
     , rc.optionname  AS "OPTION_NAME"
     , rc.charvalue   AS "CONFIG_VALUE"
  FROM rs_databases rd
     , rs_config    rc
     , rs_sites     rs
 WHERE rd.dbid  = rc.objid
   AND rd.prsid = rs.id
go
IF OBJECT_ID('dbo.RINF_DSI_CONFIG') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_DSI_CONFIG >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_DSI_CONFIG >>>'
go

IF OBJECT_ID('dbo.RINF_REPDEFS') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_REPDEFS
    IF OBJECT_ID('dbo.RINF_REPDEFS') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_REPDEFS >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_REPDEFS >>>'
END
go
CREATE VIEW RINF_REPDEFS
AS
-- CREATED BY RYAN PUTNAM, MEIJER.
SELECT
      c.name            AS 'CONTROL_REP_SRVNAME'
    , b.phys_objowner   AS 'PHYS_OBJOWNER'
    , b.phys_tablename  AS 'PHYS_OBJNAME'
    , b.repl_objowner   AS 'DELIVER_OBJOWNER'
    , b.deliver_as_name AS 'DELIVER_OBJNAME'
    , d.dsname          AS 'SOURCE_DS'
    , d.dbname          AS 'SOURCE_DB'
    , b.objname         AS 'REPDEFNAME'
    , b.crdate          AS 'CRDATE'
    , b.objid           AS 'REPOBJID'
    , CASE WHEN b.attributes & 4 = 4 THEN 'YES' ELSE 'NO' END 'REP_MIN_COLS'
    , CASE WHEN b.attributes & 8 = 8 THEN 'YES' ELSE 'NO' END 'HAS_IDENT'
    , CASE WHEN b.attributes & 16 = 16 THEN 'YES' ELSE 'NO' END 'REP_IF_CHGD'
    , CASE WHEN b.attributes & 32 = 32 THEN 'YES' ELSE 'NO' END 'DROP_PNDG'
    , CASE WHEN b.attributes & 64 = 64 THEN 'YES' ELSE 'NO' END 'HAS_TXT_IMG'
    , CASE WHEN b.attributes & 128 = 128 THEN 'YES' ELSE 'NO' END 'STDBY_USE'
    , CASE WHEN b.attributes & 256 = 256 THEN 'YES' ELSE 'NO' END 'SND_COL_STDBY'
    , CASE WHEN b.attributes & 1024 = 1024 THEN 'YES' ELSE 'NO' END 'BASE_REPDEF'
    , CASE WHEN b.attributes & 4096 = 4096 THEN 'YES' ELSE 'NO' END 'OBJNAME_DIFFER'
    , CASE WHEN b.attributes & 8192 = 8192 THEN 'YES' ELSE 'NO' END 'COLUMN_MAPS'
    , CASE WHEN b.attributes & 16384 = 16384 THEN 'YES' ELSE 'NO' END 'HAS_UDDS'
    , CASE WHEN b.objtype = "R" THEN "REPDEF" ELSE "FUNCTION" END AS "REPL_TYPE"
    , CASE WHEN b.ownertype = "U" THEN "USER" ELSE "SYSTEM" END AS "OWN_TYPE"FROM rs_objects b
    , rs_sites c
    , rs_databases d
WHERE b.objtype IN ("F","R")
  AND b.dbid = d.dbid
  AND c.id = d.prsid
  AND b.ownertype IN ("U", "S")
go
IF OBJECT_ID('dbo.RINF_REPDEFS') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_REPDEFS >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_REPDEFS >>>'
go

IF OBJECT_ID('dbo.RINF_ROUTES') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_ROUTES
    IF OBJECT_ID('dbo.RINF_ROUTES') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_ROUTES >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_ROUTES >>>'
END
go
CREATE VIEW RINF_ROUTES
AS
-- AUTHOR: Ryan Putnam
SELECT CASE
         WHEN rq.number IS NOT NULL
           THEN "REMOTE"
         ELSE "LOCAL"
       END AS "SITE_LOCATION"
     , rs1.name        AS "CONTROL_REP_SRVNAME"
     , rs2.name        AS "THROUGH_REP_SRVNAME"
     , rs3.name        AS "DEST_REP_SRVNAME"
     , CASE
         WHEN rr.status = 1
           THEN "INITIALIZING"
         WHEN rr.status = 2
           THEN "VALID"
         WHEN rr.status = 3
           THEN "DROPPING GRACEFUL"
         WHEN rr.status = 4
           THEN "DROPPING FORCEFUL"
       END AS "STATUS"
     , CASE
         WHEN rr.suspended = 1
           THEN "SUSPENDED"
         WHEN rr.suspended = 2
           THEN "REBUILDING"
         WHEN rr.suspended = 3
           THEN "SUSPENDED"
         ELSE "ACTIVE"
       END AS "STATE"
     , rr.src_version  AS "VERSION"
  FROM rs_routes rr
     , rs_sites  rs1
     , rs_sites  rs2
     , rs_sites  rs3
     , rs_queues rq
 WHERE rr.source_rsid  = rs1.id
   AND rr.through_rsid = rs2.id
   AND rr.dest_rsid    = rs3.id
   AND rr.source_rsid *= rq.number
go
IF OBJECT_ID('dbo.RINF_ROUTES') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_ROUTES >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_ROUTES >>>'
go

IF OBJECT_ID('dbo.RINF_ROUTE_CONFIG') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_ROUTE_CONFIG
    IF OBJECT_ID('dbo.RINF_ROUTE_CONFIG') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_ROUTE_CONFIG >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_ROUTE_CONFIG >>>'
END
go
CREATE VIEW RINF_ROUTE_CONFIG
AS
-- AUTHOR: Ryan Putnam
SELECT rs.name        AS "CONTROL_REP_SRVNAME"
     , rc.optionname  AS "OPTION_NAME"
     , rc.charvalue   AS "CONFIG_VALUE"
  FROM rs_routes    rr
     , rs_config    rc
     , rs_sites     rs
 WHERE rr.source_rsid  = rc.objid
   AND rr.source_rsid  = rs.id
go
IF OBJECT_ID('dbo.RINF_ROUTE_CONFIG') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_ROUTE_CONFIG >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_ROUTE_CONFIG >>>'
go

IF OBJECT_ID('dbo.RINF_ROUTE_PASSWORDS') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_ROUTE_PASSWORDS
    IF OBJECT_ID('dbo.RINF_ROUTE_PASSWORDS') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_ROUTE_PASSWORDS >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_ROUTE_PASSWORDS >>>'
END
go
CREATE VIEW RINF_ROUTE_PASSWORDS
AS
-- AUTHOR: Ryan Putnam
SELECT rs.name AS "DEST_REP_SRVNAME",
       rm.username AS "DEST_REP_USERNAME",
       rm.password AS "DEST_REP_PASSWORD"
  FROM rs_maintusers rm,
       rs_sites rs
 WHERE rm.destid = rs.id
go
IF OBJECT_ID('dbo.RINF_ROUTE_PASSWORDS') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_ROUTE_PASSWORDS >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_ROUTE_PASSWORDS >>>'
go

IF OBJECT_ID('dbo.RINF_SERVER_CONFIG') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_SERVER_CONFIG
    IF OBJECT_ID('dbo.RINF_SERVER_CONFIG') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_SERVER_CONFIG >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_SERVER_CONFIG >>>'
END
go
CREATE VIEW RINF_SERVER_CONFIG
AS
-- AUTHOR: Ryan Putnam
SELECT ( SELECT rs.name
           FROM rs_sites rs
          WHERE NOT EXISTS ( SELECT 1
                               FROM rs_queues rq
                              WHERE rs.id = rq.number ) ) AS "CONTROL_REP_SRVNAME"
     , rc.optionname  AS "OPTION_NAME"
     , rc.charvalue   AS "CONFIG_VALUE"
  FROM rs_config    rc
 WHERE rc.objid = 0x0
go
IF OBJECT_ID('dbo.RINF_SERVER_CONFIG') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_SERVER_CONFIG >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_SERVER_CONFIG >>>'
go

IF OBJECT_ID('dbo.RINF_SUBS') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_SUBS
    IF OBJECT_ID('dbo.RINF_SUBS') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_SUBS >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_SUBS >>>'
END
go
CREATE VIEW RINF_SUBS
AS
-- CREATED BY RYAN PUTNAM, MEIJER.
SELECT
      f1.name           AS 'CONTROL_REP_SRVNAME'
    , f2.name           AS 'DELIVER_REP_SRVNAME'
    , b.phys_tablename  AS 'PHYS_OBJNAME'
    , b.deliver_as_name AS 'DELIVER_OBJNAME'
    , d.dsname          AS 'SOURCE_DS'
    , d.dbname          AS 'SOURCE_DB'
    , e.dsname          AS 'DELIVER_DS'
    , e.dbname          AS 'DELIVER_DB'
    , c.subname         AS 'SUBNAME'
    , b.objname         AS 'REPDEFNAME'
    , d.dbid            AS 'SOURCE_DBID'
    , e.dbid            AS 'DELIVER_DBID'
    , c.subid           AS 'SUBOBJID'
    , b.objid           AS 'REPOBJID'
    , CASE WHEN c.type & 1 = 1 THEN "YES" ELSE "NO" END AS "RANGE_SUB"
    , CASE WHEN c.type & 2 = 2 THEN "YES" ELSE "NO" END AS "EQUAL_SUB"
    , CASE WHEN c.type & 4 = 4 THEN "YES" ELSE "NO" END AS "ENTIRE_TBL"
    , CASE WHEN c.type & 8 = 8 THEN "YES" ELSE "NO" END AS "SUB_FOR_PUB"
    , CASE WHEN c.type & 128 = 128 THEN "YES" ELSE "NO" END AS "SUB_FOR_ARTICLE"
    , CASE WHEN c.status & 2 = 2 AND c.status & 4 != 4 THEN "YES" ELSE "NO" END AS "RDB_ACTIVATING"
    , CASE WHEN c.status & 4 = 4 THEN "YES" ELSE "NO" END AS "RDB_ACTIVE"
    , CASE WHEN c.status & 8 = 8 AND c.status & 16 != 16 THEN "YES" ELSE "NO" END AS "RDB_VALIDATING"
    , CASE WHEN c.status & 16 = 16 THEN "YES" ELSE "NO" END AS "RDB_VALID"
    , CASE WHEN c.status & 512 = 512 THEN "YES" ELSE "NO" END AS "PDB_ACTIVATING"
    , CASE WHEN c.status & 1024 = 1024 THEN "YES" ELSE "NO" END AS "PDB_ACTIVE"
    , CASE WHEN c.status & 2048 = 2048 THEN "YES" ELSE "NO" END AS "PDB_VALID"
    , CASE WHEN c.status & 1073741824 = 1073741824 THEN "YES" ELSE "NO" END AS "TRUNC_TBL_CMD"
    , CASE WHEN r.attributes & 1 = 1 THEN "YES" ELSE "NO" END AS "AUTOCORRECTION"
    , CASE WHEN b.objtype = "R" THEN "REPDEF" ELSE "FUNCTION" END AS "REPL_TYPE"
    , CASE WHEN b.ownertype = "U" THEN "USER" ELSE "SYSTEM" END AS "OWN_TYPE"
FROM rs_objects b
    , rs_subscriptions c
    , rs_databases d
    , rs_databases e
    , rs_databases f
    , rs_sites f1
    , rs_sites f2
    , rs_repobjs r
WHERE b.objtype   IN ("F","R")
  AND b.ownertype IN ("U","S")
  AND c.objid     =  b.objid
  AND e.dbid      =  c.dbid
  AND b.dbid      =  d.dbid
  AND f1.id       =  d.prsid
  AND r.objid     =* c.objid
  AND r.dbid      =* c.dbid
  AND c.type & 0  =  0
  AND f.dbid      =  c.dbid
  AND f2.id       =  f.prsid
go
IF OBJECT_ID('dbo.RINF_SUBS') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_SUBS >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_SUBS >>>'
go

IF OBJECT_ID('dbo.RINF_UFSTRINGS_BY_REP') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_UFSTRINGS_BY_REP
    IF OBJECT_ID('dbo.RINF_UFSTRINGS_BY_REP') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_UFSTRINGS_BY_REP >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_UFSTRINGS_BY_REP >>>'
END
go

CREATE VIEW RINF_UFSTRINGS_BY_REP
AS
-- Author: Ryan Putnam
SELECT   si.name 			AS 'CONTROL_REP_SRVNAME'
        ,db1.dsname         AS 'SOURCE_DS'
        ,db1.dbname         AS 'SOURCE_DB'
        ,db2.dsname         AS 'DELIVER_DS'
        ,db2.dbname         AS 'DELIVER_DB'
        ,ro.phys_tablename  AS 'PHYS_OBJNAME'
        ,ro.deliver_as_name AS 'DELIVER_OBJNAME'
        ,ro.objname         AS 'REPDEFNAME'
        ,sb.subname         AS 'SUBNAME'
        ,rc.classname       AS 'CLASSNAME'
        ,fs.name            AS 'FUNCNAME'
        ,st.sequence        AS 'SEQUENCE'
        ,st.textval         AS 'TEXTVAL'
        ,fs.attributes      AS 'ATTRIBUTES'
        ,fs.fstringid       AS 'FSTRINGID'
        ,st.parentid        AS 'PARENTID'
        ,ro.prsid           AS 'REPPRSID'
        ,ro.objid           AS 'REPOBJID'
        ,sb.subid	        AS 'SUBOBJID'
    , CASE WHEN ro.objtype = "R" THEN "REPDEF" ELSE "FUNCTION" END AS "REPL_TYPE"
    , CASE WHEN ro.ownertype = "U" THEN "USER" ELSE "SYSTEM" END AS "OWN_TYPE"
 FROM rs_databases db1
    , rs_objects ro
    , rs_functions f
    , rs_funcstrings fs
    , rs_classes rc
    , rs_systext st
    , rs_subscriptions sb
    , rs_sites si
    , rs_databases db2
WHERE db1.ltype = "P"
  AND ro.objtype IN ("F","R")
  AND ro.ownertype IN ("U","S")
  AND ro.dbid = db1.dbid
  AND ro.objid = f.objid
  AND ro.objid *= sb.objid
  AND f.funcid = fs.funcid
  AND fs.classid = rc.classid
  AND st.parentid = fs.fstringid
  AND si.id = db1.prsid
  AND sb.dbid *= db2.dbid
go
IF OBJECT_ID('dbo.RINF_UFSTRINGS_BY_REP') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_UFSTRINGS_BY_REP >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_UFSTRINGS_BY_REP >>>'
go

IF OBJECT_ID('dbo.RINF_UFSTRINGS_BY_SUB') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_UFSTRINGS_BY_SUB
    IF OBJECT_ID('dbo.RINF_UFSTRINGS_BY_SUB') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_UFSTRINGS_BY_SUB >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_UFSTRINGS_BY_SUB >>>'
END
go

CREATE VIEW RINF_UFSTRINGS_BY_SUB
AS
-- Author: Ryan Putnam
SELECT   si.name 			AS 'CONTROL_REP_SRVNAME'
        ,db1.dsname         AS 'SOURCE_DS'
        ,db1.dbname         AS 'SOURCE_DB'
        ,db2.dsname         AS 'DELIVER_DS'
        ,db2.dbname         AS 'DELIVER_DB'
        ,ro.phys_tablename  AS 'PHYS_OBJNAME'
        ,ro.deliver_as_name AS 'DELIVER_OBJNAME'
        ,ro.objname         AS 'REPDEFNAME'
        ,sb.subname         AS 'SUBNAME'
        ,rc.classname       AS 'CLASSNAME'
        ,fs.name            AS 'FUNCNAME'
        ,st.sequence        AS 'SEQUENCE'
        ,st.textval         AS 'TEXTVAL'
        ,fs.attributes      AS 'ATTRIBUTES'
        ,fs.fstringid       AS 'FSTRINGID'
        ,st.parentid        AS 'PARENTID'
        ,ro.prsid           AS 'REPPRSID'
        ,ro.objid           AS 'REPOBJID'
        ,sb.subid	        AS 'SUBOBJID'
    , CASE WHEN ro.objtype = "R" THEN "REPDEF" ELSE "FUNCTION" END AS "REPL_TYPE"
    , CASE WHEN ro.ownertype = "U" THEN "USER" ELSE "SYSTEM" END AS "OWN_TYPE"
 FROM rs_databases db1
    , rs_objects ro
    , rs_functions f
    , rs_funcstrings fs
    , rs_classes rc
    , rs_systext st
    , rs_subscriptions sb
    , rs_sites si
    , rs_databases db2
WHERE db1.ltype = "P"
  AND ro.objtype IN ("F","R")
  AND ro.ownertype IN ("U","S")
  AND ro.dbid = db1.dbid
  AND ro.objid = f.objid
  AND ro.objid = sb.objid
  AND f.funcid = fs.funcid
  AND fs.classid = rc.classid
  AND st.parentid = fs.fstringid
  AND si.id = db1.prsid
  AND sb.dbid = db2.dbid
  AND db2.funcclassid = rc.classid
go
IF OBJECT_ID('dbo.RINF_UFSTRINGS_BY_SUB') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_UFSTRINGS_BY_SUB >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_UFSTRINGS_BY_SUB >>>'
go

IF OBJECT_ID('dbo.RINF_UFSTRINGS_INTERNAL') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_UFSTRINGS_INTERNAL
    IF OBJECT_ID('dbo.RINF_UFSTRINGS_INTERNAL') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_UFSTRINGS_INTERNAL >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_UFSTRINGS_INTERNAL >>>'
END
go
CREATE VIEW RINF_UFSTRINGS_INTERNAL
AS
-- AUTHOR: Ryan Putnam
SELECT rs_sites.name AS "CONTROL_REP_SRVNAME",
       rc.classname AS "CLASSNAME",
       rf.name AS "FUNCNAME",
       rs.sequence AS "SEQUENCE",
       rs.textval AS "TEXTVAL",
       rf.attributes AS "ATTRIBUTES",
       rf.fstringid AS "FSTRINGID",
       rs.parentid AS "PARENTID"
  FROM rs_funcstrings rf,
       rs_systext rs,
       rs_classes rc,
       rs_functions rfunc,
       rs_sites
 WHERE rf.fstringid = rs.parentid
   AND rf.classid = rc.classid
   AND rf.funcid = rfunc.funcid
   AND rfunc.objid = 0x0000000000000000
   AND rs_sites.id =* rf.prsid
go
IF OBJECT_ID('dbo.RINF_UFSTRINGS_INTERNAL') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_UFSTRINGS_INTERNAL >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_UFSTRINGS_INTERNAL >>>'
go

IF OBJECT_ID('dbo.RINF_WHERECLAUSES') IS NOT NULL
BEGIN
    DROP VIEW dbo.RINF_WHERECLAUSES
    IF OBJECT_ID('dbo.RINF_WHERECLAUSES') IS NOT NULL
        PRINT '<<< FAILED DROPPING VIEW dbo.RINF_WHERECLAUSES >>>'
    ELSE
        PRINT '<<< DROPPED VIEW dbo.RINF_WHERECLAUSES >>>'
END
go
CREATE VIEW RINF_WHERECLAUSES
AS
-- CREATED BY RYAN PUTNAM, MEIJER.
-- GET LOW
SELECT
      s.subname AS 'SUBNAME'
    , o.objname AS 'REPDEFNAME'
    , d.dsname  AS 'SOURCE_DS'
    , d.dbname  AS 'SOURCE_DB'
    , e.dsname  AS 'DELIVER_DS'
    , e.dbname  AS 'DELIVER_DB'
    , CASE WHEN o.has_baserepdef = 0x0000000000000000
            THEN (SELECT c.colname FROM rs_columns c WHERE c.objid = r.objid AND c.colnum = r.colnum)
           ELSE  (SELECT c.colname FROM rs_columns c WHERE c.objid = r.objid AND c.basecolnum = r.colnum)
      END AS 'COLNAME'
    , CASE WHEN r.low_len > 0 AND r.low_flag = 1
            THEN " > "
           WHEN r.low_len > 0 AND r.low_flag = 2
            THEN " >= "
           WHEN r.low_len > 0 AND r.low_flag = 8
	    THEN " = "
      END AS "OPERAND"
    , CASE WHEN r.valuetype = 0 AND ASCII(SUBSTRING(r.low_value, 1, 1)) = 0
            THEN "''"
           WHEN r.valuetype = 0
            THEN "'" + CONVERT(VARCHAR(30), SUBSTRING(r.low_value, 1, r.low_len)) + "'"
           WHEN r.valuetype = 6
            THEN CONVERT(VARCHAR(3), CONVERT(TINYINT, r.low_value))
           WHEN r.valuetype = 7
            THEN CONVERT(VARCHAR(3), CONVERT(SMALLINT, r.low_value))
           WHEN r.valuetype = 8
            THEN CONVERT(VARCHAR(10), CONVERT(INT, r.low_value))
           WHEN r.valuetype = 11
            THEN CONVERT(VARCHAR(1), CONVERT(BIT, r.low_value))
           WHEN r.valuetype = 12
            THEN "'" + CONVERT(VARCHAR(20), CONVERT(DATETIME, r.low_value)) + "'"
           WHEN r.valuetype = 13
            THEN "'" + CONVERT(VARCHAR(20), CONVERT(SMALLDATETIME, r.low_value)) + "'"
           WHEN r.valuetype = 14
            THEN "$" + CONVERT(VARCHAR(30), CONVERT(MONEY, r.low_value))
           WHEN r.valuetype = 15
            THEN "$" + CONVERT(VARCHAR(30), CONVERT(SMALLMONEY, r.low_value))
           WHEN r.valuetype = 18
            THEN "'" + CONVERT(VARCHAR(30), SUBSTRING(r.low_value, 1, r.low_len)) + "'"
      END AS "VALUE"
    , r.colnum  AS 'COLID'
    , d.dbid    AS 'SOURCE_DBID'
    , e.dbid    AS 'DELIVER_DBID'
    , s.subid AS 'SUBOBJID'
    , o.objid AS 'REPOBJID'
    , CASE WHEN o.objtype = "R" THEN "REPDEF" ELSE "FUNCTION" END AS "REPL_TYPE"
    , CASE WHEN o.ownertype = "U" THEN "USER" ELSE "SYSTEM" END AS "OWN_TYPE"
FROM rs_subscriptions s
    , rs_rules r
    , rs_objects o
    , rs_databases d
    , rs_databases e
WHERE s.subid = r.subid
  AND o.objid = s.objid
  AND e.dbid    =  s.dbid
  AND o.dbid    =  d.dbid
  AND o.objtype IN ("F", "R")
  AND o.ownertype IN ("U", "S")
  AND r.low_len > 0
  AND r.low_flag IN (1,2,8)
UNION ALL
-- GET HIGH
SELECT
      s.subname AS 'SUBNAME'
    , o.objname AS 'REPDEFNAME'
    , d.dsname  AS 'SOURCE_DS'
    , d.dbname  AS 'SOURCE_DB'
    , e.dsname  AS 'DELIVER_DS'
    , e.dbname  AS 'DELIVER_DB'
    , CASE WHEN o.has_baserepdef = 0x0000000000000000
            THEN (SELECT c.colname FROM rs_columns c WHERE c.objid = r.objid AND c.colnum = r.colnum)
           ELSE  (SELECT c.colname FROM rs_columns c WHERE c.objid = r.objid AND c.basecolnum = r.colnum)
      END AS 'COLNAME'
    , CASE WHEN r.high_len > 0 AND r.high_flag = 1
            THEN " < "
           WHEN r.high_len > 0 AND r.high_flag = 2
            THEN " <= "
           WHEN r.high_len > 0 AND r.high_flag = 8
            THEN " = "
      END AS "OPERAND"
    , CASE WHEN r.valuetype = 0 AND ASCII(SUBSTRING(r.high_value, 1, 1)) = 0
            THEN "''"
           WHEN r.valuetype = 0
            THEN "'" + CONVERT(VARCHAR(30), SUBSTRING(r.high_value, 1, r.high_len)) + "'"
           WHEN r.valuetype = 6
            THEN CONVERT(VARCHAR(3), CONVERT(TINYINT, r.high_value))
           WHEN r.valuetype = 7
            THEN CONVERT(VARCHAR(3), CONVERT(SMALLINT, r.high_value))
           WHEN r.valuetype = 8
            THEN CONVERT(VARCHAR(10), CONVERT(INT, r.high_value))
           WHEN r.valuetype = 11
            THEN CONVERT(VARCHAR(1), CONVERT(BIT, r.high_value))
           WHEN r.valuetype = 12
            THEN "'" + CONVERT(VARCHAR(20), CONVERT(DATETIME, r.high_value)) + "'"
           WHEN r.valuetype = 13
            THEN "'" + CONVERT(VARCHAR(20), CONVERT(SMALLDATETIME, r.high_value)) + "'"
           WHEN r.valuetype = 14
            THEN "$" + CONVERT(VARCHAR(30), CONVERT(MONEY, r.high_value))
           WHEN r.valuetype = 15
            THEN "$" + CONVERT(VARCHAR(30), CONVERT(SMALLMONEY, r.high_value))
           WHEN r.valuetype = 18
            THEN "'" + CONVERT(VARCHAR(30), SUBSTRING(r.high_value, 1, r.high_len)) + "'"
      END AS "VALUE"
    , r.colnum  AS 'COLID'
    , d.dbid    AS 'SOURCE_DBID'
    , e.dbid    AS 'DELIVER_DBID'
    , s.subid AS 'SUBOBJID'
    , o.objid AS 'REPOBJID'
    , CASE WHEN o.objtype = "R" THEN "REPDEF" ELSE "FUNCTION" END AS "REPL_TYPE"
    , CASE WHEN o.ownertype = "U" THEN "USER" ELSE "SYSTEM" END AS "OWN_TYPE"
FROM rs_subscriptions s
    , rs_rules r
    , rs_objects o
    , rs_databases d
    , rs_databases e
WHERE s.subid = r.subid
  AND o.objid = s.objid
  AND e.dbid    =  s.dbid
  AND o.dbid    =  d.dbid
  AND o.objtype IN ("F", "R")
  AND o.ownertype IN ("U", "S")
  AND r.high_len > 0
  AND r.high_flag IN (1,2,8)

-- you should order by subname, subid, colnum
go
IF OBJECT_ID('dbo.RINF_WHERECLAUSES') IS NOT NULL
    PRINT '<<< CREATED VIEW dbo.RINF_WHERECLAUSES >>>'
ELSE
    PRINT '<<< FAILED CREATING VIEW dbo.RINF_WHERECLAUSES >>>'
go
