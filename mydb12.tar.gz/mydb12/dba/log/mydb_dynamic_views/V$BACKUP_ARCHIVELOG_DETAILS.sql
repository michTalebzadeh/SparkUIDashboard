 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 BTYPE										   CHAR(9)
 BTYPE_KEY									   NUMBER
 SESSION_KEY									   NUMBER
 SESSION_RECID									   NUMBER
 SESSION_STAMP									   NUMBER
 ID1										   NUMBER
 ID2										   NUMBER
 THREAD#									   NUMBER
 SEQUENCE#									   NUMBER
 RESETLOGS_CHANGE#								   NUMBER
 RESETLOGS_TIME 								   DATE
 FIRST_CHANGE#									   NUMBER
 FIRST_TIME									   DATE
 NEXT_CHANGE#									   NUMBER
 NEXT_TIME									   DATE
 FILESIZE									   NUMBER
 COMPRESSION_RATIO								   NUMBER
 FILESIZE_DISPLAY								   VARCHAR2(4000)

