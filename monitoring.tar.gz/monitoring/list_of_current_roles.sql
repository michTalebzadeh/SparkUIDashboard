SET PAGES 66
SET LINES 80
BREAK ON ROLE SKIP 1
TITLE CENTER "Role Grants Report"
SELECT a.role,
b.privilege
FROM dba_roles a,
     dba_tab_privs b
WHERE a.role = b.grantee
UNION
SELECT a.role, b.privilege
FROM dba_roles a, dba_sys_privs b
WHERE a.role = b.grantee
ORDER BY 1, 2
/
exit
