 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ID										   NUMBER
 NAME										   VARCHAR2(40)
 SQL_FEATURE									   VARCHAR2(64)
 ISDEFAULT									   VARCHAR2(3)
 VALUE										   VARCHAR2(25)
 DEFAULT_VALUE									   VARCHAR2(25)

