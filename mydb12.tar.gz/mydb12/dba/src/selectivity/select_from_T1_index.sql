alter system flush buffer_cache;
alter system flush shared_pool;
--EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE( waits=>true );
--ALTER SESSION SET TRACEFILE_IDENTIFIER = 'query_T1_index';
set timing on
set autotrace on
SELECT count(1)
FROM T1
--where   n1 <= 8
where   n1 = 2
and	ind_pad <= rpad('x',39)||'x'
and     n2      < 15;
exit
