 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 SESS_SERIAL#									   NUMBER
 WAIT_ID									   NUMBER
 WAIT_EVENT									   NUMBER
 WAIT_EVENT_TEXT								   VARCHAR2(64)
 BLOCKER_INSTANCE_ID								   NUMBER
 BLOCKER_SID									   NUMBER
 BLOCKER_SESS_SERIAL#								   NUMBER

