     prompt Buffer hit ratio
     SELECT (P1.value + P2.value - P3.value) / (P1.value + P2.value) AS "Buffer hit ratio"
     FROM   v$sysstat P1, v$sysstat P2, v$sysstat P3
     WHERE  P1.name = 'db block gets'
     AND    P2.name = 'consistent gets'
     AND    P3.name = 'physical reads'
/
prompt buffer hit ratio per session
column username  format a10
SELECT    
       P1.sid
       , (P1.value + P2.value - P3.value) / (P1.value + P2.value) AS "Session buffer hit ratio"
     FROM   v$sesstat P1, v$statname N1, v$sesstat P2, v$statname N2,
            v$sesstat P3, v$statname N3
     WHERE  N1.name = 'db block gets'
     AND    P1.statistic# = N1.statistic#
     AND    P1.sid in (select sid from v$session where username IS NOT NULL)
     AND    N2.name = 'consistent gets'
     AND    P2.statistic# = N2.statistic#
     AND    P2.sid = P1.sid
     AND    N3.name = 'physical reads'
     AND    P3.statistic# = N3.statistic#
     AND    P3.sid = P1.sid
/
prompt stats on full table scans
break on tablespace_name
compute sum of count on tablespace_name
column phyrds format 999,999,999 heading "No of Read|requests"
column phyblkrd format 999,999,999 heading "Actual no of|block reads"
column ratio format 999,999.99 heading "Ratio of blocks reads/|read requests"
prompt Full table scan activity
compute sum of phyrds on tablespace_name
compute sum of phyblkrd on tablespace_name
SELECT
	  A.tablespace_name tablespace_name
	, substr(A.file_name,1,50) as file_name
        , B.phyrds phyrds
	, B.phyblkrd phyblkrd
	, B.phyblkrd/B.phyrds ratio
FROM
	  SYS.dba_data_files A
	, v$filestat B
WHERE
	  B.file# = A.file_id
ORDER BY
	  A.tablespace_name
	, A.file_id
/
exit


