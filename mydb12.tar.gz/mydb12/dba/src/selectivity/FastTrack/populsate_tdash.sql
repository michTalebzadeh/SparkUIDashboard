DECLARE
  v_max_object_id tdash.object_id%type;
  v_next_object_id tdash.object_id%type;
  v_records number;
  CURSOR C IS
    SELECT
	 OWNER
	,OBJECT_NAME
	,SUBOBJECT_NAME
	,OBJECT_ID
	,DATA_OBJECT_ID
	,OBJECT_TYPE
	,CREATED
	,LAST_DDL_TIME
	,TIMESTAMP
	,STATUS
	,TEMPORARY
	,GENERATED
	,SECONDARY
	,NAMESPACE
	,EDITION_NAME
	,PADDING1
	,PADDING2
  FROM tdash;
BEGIN
  SELECT COUNT(1) into v_records from tdash;
  SELECT MAX(object_id) INTO v_max_object_id FROM tdash;
  FOR rs in c
  LOOP
    v_next_object_id := v_max_object_id + object_id_seq.nextval;
    INSERT INTO tdash
    (
	
         OWNER
        ,OBJECT_NAME
        ,SUBOBJECT_NAME
	,OBJECT_ID
        ,DATA_OBJECT_ID
        ,OBJECT_TYPE
        ,CREATED
        ,LAST_DDL_TIME
        ,TIMESTAMP
        ,STATUS
        ,TEMPORARY
        ,GENERATED
        ,SECONDARY
        ,NAMESPACE
        ,EDITION_NAME
        ,PADDING1
        ,PADDING2

    )
    VALUES
         (
	 rs.OWNER
        ,rs.OBJECT_NAME
        ,rs.SUBOBJECT_NAME
        ,v_next_object_id
        ,rs.DATA_OBJECT_ID
        ,rs.OBJECT_TYPE
        ,rs.CREATED
        ,rs.LAST_DDL_TIME
        ,rs.TIMESTAMP
        ,rs.STATUS
        ,rs.TEMPORARY
        ,rs.GENERATED
        ,rs.SECONDARY
        ,rs.NAMESPACE
        ,rs.EDITION_NAME
        ,rs.PADDING1
        ,rs.PADDING2
  	);
  END LOOP;
  SELECT COUNT(1) into v_records from tdash;
  dbms_output.put_line(chr(10));
  dbms_output.put_line('Total number of records in tdash after : '||v_records);
EXCEPTION
  WHEN OTHERS
  THEN
        DBMS_OUTPUT.PUT('Exception encountered! (');
        DBMS_OUTPUT.PUT_LINE(SQLCODE || '): ' || SQLERRM);
END;
/
EXIT
