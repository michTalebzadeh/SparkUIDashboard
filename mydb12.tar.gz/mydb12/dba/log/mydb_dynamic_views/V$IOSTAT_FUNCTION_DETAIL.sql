 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FUNCTION_ID									   NUMBER
 FUNCTION_NAME									   VARCHAR2(18)
 FILETYPE_ID									   NUMBER
 FILETYPE_NAME									   VARCHAR2(28)
 SMALL_READ_MEGABYTES								   NUMBER
 SMALL_WRITE_MEGABYTES								   NUMBER
 LARGE_READ_MEGABYTES								   NUMBER
 LARGE_WRITE_MEGABYTES								   NUMBER
 SMALL_READ_REQS								   NUMBER
 SMALL_WRITE_REQS								   NUMBER
 LARGE_READ_REQS								   NUMBER
 LARGE_WRITE_REQS								   NUMBER
 NUMBER_OF_WAITS								   NUMBER
 WAIT_TIME									   NUMBER

