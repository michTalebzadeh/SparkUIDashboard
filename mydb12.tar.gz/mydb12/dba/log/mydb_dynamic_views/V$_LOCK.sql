 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 LADDR										   RAW(4)
 KADDR										   RAW(4)
 SADDR										   RAW(4)
 RADDR										   RAW(4)
 LMODE										   NUMBER
 REQUEST									   NUMBER
 CTIME										   NUMBER
 BLOCK										   NUMBER

