--set autotrace traceonly
alter system flush buffer_cache;
set autotrace on
set timing on
select 
	cust_id "Customer ID",
count(amount_sold) "Number of orders",
sum(amount_sold) "Total customer's amount",
avg(amount_sold) "Average order",
sqrt((sum(power(amount_sold,2))-(count(1)*power(avg(amount_sold),2)))/(count(1)-1)) "Standard deviation"
from sales
group by cust_id
having sum(amount_sold) > 94000
and avg(amount_sold) < sqrt((sum(power(amount_sold,2))-(count(1)*power(avg(amount_sold),2)))/(count(1)-1)) 
order by 3 desc;
exit

