 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 RECID										   NUMBER
 STAMP										   NUMBER
 DEVICE_TYPE									   VARCHAR2(17)
 HANDLE 									   VARCHAR2(513)
 COMMENTS									   VARCHAR2(81)
 MEDIA										   VARCHAR2(65)
 MEDIA_POOL									   NUMBER
 TAG										   VARCHAR2(32)
 STATUS 									   VARCHAR2(1)
 DELETED									   VARCHAR2(3)
 THREAD#									   NUMBER
 SEQUENCE#									   NUMBER
 RESETLOGS_CHANGE#								   NUMBER
 RESETLOGS_TIME 								   DATE
 FIRST_CHANGE#									   NUMBER
 FIRST_TIME									   DATE
 NEXT_CHANGE#									   NUMBER
 NEXT_TIME									   DATE
 BLOCKS 									   NUMBER
 BLOCK_SIZE									   NUMBER
 START_TIME									   DATE
 COMPLETION_TIME								   DATE
 ELAPSED_SECONDS								   NUMBER
 RMAN_STATUS_RECID								   NUMBER
 RMAN_STATUS_STAMP								   NUMBER
 TERMINAL									   VARCHAR2(3)
 KEEP										   VARCHAR2(3)
 KEEP_UNTIL									   DATE
 KEEP_OPTIONS									   VARCHAR2(11)

