 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 OCCUPANT_NAME									   VARCHAR2(64)
 OCCUPANT_DESC									   VARCHAR2(64)
 SCHEMA_NAME									   VARCHAR2(64)
 MOVE_PROCEDURE 								   VARCHAR2(64)
 MOVE_PROCEDURE_DESC								   VARCHAR2(64)
 SPACE_USAGE_KBYTES								   NUMBER

