 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SESSION_KEY									   NUMBER
 SESSION_RECID									   NUMBER
 SESSION_STAMP									   NUMBER
 COPY_KEY									   NUMBER
 FILE#										   NUMBER
 NAME										   VARCHAR2(513)
 TAG										   VARCHAR2(32)
 CREATION_CHANGE#								   NUMBER
 CREATION_TIME									   DATE
 CHECKPOINT_CHANGE#								   NUMBER
 CHECKPOINT_TIME								   DATE
 MARKED_CORRUPT 								   NUMBER
 OUTPUT_BYTES									   NUMBER
 COMPLETION_TIME								   DATE
 CONTROLFILE_TYPE								   VARCHAR2(1)
 KEEP										   VARCHAR2(3)
 KEEP_UNTIL									   DATE
 KEEP_OPTIONS									   VARCHAR2(11)
 IS_RECOVERY_DEST_FILE								   VARCHAR2(3)
 OUTPUT_BYTES_DISPLAY								   VARCHAR2(4000)

