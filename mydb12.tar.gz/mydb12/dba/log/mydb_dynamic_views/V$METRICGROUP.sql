 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 GROUP_ID									   NUMBER
 NAME										   VARCHAR2(64)
 INTERVAL_SIZE									   NUMBER
 MAX_INTERVAL									   NUMBER

