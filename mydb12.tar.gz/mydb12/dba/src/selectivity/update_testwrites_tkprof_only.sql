alter system flush buffer_cache;
alter system flush shared_pool;
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'ssdtester_update_testwrites_tkprof_only';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
UPDATE testwrites
SET PADDING1 = RPAD('y',4000,'y')
WHERE object_id BETWEEN 10000 AND 200000;
commit;
exit
