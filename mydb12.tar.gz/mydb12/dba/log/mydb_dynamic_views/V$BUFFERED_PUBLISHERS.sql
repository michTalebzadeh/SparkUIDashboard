 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 QUEUE_ID									   NUMBER
 QUEUE_SCHEMA									   VARCHAR2(30)
 QUEUE_NAME									   VARCHAR2(30)
 SENDER_NAME									   VARCHAR2(30)
 SENDER_ADDRESS 								   VARCHAR2(1024)
 SENDER_PROTOCOL								   NUMBER
 NUM_MSGS									   NUMBER
 CNUM_MSGS									   NUMBER
 LAST_ENQUEUED_MSG								   NUMBER
 UNBROWSED_MSGS 								   NUMBER
 OVERSPILLED_MSGS								   NUMBER
 MEMORY_USAGE									   NUMBER
 ELAPSED_ENQUEUE_TIME								   NUMBER
 ENQUEUE_CPU_TIME								   NUMBER
 LAST_ENQUEUE_TIME								   TIMESTAMP(3) WITH TIME ZONE
 PUBLISHER_STATE								   VARCHAR2(59)

