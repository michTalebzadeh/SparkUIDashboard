use test
go
drop table SMALLSALES
go
 CREATE existing table SMALLSALES
 (
  PROD_ID        int                        NOT NULL,
  CUST_ID        int                        NOT NULL,
  TIME_ID        datetime                     NOT NULL,
  CHANNEL_ID     int                        NOT NULL,
  PROMO_ID       int                        NOT NULL,
  QUANTITY_SOLD  decimal(10,2)                NOT NULL,
  AMOUNT_SOLD    decimal(10,2)                NOT NULL
 )
at 'DCORACLE..system.SMALLSALES'
go
sp_help SMALLSALES
go

