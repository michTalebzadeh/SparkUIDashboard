--exec dbms_monitor.session_trace_enable( waits=>true );
--ALTER SESSION SET TRACEFILE_IDENTIFIER = 'sales';
--set autotrace on
set timing on
SELECT *
FROM
(
           SELECT
                    sales.cust_id CUST_ID,
                    COUNT(sales.amount_sold+t.amount_sold) TotalAmountSold,
                    SUM(sales.amount_sold+t.amount_sold) TotalSales,
                    AVG(sales.amount_sold+t.amount_sold) AvgAmountSold,
                    STDDEV(sales.amount_sold+t.amount_sold) STDDEV
           FROM
                   TABLE(sales_array) t,
                   sales
          WHERE
                   t.PROD_ID = sales.PROD_ID
          AND
                   t.CUST_ID = sales.CUST_ID
          AND
                   t.TIME_ID > sales.TIME_ID
          GROUP BY
                   sales.CUST_ID
          HAVING
                   SUM(sales.amount_sold+t.amount_sold) > 100000
	  AND
		   COUNT(sales.amount_sold+t.amount_sold) > 1000
          AND
                   AVG(sales.amount_sold+t.amount_sold) < STDDEV(sales.amount_sold+t.amount_sold)
   ) rs
ORDER BY rs.CUST_ID;
exit
