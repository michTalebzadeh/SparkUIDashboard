set echo on
drop table t9;
clear screen
create table t9 ( x int, y int ) tablespace manual;
insert into t9 values (1,1);
commit;
exec dbms_stats.gather_table_stats( user, 'T9' );
select * from t9;
pause
clear screen


variable a refcursor
variable b refcursor
variable c refcursor

alter session set events '10046 trace name context forever, level 12';
begin
    open :a for select * from t9 a;
    open :b for select * from t9 b;
    open :c for select * from t9 c;
end;
/
pause
clear screen
print a
pause
clear screen

begin
    for i in 1 .. 10000
    loop
        update t9 set x = x+1;
        commit;
    end loop;
end;
/

pause
clear screen
print b
update t9 set x = x+1;
commit;

print c
pause
clear screen


@tk "sys=no"

clear screen

insert into t9 values ( 1,1 );
alter table t9 move;
exec dbms_stats.gather_table_stats( user, 'T9' );
select x, dbms_rowid.rowid_block_number(rowid) from t9;
create index t9_idx on t9(x);
commit;
pause
clear screen
variable a refcursor
variable b refcursor
variable c refcursor
alter session set events '10046 trace name context forever, level 12';


begin
    open :a for select /*+ FIRST_ROWS */ * from t9 a where x > 1;
    open :b for select /*+ FIRST_ROWS */ * from t9 b where x > 1;
    open :c for select /*+ FIRST_ROWS */ * from t9 c where x > 1;
end;
/


pause
clear screen

print a


pause
clear screen

begin
    for i in 1 .. 10000
    loop
        update t9 set x = x where x = 1;
        commit;
    end loop;
end;
/

pause
clear screen

print b
print c
pause
clear screen

@tk "sys=no"


select x, dbms_rowid.rowid_block_number(rowid) from t9;
pause
clear screen
variable a refcursor
variable b refcursor
variable c refcursor
alter session set events '10046 trace name context forever, level 12';


begin
    open :a for select /*+ FIRST_ROWS */ * from t9 a where x > 1;
    open :b for select /*+ FIRST_ROWS */ * from t9 b where x > 1;
    open :c for select /*+ FIRST_ROWS */ * from t9 c where x > 1;
end;
/


pause
clear screen

print a


pause
clear screen

begin
    for i in 1 .. 10000
    loop
        update t9 set x = -x where abs(x) = 1;
        commit;
    end loop;
end;
/

pause
clear screen

print b
print c
pause
clear screen
