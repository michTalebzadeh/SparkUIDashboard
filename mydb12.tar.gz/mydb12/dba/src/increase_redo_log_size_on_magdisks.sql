ALTER DATABASE   ADD LOGFILE GROUP 1 ('/data1/oracle/mydb/redo1a.log','/data2/oracle/mydb/redo1b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 2 ('/data1/oracle/mydb/redo2a.log','/data2/oracle/mydb/redo2b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 3 ('/data1/oracle/mydb/redo3a.log','/data2/oracle/mydb/redo3b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 4 ('/data1/oracle/mydb/redo4a.log','/data2/oracle/mydb/redo4b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 5 ('/data1/oracle/mydb/redo5a.log','/data2/oracle/mydb/redo5b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 6 ('/data1/oracle/mydb/redo6a.log','/data2/oracle/mydb/redo6b.log')      SIZE 1000M REUSE;
