                 
 use skeleton
go 

                                                                                                                                                                                                                                                                              
 drop view sysquerymetrics
go                                                                                                                                                                                                                                                 

