COLUMN "Total GB" FORMAT 999,999,999
COLUMN "Redo GB" FORMAT 999,999,999
COLUMN "Temp GB" FORMAT 999,999,999
COLUMN "Data GB" FORMAT 999,999,999

Prompt
Prompt "Database Size from dba_data_files, dba_temp_files, v$log"

select (select sum(bytes/1048576/1024) from dba_data_files) "Data GB", 
(select NVL(sum(bytes/1048576/1024),0) from dba_temp_files) "Temp GB",
(select sum(bytes/1048576/1024)*max(members) from v$log) "Redo GB",
(select sum(bytes/1048576/1024) from dba_data_files) +
(select NVL(sum(bytes/1048576/1024),0) from dba_temp_files) +
(select sum(bytes/1048576/1024)*max(members) from v$log) "Total GB"
from dual;
exit

