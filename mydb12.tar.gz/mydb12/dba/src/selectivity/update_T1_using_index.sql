alter system flush buffer_cache;
alter system flush shared_pool;
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_t1_ssdtester';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
--set timing on
--set autotrace on
update T1
set ind_pad = ind_pad
where   n1 = 2
and	ind_pad <= rpad('x',39)||'x'
and     n2      < 18;
commit;
exit
