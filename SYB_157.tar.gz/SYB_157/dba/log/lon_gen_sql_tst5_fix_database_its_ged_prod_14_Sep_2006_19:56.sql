use its_ged_prod
go
dbcc traceon(3604)
go
print " "
print "======= dbcc checkdb ======="
print " "
go
dbcc checkdb
go
print " "
print "======= dbcc checkcatalog ======="
print " "
go
dbcc checkcatalog
go
print " "
print "======= dbcc checkalloc with fix option======="
print " "
go
use master
go
sp_dboption its_ged_prod,'single',true
go
use its_ged_prod
go
checkpoint
go
dbcc checkalloc(its_ged_prod,fix)
go
use master
go
sp_dboption its_ged_prod,'single',false
go
use its_ged_prod
go
checkpoint
go
sp_helpdb its_ged_prod
go
exit
