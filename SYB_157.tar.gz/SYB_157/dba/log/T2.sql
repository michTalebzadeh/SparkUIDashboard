use test
go
set switch on 3604
go
dbcc proc_cache(free_unused)
go
--set literal_autoparam off
go
set showplan on
go
set option show on -- get index selectivity
go
set statistics plancost, resource, time, io on
go
select * from T2 where small_vc ='xxx'
go
exit
