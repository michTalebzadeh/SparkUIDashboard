set echo off
set linesize 180
set pagesize 40
set heading on
break on Database skip 1 on report
break on ID skip 1 on report
break on Table skip 1 on report
SELECT
         (SELECT SUBSTR(NAME,1,15) FROM DBS d where t.db_id = d.db_id) AS Database
        , t.tbl_id AS "ID"
	, SUBSTR(t.tbl_name,1,30) AS "Table"
	, SUBSTR(p.param_key,1,50) AS "Key"
        , (CASE p.param_key
           WHEN 'transient_lastDdlTime' THEN substr((timestamp '1970-01-01 00:00:00' + numtodsinterval(p.param_value,'second')) at time zone tz_offset('GMT'),1,18)
           WHEN 'last_modified_time' THEN substr((timestamp '1970-01-01 00:00:00' + numtodsinterval(p.param_value,'second')) at time zone tz_offset('GMT'),1,18)
           WHEN 'totalSize' THEN substr(trim(to_char((to_number(p.param_value)/1024),99999999.99)),1,20)||'KB'
           WHEN 'rawDataSize' THEN substr(trim(to_char((to_number(p.param_value)/1024),99999999.99)),1,20)||'KB'
           WHEN 'EXTERNAL' THEN 'External Table'
           ELSE SUBSTR(p.param_value,1,50)
          END) Value
FROM tbls t
INNER JOIN table_params p
ON t.tbl_id = p.tbl_id
ORDER BY Database, t.tbl_id,t.tbl_name,p.param_key
;
exit
