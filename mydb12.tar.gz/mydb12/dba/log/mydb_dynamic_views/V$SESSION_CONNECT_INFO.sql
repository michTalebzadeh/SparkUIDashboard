 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 SERIAL#									   NUMBER
 AUTHENTICATION_TYPE								   VARCHAR2(26)
 OSUSER 									   VARCHAR2(30)
 NETWORK_SERVICE_BANNER 							   VARCHAR2(4000)
 CLIENT_CHARSET 								   VARCHAR2(40)
 CLIENT_CONNECTION								   VARCHAR2(13)
 CLIENT_OCI_LIBRARY								   VARCHAR2(27)
 CLIENT_VERSION 								   VARCHAR2(40)
 CLIENT_DRIVER									   VARCHAR2(9)
 CLIENT_LOBATTR 								   VARCHAR2(23)
 CLIENT_REGID									   NUMBER

