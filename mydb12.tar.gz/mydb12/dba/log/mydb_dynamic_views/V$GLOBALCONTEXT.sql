 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 NAMESPACE									   VARCHAR2(30)
 ATTRIBUTE									   VARCHAR2(30)
 VALUE										   VARCHAR2(4000)
 USERNAME									   VARCHAR2(30)
 CLIENT_IDENTIFIER								   VARCHAR2(65)

