use master
go
set nocount on
go
checkpoint
go
declare @msg char(100), @errorno int
dump tran its_ged_prod with truncate_only
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Tue Jan 22 00:30:12 GMT 2002 db_dump_adsm.ksh Dump of its_ged_prod log failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go
declare @msg char(100), @errorno int
dump database its_ged_prod to "/apps/sybase/dump/lon_gedimg_sql_prd/its_ged_prod.dmp.stripe1" stripe on "/apps/sybase/dump/lon_gedimg_sql_prd/its_ged_prod.dmp.stripe2" stripe on "/apps/sybase/dump/lon_gedimg_sql_prd/its_ged_prod.dmp.stripe3" stripe on "/apps/sybase/dump/lon_gedimg_sql_prd/its_ged_prod.dmp.stripe4"
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Tue Jan 22 00:30:12 GMT 2002 db_dump_adsm.ksh Dump of its_ged_prod failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go

