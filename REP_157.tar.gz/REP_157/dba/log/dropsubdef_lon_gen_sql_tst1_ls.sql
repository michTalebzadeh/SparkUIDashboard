--
------> table its_ged_prod.dbGED_usereq_acctconf_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_acctconf_tb_ls for dbGED_usereq_acctconf_tb_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_accttype_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_accttype_tb_ls for dbGED_usereq_accttype_tb_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_bizarea_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_bizarea_tb_ls for dbGED_usereq_bizarea_tb_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_confdef_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_confdef_tb_ls for dbGED_usereq_confdef_tb_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_groups_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_groups_tb_ls for dbGED_usereq_groups_tb_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_location_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_location_tb_ls for dbGED_usereq_location_tb_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_super_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_super_tb_ls for dbGED_usereq_super_tb_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_userreq_new_tb <------
--
DROP SUBSCRIPTION dbGED_userreq_new_tb_ls for dbGED_userreq_new_tb_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbJobStatus <------
--
DROP SUBSCRIPTION dbJobStatus_ls for dbJobStatus_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStageDividend <------
--
DROP SUBSCRIPTION dbStageDividend_ls for dbStageDividend_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStageDividend_Old <------
--
DROP SUBSCRIPTION dbStageDividend_Old_ls for dbStageDividend_Old_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStageRicRef <------
--
DROP SUBSCRIPTION dbStageRicRef_ls for dbStageRicRef_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStageStock <------
--
DROP SUBSCRIPTION dbStageStock_ls for dbStageStock_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStageStock_Old <------
--
DROP SUBSCRIPTION dbStageStock_Old_ls for dbStageStock_Old_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStar_Input <------
--
DROP SUBSCRIPTION dbStar_Input_ls for dbStar_Input_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStar_Input1 <------
--
DROP SUBSCRIPTION dbStar_Input1_ls for dbStar_Input1_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_EOD_blotter_extra <------
--
DROP SUBSCRIPTION db_EOD_blotter_extra_ls for db_EOD_blotter_extra_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_EOD_blotter_sec_data <------
--
DROP SUBSCRIPTION db_EOD_blotter_sec_data_ls for db_EOD_blotter_sec_data_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_EOD_blotter_signoff <------
--
DROP SUBSCRIPTION db_EOD_blotter_signoff_ls for db_EOD_blotter_signoff_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_EOD_blotter_status <------
--
DROP SUBSCRIPTION db_EOD_blotter_status_ls for db_EOD_blotter_status_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_EOD_blotter_trades <------
--
DROP SUBSCRIPTION db_EOD_blotter_trades_ls for db_EOD_blotter_trades_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_YC_Upload_Ccys <------
--
DROP SUBSCRIPTION db_YC_Upload_Ccys_ls for db_YC_Upload_Ccys_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_alternate_code <------
--
DROP SUBSCRIPTION db_alternate_code_ls for db_alternate_code_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_asian_history <------
--
DROP SUBSCRIPTION db_asian_history_ls for db_asian_history_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_autolaunchLedgers <------
--
DROP SUBSCRIPTION db_autolaunchLedgers_ls for db_autolaunchLedgers_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_autolaunchUsers <------
--
DROP SUBSCRIPTION db_autolaunchUsers_ls for db_autolaunchUsers_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_average_trade_err <------
--
DROP SUBSCRIPTION db_average_trade_err_ls for db_average_trade_err_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_average_trade_list <------
--
DROP SUBSCRIPTION db_average_trade_list_ls for db_average_trade_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_average_trade_xref <------
--
DROP SUBSCRIPTION db_average_trade_xref_ls for db_average_trade_xref_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_error <------
--
DROP SUBSCRIPTION db_avg_error_ls for db_avg_error_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_exec_xref <------
--
DROP SUBSCRIPTION db_avg_exec_xref_ls for db_avg_exec_xref_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_exec_xref_audit <------
--
DROP SUBSCRIPTION db_avg_exec_xref_audit_ls for db_avg_exec_xref_audit_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_netting_grp <------
--
DROP SUBSCRIPTION db_avg_netting_grp_ls for db_avg_netting_grp_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_netting_grp_audit <------
--
DROP SUBSCRIPTION db_avg_netting_grp_audit_ls for db_avg_netting_grp_audit_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule <------
--
DROP SUBSCRIPTION db_avg_rule_ls for db_avg_rule_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_audit <------
--
DROP SUBSCRIPTION db_avg_rule_audit_ls for db_avg_rule_audit_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_except_audit <------
--
DROP SUBSCRIPTION db_avg_rule_except_audit_ls for db_avg_rule_except_audit_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_exception <------
--
DROP SUBSCRIPTION db_avg_rule_exception_ls for db_avg_rule_exception_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_set <------
--
DROP SUBSCRIPTION db_avg_rule_set_ls for db_avg_rule_set_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_set_audit <------
--
DROP SUBSCRIPTION db_avg_rule_set_audit_ls for db_avg_rule_set_audit_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_type <------
--
DROP SUBSCRIPTION db_avg_rule_type_ls for db_avg_rule_type_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_trade <------
--
DROP SUBSCRIPTION db_avg_trade_ls for db_avg_trade_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_trade_audit <------
--
DROP SUBSCRIPTION db_avg_trade_audit_ls for db_avg_trade_audit_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_calendar_map <------
--
DROP SUBSCRIPTION db_calendar_map_ls for db_calendar_map_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_column_defaults <------
--
DROP SUBSCRIPTION db_column_defaults_ls for db_column_defaults_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_curve_missing_map <------
--
DROP SUBSCRIPTION db_curve_missing_map_ls for db_curve_missing_map_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_div_tax_rules <------
--
DROP SUBSCRIPTION db_div_tax_rules_ls for db_div_tax_rules_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_error_message <------
--
DROP SUBSCRIPTION db_error_message_ls for db_error_message_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_eurex_defaults <------
--
DROP SUBSCRIPTION db_eurex_defaults_ls for db_eurex_defaults_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_eurex_xetra_ar_prod <------
--
DROP SUBSCRIPTION db_eurex_xetra_ar_prod_ls for db_eurex_xetra_ar_prod_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_eurex_xetra_routing <------
--
DROP SUBSCRIPTION db_eurex_xetra_routing_ls for db_eurex_xetra_routing_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_eurex_xetra_trades <------
--
DROP SUBSCRIPTION db_eurex_xetra_trades_ls for db_eurex_xetra_trades_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_eurex_xetra_trades_arc <------
--
DROP SUBSCRIPTION db_eurex_xetra_trades_arc_ls for db_eurex_xetra_trades_arc_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_excep_price_env <------
--
DROP SUBSCRIPTION db_excep_price_env_ls for db_excep_price_env_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_imagine_user_dealer_map <------
--
DROP SUBSCRIPTION db_imagine_user_dealer_map_ls for db_imagine_user_dealer_map_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_last_message <------
--
DROP SUBSCRIPTION db_last_message_ls for db_last_message_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_mark_errors <------
--
DROP SUBSCRIPTION db_mark_errors_ls for db_mark_errors_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_auto_routed_products <------
--
DROP SUBSCRIPTION db_orc_auto_routed_products_ls for db_orc_auto_routed_products_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_auto_routing <------
--
DROP SUBSCRIPTION db_orc_auto_routing_ls for db_orc_auto_routing_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_exch_sett_date <------
--
DROP SUBSCRIPTION db_orc_exch_sett_date_ls for db_orc_exch_sett_date_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_exchange <------
--
DROP SUBSCRIPTION db_orc_exchange_ls for db_orc_exchange_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_exec_id <------
--
DROP SUBSCRIPTION db_orc_exec_id_ls for db_orc_exec_id_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_executions <------
--
DROP SUBSCRIPTION db_orc_executions_ls for db_orc_executions_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_executions_hist <------
--
DROP SUBSCRIPTION db_orc_executions_hist_ls for db_orc_executions_hist_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_heartbeat <------
--
DROP SUBSCRIPTION db_orc_heartbeat_ls for db_orc_heartbeat_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_imag_warrant_recon <------
--
DROP SUBSCRIPTION db_orc_imag_warrant_recon_ls for db_orc_imag_warrant_recon_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_portfolio <------
--
DROP SUBSCRIPTION db_orc_portfolio_ls for db_orc_portfolio_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_process_state <------
--
DROP SUBSCRIPTION db_orc_process_state_ls for db_orc_process_state_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_sec_exchange <------
--
DROP SUBSCRIPTION db_orc_sec_exchange_ls for db_orc_sec_exchange_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_trade_id_map <------
--
DROP SUBSCRIPTION db_orc_trade_id_map_ls for db_orc_trade_id_map_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_trade_recon <------
--
DROP SUBSCRIPTION db_orc_trade_recon_ls for db_orc_trade_recon_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_trader <------
--
DROP SUBSCRIPTION db_orc_trader_ls for db_orc_trader_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_underlying <------
--
DROP SUBSCRIPTION db_orc_underlying_ls for db_orc_underlying_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_warrant_recon <------
--
DROP SUBSCRIPTION db_orc_warrant_recon_ls for db_orc_warrant_recon_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_audit <------
--
DROP SUBSCRIPTION db_perm_audit_ls for db_perm_audit_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_bus_cat <------
--
DROP SUBSCRIPTION db_perm_bus_cat_ls for db_perm_bus_cat_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_business <------
--
DROP SUBSCRIPTION db_perm_business_ls for db_perm_business_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_resources <------
--
DROP SUBSCRIPTION db_perm_resources_ls for db_perm_resources_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_role <------
--
DROP SUBSCRIPTION db_perm_role_ls for db_perm_role_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_supervisor <------
--
DROP SUBSCRIPTION db_perm_supervisor_ls for db_perm_supervisor_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_users <------
--
DROP SUBSCRIPTION db_perm_users_ls for db_perm_users_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_pre_volatility_detail <------
--
DROP SUBSCRIPTION db_pre_volatility_detail_ls for db_pre_volatility_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_recon_position_log <------
--
DROP SUBSCRIPTION db_recon_position_log_ls for db_recon_position_log_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_recon_trade_log <------
--
DROP SUBSCRIPTION db_recon_trade_log_ls for db_recon_trade_log_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_rolled_market_prices <------
--
DROP SUBSCRIPTION db_rolled_market_prices_ls for db_rolled_market_prices_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_script_parameters <------
--
DROP SUBSCRIPTION db_script_parameters_ls for db_script_parameters_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_security_codes <------
--
DROP SUBSCRIPTION db_security_codes_ls for db_security_codes_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_status_history <------
--
DROP SUBSCRIPTION db_status_history_ls for db_status_history_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_swx_trade_reporting <------
--
DROP SUBSCRIPTION db_swx_trade_reporting_ls for db_swx_trade_reporting_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_temp_market_price <------
--
DROP SUBSCRIPTION db_temp_market_price_ls for db_temp_market_price_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets <------
--
DROP SUBSCRIPTION db_tickets_ls for db_tickets_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets_approval_options <------
--
DROP SUBSCRIPTION db_tickets_approval_options_ls for db_tickets_approval_options_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets_comments <------
--
DROP SUBSCRIPTION db_tickets_comments_ls for db_tickets_comments_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets_exec_queue <------
--
DROP SUBSCRIPTION db_tickets_exec_queue_ls for db_tickets_exec_queue_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets_status_history <------
--
DROP SUBSCRIPTION db_tickets_status_history_ls for db_tickets_status_history_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets_user <------
--
DROP SUBSCRIPTION db_tickets_user_ls for db_tickets_user_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trader_permissions <------
--
DROP SUBSCRIPTION db_trader_permissions_ls for db_trader_permissions_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trading_account <------
--
DROP SUBSCRIPTION db_trading_account_ls for db_trading_account_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trading_book <------
--
DROP SUBSCRIPTION db_trading_book_ls for db_trading_book_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trading_desk <------
--
DROP SUBSCRIPTION db_trading_desk_ls for db_trading_desk_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trading_view <------
--
DROP SUBSCRIPTION db_trading_view_ls for db_trading_view_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trading_webview <------
--
DROP SUBSCRIPTION db_trading_webview_ls for db_trading_webview_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_ts_adjustment <------
--
DROP SUBSCRIPTION db_ts_adjustment_ls for db_ts_adjustment_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_valid_interface_users <------
--
DROP SUBSCRIPTION db_valid_interface_users_ls for db_valid_interface_users_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_volatility_ancillary <------
--
DROP SUBSCRIPTION db_volatility_ancillary_ls for db_volatility_ancillary_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_xetra_defaults <------
--
DROP SUBSCRIPTION db_xetra_defaults_ls for db_xetra_defaults_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_xol_master_list <------
--
DROP SUBSCRIPTION db_xol_master_list_ls for db_xol_master_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_xol_outgoing_ca <------
--
DROP SUBSCRIPTION db_xol_outgoing_ca_ls for db_xol_outgoing_ca_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dba_check_rep_delay <------
--
DROP SUBSCRIPTION dba_check_rep_delay_ls for dba_check_rep_delay_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbs_COUNTER <------
--
DROP SUBSCRIPTION dbs_COUNTER_ls for dbs_COUNTER_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_kueu_file <------
--
DROP SUBSCRIPTION dbt_kueu_file_ls for dbt_kueu_file_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_sec_map <------
--
DROP SUBSCRIPTION dbt_sec_map_ls for dbt_sec_map_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_sec_type_mapping <------
--
DROP SUBSCRIPTION dbt_sec_type_mapping_ls for dbt_sec_type_mapping_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_sequence <------
--
DROP SUBSCRIPTION dbt_sequence_ls for dbt_sequence_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_trade_target <------
--
DROP SUBSCRIPTION dbt_trade_target_ls for dbt_trade_target_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_trade_target_temp <------
--
DROP SUBSCRIPTION dbt_trade_target_temp_ls for dbt_trade_target_temp_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_trade_triggers <------
--
DROP SUBSCRIPTION dbt_trade_triggers_ls for dbt_trade_triggers_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbtrader_secm <------
--
DROP SUBSCRIPTION dbtrader_secm_ls for dbtrader_secm_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.euro_rates <------
--
DROP SUBSCRIPTION euro_rates_ls for euro_rates_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.exec_queue_errors <------
--
DROP SUBSCRIPTION exec_queue_errors_ls for exec_queue_errors_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.gedi_admin_status <------
--
DROP SUBSCRIPTION gedi_admin_status_ls for gedi_admin_status_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_account <------
--
DROP SUBSCRIPTION hts_account_ls for hts_account_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_action_profile <------
--
DROP SUBSCRIPTION hts_action_profile_ls for hts_action_profile_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_action_profile_list <------
--
DROP SUBSCRIPTION hts_action_profile_list_ls for hts_action_profile_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_adjustment <------
--
DROP SUBSCRIPTION hts_adjustment_ls for hts_adjustment_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_adjustment_user_data <------
--
DROP SUBSCRIPTION hts_adjustment_user_data_ls for hts_adjustment_user_data_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ae_codes <------
--
DROP SUBSCRIPTION hts_ae_codes_ls for hts_ae_codes_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_audit_status <------
--
DROP SUBSCRIPTION hts_audit_status_ls for hts_audit_status_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_auto_quote <------
--
DROP SUBSCRIPTION hts_auto_quote_ls for hts_auto_quote_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_b2b_trade_event <------
--
DROP SUBSCRIPTION hts_b2b_trade_event_ls for hts_b2b_trade_event_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ba_spread_class <------
--
DROP SUBSCRIPTION hts_ba_spread_class_ls for hts_ba_spread_class_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ba_spread_detail <------
--
DROP SUBSCRIPTION hts_ba_spread_detail_ls for hts_ba_spread_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ba_spread_list <------
--
DROP SUBSCRIPTION hts_ba_spread_list_ls for hts_ba_spread_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_balance_transfer_log <------
--
DROP SUBSCRIPTION hts_balance_transfer_log_ls for hts_balance_transfer_log_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_basis_detail <------
--
DROP SUBSCRIPTION hts_basis_detail_ls for hts_basis_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_basis_list <------
--
DROP SUBSCRIPTION hts_basis_list_ls for hts_basis_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_bo_event <------
--
DROP SUBSCRIPTION hts_bo_event_ls for hts_bo_event_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_borrow_detail <------
--
DROP SUBSCRIPTION hts_borrow_detail_ls for hts_borrow_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_borrow_list <------
--
DROP SUBSCRIPTION hts_borrow_list_ls for hts_borrow_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_broker <------
--
DROP SUBSCRIPTION hts_broker_ls for hts_broker_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_broker_user_data <------
--
DROP SUBSCRIPTION hts_broker_user_data_ls for hts_broker_user_data_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_bs_codes <------
--
DROP SUBSCRIPTION hts_bs_codes_ls for hts_bs_codes_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ca_event <------
--
DROP SUBSCRIPTION hts_ca_event_ls for hts_ca_event_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_capreq_basket <------
--
DROP SUBSCRIPTION hts_capreq_basket_ls for hts_capreq_basket_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_capreq_divisors <------
--
DROP SUBSCRIPTION hts_capreq_divisors_ls for hts_capreq_divisors_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_capreq_overrides <------
--
DROP SUBSCRIPTION hts_capreq_overrides_ls for hts_capreq_overrides_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_capreq_xref <------
--
DROP SUBSCRIPTION hts_capreq_xref_ls for hts_capreq_xref_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_cash_coll_sched <------
--
DROP SUBSCRIPTION hts_cash_coll_sched_ls for hts_cash_coll_sched_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ccy_round <------
--
DROP SUBSCRIPTION hts_ccy_round_ls for hts_ccy_round_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_interval <------
--
DROP SUBSCRIPTION hts_charge_interval_ls for hts_charge_interval_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_rule <------
--
DROP SUBSCRIPTION hts_charge_rule_ls for hts_charge_rule_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_sched_detail <------
--
DROP SUBSCRIPTION hts_charge_sched_detail_ls for hts_charge_sched_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_sched_list <------
--
DROP SUBSCRIPTION hts_charge_sched_list_ls for hts_charge_sched_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_schedule <------
--
DROP SUBSCRIPTION hts_charge_schedule_ls for hts_charge_schedule_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_type <------
--
DROP SUBSCRIPTION hts_charge_type_ls for hts_charge_type_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_coll_pool <------
--
DROP SUBSCRIPTION hts_coll_pool_ls for hts_coll_pool_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_collateral <------
--
DROP SUBSCRIPTION hts_collateral_ls for hts_collateral_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_constituent <------
--
DROP SUBSCRIPTION hts_constituent_ls for hts_constituent_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_corr_detail <------
--
DROP SUBSCRIPTION hts_corr_detail_ls for hts_corr_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_corr_list <------
--
DROP SUBSCRIPTION hts_corr_list_ls for hts_corr_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_country <------
--
DROP SUBSCRIPTION hts_country_ls for hts_country_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_credit_ratings <------
--
DROP SUBSCRIPTION hts_credit_ratings_ls for hts_credit_ratings_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_credit_spreads <------
--
DROP SUBSCRIPTION hts_credit_spreads_ls for hts_credit_spreads_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_credit_spreads_list <------
--
DROP SUBSCRIPTION hts_credit_spreads_list_ls for hts_credit_spreads_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_customer <------
--
DROP SUBSCRIPTION hts_customer_ls for hts_customer_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_customer_usage <------
--
DROP SUBSCRIPTION hts_customer_usage_ls for hts_customer_usage_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_data_relation <------
--
DROP SUBSCRIPTION hts_data_relation_ls for hts_data_relation_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbl_log <------
--
DROP SUBSCRIPTION hts_dbl_log_ls for hts_dbl_log_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbl_trade_log <------
--
DROP SUBSCRIPTION hts_dbl_trade_log_ls for hts_dbl_trade_log_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbt_fee_map <------
--
DROP SUBSCRIPTION hts_dbt_fee_map_ls for hts_dbt_fee_map_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbt_fi_sec <------
--
DROP SUBSCRIPTION hts_dbt_fi_sec_ls for hts_dbt_fi_sec_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbt_system_route <------
--
DROP SUBSCRIPTION hts_dbt_system_route_ls for hts_dbt_system_route_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbt_xfce <------
--
DROP SUBSCRIPTION hts_dbt_xfce_ls for hts_dbt_xfce_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_deal <------
--
DROP SUBSCRIPTION hts_deal_ls for hts_deal_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dividend_detail <------
--
DROP SUBSCRIPTION hts_dividend_detail_ls for hts_dividend_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dividend_list <------
--
DROP SUBSCRIPTION hts_dividend_list_ls for hts_dividend_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dynamic_apps <------
--
DROP SUBSCRIPTION hts_dynamic_apps_ls for hts_dynamic_apps_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dynrule_list <------
--
DROP SUBSCRIPTION hts_dynrule_list_ls for hts_dynrule_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_emu_conv_event <------
--
DROP SUBSCRIPTION hts_emu_conv_event_ls for hts_emu_conv_event_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_eqcd_detail <------
--
DROP SUBSCRIPTION hts_eqcd_detail_ls for hts_eqcd_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_event_types <------
--
DROP SUBSCRIPTION hts_event_types_ls for hts_event_types_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_exchange <------
--
DROP SUBSCRIPTION hts_exchange_ls for hts_exchange_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_exchange_snap_status <------
--
DROP SUBSCRIPTION hts_exchange_snap_status_ls for hts_exchange_snap_status_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_exec_adj <------
--
DROP SUBSCRIPTION hts_exec_adj_ls for hts_exec_adj_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_exec_control <------
--
DROP SUBSCRIPTION hts_exec_control_ls for hts_exec_control_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_exer_notice <------
--
DROP SUBSCRIPTION hts_exer_notice_ls for hts_exer_notice_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_fi_sec_master <------
--
DROP SUBSCRIPTION hts_fi_sec_master_ls for hts_fi_sec_master_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_filter_columns <------
--
DROP SUBSCRIPTION hts_filter_columns_ls for hts_filter_columns_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_filter_detail <------
--
DROP SUBSCRIPTION hts_filter_detail_ls for hts_filter_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_filter_list <------
--
DROP SUBSCRIPTION hts_filter_list_ls for hts_filter_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_fiscal_calendar <------
--
DROP SUBSCRIPTION hts_fiscal_calendar_ls for hts_fiscal_calendar_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_fixings <------
--
DROP SUBSCRIPTION hts_fixings_ls for hts_fixings_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_formula_rule_detail <------
--
DROP SUBSCRIPTION hts_formula_rule_detail_ls for hts_formula_rule_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_formula_rule_list <------
--
DROP SUBSCRIPTION hts_formula_rule_list_ls for hts_formula_rule_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_funding_rates <------
--
DROP SUBSCRIPTION hts_funding_rates_ls for hts_funding_rates_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_fx_detail <------
--
DROP SUBSCRIPTION hts_fx_detail_ls for hts_fx_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_fx_list <------
--
DROP SUBSCRIPTION hts_fx_list_ls for hts_fx_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_gen_otc <------
--
DROP SUBSCRIPTION hts_gen_otc_ls for hts_gen_otc_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_gen_sec_types <------
--
DROP SUBSCRIPTION hts_gen_sec_types_ls for hts_gen_sec_types_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_genfilter_cells <------
--
DROP SUBSCRIPTION hts_genfilter_cells_ls for hts_genfilter_cells_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_genfilter_columns <------
--
DROP SUBSCRIPTION hts_genfilter_columns_ls for hts_genfilter_columns_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_genfilter_detail <------
--
DROP SUBSCRIPTION hts_genfilter_detail_ls for hts_genfilter_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_gotc_rebate_pay_types <------
--
DROP SUBSCRIPTION hts_gotc_rebate_pay_types_ls for hts_gotc_rebate_pay_types_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_gotc_schedule <------
--
DROP SUBSCRIPTION hts_gotc_schedule_ls for hts_gotc_schedule_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_gotc_trigger_types <------
--
DROP SUBSCRIPTION hts_gotc_trigger_types_ls for hts_gotc_trigger_types_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_group <------
--
DROP SUBSCRIPTION hts_group_ls for hts_group_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_group_control <------
--
DROP SUBSCRIPTION hts_group_control_ls for hts_group_control_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_historical_prices <------
--
DROP SUBSCRIPTION hts_historical_prices_ls for hts_historical_prices_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_hold_audit_trail_log <------
--
DROP SUBSCRIPTION hts_hold_audit_trail_log_ls for hts_hold_audit_trail_log_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_hold_map <------
--
DROP SUBSCRIPTION hts_hold_map_ls for hts_hold_map_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_hold_user_data <------
--
DROP SUBSCRIPTION hts_hold_user_data_ls for hts_hold_user_data_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_holding_greeks <------
--
DROP SUBSCRIPTION hts_holding_greeks_ls for hts_holding_greeks_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_holiday_detail <------
--
DROP SUBSCRIPTION hts_holiday_detail_ls for hts_holiday_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_holiday_list <------
--
DROP SUBSCRIPTION hts_holiday_list_ls for hts_holiday_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_industry <------
--
DROP SUBSCRIPTION hts_industry_ls for hts_industry_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_irate_source <------
--
DROP SUBSCRIPTION hts_irate_source_ls for hts_irate_source_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_issuer <------
--
DROP SUBSCRIPTION hts_issuer_ls for hts_issuer_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_issuer_related_view <------
--
DROP SUBSCRIPTION hts_issuer_related_view_ls for hts_issuer_related_view_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_legacy_stock_split <------
--
DROP SUBSCRIPTION hts_legacy_stock_split_ls for hts_legacy_stock_split_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_legal_entity <------
--
DROP SUBSCRIPTION hts_legal_entity_ls for hts_legal_entity_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_lim_cmb_type <------
--
DROP SUBSCRIPTION hts_lim_cmb_type_ls for hts_lim_cmb_type_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_limit_detail <------
--
DROP SUBSCRIPTION hts_limit_detail_ls for hts_limit_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_limit_field <------
--
DROP SUBSCRIPTION hts_limit_field_ls for hts_limit_field_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_limit_list <------
--
DROP SUBSCRIPTION hts_limit_list_ls for hts_limit_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_limit_monitor_event <------
--
DROP SUBSCRIPTION hts_limit_monitor_event_ls for hts_limit_monitor_event_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_location <------
--
DROP SUBSCRIPTION hts_location_ls for hts_location_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_lock <------
--
DROP SUBSCRIPTION hts_lock_ls for hts_lock_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_mark <------
--
DROP SUBSCRIPTION hts_mark_ls for hts_mark_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_mark_acct <------
--
DROP SUBSCRIPTION hts_mark_acct_ls for hts_mark_acct_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_market_price <------
--
DROP SUBSCRIPTION hts_market_price_ls for hts_market_price_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_mmkt_usec <------
--
DROP SUBSCRIPTION hts_mmkt_usec_ls for hts_mmkt_usec_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_monitor_limit <------
--
DROP SUBSCRIPTION hts_monitor_limit_ls for hts_monitor_limit_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_name_change_notice <------
--
DROP SUBSCRIPTION hts_name_change_notice_ls for hts_name_change_notice_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_nosplit <------
--
DROP SUBSCRIPTION hts_nosplit_ls for hts_nosplit_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_object_limit <------
--
DROP SUBSCRIPTION hts_object_limit_ls for hts_object_limit_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_opt_exer_event <------
--
DROP SUBSCRIPTION hts_opt_exer_event_ls for hts_opt_exer_event_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ord_control <------
--
DROP SUBSCRIPTION hts_ord_control_ls for hts_ord_control_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ordhdg_group_detail <------
--
DROP SUBSCRIPTION hts_ordhdg_group_detail_ls for hts_ordhdg_group_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ordhdg_group_list <------
--
DROP SUBSCRIPTION hts_ordhdg_group_list_ls for hts_ordhdg_group_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_pc_codes <------
--
DROP SUBSCRIPTION hts_pc_codes_ls for hts_pc_codes_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_perm_control <------
--
DROP SUBSCRIPTION hts_perm_control_ls for hts_perm_control_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_pl_archive <------
--
DROP SUBSCRIPTION hts_pl_archive_ls for hts_pl_archive_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_port_control <------
--
DROP SUBSCRIPTION hts_port_control_ls for hts_port_control_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_price_detail <------
--
DROP SUBSCRIPTION hts_price_detail_ls for hts_price_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_price_env <------
--
DROP SUBSCRIPTION hts_price_env_ls for hts_price_env_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_price_list <------
--
DROP SUBSCRIPTION hts_price_list_ls for hts_price_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_profit_loss <------
--
DROP SUBSCRIPTION hts_profit_loss_ls for hts_profit_loss_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_quote_rule <------
--
DROP SUBSCRIPTION hts_quote_rule_ls for hts_quote_rule_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_quote_rule_spreads <------
--
DROP SUBSCRIPTION hts_quote_rule_spreads_ls for hts_quote_rule_spreads_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_registry <------
--
DROP SUBSCRIPTION hts_registry_ls for hts_registry_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_regulatory_agency <------
--
DROP SUBSCRIPTION hts_regulatory_agency_ls for hts_regulatory_agency_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_replication_status <------
--
DROP SUBSCRIPTION hts_replication_status_ls for hts_replication_status_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_restricted_sec <------
--
DROP SUBSCRIPTION hts_restricted_sec_ls for hts_restricted_sec_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_reuters_masks <------
--
DROP SUBSCRIPTION hts_reuters_masks_ls for hts_reuters_masks_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_rm_ccy_default <------
--
DROP SUBSCRIPTION hts_rm_ccy_default_ls for hts_rm_ccy_default_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_roll_detail <------
--
DROP SUBSCRIPTION hts_roll_detail_ls for hts_roll_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_roll_list <------
--
DROP SUBSCRIPTION hts_roll_list_ls for hts_roll_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_scenario_maps <------
--
DROP SUBSCRIPTION hts_scenario_maps_ls for hts_scenario_maps_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sched_list <------
--
DROP SUBSCRIPTION hts_sched_list_ls for hts_sched_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sec_comment <------
--
DROP SUBSCRIPTION hts_sec_comment_ls for hts_sec_comment_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sec_def_attribs <------
--
DROP SUBSCRIPTION hts_sec_def_attribs_ls for hts_sec_def_attribs_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sec_master <------
--
DROP SUBSCRIPTION hts_sec_master_ls for hts_sec_master_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_settle_rule <------
--
DROP SUBSCRIPTION hts_settle_rule_ls for hts_settle_rule_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sfailure_event <------
--
DROP SUBSCRIPTION hts_sfailure_event_ls for hts_sfailure_event_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_audit_trail_log <------
--
DROP SUBSCRIPTION hts_sm_audit_trail_log_ls for hts_sm_audit_trail_log_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_ba_detail <------
--
DROP SUBSCRIPTION hts_sm_ba_detail_ls for hts_sm_ba_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_binary_detail <------
--
DROP SUBSCRIPTION hts_sm_binary_detail_ls for hts_sm_binary_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_cfd <------
--
DROP SUBSCRIPTION hts_sm_cfd_ls for hts_sm_cfd_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_deriv_detail <------
--
DROP SUBSCRIPTION hts_sm_deriv_detail_ls for hts_sm_deriv_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_eqss_detail <------
--
DROP SUBSCRIPTION hts_sm_eqss_detail_ls for hts_sm_eqss_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_relation <------
--
DROP SUBSCRIPTION hts_sm_relation_ls for hts_sm_relation_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_repo <------
--
DROP SUBSCRIPTION hts_sm_repo_ls for hts_sm_repo_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_repo_sched <------
--
DROP SUBSCRIPTION hts_sm_repo_sched_ls for hts_sm_repo_sched_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_stripbond_detail <------
--
DROP SUBSCRIPTION hts_sm_stripbond_detail_ls for hts_sm_stripbond_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_user_data <------
--
DROP SUBSCRIPTION hts_sm_user_data_ls for hts_sm_user_data_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_usymbol_view <------
--
DROP SUBSCRIPTION hts_sm_usymbol_view_ls for hts_sm_usymbol_view_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_snap_status <------
--
DROP SUBSCRIPTION hts_snap_status_ls for hts_snap_status_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sp_return_codes <------
--
DROP SUBSCRIPTION hts_sp_return_codes_ls for hts_sp_return_codes_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_split <------
--
DROP SUBSCRIPTION hts_split_ls for hts_split_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_split_log <------
--
DROP SUBSCRIPTION hts_split_log_ls for hts_split_log_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_split_status <------
--
DROP SUBSCRIPTION hts_split_status_ls for hts_split_status_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_spot_list <------
--
DROP SUBSCRIPTION hts_spot_list_ls for hts_spot_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_stock_merger <------
--
DROP SUBSCRIPTION hts_stock_merger_ls for hts_stock_merger_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_stock_merger_list <------
--
DROP SUBSCRIPTION hts_stock_merger_list_ls for hts_stock_merger_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_stock_spinoff <------
--
DROP SUBSCRIPTION hts_stock_spinoff_ls for hts_stock_spinoff_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_stock_spinoff_list <------
--
DROP SUBSCRIPTION hts_stock_spinoff_list_ls for hts_stock_spinoff_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_strategy <------
--
DROP SUBSCRIPTION hts_strategy_ls for hts_strategy_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_strategy_component <------
--
DROP SUBSCRIPTION hts_strategy_component_ls for hts_strategy_component_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_strategy_group <------
--
DROP SUBSCRIPTION hts_strategy_group_ls for hts_strategy_group_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap <------
--
DROP SUBSCRIPTION hts_swap_ls for hts_swap_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_basket_reset <------
--
DROP SUBSCRIPTION hts_swap_basket_reset_ls for hts_swap_basket_reset_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_detail <------
--
DROP SUBSCRIPTION hts_swap_detail_ls for hts_swap_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_div_sched <------
--
DROP SUBSCRIPTION hts_swap_div_sched_ls for hts_swap_div_sched_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_equity_leg <------
--
DROP SUBSCRIPTION hts_swap_equity_leg_ls for hts_swap_equity_leg_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_event_sched <------
--
DROP SUBSCRIPTION hts_swap_event_sched_ls for hts_swap_event_sched_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_floating_leg <------
--
DROP SUBSCRIPTION hts_swap_floating_leg_ls for hts_swap_floating_leg_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_leg <------
--
DROP SUBSCRIPTION hts_swap_leg_ls for hts_swap_leg_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_list <------
--
DROP SUBSCRIPTION hts_swap_list_ls for hts_swap_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_quanto_leg <------
--
DROP SUBSCRIPTION hts_swap_quanto_leg_ls for hts_swap_quanto_leg_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_sched_filt <------
--
DROP SUBSCRIPTION hts_swap_sched_filt_ls for hts_swap_sched_filt_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_system_status <------
--
DROP SUBSCRIPTION hts_system_status_ls for hts_system_status_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tax_rules <------
--
DROP SUBSCRIPTION hts_tax_rules_ls for hts_tax_rules_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_template_detail <------
--
DROP SUBSCRIPTION hts_template_detail_ls for hts_template_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_template_list <------
--
DROP SUBSCRIPTION hts_template_list_ls for hts_template_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tick_size_list <------
--
DROP SUBSCRIPTION hts_tick_size_list_ls for hts_tick_size_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tick_sizes <------
--
DROP SUBSCRIPTION hts_tick_sizes_ls for hts_tick_sizes_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tickets <------
--
DROP SUBSCRIPTION hts_tickets_ls for hts_tickets_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_time_zone <------
--
DROP SUBSCRIPTION hts_time_zone_ls for hts_time_zone_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_trader <------
--
DROP SUBSCRIPTION hts_trader_ls for hts_trader_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_trader_security <------
--
DROP SUBSCRIPTION hts_trader_security_ls for hts_trader_security_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tvol_detail <------
--
DROP SUBSCRIPTION hts_tvol_detail_ls for hts_tvol_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tvol_list <------
--
DROP SUBSCRIPTION hts_tvol_list_ls for hts_tvol_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_underlying <------
--
DROP SUBSCRIPTION hts_underlying_ls for hts_underlying_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_user <------
--
DROP SUBSCRIPTION hts_user_ls for hts_user_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_user_company <------
--
DROP SUBSCRIPTION hts_user_company_ls for hts_user_company_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_user_info <------
--
DROP SUBSCRIPTION hts_user_info_ls for hts_user_info_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_user_message <------
--
DROP SUBSCRIPTION hts_user_message_ls for hts_user_message_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_user_rt_default <------
--
DROP SUBSCRIPTION hts_user_rt_default_ls for hts_user_rt_default_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_users <------
--
DROP SUBSCRIPTION hts_users_ls for hts_users_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_valid_date_patterns <------
--
DROP SUBSCRIPTION hts_valid_date_patterns_ls for hts_valid_date_patterns_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_var_cross_ref <------
--
DROP SUBSCRIPTION hts_var_cross_ref_ls for hts_var_cross_ref_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_volatility_detail <------
--
DROP SUBSCRIPTION hts_volatility_detail_ls for hts_volatility_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_volatility_detail_arc <------
--
DROP SUBSCRIPTION hts_volatility_detail_arc_ls for hts_volatility_detail_arc_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_volatility_list <------
--
DROP SUBSCRIPTION hts_volatility_list_ls for hts_volatility_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_volatility_list_arc <------
--
DROP SUBSCRIPTION hts_volatility_list_arc_ls for hts_volatility_list_arc_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_xact_history <------
--
DROP SUBSCRIPTION hts_xact_history_ls for hts_xact_history_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_xrate_detail <------
--
DROP SUBSCRIPTION hts_xrate_detail_ls for hts_xrate_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_xrate_list <------
--
DROP SUBSCRIPTION hts_xrate_list_ls for hts_xrate_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_alg_risk <------
--
DROP SUBSCRIPTION hts_yc_alg_risk_ls for hts_yc_alg_risk_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_cred_agency <------
--
DROP SUBSCRIPTION hts_yc_cred_agency_ls for hts_yc_cred_agency_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_cred_i2s_map <------
--
DROP SUBSCRIPTION hts_yc_cred_i2s_map_ls for hts_yc_cred_i2s_map_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_cred_level <------
--
DROP SUBSCRIPTION hts_yc_cred_level_ls for hts_yc_cred_level_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_cred_matrix <------
--
DROP SUBSCRIPTION hts_yc_cred_matrix_ls for hts_yc_cred_matrix_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_curve <------
--
DROP SUBSCRIPTION hts_yc_curve_ls for hts_yc_curve_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_hdg_instr <------
--
DROP SUBSCRIPTION hts_yc_hdg_instr_ls for hts_yc_hdg_instr_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_hdg_strat <------
--
DROP SUBSCRIPTION hts_yc_hdg_strat_ls for hts_yc_hdg_strat_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_link_data <------
--
DROP SUBSCRIPTION hts_yc_link_data_ls for hts_yc_link_data_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_mkt_instr <------
--
DROP SUBSCRIPTION hts_yc_mkt_instr_ls for hts_yc_mkt_instr_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_mkt_instr_data <------
--
DROP SUBSCRIPTION hts_yc_mkt_instr_data_ls for hts_yc_mkt_instr_data_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_mkt_instr_hdr <------
--
DROP SUBSCRIPTION hts_yc_mkt_instr_hdr_ls for hts_yc_mkt_instr_hdr_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_model <------
--
DROP SUBSCRIPTION hts_yc_model_ls for hts_yc_model_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_risk_curve <------
--
DROP SUBSCRIPTION hts_yc_risk_curve_ls for hts_yc_risk_curve_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_risk_curves_view <------
--
DROP SUBSCRIPTION hts_yc_risk_curves_view_ls for hts_yc_risk_curves_view_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_risk_data <------
--
DROP SUBSCRIPTION hts_yc_risk_data_ls for hts_yc_risk_data_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_risk_scenar_view <------
--
DROP SUBSCRIPTION hts_yc_risk_scenar_view_ls for hts_yc_risk_scenar_view_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_risk_scenario <------
--
DROP SUBSCRIPTION hts_yc_risk_scenario_ls for hts_yc_risk_scenario_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_scenario <------
--
DROP SUBSCRIPTION hts_yc_scenario_ls for hts_yc_scenario_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_sp <------
--
DROP SUBSCRIPTION hts_yc_sp_ls for hts_yc_sp_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_sp_hdr <------
--
DROP SUBSCRIPTION hts_yc_sp_hdr_ls for hts_yc_sp_hdr_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_strip <------
--
DROP SUBSCRIPTION hts_yc_strip_ls for hts_yc_strip_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_swap_spec <------
--
DROP SUBSCRIPTION hts_yc_swap_spec_ls for hts_yc_swap_spec_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yield_detail <------
--
DROP SUBSCRIPTION hts_yield_detail_ls for hts_yield_detail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yield_list <------
--
DROP SUBSCRIPTION hts_yield_list_ls for hts_yield_list_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.lic_feature <------
--
DROP SUBSCRIPTION lic_feature_ls for lic_feature_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.lic_usage <------
--
DROP SUBSCRIPTION lic_usage_ls for lic_usage_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.mdl_portf_colnames_tb <------
--
DROP SUBSCRIPTION mdl_portf_colnames_tb_ls for mdl_portf_colnames_tb_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONCDRImport <------
--
DROP SUBSCRIPTION t_ICONCDRImport_ls for t_ICONCDRImport_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONCDRLookup <------
--
DROP SUBSCRIPTION t_ICONCDRLookup_ls for t_ICONCDRLookup_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONFeedControl <------
--
DROP SUBSCRIPTION t_ICONFeedControl_ls for t_ICONFeedControl_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONFilesInfo <------
--
DROP SUBSCRIPTION t_ICONFilesInfo_ls for t_ICONFilesInfo_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONPrepareTradeFile <------
--
DROP SUBSCRIPTION t_ICONPrepareTradeFile_ls for t_ICONPrepareTradeFile_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONTradesCompare <------
--
DROP SUBSCRIPTION t_ICONTradesCompare_ls for t_ICONTradesCompare_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONTradesSentDetail <------
--
DROP SUBSCRIPTION t_ICONTradesSentDetail_ls for t_ICONTradesSentDetail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONTradesTemp <------
--
DROP SUBSCRIPTION t_ICONTradesTemp_ls for t_ICONTradesTemp_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_init_ICONPrepareTradeFile <------
--
DROP SUBSCRIPTION t_init_ICONPrepareTradeFile_ls for t_init_ICONPrepareTradeFile_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_init_ICONTradesSentDetail <------
--
DROP SUBSCRIPTION t_init_ICONTradesSentDetail_ls for t_init_ICONTradesSentDetail_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_init_ImportCDR <------
--
DROP SUBSCRIPTION t_init_ImportCDR_ls for t_init_ImportCDR_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.test1 <------
--
DROP SUBSCRIPTION test1_ls for test1_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.user_location <------
--
DROP SUBSCRIPTION user_location_ls for user_location_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.world_clock <------
--
DROP SUBSCRIPTION world_clock_ls for world_clock_ld
WITH REPLICATE AT lon_gen_sql_tst4.its_ged_prod
WITHOUT PURGE
go
