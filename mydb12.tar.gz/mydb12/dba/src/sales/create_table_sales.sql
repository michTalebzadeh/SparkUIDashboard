drop table sales;
create table sales tablespace app1 as select * from sh.sales;
select count(1) from sales;
quit
