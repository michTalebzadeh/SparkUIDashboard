 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SERVICE_ID									   NUMBER
 NAME										   VARCHAR2(64)
 NAME_HASH									   NUMBER
 NETWORK_NAME									   VARCHAR2(512)
 CREATION_DATE									   DATE
 CREATION_DATE_HASH								   NUMBER
 GOAL										   VARCHAR2(12)
 DTP										   VARCHAR2(1)
 AQ_HA_NOTIFICATION								   VARCHAR2(3)
 CLB_GOAL									   VARCHAR2(5)

