-- if status = PENDING OFFLINE then tablespace cannot be dropped!
SELECT
	rn.name,
	rs.status
FROM
	v$rollname rn,
	v$rollstat rs
WHERE
	rn.name in
		(SELECT
			segment_name 
		 FROM
			dba_segments
		 WHERE
			tablespace_name = 'UNDOTBS1'
		)
		 AND
			rn.usn = rs.usn
/
exit
			

