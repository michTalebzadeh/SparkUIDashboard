drop table salesfeed_external_table;
CREATE TABLE salesfeed_external_table
(
          PROD_ID               NUMBER
        , CUST_ID               NUMBER
        , TIME_ID               DATE
        , CHANNEL_ID            NUMBER
        , PROMO_ID              NUMBER
        , QUANTITY_SOLD         NUMBER(10,2)
        , AMOUNT_SOLD           NUMBER(10,2)
)
ORGANIZATION EXTERNAL
(
        TYPE ORACLE_LOADER
        DEFAULT DIRECTORY sales_feeds
        ACCESS PARAMETERS
        (
                RECORDS DELIMITED BY newline
                FIELDS TERMINATED BY '\t'
       	        MISSING FIELD VALUES ARE NULL
       	        ( 	  PROD_ID
			, CUST_ID
			, TIME_ID DATE	'dd/mm/yyyy HH24:MI:SS'
			, CHANNEL_ID
			, PROMO_ID
			, QUANTITY_SOLD
			, AMOUNT_SOLD
		)
        )
        LOCATION ('salesfeed.dat')
)
REJECT LIMIT 0
/
exit
