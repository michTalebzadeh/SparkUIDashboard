 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 INCIDENT_ID									   NUMBER
 CREATE_TIME									   TIMESTAMP(13) WITH TIME ZONE
 IS_DISABLED									   VARCHAR2(1)
 IS_ACTIVE									   VARCHAR2(1)
 IMPT_NATURE									   VARCHAR2(14)
 IMPACT1									   VARCHAR2(128)
 IMPACT2									   VARCHAR2(128)
 IMPACT3									   VARCHAR2(128)
 IMPACT4									   VARCHAR2(128)

