drop table cacher;
create table cacher(c1 char(2000), c2 char(2000), c3 char(2000), c4 char(2000))PCTFREE 0 
nologging;
insert /*+ append */ into cacher
select 
	  RPAD('*',2000) 
	 ,RPAD('*',2000) 
	 ,RPAD('*',2000) 
	 ,RPAD('*',2000) 
from dual
connect by level <= 130000;
EXEC DBMS_STATS.gather_table_stats(ownname=>user,tabname=>'CACHER',estimate_percent=>100);
commit;
alter system flush buffer_cache;
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
--ALTER SESSION SET EVENTS '10949 trace name context forever, level 1'  -- No Direct path read ;
select count(*) from cacher;
select count(*) from cacher;
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'catcher';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
--set autotrace on stat
 select count(*) from cacher;
--set autotrace off;
exit
