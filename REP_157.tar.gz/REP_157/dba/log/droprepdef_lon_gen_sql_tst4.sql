--
------> table its_ged_prod.dbGED_usereq_acctconf_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_acctconf_tb_sd
go
--
------> table its_ged_prod.dbGED_usereq_accttype_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_accttype_tb_sd
go
--
------> table its_ged_prod.dbGED_usereq_bizarea_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_bizarea_tb_sd
go
--
------> table its_ged_prod.dbGED_usereq_confdef_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_confdef_tb_sd
go
--
------> table its_ged_prod.dbGED_usereq_groups_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_groups_tb_sd
go
--
------> table its_ged_prod.dbGED_usereq_location_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_location_tb_sd
go
--
------> table its_ged_prod.dbGED_usereq_super_tb <------
--
DROP REPLICATION DEFINITION dbGED_usereq_super_tb_sd
go
--
------> table its_ged_prod.dbGED_userreq_new_tb <------
--
DROP REPLICATION DEFINITION dbGED_userreq_new_tb_sd
go
--
------> table its_ged_prod.dbJobStatus <------
--
DROP REPLICATION DEFINITION dbJobStatus_sd
go
--
------> table its_ged_prod.dbStageDividend <------
--
DROP REPLICATION DEFINITION dbStageDividend_sd
go
--
------> table its_ged_prod.dbStageDividend_Old <------
--
DROP REPLICATION DEFINITION dbStageDividend_Old_sd
go
--
------> table its_ged_prod.dbStageRicRef <------
--
DROP REPLICATION DEFINITION dbStageRicRef_sd
go
--
------> table its_ged_prod.dbStageStock <------
--
DROP REPLICATION DEFINITION dbStageStock_sd
go
--
------> table its_ged_prod.dbStageStock_Old <------
--
DROP REPLICATION DEFINITION dbStageStock_Old_sd
go
--
------> table its_ged_prod.dbStar_Input <------
--
DROP REPLICATION DEFINITION dbStar_Input_sd
go
--
------> table its_ged_prod.dbStar_Input1 <------
--
DROP REPLICATION DEFINITION dbStar_Input1_sd
go
--
------> table its_ged_prod.db_EOD_blotter_extra <------
--
DROP REPLICATION DEFINITION db_EOD_blotter_extra_sd
go
--
------> table its_ged_prod.db_EOD_blotter_sec_data <------
--
DROP REPLICATION DEFINITION db_EOD_blotter_sec_data_sd
go
--
------> table its_ged_prod.db_EOD_blotter_signoff <------
--
DROP REPLICATION DEFINITION db_EOD_blotter_signoff_sd
go
--
------> table its_ged_prod.db_EOD_blotter_status <------
--
DROP REPLICATION DEFINITION db_EOD_blotter_status_sd
go
--
------> table its_ged_prod.db_EOD_blotter_trades <------
--
DROP REPLICATION DEFINITION db_EOD_blotter_trades_sd
go
--
------> table its_ged_prod.db_YC_Upload_Ccys <------
--
DROP REPLICATION DEFINITION db_YC_Upload_Ccys_sd
go
--
------> table its_ged_prod.db_alternate_code <------
--
DROP REPLICATION DEFINITION db_alternate_code_sd
go
--
------> table its_ged_prod.db_asian_history <------
--
DROP REPLICATION DEFINITION db_asian_history_sd
go
--
------> table its_ged_prod.db_autolaunchLedgers <------
--
DROP REPLICATION DEFINITION db_autolaunchLedgers_sd
go
--
------> table its_ged_prod.db_autolaunchUsers <------
--
DROP REPLICATION DEFINITION db_autolaunchUsers_sd
go
--
------> table its_ged_prod.db_average_trade_err <------
--
DROP REPLICATION DEFINITION db_average_trade_err_sd
go
--
------> table its_ged_prod.db_average_trade_list <------
--
DROP REPLICATION DEFINITION db_average_trade_list_sd
go
--
------> table its_ged_prod.db_average_trade_xref <------
--
DROP REPLICATION DEFINITION db_average_trade_xref_sd
go
--
------> table its_ged_prod.db_avg_error <------
--
DROP REPLICATION DEFINITION db_avg_error_sd
go
--
------> table its_ged_prod.db_avg_exec_xref <------
--
DROP REPLICATION DEFINITION db_avg_exec_xref_sd
go
--
------> table its_ged_prod.db_avg_exec_xref_audit <------
--
DROP REPLICATION DEFINITION db_avg_exec_xref_audit_sd
go
--
------> table its_ged_prod.db_avg_netting_grp <------
--
DROP REPLICATION DEFINITION db_avg_netting_grp_sd
go
--
------> table its_ged_prod.db_avg_netting_grp_audit <------
--
DROP REPLICATION DEFINITION db_avg_netting_grp_audit_sd
go
--
------> table its_ged_prod.db_avg_rule <------
--
DROP REPLICATION DEFINITION db_avg_rule_sd
go
--
------> table its_ged_prod.db_avg_rule_audit <------
--
DROP REPLICATION DEFINITION db_avg_rule_audit_sd
go
--
------> table its_ged_prod.db_avg_rule_except_audit <------
--
DROP REPLICATION DEFINITION db_avg_rule_except_audit_sd
go
--
------> table its_ged_prod.db_avg_rule_exception <------
--
DROP REPLICATION DEFINITION db_avg_rule_exception_sd
go
--
------> table its_ged_prod.db_avg_rule_set <------
--
DROP REPLICATION DEFINITION db_avg_rule_set_sd
go
--
------> table its_ged_prod.db_avg_rule_set_audit <------
--
DROP REPLICATION DEFINITION db_avg_rule_set_audit_sd
go
--
------> table its_ged_prod.db_avg_rule_type <------
--
DROP REPLICATION DEFINITION db_avg_rule_type_sd
go
--
------> table its_ged_prod.db_avg_trade <------
--
DROP REPLICATION DEFINITION db_avg_trade_sd
go
--
------> table its_ged_prod.db_avg_trade_audit <------
--
DROP REPLICATION DEFINITION db_avg_trade_audit_sd
go
--
------> table its_ged_prod.db_calendar_map <------
--
DROP REPLICATION DEFINITION db_calendar_map_sd
go
--
------> table its_ged_prod.db_column_defaults <------
--
DROP REPLICATION DEFINITION db_column_defaults_sd
go
--
------> table its_ged_prod.db_curve_missing_map <------
--
DROP REPLICATION DEFINITION db_curve_missing_map_sd
go
--
------> table its_ged_prod.db_div_tax_rules <------
--
DROP REPLICATION DEFINITION db_div_tax_rules_sd
go
--
------> table its_ged_prod.db_error_message <------
--
DROP REPLICATION DEFINITION db_error_message_sd
go
--
------> table its_ged_prod.db_eurex_defaults <------
--
DROP REPLICATION DEFINITION db_eurex_defaults_sd
go
--
------> table its_ged_prod.db_eurex_xetra_ar_prod <------
--
DROP REPLICATION DEFINITION db_eurex_xetra_ar_prod_sd
go
--
------> table its_ged_prod.db_eurex_xetra_routing <------
--
DROP REPLICATION DEFINITION db_eurex_xetra_routing_sd
go
--
------> table its_ged_prod.db_eurex_xetra_trades <------
--
DROP REPLICATION DEFINITION db_eurex_xetra_trades_sd
go
--
------> table its_ged_prod.db_eurex_xetra_trades_arc <------
--
DROP REPLICATION DEFINITION db_eurex_xetra_trades_arc_sd
go
--
------> table its_ged_prod.db_excep_price_env <------
--
DROP REPLICATION DEFINITION db_excep_price_env_sd
go
--
------> table its_ged_prod.db_imagine_user_dealer_map <------
--
DROP REPLICATION DEFINITION db_imagine_user_dealer_map_sd
go
--
------> table its_ged_prod.db_last_message <------
--
DROP REPLICATION DEFINITION db_last_message_sd
go
--
------> table its_ged_prod.db_mark_errors <------
--
DROP REPLICATION DEFINITION db_mark_errors_sd
go
--
------> table its_ged_prod.db_orc_auto_routed_products <------
--
DROP REPLICATION DEFINITION db_orc_auto_routed_products_sd
go
--
------> table its_ged_prod.db_orc_auto_routing <------
--
DROP REPLICATION DEFINITION db_orc_auto_routing_sd
go
--
------> table its_ged_prod.db_orc_exch_sett_date <------
--
DROP REPLICATION DEFINITION db_orc_exch_sett_date_sd
go
--
------> table its_ged_prod.db_orc_exchange <------
--
DROP REPLICATION DEFINITION db_orc_exchange_sd
go
--
------> table its_ged_prod.db_orc_exec_id <------
--
DROP REPLICATION DEFINITION db_orc_exec_id_sd
go
--
------> table its_ged_prod.db_orc_executions <------
--
DROP REPLICATION DEFINITION db_orc_executions_sd
go
--
------> table its_ged_prod.db_orc_executions_hist <------
--
DROP REPLICATION DEFINITION db_orc_executions_hist_sd
go
--
------> table its_ged_prod.db_orc_heartbeat <------
--
DROP REPLICATION DEFINITION db_orc_heartbeat_sd
go
--
------> table its_ged_prod.db_orc_imag_warrant_recon <------
--
DROP REPLICATION DEFINITION db_orc_imag_warrant_recon_sd
go
--
------> table its_ged_prod.db_orc_portfolio <------
--
DROP REPLICATION DEFINITION db_orc_portfolio_sd
go
--
------> table its_ged_prod.db_orc_process_state <------
--
DROP REPLICATION DEFINITION db_orc_process_state_sd
go
--
------> table its_ged_prod.db_orc_sec_exchange <------
--
DROP REPLICATION DEFINITION db_orc_sec_exchange_sd
go
--
------> table its_ged_prod.db_orc_trade_id_map <------
--
DROP REPLICATION DEFINITION db_orc_trade_id_map_sd
go
--
------> table its_ged_prod.db_orc_trade_recon <------
--
DROP REPLICATION DEFINITION db_orc_trade_recon_sd
go
--
------> table its_ged_prod.db_orc_trader <------
--
DROP REPLICATION DEFINITION db_orc_trader_sd
go
--
------> table its_ged_prod.db_orc_underlying <------
--
DROP REPLICATION DEFINITION db_orc_underlying_sd
go
--
------> table its_ged_prod.db_orc_warrant_recon <------
--
DROP REPLICATION DEFINITION db_orc_warrant_recon_sd
go
--
------> table its_ged_prod.db_perm_audit <------
--
DROP REPLICATION DEFINITION db_perm_audit_sd
go
--
------> table its_ged_prod.db_perm_bus_cat <------
--
DROP REPLICATION DEFINITION db_perm_bus_cat_sd
go
--
------> table its_ged_prod.db_perm_business <------
--
DROP REPLICATION DEFINITION db_perm_business_sd
go
--
------> table its_ged_prod.db_perm_resources <------
--
DROP REPLICATION DEFINITION db_perm_resources_sd
go
--
------> table its_ged_prod.db_perm_role <------
--
DROP REPLICATION DEFINITION db_perm_role_sd
go
--
------> table its_ged_prod.db_perm_supervisor <------
--
DROP REPLICATION DEFINITION db_perm_supervisor_sd
go
--
------> table its_ged_prod.db_perm_users <------
--
DROP REPLICATION DEFINITION db_perm_users_sd
go
--
------> table its_ged_prod.db_pre_volatility_detail <------
--
DROP REPLICATION DEFINITION db_pre_volatility_detail_sd
go
--
------> table its_ged_prod.db_recon_position_log <------
--
DROP REPLICATION DEFINITION db_recon_position_log_sd
go
--
------> table its_ged_prod.db_recon_trade_log <------
--
DROP REPLICATION DEFINITION db_recon_trade_log_sd
go
--
------> table its_ged_prod.db_rolled_market_prices <------
--
DROP REPLICATION DEFINITION db_rolled_market_prices_sd
go
--
------> table its_ged_prod.db_script_parameters <------
--
DROP REPLICATION DEFINITION db_script_parameters_sd
go
--
------> table its_ged_prod.db_security_codes <------
--
DROP REPLICATION DEFINITION db_security_codes_sd
go
--
------> table its_ged_prod.db_status_history <------
--
DROP REPLICATION DEFINITION db_status_history_sd
go
--
------> table its_ged_prod.db_swx_trade_reporting <------
--
DROP REPLICATION DEFINITION db_swx_trade_reporting_sd
go
--
------> table its_ged_prod.db_temp_market_price <------
--
DROP REPLICATION DEFINITION db_temp_market_price_sd
go
--
------> table its_ged_prod.db_tickets <------
--
DROP REPLICATION DEFINITION db_tickets_sd
go
--
------> table its_ged_prod.db_tickets_approval_options <------
--
DROP REPLICATION DEFINITION db_tickets_approval_options_sd
go
--
------> table its_ged_prod.db_tickets_comments <------
--
DROP REPLICATION DEFINITION db_tickets_comments_sd
go
--
------> table its_ged_prod.db_tickets_exec_queue <------
--
DROP REPLICATION DEFINITION db_tickets_exec_queue_sd
go
--
------> table its_ged_prod.db_tickets_status_history <------
--
DROP REPLICATION DEFINITION db_tickets_status_history_sd
go
--
------> table its_ged_prod.db_tickets_user <------
--
DROP REPLICATION DEFINITION db_tickets_user_sd
go
--
------> table its_ged_prod.db_trader_permissions <------
--
DROP REPLICATION DEFINITION db_trader_permissions_sd
go
--
------> table its_ged_prod.db_trading_account <------
--
DROP REPLICATION DEFINITION db_trading_account_sd
go
--
------> table its_ged_prod.db_trading_book <------
--
DROP REPLICATION DEFINITION db_trading_book_sd
go
--
------> table its_ged_prod.db_trading_desk <------
--
DROP REPLICATION DEFINITION db_trading_desk_sd
go
--
------> table its_ged_prod.db_trading_view <------
--
DROP REPLICATION DEFINITION db_trading_view_sd
go
--
------> table its_ged_prod.db_trading_webview <------
--
DROP REPLICATION DEFINITION db_trading_webview_sd
go
--
------> table its_ged_prod.db_ts_adjustment <------
--
DROP REPLICATION DEFINITION db_ts_adjustment_sd
go
--
------> table its_ged_prod.db_valid_interface_users <------
--
DROP REPLICATION DEFINITION db_valid_interface_users_sd
go
--
------> table its_ged_prod.db_volatility_ancillary <------
--
DROP REPLICATION DEFINITION db_volatility_ancillary_sd
go
--
------> table its_ged_prod.db_xetra_defaults <------
--
DROP REPLICATION DEFINITION db_xetra_defaults_sd
go
--
------> table its_ged_prod.db_xol_master_list <------
--
DROP REPLICATION DEFINITION db_xol_master_list_sd
go
--
------> table its_ged_prod.db_xol_outgoing_ca <------
--
DROP REPLICATION DEFINITION db_xol_outgoing_ca_sd
go
--
------> table its_ged_prod.dba_check_rep_delay <------
--
DROP REPLICATION DEFINITION dba_check_rep_delay_sd
go
--
------> table its_ged_prod.dbs_COUNTER <------
--
DROP REPLICATION DEFINITION dbs_COUNTER_sd
go
--
------> table its_ged_prod.dbt_kueu_file <------
--
DROP REPLICATION DEFINITION dbt_kueu_file_sd
go
--
------> table its_ged_prod.dbt_sec_map <------
--
DROP REPLICATION DEFINITION dbt_sec_map_sd
go
--
------> table its_ged_prod.dbt_sec_type_mapping <------
--
DROP REPLICATION DEFINITION dbt_sec_type_mapping_sd
go
--
------> table its_ged_prod.dbt_sequence <------
--
DROP REPLICATION DEFINITION dbt_sequence_sd
go
--
------> table its_ged_prod.dbt_trade_target <------
--
DROP REPLICATION DEFINITION dbt_trade_target_sd
go
--
------> table its_ged_prod.dbt_trade_target_temp <------
--
DROP REPLICATION DEFINITION dbt_trade_target_temp_sd
go
--
------> table its_ged_prod.dbt_trade_triggers <------
--
DROP REPLICATION DEFINITION dbt_trade_triggers_sd
go
--
------> table its_ged_prod.dbtrader_secm <------
--
DROP REPLICATION DEFINITION dbtrader_secm_sd
go
--
------> table its_ged_prod.euro_rates <------
--
DROP REPLICATION DEFINITION euro_rates_sd
go
--
------> table its_ged_prod.exec_queue_errors <------
--
DROP REPLICATION DEFINITION exec_queue_errors_sd
go
--
------> table its_ged_prod.gedi_admin_status <------
--
DROP REPLICATION DEFINITION gedi_admin_status_sd
go
--
------> table its_ged_prod.hts_account <------
--
DROP REPLICATION DEFINITION hts_account_sd
go
--
------> table its_ged_prod.hts_action_profile <------
--
DROP REPLICATION DEFINITION hts_action_profile_sd
go
--
------> table its_ged_prod.hts_action_profile_list <------
--
DROP REPLICATION DEFINITION hts_action_profile_list_sd
go
--
------> table its_ged_prod.hts_adjustment <------
--
DROP REPLICATION DEFINITION hts_adjustment_sd
go
--
------> table its_ged_prod.hts_adjustment_user_data <------
--
DROP REPLICATION DEFINITION hts_adjustment_user_data_sd
go
--
------> table its_ged_prod.hts_ae_codes <------
--
DROP REPLICATION DEFINITION hts_ae_codes_sd
go
--
------> table its_ged_prod.hts_audit_status <------
--
DROP REPLICATION DEFINITION hts_audit_status_sd
go
--
------> table its_ged_prod.hts_auto_quote <------
--
DROP REPLICATION DEFINITION hts_auto_quote_sd
go
--
------> table its_ged_prod.hts_b2b_trade_event <------
--
DROP REPLICATION DEFINITION hts_b2b_trade_event_sd
go
--
------> table its_ged_prod.hts_ba_spread_class <------
--
DROP REPLICATION DEFINITION hts_ba_spread_class_sd
go
--
------> table its_ged_prod.hts_ba_spread_detail <------
--
DROP REPLICATION DEFINITION hts_ba_spread_detail_sd
go
--
------> table its_ged_prod.hts_ba_spread_list <------
--
DROP REPLICATION DEFINITION hts_ba_spread_list_sd
go
--
------> table its_ged_prod.hts_balance_transfer_log <------
--
DROP REPLICATION DEFINITION hts_balance_transfer_log_sd
go
--
------> table its_ged_prod.hts_basis_detail <------
--
DROP REPLICATION DEFINITION hts_basis_detail_sd
go
--
------> table its_ged_prod.hts_basis_list <------
--
DROP REPLICATION DEFINITION hts_basis_list_sd
go
--
------> table its_ged_prod.hts_bo_event <------
--
DROP REPLICATION DEFINITION hts_bo_event_sd
go
--
------> table its_ged_prod.hts_borrow_detail <------
--
DROP REPLICATION DEFINITION hts_borrow_detail_sd
go
--
------> table its_ged_prod.hts_borrow_list <------
--
DROP REPLICATION DEFINITION hts_borrow_list_sd
go
--
------> table its_ged_prod.hts_broker <------
--
DROP REPLICATION DEFINITION hts_broker_sd
go
--
------> table its_ged_prod.hts_broker_user_data <------
--
DROP REPLICATION DEFINITION hts_broker_user_data_sd
go
--
------> table its_ged_prod.hts_bs_codes <------
--
DROP REPLICATION DEFINITION hts_bs_codes_sd
go
--
------> table its_ged_prod.hts_ca_event <------
--
DROP REPLICATION DEFINITION hts_ca_event_sd
go
--
------> table its_ged_prod.hts_capreq_basket <------
--
DROP REPLICATION DEFINITION hts_capreq_basket_sd
go
--
------> table its_ged_prod.hts_capreq_divisors <------
--
DROP REPLICATION DEFINITION hts_capreq_divisors_sd
go
--
------> table its_ged_prod.hts_capreq_overrides <------
--
DROP REPLICATION DEFINITION hts_capreq_overrides_sd
go
--
------> table its_ged_prod.hts_capreq_xref <------
--
DROP REPLICATION DEFINITION hts_capreq_xref_sd
go
--
------> table its_ged_prod.hts_cash_coll_sched <------
--
DROP REPLICATION DEFINITION hts_cash_coll_sched_sd
go
--
------> table its_ged_prod.hts_ccy_round <------
--
DROP REPLICATION DEFINITION hts_ccy_round_sd
go
--
------> table its_ged_prod.hts_charge_interval <------
--
DROP REPLICATION DEFINITION hts_charge_interval_sd
go
--
------> table its_ged_prod.hts_charge_rule <------
--
DROP REPLICATION DEFINITION hts_charge_rule_sd
go
--
------> table its_ged_prod.hts_charge_sched_detail <------
--
DROP REPLICATION DEFINITION hts_charge_sched_detail_sd
go
--
------> table its_ged_prod.hts_charge_sched_list <------
--
DROP REPLICATION DEFINITION hts_charge_sched_list_sd
go
--
------> table its_ged_prod.hts_charge_schedule <------
--
DROP REPLICATION DEFINITION hts_charge_schedule_sd
go
--
------> table its_ged_prod.hts_charge_type <------
--
DROP REPLICATION DEFINITION hts_charge_type_sd
go
--
------> table its_ged_prod.hts_coll_pool <------
--
DROP REPLICATION DEFINITION hts_coll_pool_sd
go
--
------> table its_ged_prod.hts_collateral <------
--
DROP REPLICATION DEFINITION hts_collateral_sd
go
--
------> table its_ged_prod.hts_constituent <------
--
DROP REPLICATION DEFINITION hts_constituent_sd
go
--
------> table its_ged_prod.hts_corr_detail <------
--
DROP REPLICATION DEFINITION hts_corr_detail_sd
go
--
------> table its_ged_prod.hts_corr_list <------
--
DROP REPLICATION DEFINITION hts_corr_list_sd
go
--
------> table its_ged_prod.hts_country <------
--
DROP REPLICATION DEFINITION hts_country_sd
go
--
------> table its_ged_prod.hts_credit_ratings <------
--
DROP REPLICATION DEFINITION hts_credit_ratings_sd
go
--
------> table its_ged_prod.hts_credit_spreads <------
--
DROP REPLICATION DEFINITION hts_credit_spreads_sd
go
--
------> table its_ged_prod.hts_credit_spreads_list <------
--
DROP REPLICATION DEFINITION hts_credit_spreads_list_sd
go
--
------> table its_ged_prod.hts_customer <------
--
DROP REPLICATION DEFINITION hts_customer_sd
go
--
------> table its_ged_prod.hts_customer_usage <------
--
DROP REPLICATION DEFINITION hts_customer_usage_sd
go
--
------> table its_ged_prod.hts_data_relation <------
--
DROP REPLICATION DEFINITION hts_data_relation_sd
go
--
------> table its_ged_prod.hts_dbl_log <------
--
DROP REPLICATION DEFINITION hts_dbl_log_sd
go
--
------> table its_ged_prod.hts_dbl_trade_log <------
--
DROP REPLICATION DEFINITION hts_dbl_trade_log_sd
go
--
------> table its_ged_prod.hts_dbt_fee_map <------
--
DROP REPLICATION DEFINITION hts_dbt_fee_map_sd
go
--
------> table its_ged_prod.hts_dbt_fi_sec <------
--
DROP REPLICATION DEFINITION hts_dbt_fi_sec_sd
go
--
------> table its_ged_prod.hts_dbt_system_route <------
--
DROP REPLICATION DEFINITION hts_dbt_system_route_sd
go
--
------> table its_ged_prod.hts_dbt_xfce <------
--
DROP REPLICATION DEFINITION hts_dbt_xfce_sd
go
--
------> table its_ged_prod.hts_deal <------
--
DROP REPLICATION DEFINITION hts_deal_sd
go
--
------> table its_ged_prod.hts_dividend_detail <------
--
DROP REPLICATION DEFINITION hts_dividend_detail_sd
go
--
------> table its_ged_prod.hts_dividend_list <------
--
DROP REPLICATION DEFINITION hts_dividend_list_sd
go
--
------> table its_ged_prod.hts_dynamic_apps <------
--
DROP REPLICATION DEFINITION hts_dynamic_apps_sd
go
--
------> table its_ged_prod.hts_dynrule_list <------
--
DROP REPLICATION DEFINITION hts_dynrule_list_sd
go
--
------> table its_ged_prod.hts_emu_conv_event <------
--
DROP REPLICATION DEFINITION hts_emu_conv_event_sd
go
--
------> table its_ged_prod.hts_eqcd_detail <------
--
DROP REPLICATION DEFINITION hts_eqcd_detail_sd
go
--
------> table its_ged_prod.hts_event_types <------
--
DROP REPLICATION DEFINITION hts_event_types_sd
go
--
------> table its_ged_prod.hts_exchange <------
--
DROP REPLICATION DEFINITION hts_exchange_sd
go
--
------> table its_ged_prod.hts_exchange_snap_status <------
--
DROP REPLICATION DEFINITION hts_exchange_snap_status_sd
go
--
------> table its_ged_prod.hts_exec_adj <------
--
DROP REPLICATION DEFINITION hts_exec_adj_sd
go
--
------> table its_ged_prod.hts_exec_control <------
--
DROP REPLICATION DEFINITION hts_exec_control_sd
go
--
------> table its_ged_prod.hts_exer_notice <------
--
DROP REPLICATION DEFINITION hts_exer_notice_sd
go
--
------> table its_ged_prod.hts_fi_sec_master <------
--
DROP REPLICATION DEFINITION hts_fi_sec_master_sd
go
--
------> table its_ged_prod.hts_filter_columns <------
--
DROP REPLICATION DEFINITION hts_filter_columns_sd
go
--
------> table its_ged_prod.hts_filter_detail <------
--
DROP REPLICATION DEFINITION hts_filter_detail_sd
go
--
------> table its_ged_prod.hts_filter_list <------
--
DROP REPLICATION DEFINITION hts_filter_list_sd
go
--
------> table its_ged_prod.hts_fiscal_calendar <------
--
DROP REPLICATION DEFINITION hts_fiscal_calendar_sd
go
--
------> table its_ged_prod.hts_fixings <------
--
DROP REPLICATION DEFINITION hts_fixings_sd
go
--
------> table its_ged_prod.hts_formula_rule_detail <------
--
DROP REPLICATION DEFINITION hts_formula_rule_detail_sd
go
--
------> table its_ged_prod.hts_formula_rule_list <------
--
DROP REPLICATION DEFINITION hts_formula_rule_list_sd
go
--
------> table its_ged_prod.hts_funding_rates <------
--
DROP REPLICATION DEFINITION hts_funding_rates_sd
go
--
------> table its_ged_prod.hts_fx_detail <------
--
DROP REPLICATION DEFINITION hts_fx_detail_sd
go
--
------> table its_ged_prod.hts_fx_list <------
--
DROP REPLICATION DEFINITION hts_fx_list_sd
go
--
------> table its_ged_prod.hts_gen_otc <------
--
DROP REPLICATION DEFINITION hts_gen_otc_sd
go
--
------> table its_ged_prod.hts_gen_sec_types <------
--
DROP REPLICATION DEFINITION hts_gen_sec_types_sd
go
--
------> table its_ged_prod.hts_genfilter_cells <------
--
DROP REPLICATION DEFINITION hts_genfilter_cells_sd
go
--
------> table its_ged_prod.hts_genfilter_columns <------
--
DROP REPLICATION DEFINITION hts_genfilter_columns_sd
go
--
------> table its_ged_prod.hts_genfilter_detail <------
--
DROP REPLICATION DEFINITION hts_genfilter_detail_sd
go
--
------> table its_ged_prod.hts_gotc_rebate_pay_types <------
--
DROP REPLICATION DEFINITION hts_gotc_rebate_pay_types_sd
go
--
------> table its_ged_prod.hts_gotc_schedule <------
--
DROP REPLICATION DEFINITION hts_gotc_schedule_sd
go
--
------> table its_ged_prod.hts_gotc_trigger_types <------
--
DROP REPLICATION DEFINITION hts_gotc_trigger_types_sd
go
--
------> table its_ged_prod.hts_group <------
--
DROP REPLICATION DEFINITION hts_group_sd
go
--
------> table its_ged_prod.hts_group_control <------
--
DROP REPLICATION DEFINITION hts_group_control_sd
go
--
------> table its_ged_prod.hts_historical_prices <------
--
DROP REPLICATION DEFINITION hts_historical_prices_sd
go
--
------> table its_ged_prod.hts_hold_audit_trail_log <------
--
DROP REPLICATION DEFINITION hts_hold_audit_trail_log_sd
go
--
------> table its_ged_prod.hts_hold_map <------
--
DROP REPLICATION DEFINITION hts_hold_map_sd
go
--
------> table its_ged_prod.hts_hold_user_data <------
--
DROP REPLICATION DEFINITION hts_hold_user_data_sd
go
--
------> table its_ged_prod.hts_holding_greeks <------
--
DROP REPLICATION DEFINITION hts_holding_greeks_sd
go
--
------> table its_ged_prod.hts_holiday_detail <------
--
DROP REPLICATION DEFINITION hts_holiday_detail_sd
go
--
------> table its_ged_prod.hts_holiday_list <------
--
DROP REPLICATION DEFINITION hts_holiday_list_sd
go
--
------> table its_ged_prod.hts_industry <------
--
DROP REPLICATION DEFINITION hts_industry_sd
go
--
------> table its_ged_prod.hts_irate_source <------
--
DROP REPLICATION DEFINITION hts_irate_source_sd
go
--
------> table its_ged_prod.hts_issuer <------
--
DROP REPLICATION DEFINITION hts_issuer_sd
go
--
------> table its_ged_prod.hts_issuer_related_view <------
--
DROP REPLICATION DEFINITION hts_issuer_related_view_sd
go
--
------> table its_ged_prod.hts_legacy_stock_split <------
--
DROP REPLICATION DEFINITION hts_legacy_stock_split_sd
go
--
------> table its_ged_prod.hts_legal_entity <------
--
DROP REPLICATION DEFINITION hts_legal_entity_sd
go
--
------> table its_ged_prod.hts_lim_cmb_type <------
--
DROP REPLICATION DEFINITION hts_lim_cmb_type_sd
go
--
------> table its_ged_prod.hts_limit_detail <------
--
DROP REPLICATION DEFINITION hts_limit_detail_sd
go
--
------> table its_ged_prod.hts_limit_field <------
--
DROP REPLICATION DEFINITION hts_limit_field_sd
go
--
------> table its_ged_prod.hts_limit_list <------
--
DROP REPLICATION DEFINITION hts_limit_list_sd
go
--
------> table its_ged_prod.hts_limit_monitor_event <------
--
DROP REPLICATION DEFINITION hts_limit_monitor_event_sd
go
--
------> table its_ged_prod.hts_location <------
--
DROP REPLICATION DEFINITION hts_location_sd
go
--
------> table its_ged_prod.hts_lock <------
--
DROP REPLICATION DEFINITION hts_lock_sd
go
--
------> table its_ged_prod.hts_mark <------
--
DROP REPLICATION DEFINITION hts_mark_sd
go
--
------> table its_ged_prod.hts_mark_acct <------
--
DROP REPLICATION DEFINITION hts_mark_acct_sd
go
--
------> table its_ged_prod.hts_market_price <------
--
DROP REPLICATION DEFINITION hts_market_price_sd
go
--
------> table its_ged_prod.hts_mmkt_usec <------
--
DROP REPLICATION DEFINITION hts_mmkt_usec_sd
go
--
------> table its_ged_prod.hts_monitor_limit <------
--
DROP REPLICATION DEFINITION hts_monitor_limit_sd
go
--
------> table its_ged_prod.hts_name_change_notice <------
--
DROP REPLICATION DEFINITION hts_name_change_notice_sd
go
--
------> table its_ged_prod.hts_nosplit <------
--
DROP REPLICATION DEFINITION hts_nosplit_sd
go
--
------> table its_ged_prod.hts_object_limit <------
--
DROP REPLICATION DEFINITION hts_object_limit_sd
go
--
------> table its_ged_prod.hts_opt_exer_event <------
--
DROP REPLICATION DEFINITION hts_opt_exer_event_sd
go
--
------> table its_ged_prod.hts_ord_control <------
--
DROP REPLICATION DEFINITION hts_ord_control_sd
go
--
------> table its_ged_prod.hts_ordhdg_group_detail <------
--
DROP REPLICATION DEFINITION hts_ordhdg_group_detail_sd
go
--
------> table its_ged_prod.hts_ordhdg_group_list <------
--
DROP REPLICATION DEFINITION hts_ordhdg_group_list_sd
go
--
------> table its_ged_prod.hts_pc_codes <------
--
DROP REPLICATION DEFINITION hts_pc_codes_sd
go
--
------> table its_ged_prod.hts_perm_control <------
--
DROP REPLICATION DEFINITION hts_perm_control_sd
go
--
------> table its_ged_prod.hts_pl_archive <------
--
DROP REPLICATION DEFINITION hts_pl_archive_sd
go
--
------> table its_ged_prod.hts_port_control <------
--
DROP REPLICATION DEFINITION hts_port_control_sd
go
--
------> table its_ged_prod.hts_price_detail <------
--
DROP REPLICATION DEFINITION hts_price_detail_sd
go
--
------> table its_ged_prod.hts_price_env <------
--
DROP REPLICATION DEFINITION hts_price_env_sd
go
--
------> table its_ged_prod.hts_price_list <------
--
DROP REPLICATION DEFINITION hts_price_list_sd
go
--
------> table its_ged_prod.hts_profit_loss <------
--
DROP REPLICATION DEFINITION hts_profit_loss_sd
go
--
------> table its_ged_prod.hts_quote_rule <------
--
DROP REPLICATION DEFINITION hts_quote_rule_sd
go
--
------> table its_ged_prod.hts_quote_rule_spreads <------
--
DROP REPLICATION DEFINITION hts_quote_rule_spreads_sd
go
--
------> table its_ged_prod.hts_registry <------
--
DROP REPLICATION DEFINITION hts_registry_sd
go
--
------> table its_ged_prod.hts_regulatory_agency <------
--
DROP REPLICATION DEFINITION hts_regulatory_agency_sd
go
--
------> table its_ged_prod.hts_replication_status <------
--
DROP REPLICATION DEFINITION hts_replication_status_sd
go
--
------> table its_ged_prod.hts_restricted_sec <------
--
DROP REPLICATION DEFINITION hts_restricted_sec_sd
go
--
------> table its_ged_prod.hts_reuters_masks <------
--
DROP REPLICATION DEFINITION hts_reuters_masks_sd
go
--
------> table its_ged_prod.hts_rm_ccy_default <------
--
DROP REPLICATION DEFINITION hts_rm_ccy_default_sd
go
--
------> table its_ged_prod.hts_roll_detail <------
--
DROP REPLICATION DEFINITION hts_roll_detail_sd
go
--
------> table its_ged_prod.hts_roll_list <------
--
DROP REPLICATION DEFINITION hts_roll_list_sd
go
--
------> table its_ged_prod.hts_scenario_maps <------
--
DROP REPLICATION DEFINITION hts_scenario_maps_sd
go
--
------> table its_ged_prod.hts_sched_list <------
--
DROP REPLICATION DEFINITION hts_sched_list_sd
go
--
------> table its_ged_prod.hts_sec_comment <------
--
DROP REPLICATION DEFINITION hts_sec_comment_sd
go
--
------> table its_ged_prod.hts_sec_def_attribs <------
--
DROP REPLICATION DEFINITION hts_sec_def_attribs_sd
go
--
------> table its_ged_prod.hts_sec_master <------
--
DROP REPLICATION DEFINITION hts_sec_master_sd
go
--
------> table its_ged_prod.hts_settle_rule <------
--
DROP REPLICATION DEFINITION hts_settle_rule_sd
go
--
------> table its_ged_prod.hts_sfailure_event <------
--
DROP REPLICATION DEFINITION hts_sfailure_event_sd
go
--
------> table its_ged_prod.hts_sm_audit_trail_log <------
--
DROP REPLICATION DEFINITION hts_sm_audit_trail_log_sd
go
--
------> table its_ged_prod.hts_sm_ba_detail <------
--
DROP REPLICATION DEFINITION hts_sm_ba_detail_sd
go
--
------> table its_ged_prod.hts_sm_binary_detail <------
--
DROP REPLICATION DEFINITION hts_sm_binary_detail_sd
go
--
------> table its_ged_prod.hts_sm_cfd <------
--
DROP REPLICATION DEFINITION hts_sm_cfd_sd
go
--
------> table its_ged_prod.hts_sm_deriv_detail <------
--
DROP REPLICATION DEFINITION hts_sm_deriv_detail_sd
go
--
------> table its_ged_prod.hts_sm_eqss_detail <------
--
DROP REPLICATION DEFINITION hts_sm_eqss_detail_sd
go
--
------> table its_ged_prod.hts_sm_relation <------
--
DROP REPLICATION DEFINITION hts_sm_relation_sd
go
--
------> table its_ged_prod.hts_sm_repo <------
--
DROP REPLICATION DEFINITION hts_sm_repo_sd
go
--
------> table its_ged_prod.hts_sm_repo_sched <------
--
DROP REPLICATION DEFINITION hts_sm_repo_sched_sd
go
--
------> table its_ged_prod.hts_sm_stripbond_detail <------
--
DROP REPLICATION DEFINITION hts_sm_stripbond_detail_sd
go
--
------> table its_ged_prod.hts_sm_user_data <------
--
DROP REPLICATION DEFINITION hts_sm_user_data_sd
go
--
------> table its_ged_prod.hts_sm_usymbol_view <------
--
DROP REPLICATION DEFINITION hts_sm_usymbol_view_sd
go
--
------> table its_ged_prod.hts_snap_status <------
--
DROP REPLICATION DEFINITION hts_snap_status_sd
go
--
------> table its_ged_prod.hts_sp_return_codes <------
--
DROP REPLICATION DEFINITION hts_sp_return_codes_sd
go
--
------> table its_ged_prod.hts_split <------
--
DROP REPLICATION DEFINITION hts_split_sd
go
--
------> table its_ged_prod.hts_split_log <------
--
DROP REPLICATION DEFINITION hts_split_log_sd
go
--
------> table its_ged_prod.hts_split_status <------
--
DROP REPLICATION DEFINITION hts_split_status_sd
go
--
------> table its_ged_prod.hts_spot_list <------
--
DROP REPLICATION DEFINITION hts_spot_list_sd
go
--
------> table its_ged_prod.hts_stock_merger <------
--
DROP REPLICATION DEFINITION hts_stock_merger_sd
go
--
------> table its_ged_prod.hts_stock_merger_list <------
--
DROP REPLICATION DEFINITION hts_stock_merger_list_sd
go
--
------> table its_ged_prod.hts_stock_spinoff <------
--
DROP REPLICATION DEFINITION hts_stock_spinoff_sd
go
--
------> table its_ged_prod.hts_stock_spinoff_list <------
--
DROP REPLICATION DEFINITION hts_stock_spinoff_list_sd
go
--
------> table its_ged_prod.hts_strategy <------
--
DROP REPLICATION DEFINITION hts_strategy_sd
go
--
------> table its_ged_prod.hts_strategy_component <------
--
DROP REPLICATION DEFINITION hts_strategy_component_sd
go
--
------> table its_ged_prod.hts_strategy_group <------
--
DROP REPLICATION DEFINITION hts_strategy_group_sd
go
--
------> table its_ged_prod.hts_swap <------
--
DROP REPLICATION DEFINITION hts_swap_sd
go
--
------> table its_ged_prod.hts_swap_basket_reset <------
--
DROP REPLICATION DEFINITION hts_swap_basket_reset_sd
go
--
------> table its_ged_prod.hts_swap_detail <------
--
DROP REPLICATION DEFINITION hts_swap_detail_sd
go
--
------> table its_ged_prod.hts_swap_div_sched <------
--
DROP REPLICATION DEFINITION hts_swap_div_sched_sd
go
--
------> table its_ged_prod.hts_swap_equity_leg <------
--
DROP REPLICATION DEFINITION hts_swap_equity_leg_sd
go
--
------> table its_ged_prod.hts_swap_event_sched <------
--
DROP REPLICATION DEFINITION hts_swap_event_sched_sd
go
--
------> table its_ged_prod.hts_swap_floating_leg <------
--
DROP REPLICATION DEFINITION hts_swap_floating_leg_sd
go
--
------> table its_ged_prod.hts_swap_leg <------
--
DROP REPLICATION DEFINITION hts_swap_leg_sd
go
--
------> table its_ged_prod.hts_swap_list <------
--
DROP REPLICATION DEFINITION hts_swap_list_sd
go
--
------> table its_ged_prod.hts_swap_quanto_leg <------
--
DROP REPLICATION DEFINITION hts_swap_quanto_leg_sd
go
--
------> table its_ged_prod.hts_swap_sched_filt <------
--
DROP REPLICATION DEFINITION hts_swap_sched_filt_sd
go
--
------> table its_ged_prod.hts_system_status <------
--
DROP REPLICATION DEFINITION hts_system_status_sd
go
--
------> table its_ged_prod.hts_tax_rules <------
--
DROP REPLICATION DEFINITION hts_tax_rules_sd
go
--
------> table its_ged_prod.hts_template_detail <------
--
DROP REPLICATION DEFINITION hts_template_detail_sd
go
--
------> table its_ged_prod.hts_template_list <------
--
DROP REPLICATION DEFINITION hts_template_list_sd
go
--
------> table its_ged_prod.hts_tick_size_list <------
--
DROP REPLICATION DEFINITION hts_tick_size_list_sd
go
--
------> table its_ged_prod.hts_tick_sizes <------
--
DROP REPLICATION DEFINITION hts_tick_sizes_sd
go
--
------> table its_ged_prod.hts_tickets <------
--
DROP REPLICATION DEFINITION hts_tickets_sd
go
--
------> table its_ged_prod.hts_time_zone <------
--
DROP REPLICATION DEFINITION hts_time_zone_sd
go
--
------> table its_ged_prod.hts_trader <------
--
DROP REPLICATION DEFINITION hts_trader_sd
go
--
------> table its_ged_prod.hts_trader_security <------
--
DROP REPLICATION DEFINITION hts_trader_security_sd
go
--
------> table its_ged_prod.hts_tvol_detail <------
--
DROP REPLICATION DEFINITION hts_tvol_detail_sd
go
--
------> table its_ged_prod.hts_tvol_list <------
--
DROP REPLICATION DEFINITION hts_tvol_list_sd
go
--
------> table its_ged_prod.hts_underlying <------
--
DROP REPLICATION DEFINITION hts_underlying_sd
go
--
------> table its_ged_prod.hts_user <------
--
DROP REPLICATION DEFINITION hts_user_sd
go
--
------> table its_ged_prod.hts_user_company <------
--
DROP REPLICATION DEFINITION hts_user_company_sd
go
--
------> table its_ged_prod.hts_user_info <------
--
DROP REPLICATION DEFINITION hts_user_info_sd
go
--
------> table its_ged_prod.hts_user_message <------
--
DROP REPLICATION DEFINITION hts_user_message_sd
go
--
------> table its_ged_prod.hts_user_rt_default <------
--
DROP REPLICATION DEFINITION hts_user_rt_default_sd
go
--
------> table its_ged_prod.hts_users <------
--
DROP REPLICATION DEFINITION hts_users_sd
go
--
------> table its_ged_prod.hts_valid_date_patterns <------
--
DROP REPLICATION DEFINITION hts_valid_date_patterns_sd
go
--
------> table its_ged_prod.hts_var_cross_ref <------
--
DROP REPLICATION DEFINITION hts_var_cross_ref_sd
go
--
------> table its_ged_prod.hts_volatility_detail <------
--
DROP REPLICATION DEFINITION hts_volatility_detail_sd
go
--
------> table its_ged_prod.hts_volatility_detail_arc <------
--
DROP REPLICATION DEFINITION hts_volatility_detail_arc_sd
go
--
------> table its_ged_prod.hts_volatility_list <------
--
DROP REPLICATION DEFINITION hts_volatility_list_sd
go
--
------> table its_ged_prod.hts_volatility_list_arc <------
--
DROP REPLICATION DEFINITION hts_volatility_list_arc_sd
go
--
------> table its_ged_prod.hts_xact_history <------
--
DROP REPLICATION DEFINITION hts_xact_history_sd
go
--
------> table its_ged_prod.hts_xrate_detail <------
--
DROP REPLICATION DEFINITION hts_xrate_detail_sd
go
--
------> table its_ged_prod.hts_xrate_list <------
--
DROP REPLICATION DEFINITION hts_xrate_list_sd
go
--
------> table its_ged_prod.hts_yc_alg_risk <------
--
DROP REPLICATION DEFINITION hts_yc_alg_risk_sd
go
--
------> table its_ged_prod.hts_yc_cred_agency <------
--
DROP REPLICATION DEFINITION hts_yc_cred_agency_sd
go
--
------> table its_ged_prod.hts_yc_cred_i2s_map <------
--
DROP REPLICATION DEFINITION hts_yc_cred_i2s_map_sd
go
--
------> table its_ged_prod.hts_yc_cred_level <------
--
DROP REPLICATION DEFINITION hts_yc_cred_level_sd
go
--
------> table its_ged_prod.hts_yc_cred_matrix <------
--
DROP REPLICATION DEFINITION hts_yc_cred_matrix_sd
go
--
------> table its_ged_prod.hts_yc_curve <------
--
DROP REPLICATION DEFINITION hts_yc_curve_sd
go
--
------> table its_ged_prod.hts_yc_hdg_instr <------
--
DROP REPLICATION DEFINITION hts_yc_hdg_instr_sd
go
--
------> table its_ged_prod.hts_yc_hdg_strat <------
--
DROP REPLICATION DEFINITION hts_yc_hdg_strat_sd
go
--
------> table its_ged_prod.hts_yc_link_data <------
--
DROP REPLICATION DEFINITION hts_yc_link_data_sd
go
--
------> table its_ged_prod.hts_yc_mkt_instr <------
--
DROP REPLICATION DEFINITION hts_yc_mkt_instr_sd
go
--
------> table its_ged_prod.hts_yc_mkt_instr_data <------
--
DROP REPLICATION DEFINITION hts_yc_mkt_instr_data_sd
go
--
------> table its_ged_prod.hts_yc_mkt_instr_hdr <------
--
DROP REPLICATION DEFINITION hts_yc_mkt_instr_hdr_sd
go
--
------> table its_ged_prod.hts_yc_model <------
--
DROP REPLICATION DEFINITION hts_yc_model_sd
go
--
------> table its_ged_prod.hts_yc_risk_curve <------
--
DROP REPLICATION DEFINITION hts_yc_risk_curve_sd
go
--
------> table its_ged_prod.hts_yc_risk_curves_view <------
--
DROP REPLICATION DEFINITION hts_yc_risk_curves_view_sd
go
--
------> table its_ged_prod.hts_yc_risk_data <------
--
DROP REPLICATION DEFINITION hts_yc_risk_data_sd
go
--
------> table its_ged_prod.hts_yc_risk_scenar_view <------
--
DROP REPLICATION DEFINITION hts_yc_risk_scenar_view_sd
go
--
------> table its_ged_prod.hts_yc_risk_scenario <------
--
DROP REPLICATION DEFINITION hts_yc_risk_scenario_sd
go
--
------> table its_ged_prod.hts_yc_scenario <------
--
DROP REPLICATION DEFINITION hts_yc_scenario_sd
go
--
------> table its_ged_prod.hts_yc_sp <------
--
DROP REPLICATION DEFINITION hts_yc_sp_sd
go
--
------> table its_ged_prod.hts_yc_sp_hdr <------
--
DROP REPLICATION DEFINITION hts_yc_sp_hdr_sd
go
--
------> table its_ged_prod.hts_yc_strip <------
--
DROP REPLICATION DEFINITION hts_yc_strip_sd
go
--
------> table its_ged_prod.hts_yc_swap_spec <------
--
DROP REPLICATION DEFINITION hts_yc_swap_spec_sd
go
--
------> table its_ged_prod.hts_yield_detail <------
--
DROP REPLICATION DEFINITION hts_yield_detail_sd
go
--
------> table its_ged_prod.hts_yield_list <------
--
DROP REPLICATION DEFINITION hts_yield_list_sd
go
--
------> table its_ged_prod.lic_feature <------
--
DROP REPLICATION DEFINITION lic_feature_sd
go
--
------> table its_ged_prod.lic_usage <------
--
DROP REPLICATION DEFINITION lic_usage_sd
go
--
------> table its_ged_prod.mdl_portf_colnames_tb <------
--
DROP REPLICATION DEFINITION mdl_portf_colnames_tb_sd
go
--
------> table its_ged_prod.t_ICONCDRImport <------
--
DROP REPLICATION DEFINITION t_ICONCDRImport_sd
go
--
------> table its_ged_prod.t_ICONCDRLookup <------
--
DROP REPLICATION DEFINITION t_ICONCDRLookup_sd
go
--
------> table its_ged_prod.t_ICONFeedControl <------
--
DROP REPLICATION DEFINITION t_ICONFeedControl_sd
go
--
------> table its_ged_prod.t_ICONFilesInfo <------
--
DROP REPLICATION DEFINITION t_ICONFilesInfo_sd
go
--
------> table its_ged_prod.t_ICONPrepareTradeFile <------
--
DROP REPLICATION DEFINITION t_ICONPrepareTradeFile_sd
go
--
------> table its_ged_prod.t_ICONTradesCompare <------
--
DROP REPLICATION DEFINITION t_ICONTradesCompare_sd
go
--
------> table its_ged_prod.t_ICONTradesSentDetail <------
--
DROP REPLICATION DEFINITION t_ICONTradesSentDetail_sd
go
--
------> table its_ged_prod.t_ICONTradesTemp <------
--
DROP REPLICATION DEFINITION t_ICONTradesTemp_sd
go
--
------> table its_ged_prod.t_init_ICONPrepareTradeFile <------
--
DROP REPLICATION DEFINITION t_init_ICONPrepareTradeFile_sd
go
--
------> table its_ged_prod.t_init_ICONTradesSentDetail <------
--
DROP REPLICATION DEFINITION t_init_ICONTradesSentDetail_sd
go
--
------> table its_ged_prod.t_init_ImportCDR <------
--
DROP REPLICATION DEFINITION t_init_ImportCDR_sd
go
--
------> table its_ged_prod.test1 <------
--
DROP REPLICATION DEFINITION test1_sd
go
--
------> table its_ged_prod.user_location <------
--
DROP REPLICATION DEFINITION user_location_sd
go
--
------> table its_ged_prod.world_clock <------
--
DROP REPLICATION DEFINITION world_clock_sd
go
