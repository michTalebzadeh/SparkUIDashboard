prompt
Prompt +------------------------------+
Prompt | DBWR I/O FROM V$SYSTEM_EVENT |
Prompt +------------------------------+

select * from v$system_event
where event in ('free buffer waits','free buffer inspected');
/
exit
