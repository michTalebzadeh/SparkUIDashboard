 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SERVICE_NAME									   VARCHAR2(64)
 SERVICE_NAME_HASH								   NUMBER
 EVENT										   VARCHAR2(64)
 EVENT_ID									   NUMBER
 TOTAL_WAITS									   NUMBER
 TOTAL_TIMEOUTS 								   NUMBER
 TIME_WAITED									   NUMBER
 AVERAGE_WAIT									   NUMBER
 MAX_WAIT									   NUMBER
 TIME_WAITED_MICRO								   NUMBER

