 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 GROUP_NUMBER									   NUMBER
 NAME										   VARCHAR2(30)
 SECTOR_SIZE									   NUMBER
 BLOCK_SIZE									   NUMBER
 ALLOCATION_UNIT_SIZE								   NUMBER
 STATE										   VARCHAR2(11)
 TYPE										   VARCHAR2(6)
 TOTAL_MB									   NUMBER
 FREE_MB									   NUMBER
 HOT_USED_MB									   NUMBER
 COLD_USED_MB									   NUMBER
 REQUIRED_MIRROR_FREE_MB							   NUMBER
 USABLE_FILE_MB 								   NUMBER
 OFFLINE_DISKS									   NUMBER
 COMPATIBILITY									   VARCHAR2(60)
 DATABASE_COMPATIBILITY 							   VARCHAR2(60)
 VOTING_FILES									   VARCHAR2(1)

