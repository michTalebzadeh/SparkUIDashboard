@$HOME/abc
--v$sql & v$session tables will help: 
select s.username, q.sql_text 
  from v$sql q, v$session s
  where s.sql_address = q.address
    and s.sql_hash_value = q.hash_value
    and s.status = 'ACTIVE'
/
exit
