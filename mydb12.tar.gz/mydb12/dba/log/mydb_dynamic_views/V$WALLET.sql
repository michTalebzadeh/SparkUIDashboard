 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 CERT_ID									   VARCHAR2(52)
 DN										   VARCHAR2(255)
 SERIAL_NUM									   VARCHAR2(40)
 ISSUER 									   VARCHAR2(255)
 KEYSIZE									   NUMBER
 STATUS 									   VARCHAR2(16)

