use master
go
load database its_ged_prod from 'compress::/dbdumps/lon_gen_sql_tst1/its_ged_prod_01'
go
exit
