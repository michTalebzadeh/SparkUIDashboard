@login
select TO_CHAR(MIN(Begin_Time),'DD-MON-YYYY HH24:MI:SS')
                                 "Begin Time",
       TO_CHAR(MAX(End_Time),'DD-MON-YYYY HH24:MI:SS')
                                 "End Time",
       SUM(Undoblks)       "Total Undo Blocks Used",
       SUM(Txncount)       "Total Num Trans Exec",
       MAX(Maxquerylen)    "Longest Query(in secs)",
       MAX(Maxconcurrency) "Highest Concurrent Trans Count",
       SUM(Ssolderrcnt),
       SUM(Nospaceerrcnt)
from V$UNDOSTAT
/
exit
/
