 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 GROUP_NUMBER									   NUMBER
 MEMBER_NUMBER									   NUMBER
 MEMBER_INCARNATION								   NUMBER
 USERGROUP_NUMBER								   NUMBER
 USERGROUP_INCARNATION								   NUMBER

