set timing on
ALTER SESSION SET EVENTS '10046 TRACE NAME CONTEXT FOREVER, LEVEL 8';
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_with_tdash_tester';
                        SELECT * FROM tdash WHERE object_id in (100,3876700,3876701);
exit
