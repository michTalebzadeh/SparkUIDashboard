select * from user_constraints where table_name = 'TDASH' and constraint_type = 'P';
select * from user_indexes where table_name = 'TDASH';
exit
