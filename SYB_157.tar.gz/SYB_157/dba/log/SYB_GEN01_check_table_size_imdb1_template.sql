                        
 ---------------------- 
 use imdb1_template 
go 

                                                                                                                                                                                                                                                                                 
 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- 
 sp_spaceused DBA_OBJECTS
go                                                                                                                                                                                                                                                     
 sp_spaceused IQSALES
go                                                                                                                                                                                                                                                         
 sp_spaceused IQUNPART
go                                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$ACCESS
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$ACTIVE_INSTANCES
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$ACTIVE_SERVICES
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$ACTIVE_SESSION_HISTORY
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$ACTIVE_SESS_POOL_MTH
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$ADVISOR_PROGRESS
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$ALERT_TYPES
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$AQ1
go                                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$ARCHIVE
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$ARCHIVED_LOG
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$ARCHIVE_DEST
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$ARCHIVE_DEST_STATUS
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$ARCHIVE_GAP
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$ARCHIVE_PROCESSES
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$ASH_INFO
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$ASM_ACFSSNAPSHOTS
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$ASM_ACFSVOLUMES
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$ASM_ALIAS
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$ASM_ATTRIBUTE
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$ASM_CLIENT
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$ASM_DISK
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$ASM_DISKGROUP
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$ASM_DISKGROUP_STAT
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$ASM_DISK_IOSTAT
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$ASM_DISK_STAT
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$ASM_FILE
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$ASM_FILESYSTEM
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$ASM_OPERATION
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$ASM_TEMPLATE
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$ASM_USER
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$ASM_USERGROUP
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$ASM_USERGROUP_MEMBER
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$ASM_VOLUME
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$ASM_VOLUME_STAT
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$AW_AGGREGATE_OP
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$AW_ALLOCATE_OP
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$AW_CALC
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$AW_LONGOPS
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$AW_OLAP
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$AW_SESSION_INFO
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$BACKUP
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$BACKUP_ARCHIVELOG_DETAILS
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$BACKUP_ARCHIVELOG_SUMMARY
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$BACKUP_ASYNC_IO
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$BACKUP_CONTROLFILE_DETAILS
go                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$BACKUP_CONTROLFILE_SUMMARY
go                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$BACKUP_COPY_DETAILS
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$BACKUP_COPY_SUMMARY
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$BACKUP_CORRUPTION
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$BACKUP_DATAFILE
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$BACKUP_DATAFILE_DETAILS
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$BACKUP_DATAFILE_SUMMARY
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$BACKUP_DEVICE
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$BACKUP_PIECE
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$BACKUP_PIECE_DETAILS
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$BACKUP_REDOLOG
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$BACKUP_SET
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$BACKUP_SET_DETAILS
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$BACKUP_SET_SUMMARY
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$BACKUP_SPFILE
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$BACKUP_SPFILE_DETAILS
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$BACKUP_SPFILE_SUMMARY
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$BACKUP_SYNC_IO
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$BGPROCESS
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$BH
go                                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$BLOCKING_QUIESCE
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$BLOCK_CHANGE_TRACKING
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$BSP
go                                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$BUFFERED_PUBLISHERS
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$BUFFERED_QUEUES
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$BUFFERED_SUBSCRIBERS
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$BUFFER_POOL
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$BUFFER_POOL_STATISTICS
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$CALLTAG
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$CELL
go                                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$CELL_CONFIG
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$CELL_REQUEST_TOTALS
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$CELL_STATE
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$CELL_THREAD_HISTORY
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$CIRCUIT
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$CLASS_CACHE_TRANSFER
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$CLASS_PING
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$CLIENT_STATS
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$CLUSTER_INTERCONNECTS
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$CONFIGURED_INTERCONNECTS
go                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$CONTEXT
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$CONTROLFILE
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$CONTROLFILE_RECORD_SECTION
go                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$COPY_CORRUPTION
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$CORRUPT_XID_LIST
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$CPOOL_CC_INFO
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$CPOOL_CC_STATS
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$CPOOL_CONN_INFO
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$CPOOL_STATS
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$CR_BLOCK_SERVER
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$CURRENT_BLOCK_SERVER
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$DATABASE
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$DATABASE_BLOCK_CORRUPTION
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$DATABASE_INCARNATION
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$DATAFILE
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$DATAFILE_COPY
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$DATAFILE_HEADER
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$DATAGUARD_CONFIG
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$DATAGUARD_STATS
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$DATAGUARD_STATUS
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$DATAPUMP_JOB
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$DATAPUMP_SESSION
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$DBFILE
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$DBLINK
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$DB_CACHE_ADVICE
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$DB_OBJECT_CACHE
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$DB_PIPES
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$DB_TRANSPORTABLE_PLATFORM
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$DELETED_OBJECT
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$DETACHED_SESSION
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$DIAG_CRITICAL_ERROR
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$DIAG_INFO
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$DISPATCHER
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$DISPATCHER_CONFIG
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$DISPATCHER_RATE
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$DLM_ALL_LOCKS
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$DLM_CONVERT_LOCAL
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$DLM_CONVERT_REMOTE
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$DLM_LATCH
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$DLM_LOCKS
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$DLM_MISC
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$DLM_RESS
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$DLM_TRAFFIC_CONTROLLER
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$DNFS_CHANNELS
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$DNFS_FILES
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$DNFS_SERVERS
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$DNFS_STATS
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$DYNAMIC_REMASTER_STATS
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$EMON
go                                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$ENABLEDPRIVS
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$ENCRYPTED_TABLESPACES
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$ENCRYPTION_WALLET
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$ENQUEUE_LOCK
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$ENQUEUE_STAT
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$ENQUEUE_STATISTICS
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$EVENTMETRIC
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$EVENT_HISTOGRAM
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$EVENT_NAME
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$EXECUTION
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$FAST_START_SERVERS
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$FAST_START_TRANSACTIONS
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$FILEMETRIC
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$FILEMETRIC_HISTORY
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$FILESPACE_USAGE
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$FILESTAT
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$FILE_CACHE_TRANSFER
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$FILE_HISTOGRAM
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$FILE_OPTIMIZED_HISTOGRAM
go                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$FILE_PING
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$FIXED_TABLE
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$FIXED_VIEW_DEFINITION
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$FLASHBACK_DATABASE_LOG
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$FLASHBACK_DATABASE_LOGFILE
go                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$FLASHBACK_DATABASE_STAT
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$FLASHBACK_TXN_GRAPH
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$FLASHBACK_TXN_MODS
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$FLASH_RECOVERY_AREA_USAGE
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$FOREIGN_ARCHIVED_LOG
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$FS_FAILOVER_HISTOGRAM
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$FS_FAILOVER_STATS
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$GCSHVMASTER_INFO
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$GCSPFMASTER_INFO
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$GC_ELEMENT
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$GES_BLOCKING_ENQUEUE
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$GES_ENQUEUE
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$GLOBALCONTEXT
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$GLOBAL_BLOCKED_LOCKS
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$GLOBAL_TRANSACTION
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$HM_CHECK
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$HM_CHECK_PARAM
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$HM_FINDING
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$HM_INFO
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$HM_RECOMMENDATION
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$HM_RUN
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$HS_AGENT
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$HS_PARAMETER
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$HS_SESSION
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$HVMASTER_INFO
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$INCMETER_CONFIG
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$INCMETER_INFO
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$INCMETER_SUMMARY
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$INDEXED_FIXED_COLUMN
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$INSTANCE
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$INSTANCE_CACHE_TRANSFER
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$INSTANCE_LOG_GROUP
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$INSTANCE_RECOVERY
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$IOFUNCMETRIC
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$IOFUNCMETRIC_HISTORY
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$IOSTAT_CONSUMER_GROUP
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$IOSTAT_FILE
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$IOSTAT_FUNCTION
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$IOSTAT_FUNCTION_DETAIL
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$IOSTAT_NETWORK
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$IO_CALIBRATION_STATUS
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$IR_FAILURE
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$IR_FAILURE_SET
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$IR_MANUAL_CHECKLIST
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$IR_REPAIR
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$JAVAPOOL
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$JAVA_LIBRARY_CACHE_MEMORY
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$JAVA_POOL_ADVICE
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$LATCH
go                                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$LATCHHOLDER
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$LATCHNAME
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$LATCH_CHILDREN
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$LATCH_MISSES
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$LATCH_PARENT
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$LIBCACHE_LOCKS
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$LIBRARYCACHE
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$LIBRARY_CACHE_MEMORY
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$LICENSE
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$LISTENER_NETWORK
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$LOADISTAT
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$LOADPSTAT
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$LOBSTAT
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$LOCK
go                                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$LOCKED_OBJECT
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$LOCKS_WITH_COLLISIONS
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$LOCK_ACTIVITY
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$LOCK_ELEMENT
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$LOCK_TYPE
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$LOG
go                                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$LOGFILE
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$LOGHIST
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$LOGMNR_CALLBACK
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$LOGMNR_CONTENTS
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$LOGMNR_DICTIONARY
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$LOGMNR_DICTIONARY_LOAD
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$LOGMNR_LATCH
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$LOGMNR_LOGFILE
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$LOGMNR_LOGS
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$LOGMNR_PARAMETERS
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$LOGMNR_PROCESS
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$LOGMNR_REGION
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$LOGMNR_SESSION
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$LOGMNR_STATS
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$LOGMNR_TRANSACTION
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$LOGSTDBY
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$LOGSTDBY_PROCESS
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$LOGSTDBY_PROGRESS
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$LOGSTDBY_STATE
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$LOGSTDBY_STATS
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$LOGSTDBY_TRANSACTION
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$LOG_HISTORY
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$MANAGED_STANDBY
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$MAP_COMP_LIST
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$MAP_ELEMENT
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$MAP_EXT_ELEMENT
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$MAP_FILE
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$MAP_FILE_EXTENT
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$MAP_FILE_IO_STACK
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$MAP_LIBRARY
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$MAP_SUBELEMENT
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$MAX_ACTIVE_SESS_TARGET_MTH
go                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$MEMORY_CURRENT_RESIZE_OPS
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$MEMORY_DYNAMIC_COMPONENTS
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$MEMORY_RESIZE_OPS
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$MEMORY_TARGET_ADVICE
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$METRIC
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$METRICGROUP
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$METRICNAME
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$METRIC_HISTORY
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$MTTR_TARGET_ADVICE
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$MUTEX_SLEEP
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$MUTEX_SLEEP_HISTORY
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$MVREFRESH
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$MYSTAT
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$NFS_CLIENTS
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$NFS_LOCKS
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$NFS_OPEN_FILES
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$NLS_PARAMETERS
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$NLS_VALID_VALUES
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$OBJECT_DEPENDENCY
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$OBJECT_PRIVILEGE
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$OBSOLETE_PARAMETER
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$OFFLINE_RANGE
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$OPEN_CURSOR
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$OPTION
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$OSSTAT
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$PARALLEL_DEGREE_LIMIT_MTH
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$PARAMETER
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$PARAMETER2
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$PARAMETER_VALID_VALUES
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$PERSISTENT_PUBLISHERS
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$PERSISTENT_QMN_CACHE
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$PERSISTENT_QUEUES
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$PERSISTENT_SUBSCRIBERS
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$PGASTAT
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$PGA_TARGET_ADVICE
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$PGA_TARGET_ADVICE_HISTOGRAM
go                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$POLICY_HISTORY
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$PQ_SESSTAT
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$PQ_SLAVE
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$PQ_SYSSTAT
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$PQ_TQSTAT
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$PROCESS
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$PROCESS_GROUP
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$PROCESS_MEMORY
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$PROCESS_MEMORY_DETAIL
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$PROCESS_MEMORY_DETAIL_PROG
go                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$PROPAGATION_RECEIVER
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$PROPAGATION_SENDER
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$PROXY_ARCHIVEDLOG
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$PROXY_ARCHIVELOG_DETAILS
go                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$PROXY_ARCHIVELOG_SUMMARY
go                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$PROXY_COPY_DETAILS
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$PROXY_COPY_SUMMARY
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$PROXY_DATAFILE
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$PWFILE_USERS
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$PX_BUFFER_ADVICE
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$PX_INSTANCE_GROUP
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$PX_PROCESS
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$PX_PROCESS_SYSSTAT
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$PX_SESSION
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$PX_SESSTAT
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$QMON_COORDINATOR_STATS
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$QMON_SERVER_STATS
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$QMON_TASKS
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$QMON_TASK_STATS
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$QUEUE
go                                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$QUEUEING_MTH
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$RECOVERY_AREA_USAGE
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$RECOVERY_FILE_DEST
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$RECOVERY_FILE_STATUS
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$RECOVERY_LOG
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$RECOVERY_PROGRESS
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$RECOVERY_STATUS
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$RECOVER_FILE
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$REDO_DEST_RESP_HISTOGRAM
go                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$REPLPROP
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$REPLQUEUE
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$REQDIST
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$RESERVED_WORDS
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$RESOURCE
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$RESOURCE_LIMIT
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$RESTORE_POINT
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$RESULT_CACHE_DEPENDENCY
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$RESULT_CACHE_MEMORY
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$RESULT_CACHE_OBJECTS
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$RESULT_CACHE_STATISTICS
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$RESUMABLE
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$RFS_THREAD
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$RMAN_BACKUP_JOB_DETAILS
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$RMAN_BACKUP_SUBJOB_DETAILS
go                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$RMAN_BACKUP_TYPE
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$RMAN_COMPRESSION_ALGORITHM
go                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$RMAN_CONFIGURATION
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$RMAN_ENCRYPTION_ALGORITHMS
go                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$RMAN_OUTPUT
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$RMAN_STATUS
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$ROLLSTAT
go                                                                                                                                                                                                                                                 
go                                                                                                                                                                                                                                                 
go                                                                                                                                                                                                                                          
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$RSRCMGRMETRIC
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$RSRCMGRMETRIC_HISTORY
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$RSRC_CONSUMER_GROUP
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$RSRC_CONSUMER_GROUP_CPU_MTH
go                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$RSRC_CONS_GROUP_HISTORY
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$RSRC_PLAN
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$RSRC_PLAN_CPU_MTH
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$RSRC_PLAN_HISTORY
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$RSRC_SESSION_INFO
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$RULE
go                                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$RULE_SET
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$RULE_SET_AGGREGATE_STATS
go                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$SCHEDULER_RUNNING_JOBS
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$SECUREFILE_TIMER
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$SEGMENT_STATISTICS
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$SEGSTAT
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SEGSTAT_NAME
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$SERVICEMETRIC
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$SERVICEMETRIC_HISTORY
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$SERVICES
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$SERVICE_EVENT
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$SERVICE_STATS
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$SERVICE_WAIT_CLASS
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$SERV_MOD_ACT_STATS
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$SESSION
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SESSION_BLOCKERS
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$SESSION_CONNECT_INFO
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$SESSION_CURSOR_CACHE
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$SESSION_EVENT
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$SESSION_FIX_CONTROL
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$SESSION_LONGOPS
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$SESSION_OBJECT_CACHE
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$SESSION_WAIT
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$SESSION_WAIT_CLASS
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$SESSION_WAIT_HISTORY
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$SESSMETRIC
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$SESSTAT
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SESS_IO
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SESS_TIME_MODEL
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$SES_OPTIMIZER_ENV
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SGA
go                                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$SGAINFO
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SGASTAT
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SGA_CURRENT_RESIZE_OPS
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$SGA_DYNAMIC_COMPONENTS
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$SGA_DYNAMIC_FREE_MEMORY
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SGA_RESIZE_OPS
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$SGA_TARGET_ADVICE
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SHARED_POOL_ADVICE
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$SHARED_POOL_RESERVED
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$SHARED_SERVER
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$SHARED_SERVER_MONITOR
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$SORT_SEGMENT
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$SORT_USAGE
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$SPPARAMETER
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$SQL
go                                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$SQLAREA
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SQLAREA_PLAN_HASH
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SQLCOMMAND
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$SQLFN_ARG_METADATA
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$SQLFN_METADATA
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$SQLPA_METRIC
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$SQLSTATS
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$SQLSTATS_PLAN_HASH
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$SQLTEXT
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SQLTEXT_WITH_NEWLINES
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$SQL_BIND_DATA
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$SQL_BIND_METADATA
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SQL_CS_HISTOGRAM
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$SQL_CS_SELECTIVITY
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$SQL_CS_STATISTICS
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SQL_CURSOR
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$SQL_FEATURE
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$SQL_FEATURE_DEPENDENCY
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$SQL_FEATURE_HIERARCHY
go                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$SQL_HINT
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$SQL_JOIN_FILTER
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$SQL_MONITOR
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$SQL_OPTIMIZER_ENV
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SQL_PLAN
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$SQL_PLAN_MONITOR
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$SQL_PLAN_STATISTICS
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$SQL_PLAN_STATISTICS_ALL
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SQL_REDIRECTION
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$SQL_SHARED_CURSOR
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SQL_SHARED_MEMORY
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SQL_WORKAREA
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$SQL_WORKAREA_ACTIVE
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$SQL_WORKAREA_HISTOGRAM
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$SSCR_SESSIONS
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$STANDBY_EVENT_HISTOGRAM
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$STANDBY_LOG
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$STATISTICS_LEVEL
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$STATNAME
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$STREAMS_APPLY_COORDINATOR
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$STREAMS_APPLY_READER
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$STREAMS_APPLY_SERVER
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$STREAMS_CAPTURE
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$STREAMS_MESSAGE_TRACKING
go                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$STREAMS_POOL_ADVICE
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$STREAMS_POOL_STATISTICS
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$STREAMS_TRANSACTION
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$SUBCACHE
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$SUBSCR_REGISTRATION_STATS
go                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$SYSAUX_OCCUPANTS
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$SYSMETRIC
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$SYSMETRIC_HISTORY
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SYSMETRIC_SUMMARY
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SYSSTAT
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$SYSTEM_CURSOR_CACHE
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$SYSTEM_EVENT
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$SYSTEM_FIX_CONTROL
go                                                                                                                                                                                                                                       
 sp_spaceused MYDB_V$SYSTEM_PARAMETER
go                                                                                                                                                                                                                                         
 sp_spaceused MYDB_V$SYSTEM_PARAMETER2
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SYSTEM_WAIT_CLASS
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SYS_OPTIMIZER_ENV
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$SYS_TIME_MODEL
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$TABLESPACE
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$TEMPFILE
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$TEMPORARY_LOBS
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$TEMPSTAT
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$TEMP_CACHE_TRANSFER
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$TEMP_EXTENT_MAP
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$TEMP_PING
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$TEMP_SPACE_HEADER
go                                                                                                                                                                                                                                        
 sp_spaceused MYDB_V$THREAD
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$THRESHOLD_TYPES
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$TIMER
go                                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V$TIMEZONE_FILE
go                                                                                                                                                                                                                                            
 sp_spaceused MYDB_V$TIMEZONE_NAMES
go                                                                                                                                                                                                                                           
 sp_spaceused MYDB_V$TOPLEVELCALL
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$TRANSACTION
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$TRANSACTION_ENQUEUE
go                                                                                                                                                                                                                                      
 sp_spaceused MYDB_V$TRANSPORTABLE_PLATFORM
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$TSM_SESSIONS
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$TYPE_SIZE
go                                                                                                                                                                                                                                                
 sp_spaceused MYDB_V$UNDOSTAT
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$UNUSABLE_BACKUPFILE_DETAILS
go                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$VERSION
go                                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$VPD_POLICY
go                                                                                                                                                                                                                                               
 sp_spaceused MYDB_V$WAITCLASSMETRIC
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$WAITCLASSMETRIC_HISTORY
go                                                                                                                                                                                                                                  
 sp_spaceused MYDB_V$WAITSTAT
go                                                                                                                                                                                                                                                 
 sp_spaceused MYDB_V$WAIT_CHAINS
go                                                                                                                                                                                                                                              
 sp_spaceused MYDB_V$WALLET
go                                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$WLM_PCMETRIC
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$WLM_PCMETRIC_HISTORY
go                                                                                                                                                                                                                                     
 sp_spaceused MYDB_V$WLM_PC_STATS
go                                                                                                                                                                                                                                             
 sp_spaceused MYDB_V$WORKLOAD_REPLAY_THREAD
go                                                                                                                                                                                                                                   
 sp_spaceused MYDB_V$XML_AUDIT_TRAIL
go                                                                                                                                                                                                                                          
 sp_spaceused MYDB_V$_LOCK
go                                                                                                                                                                                                                                                    
 sp_spaceused MYDB_V_$PROCESS
go                                                                                                                                                                                                                                                 
 sp_spaceused ORASALES
go                                                                                                                                                                                                                                                        
 sp_spaceused SALES
go                                                                                                                                                                                                                                                           
 sp_spaceused T1
go                                                                                                                                                                                                                                                              
 sp_spaceused UNPART
go                                                                                                                                                                                                                                                          
 sp_spaceused UNPART_tst5
go                                                                                                                                                                                                                                                     
 sp_spaceused abc
go                                                                                                                                                                                                                                                             
 sp_spaceused nulltest
go                                                                                                                                                                                                                                                        
 sp_spaceused ooo
go                                                                                                                                                                                                                                                             
 sp_spaceused t_holding_analytic_hist
go                                                                                                                                                                                                                                         
 sp_spaceused testme2
go                                                                                                                                                                                                                                                         
 sp_spaceused www
go                                                                                                                                                                                                                                                             

