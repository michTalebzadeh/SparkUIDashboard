use master
go
dump database master to 'compress::4::/dbdumps/lon_gen_sql_tst5/dumps/lon_gen_sql_tst5.master.20061113_2138.01.cdmp' 
go
exit
