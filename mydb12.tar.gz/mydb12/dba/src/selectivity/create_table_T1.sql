DROP TABLE T1;
CREATE TABLE T1
                (
                        n1 NUMBER(5)    NOT NULL,
                        ind_pad VARCHAR2(40) NOT NULL,
                        n2 NUMBER(5)    NOT NULL,
                        small_vc VARCHAR2(10) NOT NULL,
                        padding  VARCHAR2(200) NOT NULL
                 );

create index t1_i1 on t1(n1, ind_pad, n2);
desc t1;
exit


