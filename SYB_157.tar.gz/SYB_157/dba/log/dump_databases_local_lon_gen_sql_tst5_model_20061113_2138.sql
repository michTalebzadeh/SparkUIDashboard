use master
go
dump database model to 'compress::4::/dbdumps/lon_gen_sql_tst5/dumps/lon_gen_sql_tst5.model.20061113_2138.01.cdmp' 
go
exit
