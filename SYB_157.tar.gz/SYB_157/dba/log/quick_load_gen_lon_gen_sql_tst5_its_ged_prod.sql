use master
go
load database its_ged_prod from 'compress::/dbdumps/lon_gen_sql_tst5/dumps/lon_gen_sql_tst1.its_ged_prod.20060816_0957.01.cdmp' 
go
exit
