 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ADDR										   RAW(4)
 SID										   NUMBER
 ENABLED									   VARCHAR2(3)
 STATUS 									   VARCHAR2(9)
 TIMEOUT									   NUMBER
 SUSPEND_TIME									   VARCHAR2(20)
 RESUME_TIME									   VARCHAR2(20)
 NAME										   VARCHAR2(4000)
 ERROR_NUMBER									   NUMBER
 ERROR_PARAMETER1								   VARCHAR2(80)
 ERROR_PARAMETER2								   VARCHAR2(80)
 ERROR_PARAMETER3								   VARCHAR2(80)
 ERROR_PARAMETER4								   VARCHAR2(80)
 ERROR_PARAMETER5								   VARCHAR2(80)
 ERROR_MSG									   VARCHAR2(4000)

