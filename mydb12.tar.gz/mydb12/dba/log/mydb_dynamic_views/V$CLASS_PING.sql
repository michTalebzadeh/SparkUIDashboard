 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 CLASS										   CHAR(10)
 X_2_NULL									   NUMBER
 X_2_NULL_FORCED_WRITE								   NUMBER
 X_2_NULL_FORCED_STALE								   NUMBER
 X_2_S										   NUMBER
 X_2_S_FORCED_WRITE								   NUMBER
 X_2_SSX									   NUMBER
 X_2_SSX_FORCED_WRITE								   NUMBER
 S_2_NULL									   NUMBER
 S_2_NULL_FORCED_STALE								   NUMBER
 SS_2_NULL									   NUMBER
 SS_2_RLS									   NUMBER
 OP_2_SS									   NUMBER
 NULL_2_X									   NUMBER
 S_2_X										   NUMBER
 SSX_2_X									   NUMBER
 NULL_2_S									   NUMBER
 NULL_2_SS									   NUMBER

