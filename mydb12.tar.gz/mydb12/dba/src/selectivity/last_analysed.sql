set echo off
set linesize 180
set pagesize 40
set heading on
break on Database skip 1 on report
break on Table skip 1 on report
column time format a25 heading "LAST_ANALYSED Time (GMT)"
SELECT 
	  SUBSTR(DB_NAME,1,12) AS "Database"
	, SUBSTR(TABLE_NAME,1,15) AS "Table"
	, SUBSTR(COLUMN_NAME,1,15) AS "Column"
	, SUBSTR((timestamp '1970-01-01 00:00:00' + NUMTODSINTERVAL(LAST_ANALYZED,'second')) AT TIME ZONE tz_offset('GMT'),1,18) AS time
FROM tab_col_stats
ORDER by DB_NAME, TABLE_NAME, COLUMN_NAME;
exit
/
