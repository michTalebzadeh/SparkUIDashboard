CREATE OR REPLACE PROCEDURE kill_session_sp
(
	  pn_sid IN number
	, pn_serial IN number)
AS
lv_user varchar2(30);
BEGIN
  SELECT username INTO lv_user FROM v$session WHERE sid = pn_sid AND serial# = pn_serial;
IF lv_user IS NOT NULL AND lv_user NOT IN ('SYS','SYSTEM')
THEN
  EXECUTE IMMEDIATE 'ALTER SYSTEM KILL SESSION '''||pn_sid||','||pn_serial||'''';
ELSE
  RAISE_APPLICATION_ERROR(-20000,'Attempt to kill protected system session has been blocked for user '||lv_user);
END IF;
END kill_session_sp;
/
exit
