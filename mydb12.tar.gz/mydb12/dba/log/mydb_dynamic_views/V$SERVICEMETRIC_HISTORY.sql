 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 BEGIN_TIME									   DATE
 END_TIME									   DATE
 INTSIZE_CSEC									   NUMBER
 GROUP_ID									   NUMBER
 SERVICE_NAME_HASH								   NUMBER
 SERVICE_NAME									   VARCHAR2(64)
 CTMHASH									   NUMBER
 ELAPSEDPERCALL 								   NUMBER
 CPUPERCALL									   NUMBER
 DBTIMEPERCALL									   NUMBER
 CALLSPERSEC									   NUMBER
 DBTIMEPERSEC									   NUMBER

