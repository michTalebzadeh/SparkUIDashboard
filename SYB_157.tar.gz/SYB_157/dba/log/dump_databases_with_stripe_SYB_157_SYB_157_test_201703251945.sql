use master
go
dump database test to 'compress::4::/backup/sybase/SYB_157//SYB_157.test.201703251945.01.cdmp' 
go
exit
