CREATE OR REPLACE TYPE MyStddevImpl AS OBJECT
(
  v_power number, -- sum(power^2) of the column
  v_sum   number, -- average value
  v_iteration number, -- count(1)

  STATIC FUNCTION ODCIAggregateInitialize(sctx IN OUT MyStddevImpl) 
    RETURN NUMBER,

  MEMBER FUNCTION ODCIAggregateIterate(self IN OUT MyStddevImpl, 
    value IN number)
    RETURN number,

  MEMBER FUNCTION ODCIAggregateTerminate(self IN MyStddevImpl, 
    returnValue OUT number, flags IN number)
    RETURN number,

  MEMBER FUNCTION ODCIAggregateMerge(self IN OUT MyStddevImpl, 
   ctx2 IN MyStddevImpl)
   RETURN number
);
/
show error

CREATE OR REPLACE TYPE BODY MyStddevImpl
AS
STATIC FUNCTION ODCIAggregateInitialize(sctx IN OUT MyStddevImpl) 
RETURN NUMBER
AS 
BEGIN
  sctx := MyStddevImpl(0,0,0);  
  RETURN ODCIConst.Success;
END;

MEMBER FUNCTION ODCIAggregateIterate(self IN OUT MyStddevImpl, value IN number) 
RETURN number
AS
BEGIN
  self.v_sum   := self.v_sum + value;   -- used to get averages
  self.v_power := self.v_power + power(value,2);
  self.v_iteration := self.v_iteration + 1;  -- total  number of rows
  return ODCIConst.Success;
END;

MEMBER FUNCTION ODCIAggregateTerminate(self IN MyStddevImpl, returnValue OUT 
                                       number, flags IN number)
RETURN number
AS
  v_avg number;
BEGIN
  v_avg :=  self.v_sum/self.v_iteration;   -- this is the average value
   -- sqrt((sum(power(amount_sold,2))-(count(1)*power(avg(amount_sold),2)))/(count(1)-1)) 
  returnValue := sqrt((self.v_power - (self.v_iteration * power(v_avg,2))) /(self.v_iteration-1));
  RETURN ODCIConst.Success;
EXCEPTION
  WHEN VALUE_ERROR
  THEN
    RETURN ODCIConst.error;
END;

MEMBER FUNCTION ODCIAggregateMerge(self IN OUT MyStddevImpl, ctx2 IN 
MyStddevImpl)
RETURN number
AS
BEGIN
 RETURN ODCIConst.Success;
END;
END;
/
show error
CREATE OR REPLACE FUNCTION MyStddev (input number)
RETURN number 
AGGREGATE USING MyStddevImpl;
/
show error
exit
