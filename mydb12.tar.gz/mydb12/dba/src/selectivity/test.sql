ALTER SESSION SET TRACEFILE_IDENTIFIER = 'stddev';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
DECLARE
        v_stddev number;
BEGIN
	SELECT scratchpad.MyStddev(amount_sold) INTO v_stddev from sales;
END;
/
exit
