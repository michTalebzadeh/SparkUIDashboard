/********************************************/
/*------------ temp -------------*/
/********************************************/
select 'Started altering temp tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
ALTER TABLESPACE "TEMP" ADD TEMPFILE '/ssdsdc1/oracle/mydb12/MYDB12/datafile/temp04.dbf' SIZE 5000M REUSE AUTOEXTEND ON NEXT 640K MAXSIZE 32767M;
select 'Finished  altering temp tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
