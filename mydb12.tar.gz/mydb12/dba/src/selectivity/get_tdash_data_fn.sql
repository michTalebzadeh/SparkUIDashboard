CREATE OR REPLACE FUNCTION get_tdash_data_fn (p_owner tdash.owner%TYPE)
RETURN SYS_REFCURSOR
AS
  v_rc sys_refcursor;
BEGIN
  OPEN v_rc for 'select object_name, object_type from tdash where owner = :owner' using p_owner;
  RETURN v_rc;
END;
/
show error
exit
