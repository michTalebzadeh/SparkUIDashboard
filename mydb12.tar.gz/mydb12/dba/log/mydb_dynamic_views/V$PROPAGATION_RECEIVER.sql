 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SRC_QUEUE_SCHEMA								   VARCHAR2(30)
 SRC_QUEUE_NAME 								   VARCHAR2(30)
 SRC_DBNAME									   VARCHAR2(128)
 DST_QUEUE_SCHEMA								   VARCHAR2(30)
 DST_QUEUE_NAME 								   VARCHAR2(30)
 STARTUP_TIME									   DATE
 HIGH_WATER_MARK								   NUMBER
 ACKNOWLEDGEMENT								   NUMBER
 LAST_RECEIVED_MSG								   NUMBER
 TOTAL_MSGS									   NUMBER
 ELAPSED_UNPICKLE_TIME								   NUMBER
 ELAPSED_RULE_TIME								   NUMBER
 ELAPSED_ENQUEUE_TIME								   NUMBER
 SESSION_ID									   NUMBER
 SERIAL#									   NUMBER
 SPID										   VARCHAR2(24)
 PROPAGATION_NAME								   VARCHAR2(30)
 STATE										   VARCHAR2(43)
 LAST_RECEIVED_MSG_POSITION							   RAW(64)
 ACKNOWLEGEMENT_POSITION							   RAW(64)

