use master
go
if not exists(select 1 from master..syslogins where name = 'talemi')
  exec sp_addlogin talemi, 'london01',tempdb
go
use ASEIMDB
go
exec sp_adduser talemi, talemi, "public"
go
use ASEIMDB_template
go
exec sp_adduser talemi, talemi, "public"
go
use DBA_CONTROL_old
go
exec sp_adduser talemi, talemi, "public"
go
use DBHDD
go
exec sp_adduser talemi, talemi, "public"
go
use DBSSD
go
exec sp_adduser talemi, talemi, "public"
go
use dcoracle
go
exec sp_adduser talemi, talemi, "public"
go
use fiqrdb
go
exec sp_adduser talemi, talemi, "public"
go
use gfx_dev1
go
exec sp_adduser talemi, talemi, "public"
go
use hivedb
go
exec sp_adduser talemi, talemi, "public"
go
use its
go
exec sp_adduser talemi, talemi, "public"
go
use mda_analysis
go
exec sp_adduser talemi, talemi, "public"
go
use reptest
go
exec sp_adduser talemi, talemi, "public"
go
use scratchpad
go
exec sp_adduser talemi, talemi, "public"
go
use special
go
exec sp_adduser talemi, talemi, "public"
go
use sqoopdb
go
exec sp_adduser talemi, talemi, "public"
go
use test
go
exec sp_adduser talemi, talemi, "public"
go
sp_displaylogin talemi
go
