/********************************************/
/*------------ CMP_SSD -------------*/
/********************************************/
select 'Started creating CMP_SSD tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE SMALLFILE TABLESPACE "CMP_SSD" DATAFILE '/data6/oracle/mydb12/oradata/MYDB12/datafile/CMP_SSD.dbf' SIZE 1000M AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED LOGGING
EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO
DEFAULT COMPRESS; 
select 'Finished  creating CMP_SSD tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
