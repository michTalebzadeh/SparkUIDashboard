 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 MUTEX_IDENTIFIER								   NUMBER
 SLEEP_TIMESTAMP								   TIMESTAMP(6)
 MUTEX_TYPE									   VARCHAR2(32)
 GETS										   NUMBER
 SLEEPS 									   NUMBER
 REQUESTING_SESSION								   NUMBER
 BLOCKING_SESSION								   NUMBER
 LOCATION									   VARCHAR2(40)
 MUTEX_VALUE									   RAW(4)
 P1										   NUMBER
 P1RAW										   RAW(4)
 P2										   NUMBER
 P3										   NUMBER
 P4										   NUMBER
 P5										   VARCHAR2(64)

