create or replace directory SALES_FEEDS as '/data6/oracle/feeds';
exit
