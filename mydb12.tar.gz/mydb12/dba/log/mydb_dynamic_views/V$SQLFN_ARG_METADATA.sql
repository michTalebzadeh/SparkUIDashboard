 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FUNC_ID									   NUMBER
 ARGNUM 									   NUMBER
 DATATYPE									   VARCHAR2(8)
 DESCR										   VARCHAR2(30)

