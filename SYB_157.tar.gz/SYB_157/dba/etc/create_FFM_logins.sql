sp_addlogin 'dietpe','majeka','its_ged_prod'
go
sp_addlogin 'heimgu','majeka','its_ged_prod'
go
sp_addlogin 'hekmma','majeka','its_ged_prod'
go
sp_addlogin 'jauckl','majeka','its_ged_prod'
go
sp_addlogin 'kanzth','majeka','its_ged_prod'
go
sp_addlogin 'leopja','majeka','its_ged_prod'
go
sp_addlogin 'neumol','majeka','its_ged_prod'
go
sp_addlogin 'rohemi','majeka','its_ged_prod'
go
sp_addlogin 'schmju','majeka','its_ged_prod'
go
sp_addlogin 'walzbe','majeka','its_ged_prod'
go
sp_addlogin 'weindi','majeka','its_ged_prod'
go
sp_addlogin 'wurzro','majeka','its_ged_prod'
go
sp_adduser 'dietpe','dietpe'
go
sp_adduser 'heimgu','heimgu'
go
sp_adduser 'hekmma','hekmma'
go
sp_adduser 'jauckl','jauckl'
go
sp_adduser 'kanzth','kanzth'
go
sp_adduser 'leopja','leopja'
go
sp_adduser 'neumol','neumol'
go
sp_adduser 'rohemi','rohemi'
go
sp_adduser 'schmju','schmju'
go
sp_adduser 'walzbe','walzbe'
go
sp_adduser 'weindi','weindi'
go
sp_adduser 'wurzro','wurzro'
go
