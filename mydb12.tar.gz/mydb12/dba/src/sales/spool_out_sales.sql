set feedback off
set pagesize 0
set verify off
set timing off
select prod_id ||','||cust_id||','||to_char(TIME_ID,'YYYY-MM-DD')||','||channel_id||','||PROMO_ID||','||QUANTITY_SOLD||','||AMOUNT_SOLD
from mich.sales;
exit
