 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 BEGIN_TIME									   DATE
 END_TIME									   DATE
 INTSIZE_CSEC									   NUMBER
 GROUP_ID									   NUMBER
 METRIC_ID									   NUMBER
 METRIC_NAME									   VARCHAR2(64)
 VALUE										   NUMBER
 METRIC_UNIT									   VARCHAR2(64)

