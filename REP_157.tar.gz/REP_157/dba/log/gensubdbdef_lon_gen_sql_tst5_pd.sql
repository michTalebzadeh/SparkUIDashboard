--
------> Database test <------
--
CREATE SUBSCRIPTION test_pd
FOR DATABASE REPLICATION DEFINITION test_pd
WITH PRIMARY AT lon_gen_sql_tst5.test
WITH REPLICATE AT lon_gen_sql_tst1.test
WITHOUT MATERIALIZATION
go
