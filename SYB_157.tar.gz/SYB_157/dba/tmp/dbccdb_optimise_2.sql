               
 ------------- 
 use dbccdb
go 

	                                                                                                                                                                    
 
	------------------------------------------------------------------------------------------------------------------------------------------------------------------ 

	 sp_recompile "dbo.dbcc_config"
go
update statistics dbo.dbcc_config
go                                                                                             

	 sp_recompile "dbo.dbcc_counters"
go
update statistics dbo.dbcc_counters
go                                                                                         

	 sp_recompile "dbo.dbcc_dev_info"
go
update statistics dbo.dbcc_dev_info
go                                                                                         

	 sp_recompile "dbo.dbcc_fault_params"
go
update statistics dbo.dbcc_fault_params
go                                                                                 

	 sp_recompile "dbo.dbcc_faults"
go
update statistics dbo.dbcc_faults
go                                                                                             

	 sp_recompile "dbo.dbcc_operation_log"
go
update statistics dbo.dbcc_operation_log
go                                                                               

	 sp_recompile "dbo.dbcc_operation_results"
go
update statistics dbo.dbcc_operation_results
go                                                                       

	 sp_recompile "dbo.dbcc_types"
go
update statistics dbo.dbcc_types
go                                                                                               

	 sp_recompile "dbo.scanws"
go
update statistics dbo.scanws
go                                                                                                       

	 sp_recompile "dbo.textws"
go
update statistics dbo.textws
go                                                                                                       
