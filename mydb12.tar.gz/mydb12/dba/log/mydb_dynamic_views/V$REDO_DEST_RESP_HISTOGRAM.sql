 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 DEST_ID									   NUMBER
 TIME										   VARCHAR2(20)
 DURATION									   NUMBER
 FREQUENCY									   NUMBER

