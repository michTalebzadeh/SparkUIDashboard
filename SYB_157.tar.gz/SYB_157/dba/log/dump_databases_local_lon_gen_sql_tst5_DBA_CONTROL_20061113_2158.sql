use master
go
dump database DBA_CONTROL to 'compress::4::/dbdumps/lon_gen_sql_tst5/dumps/lon_gen_sql_tst5.DBA_CONTROL.20061113_2158.01.cdmp' 
go
exit
