 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 THREAD#									   NUMBER
 RESETLOGS_CHANGE#								   NUMBER
 RESET_TIMESTAMP								   NUMBER
 LAST_REDO_SEQ# 								   NUMBER
 LAST_REDO_BLK# 								   NUMBER
 LAST_REDO_TIME 								   DATE
 LOW_GAP_SCN									   NUMBER
 LOW_GAP_TIME									   DATE
 LAST_PING_TIME 								   DATE

