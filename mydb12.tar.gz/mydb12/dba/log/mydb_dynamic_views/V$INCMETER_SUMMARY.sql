 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SEVERITY_INDEX 								   VARCHAR2(14)
 CRITICAL_INICDENTS								   NUMBER
 WARNING_INCIDENTS								   NUMBER
 LAST_HOUR_INCIDENTS								   NUMBER
 CREATE_TIME									   TIMESTAMP(13) WITH TIME ZONE
 OLDEST_TRANSIENT_INC_CTIME							   TIMESTAMP(13) WITH TIME ZONE
 OLDEST_PERSISTENT_INC_CTIME							   TIMESTAMP(13) WITH TIME ZONE
 LATEST_INC_CTIME								   TIMESTAMP(13) WITH TIME ZONE

