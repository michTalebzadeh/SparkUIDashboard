select hostname,suser_name(suid),hostprocess from sysprocesses
order by suid desc
go
set rowcount 10
select suser_name(suid),count(suid)
from sysprocesses
group by suid
order by 2 desc
go
