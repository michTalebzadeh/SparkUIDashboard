 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 REMASTER_OPS									   NUMBER
 REMASTER_TIME									   NUMBER
 REMASTERED_OBJECTS								   NUMBER
 QUIESCE_TIME									   NUMBER
 FREEZE_TIME									   NUMBER
 CLEANUP_TIME									   NUMBER
 REPLAY_TIME									   NUMBER
 FIXWRITE_TIME									   NUMBER
 SYNC_TIME									   NUMBER
 RESOURCES_CLEANED								   NUMBER
 REPLAYED_LOCKS_SENT								   NUMBER
 REPLAYED_LOCKS_RECEIVED							   NUMBER
 CURRENT_OBJECTS								   NUMBER

