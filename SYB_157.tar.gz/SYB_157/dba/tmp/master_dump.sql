use master
go
set nocount on
go
checkpoint
go
declare @msg char(100), @errorno int
dump tran master with truncate_only
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Sat Jan 19 00:55:51 GMT 2002 db_dump_adsm.ksh Dump of master log failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go
declare @msg char(100), @errorno int
dump database master to "/apps/sybase/dump/lon_gedimg_sql_prd/master.dmp.stripe1"
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Sat Jan 19 00:55:51 GMT 2002 db_dump_adsm.ksh Dump of master failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go

