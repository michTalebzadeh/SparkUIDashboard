 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 HV_ID										   NUMBER
 CURRENT_MASTER 								   NUMBER
 PREVIOUS_MASTER								   NUMBER
 REMASTER_CNT									   NUMBER

