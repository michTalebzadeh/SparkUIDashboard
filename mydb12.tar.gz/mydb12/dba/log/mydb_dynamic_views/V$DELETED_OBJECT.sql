 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 RECID										   NUMBER
 STAMP										   NUMBER
 TYPE										   VARCHAR2(26)
 OBJECT_RECID									   NUMBER
 OBJECT_STAMP									   NUMBER
 OBJECT_DATA									   NUMBER
 SET_STAMP									   NUMBER
 SET_COUNT									   NUMBER

