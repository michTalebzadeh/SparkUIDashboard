set pagesize 9999
set linesize 140
set heading off
select SUBSTR(name,1,12) || ' users as of '||TO_CHAR(CURRENT_DATE, 'MON DD YYYY HH:MI AM') from v$database;
set trimspool on
column "EXPIRE DATE" format a20
select 
	   username AS UserName
	 , to_char(expiry_date,'dd/MM/YYYY') as "EXPIRE DATE"
         , case when expiry_date < sysdate then 'already expired'
             when expiry_date < sysdate+30 then 'expires in 30 days'
             when expiry_date < sysdate+60 then 'expires in 60 days'
             when expiry_date < sysdate+90 then 'expires in 90 days'
             else  'more than 90 days'
           end  AS "grace period"
	 , account_status
from dba_users
where account_status IN ( 'OPEN', 'EXPIRED(GRACE)' )
order by account_status, expiry_date, username
/
exit
