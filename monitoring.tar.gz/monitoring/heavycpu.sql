prompt
Prompt +-------------------------------------+
Prompt | heavy CPU statements from V$SQLAREA |
Prompt +-------------------------------------+

COLUMN "Gets/Exec" FORMAT 9999999.99 HEADING "Gets/Exec"
select buffer_gets, executions,
          buffer_gets/executions "Gets/Exec", 
          substr(sql_text,1,90) "ShortSQL"--, address, hash_value
from    v$sqlarea 
where  buffer_gets > 50000 
    and  executions > 0
  order  by 3 desc;
exit
