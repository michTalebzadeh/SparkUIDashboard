var  v_owner varchar2(30);
var  v_name varchar2(30);
var  v_mb number;
var  v_small number;
var  v_block_size number;
var  v_block_limit number;
var  v_num_rows number;
var  v_blocks number;
var  v_avg_space number;
var  v_table_name varchar2(30);
var  v_table_size number;
var  v_rowblock number;
var  v_percent number;
var  v_blocks_in_cache number;
var  v_dummy number;
var  v_index_name varchar2(30);
var  v_index_size number;
var  v_empty_blocks number;
var  v_used_blocks number;
--exec :v_owner := 'TESTER'
exec :v_owner := upper('&&owner')
exec :v_table_name := 'TDASH_CMP'
exec :v_index_name := 'TDASH_CMP_PK'
declare
  st varchar2(255);
begin
  st := 'select count(1) from '|| :v_owner || '.' || :v_table_name;
  EXECUTE IMMEDIATE st into :v_num_rows;
  select name,bytes/1024/1024 into :v_name,:v_mb
  from v$sgastat where name like 'buffer%cache%';
  select value into :v_block_size from v$parameter where name like 'db_block_size%';
  :v_small := 0.02 * :v_mb;
  :v_block_limit := :v_small*1024*1024/:v_block_size;
  :v_blocks_in_cache := (:v_mb * 1024 * 1024) /:v_block_size;
  select  blocks, avg_space, empty_blocks, (blocks-empty_blocks), num_rows/blocks
  into   :v_blocks, :v_avg_space, :v_empty_blocks, :v_used_blocks, :v_rowblock
from dba_tables where owner=:v_owner and table_name = :v_table_name;
SELECT SUM(bytes)/1024/1024 INTO :v_table_size
FROM dba_extents
WHERE owner=:v_owner AND segment_name=:v_table_name
GROUP BY segment_name;
SELECT 
  --  SUBSTR(s.segment_name,1,20) TABLE_NAME
  --  SUBSTR(s.tablespace_name,1,20) TABLESPACE_NAME,
  --  ROUND(DECODE(s.extents, 1, s.initial_extent,
  --  (s.initial_extent + (s.extents-1) * s.next_extent))/1024000,2) ALLOCATED_MB,
  --  ROUND((t.num_rows * t.avg_row_len / 1024000),2) INTO :v_table_size
    ROUND((t.num_rows * t.avg_row_len / 1024000),2) INTO :v_dummy
    FROM
    dba_segments s,
    dba_tables t
 WHERE
      t.owner = :v_owner
  and t.table_name = :v_table_name
  and t.owner = s.owner
  and s.segment_name = t.table_name;
  -- dbms_output.put_line('The parameter and value is '||:v_name ||', '||:v_mb||' MB');
  -- dbms_output.put_line('The small table threshold is  '||:v_small||' MB');
  -- dbms_output.put_line('The small table block limit is '||:v_block_limit||' blocks');

  SELECT SUM(bytes)/1024/1024 into :v_index_size
  FROM dba_extents
  WHERE owner=:v_owner AND segment_name=:v_index_name;
end;
/
break on report
column v_name format a30 heading 'Parameter'
column v_mb   format 999,999 heading 'buffer cache size/MB'
column v_blocks_in_cache   format 999,999,999 heading 'blocks fit in this cache'
column v_small   format 999,999 heading 'Small table threshold at 2% of buffer cache size/MB'
column v_block_limit   format 999,999 heading 'Small table block limit'
column v_num_rows format 999,999,999 heading 'rows'
column v_blocks format 999,999,999 heading 'blocks'
column v_empty_blocks format 999,999,999 heading 'empty blocks'
column v_used_blocks format 999,999,999 heading 'used blocks'
column v_block_size format 999,999,999 heading 'block size/KB'
column v_table_size format 999,999,999 heading 'Table size/MB'
column v_avg_space format 999,999 heading 'avg free space/KB'
column v_ratio format 999,999 heading 'Table block size/threshold limit'
column v_rowblack format 999,999 heading 'Table rows/block'
column v_percent format 999,999.99 heading 'Table size as percent of buffer size'
select
          :v_name v_name
        , :v_mb v_mb
        , :v_blocks_in_cache v_blocks_in_cache
from dual;
select
	  :v_small v_small
	, round(:v_block_limit) v_block_limit
from dual;
prompt hiddent parameter _small_table_threshold
Set linesize 150 pagesize 40
column name format a40 heading name
column value format a20 heading value
column isdefault format a20 heading isdefault
column description format a55 heading description word_wrap
select
          a.ksppinm name
        , b.ksppstvl value
        , b.ksppstdf isdefault
        , a.ksppdesc description
from
  x$ksppi a,
  x$ksppcv b
where
  a.indx=b.indx and
  substr(ksppinm,1,1) = '_'
and ksppinm like '_small%' escape'|'
order by 1;

prompt My table details
select
          :v_owner owner
	, :v_table_name table_name
        , :v_num_rows v_num_rows
        , :v_block_size/1024 v_block_size
        , :v_blocks v_blocks
        , :v_used_blocks v_used_blocks
        , :v_empty_blocks v_empty_blocks
        , :v_avg_space v_avg_space
        , round(:v_table_size) v_table_size
from dual;
select
          (:v_table_size*100.0/:v_mb) v_percent
from dual;
select
	  round(:v_blocks/:v_block_limit) v_ratio,
          :v_rowblock v_rowblock
from
	dual;


prompt Index info

SELECT   substr(owner,1,30) AS owner,
	 SUBSTR(TABLE_NAME||'.'||INDEX_NAME,1,40) AS "Index",
        :v_index_size AS "Index size/MB",
         NUM_ROWS AS "Index rows",
        :v_index_size*1024*1024/8192 AS "Index blocks",
         round(NUM_ROWS/(:v_index_size*1024*1024/8192)) As "Rows/per block",
	 DISTINCT_KEYS "Distinct Keys",
        LEAF_BLOCKS,
	CLUSTERING_FACTOR "CF",
	BLEVEL "Branch Level"
        --AVG_LEAF_BLOCKS_PER_KEY "Avg LBPK"
        FROM DBA_INDEXES
        WHERE owner = :v_owner
        AND TABLE_NAME = :v_table_name
        ORDER BY TABLE_NAME, INDEX_NAME;
exit
