Prompt +----------------------------------------------------------------------------------+
Prompt | Displaying SGA components from v$sga_dynamic_components                          |
Prompt +----------------------------------------------------------------------------------+
--
select component,current_size/1024/1024 current_size_mb from v$sga_dynamic_components;
--
Prompt +----------------------------------------------------------------------------------+
Prompt | SGA info  from v$sgainfo                                                         |
Prompt +----------------------------------------------------------------------------------+
select name,round(bytes/1024/2024) AS MB,resizeable from v$sgainfo
order by 2 desc;
exit

