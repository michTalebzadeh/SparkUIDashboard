--
------> Creating Database replication definition test_dd <------
--
DROP DATABASE REPLICATION DEFINITION test_dd
WITH PRIMARY AT lon_gen_sql_tst1.test
go
CREATE DATABASE REPLICATION DEFINITION test_dd
WITH PRIMARY AT lon_gen_sql_tst1.test
REPLICATE DDL
NOT REPLICATE TABLES IN (
			   'dba__rep_delay'
			 , 'next_rowid'
)
go
exit
