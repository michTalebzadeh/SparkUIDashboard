 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 OWNER_NAME									   VARCHAR2(64)
 NAME										   VARCHAR2(1000)
 TYPE										   NUMBER
 HEAP_NUM									   NUMBER
 CACHE_ID									   NUMBER
 CACHE_CNT									   NUMBER
 HEAP_SZ									   NUMBER
 HEAP_ALOC									   NUMBER
 HEAP_USED									   NUMBER

