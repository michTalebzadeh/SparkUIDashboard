prompt
Prompt +----------------------------------------------------+
Prompt | Temporary tablespace total, used and free          |
Prompt | Extracted from V$TEMP_SPACE_HEADER                 |
Prompt +----------------------------------------------------+
prompt
set echo off
set linesize 180
set pagesize 40
set heading on
col tablespace_name heading "Tablespace|Name" format a15
col fnum heading "#" format 999
col ts heading "Tablespace|Name" format a15
col tb heading "Total|File Size" format 999,999,999,999
col mb_total heading "MB Total" like tb
col mb_used heading "MB Used" like tb
col mb_free heading "MB Free" like tb
col percentfree heading "Pct|Free" format 999
col autoext heading "Auto|Extend" format a6
break on report
SELECT tablespace_name ts, (SUM(bytes_used) + SUM(bytes_free)) /1024 / 1024 mb_total,
                            SUM(bytes_used) /1024 / 1024 mb_used,
                            SUM(bytes_free) /1024 / 1024 mb_free
FROM   V$temp_space_header
GROUP  BY tablespace_name;
prompt
Prompt +----------------------------------------------------+
Prompt | Temp space usage analysis                          |
Prompt | Extracted from V$SORT_SEGMENT                      |
Prompt +----------------------------------------------------+
prompt
SELECT   A.tablespace_name ts, D.mb_total,
         SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_used,
         D.mb_total - SUM (A.used_blocks * D.block_size) / 1024 / 1024 mb_free
FROM     v$sort_segment A,
         (
         SELECT   B.name, C.block_size, SUM (C.bytes) / 1024 / 1024 mb_total
         FROM     v$tablespace B, v$tempfile C
         WHERE    B.ts#= C.ts#
         GROUP BY B.name, C.block_size
         ) D
WHERE    A.tablespace_name = D.name
GROUP by A.tablespace_name, D.mb_total;
exit

