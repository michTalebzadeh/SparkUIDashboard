 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 MAXIMUM									   NUMBER
 COUNT										   NUMBER
 OPENS										   NUMBER
 HITS										   NUMBER
 HIT_RATIO									   NUMBER

