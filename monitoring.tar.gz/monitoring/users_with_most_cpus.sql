@$HOME/abc
SELECT substr(sn.name,1,30) parameter,
       ss.username ||' ('|| se.sid ||')' user_process, se.value
FROM   v$session ss, v$sesstat se, v$statname sn
WHERE se.statistic# = sn.statistic#
AND sn.name LIKE '%CPU used by this session%'
AND se.sid = ss.sid
AND ss.serial# > 1
ORDER BY sn.name, se.value DESC
/
exit
