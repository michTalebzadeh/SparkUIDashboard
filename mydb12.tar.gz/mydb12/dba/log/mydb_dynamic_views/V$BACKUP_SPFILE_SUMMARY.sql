 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 NUM_FILES_BACKED								   NUMBER
 NUM_DISTINCT_FILES_BACKED							   NUMBER
 MIN_MODIFICATION_TIME								   DATE
 MAX_MODIFICATION_TIME								   DATE
 INPUT_BYTES									   NUMBER
 INPUT_BYTES_DISPLAY								   VARCHAR2(4000)

