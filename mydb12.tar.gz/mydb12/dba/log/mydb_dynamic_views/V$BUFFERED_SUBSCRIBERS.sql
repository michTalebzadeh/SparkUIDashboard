 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 QUEUE_ID									   NUMBER
 QUEUE_SCHEMA									   VARCHAR2(30)
 QUEUE_NAME									   VARCHAR2(30)
 SUBSCRIBER_ID									   NUMBER
 SUBSCRIBER_NAME								   VARCHAR2(30)
 SUBSCRIBER_ADDRESS								   VARCHAR2(1024)
 PROTOCOL									   NUMBER
 SUBSCRIBER_TYPE								   VARCHAR2(30)
 STARTUP_TIME									   DATE
 LAST_BROWSED_SEQ								   NUMBER
 LAST_BROWSED_NUM								   NUMBER
 LAST_DEQUEUED_SEQ								   NUMBER
 LAST_DEQUEUED_NUM								   NUMBER
 CURRENT_ENQ_SEQ								   NUMBER
 NUM_MSGS									   NUMBER
 CNUM_MSGS									   NUMBER
 TOTAL_DEQUEUED_MSG								   NUMBER
 TOTAL_SPILLED_MSG								   NUMBER
 EXPIRED_MSGS									   NUMBER
 MESSAGE_LAG									   NUMBER
 ELAPSED_DEQUEUE_TIME								   NUMBER
 DEQUEUE_CPU_TIME								   NUMBER
 LAST_DEQUEUE_TIME								   TIMESTAMP(3) WITH TIME ZONE
 OLDEST_MSGID									   RAW(16)
 OLDEST_MSG_ENQTM								   TIMESTAMP(3)

