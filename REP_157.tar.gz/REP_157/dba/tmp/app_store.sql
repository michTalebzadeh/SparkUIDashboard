set nocount on
go
use master
go
select "use master " + "
go"
select "use app_store " + " 
go"
select "update statistics " + name + " 
go" + " 
sp_recompile " + name + " 
go" 
from app_store..sysobjects 
where type = "U" 
order by name 
go 

 
