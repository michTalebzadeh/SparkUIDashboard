-- run dbms_statis or analyze table_name compute statistics beforehand
column blocks format 999,999,999 heading 'Allocated blocks'
column empty_blocks format 999,999 heading 'Empty blocks'
column avg_space format 999,999 heading 'Average space/KB'
column  num_freelist_blocks format 999,999,999 heading 'Free list blocks'
select table_name,blocks, empty_blocks,
    avg_space, num_freelist_blocks
    from user_tables
where blocks > 0
   order by blocks desc
/
column num_rows format 999,999,999 heading 'Rows'
column table_size_mb format 999,999,999 heading 'Table Size/MB'
column used_mb format 999,999,999 heading 'Used/MB'
SELECT a.table_name,
       a.num_rows num_rows,
       round(b.bytes/1024/1024) table_size_mb,
       round(a.blocks*b.bytes/b.blocks/1024/1024) used_mb,
       round(a.empty_blocks*b.bytes/b.blocks/1024/1024) AS "Free/MB" 
FROM   user_tables a,
       user_segments b
WHERE   b.segment_type = 'TABLE'
AND     a.table_name = b.segment_name
ORDER BY a.num_rows DESC
/
exit
