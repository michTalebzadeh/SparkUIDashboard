use master
go
set nocount on
go
checkpoint
go
declare @msg char(100), @errorno int
--dump tran tradetech with truncate_only
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Tue Nov 12 17:13:35 GMT 2002 db_dump.ksh Dump of tradetech log failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go
declare @msg char(100), @errorno int
dump database tradetech to "/apps/sybase/dump/lon_gedimg_sql_dev2/tradetech_JIC.dmp.stripe1"
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Tue Nov 12 17:13:35 GMT 2002 db_dump.ksh Dump of tradetech failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go

