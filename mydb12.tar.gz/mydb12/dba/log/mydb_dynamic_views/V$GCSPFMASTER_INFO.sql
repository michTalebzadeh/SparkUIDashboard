 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FILE_ID									   NUMBER
 DATA_OBJECT_ID 								   NUMBER
 GC_MASTERING_POLICY								   VARCHAR2(11)
 CURRENT_MASTER 								   NUMBER
 PREVIOUS_MASTER								   NUMBER
 REMASTER_CNT									   NUMBER

