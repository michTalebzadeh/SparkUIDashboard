--ALTER SESSION SET STATISTICS_LEVEL='ALL';
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_with_t_no_index';
alter session set events '10949 trace name context forever, level 1';
DECLARE
	type array is table of t%rowtype index by binary_integer;
	l_data array;
	l_rec t%rowtype;
BEGIN
	SELECT
         	a.*
        	,RPAD('*',4000,'*') AS PADDING1
        	,RPAD('*',4000,'*') AS PADDING2
	BULK COLLECT INTO
	l_data
  	FROM ALL_OBJECTS a;

	DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true );
	FOR i IN 1 .. l_data.count
	LOOP
		BEGIN
		  SELECT * INTO l_rec FROM t WHERE object_id = l_data(i).object_id;
		EXCEPTION
 		  WHEN NO_DATA_FOUND THEN NULL;
		END;
	END LOOP;
END;
/
exit
