use master
go
dump database lon_gen_rep_tst5_RSSD to 'compress::4::/dbdumps/lon_gen_sql_tst5/dumps/lon_gen_sql_tst5.lon_gen_rep_tst5_RSSD.20061113_2200.01.cdmp' 
go
exit
