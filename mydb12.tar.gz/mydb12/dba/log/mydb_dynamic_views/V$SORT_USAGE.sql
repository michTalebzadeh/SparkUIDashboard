 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 USERNAME									   VARCHAR2(30)
 USER										   VARCHAR2(30)
 SESSION_ADDR									   RAW(4)
 SESSION_NUM									   NUMBER
 SQLADDR									   RAW(4)
 SQLHASH									   NUMBER
 SQL_ID 									   VARCHAR2(13)
 TABLESPACE									   VARCHAR2(31)
 CONTENTS									   VARCHAR2(9)
 SEGTYPE									   VARCHAR2(9)
 SEGFILE#									   NUMBER
 SEGBLK#									   NUMBER
 EXTENTS									   NUMBER
 BLOCKS 									   NUMBER
 SEGRFNO#									   NUMBER

