REM ******************************************************************
REM   file: insertCourse.sql
REM  description: used for loading Course data
REM  created January 30, 2000
REM ******************************************************************

ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MON-RR';

SET DEFINE OFF
SPOOL insertCourse.log

INSERT INTO course VALUES (10,'DP Overview',1195,NULL,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                                   
INSERT INTO course VALUES (20,'Intro to Computers',1195,NULL,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                            
INSERT INTO course VALUES (25,'Intro to Programming',1195,140,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                           
INSERT INTO course VALUES (80,'Structured Programming Techniques',1595,204,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                              
INSERT INTO course VALUES (100,'Hands-On Windows',1195,20,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                               
INSERT INTO course VALUES (120,'Intro to Java Programming',1195,80,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                      
INSERT INTO course VALUES (122,'Intermediate Java Programming',1195,120,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                 
INSERT INTO course VALUES (124,'Advanced Java Programming',1195,122,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                     
INSERT INTO course VALUES (125,'JDeveloper',1195,122,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                                    
INSERT INTO course VALUES (130,'Intro to Unix',1195,310,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                                 
INSERT INTO course VALUES (132,'Basics of Unix Admin',1195,130,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                          
INSERT INTO course VALUES (134,'Advanced Unix Admin',1195,132,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                           
INSERT INTO course VALUES (135,'Unix Tips and Techniques',1095,134,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                      
INSERT INTO course VALUES (140,'Structured Analysis',1195,20,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                            
INSERT INTO course VALUES (142,'Project Management',1195,20,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                             
INSERT INTO course VALUES (144,'Database Design',1195,420,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                               
INSERT INTO course VALUES (145,'Internet Protocols',1195,310,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                            
INSERT INTO course VALUES (146,'Java for C/C++ Programmers',1195,NULL,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                   
INSERT INTO course VALUES (147,'GUI Programming',1195,20,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                                
INSERT INTO course VALUES (204,'Intro to SQL',1195,20,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                                   
INSERT INTO course VALUES (210,'Oracle Tools',1195,220,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                                  
INSERT INTO course VALUES (220,'PL/SQL Programming',1195,80,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                             
INSERT INTO course VALUES (230,'Intro to Internet',1095,10,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                              
INSERT INTO course VALUES (240,'Intro to the Basic Language',1095,25,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                    
INSERT INTO course VALUES (310,'Operating Systems',1195,NULL,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                            
INSERT INTO course VALUES (330,'Network Administration',1195,130,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                        
INSERT INTO course VALUES (350,'JDeveloper Lab',1195,125,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                                
INSERT INTO course VALUES (420,'Database System Principles',1195,25,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                     
INSERT INTO course VALUES (430,'JDeveloper Techniques',1195,350,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                         
INSERT INTO course VALUES (450,'DB Programming in Java',NULL,350,'DSCHERER','29-MAR-99','ARISCHER','05-APR-99');                                                                                        

COMMIT;

SPOOL OFF

