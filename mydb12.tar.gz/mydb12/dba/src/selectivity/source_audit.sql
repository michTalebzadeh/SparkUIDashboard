drop sequence identity;
CREATE SEQUENCE identity
    MINVALUE 1
    MAXVALUE 999999999999999999999999999
    START WITH 1
    INCREMENT BY 1
    CACHE  1000;
drop table source;
create table source
(
           col1 number not null
          ,col2 varchar(30) not null
);
alter table source add constraint source_pk primary key (col1);
desc source
drop table source_audit;
create table source_audit
(
           col1 number not null
          ,col2 varchar(30) not null
          ,who  varchar(30) not null
          ,application varchar(30) null
          ,hostname varchar(30) null
          ,when_changed  date not null
          ,action char(1) not null
);
desc source_audit
create or replace trigger source_b_ud_tr
before update or delete
on source
for each row
declare
  v_who varchar(30) := USER;
  v_application varchar(30);
  v_hostname varchar(30);
  v_when_changed date := sysdate;
  v_action char(1);
begin
  SELECT 
	    substr(sys_context('USERENV','HOST'),1,30)
	  , substr(sys_context('USERENV','MODULE'),1,30)
  INTO    v_hostname
         ,v_application
FROM
        dual;
  if updating then
    v_action := 'U';
  elsif deleting then
    v_action := 'D';
  end if;
  insert into source_audit
  (
  	  col1
	 ,col2
         ,who
         ,application
         ,hostname
         ,when_changed
         ,action
  )
  values
  (
          :old.col1
         ,:old.col2
         ,v_who
         ,v_application
         ,v_hostname
         ,v_when_changed
         ,v_action
  );
end source_b_ud_tr;
/
show error
create or replace trigger source_a_iu_tr
after insert or update
on source
for each row
declare
  v_who varchar(30) := USER;
  v_application varchar(30);
  v_hostname varchar(30);
  v_when_changed date := sysdate;
  v_action char(1);
begin
  SELECT
            substr(sys_context('USERENV','HOST'),1,30)
          , substr(sys_context('USERENV','MODULE'),1,30)
  INTO    v_hostname
         ,v_application
FROM
        dual;
  if inserting then
    v_action := 'I';
  elsif updating then
    v_action := 'U';
  end if;
  insert into source_audit
  (
          col1
         ,col2
         ,who
         ,application
         ,hostname
         ,when_changed
         ,action
  )
  values
  (
          :new.col1
         ,:new.col2
         ,v_who
         ,v_application
         ,v_hostname
         ,v_when_changed
         ,v_action
  );
end source_a_iud_tr;
/
show error
exit
