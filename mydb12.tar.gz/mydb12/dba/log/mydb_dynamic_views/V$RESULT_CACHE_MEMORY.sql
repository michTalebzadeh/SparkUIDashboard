 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ID										   NUMBER
 CHUNK										   NUMBER
 OFFSET 									   NUMBER
 FREE										   VARCHAR2(3)
 OBJECT_ID									   NUMBER
 POSITION									   NUMBER

