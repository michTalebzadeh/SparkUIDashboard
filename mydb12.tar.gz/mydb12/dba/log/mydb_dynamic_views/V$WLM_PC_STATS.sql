 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 PC_NAME_HASH									   NUMBER
 PC_NAME									   VARCHAR2(32)
 STAT_ID									   NUMBER
 STAT_NAME									   VARCHAR2(64)
 VALUE										   NUMBER

