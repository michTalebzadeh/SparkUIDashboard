--exec DBMS_STATS.gather_table_stats(ownname=>'MICH',tabname =>'T1',estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS', cascade=>TRUE);
exec DBMS_STATS.gather_table_stats(ownname=>'MICH',tabname =>'T1',estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS', cascade=>TRUE);
exec DBMS_STATS.gather_table_stats(ownname=>'TESTER',tabname =>'T1',estimate_percent => 100, method_opt => 'FOR ALL INDEXED COLUMNS', cascade=>TRUE);
        select
                c.owner,
                c.table_name,
                t.num_rows as "Number of rows",
                c.column_name,
                to_char(c.LAST_ANALYZED,'YYYY/MM/DD HH24:MI:SS') AS last_analyzed
        from dba_tab_columns c,
             dba_tables t
        where c.owner not in ('SYS','SYSTEM')
             -- and c.owner = UPPER('MICH')
             and c.last_analyzed is not null
             and c.table_name = t.table_name
             and c.owner = t.owner
             --and c.column_id = 1
        order by c.last_analyzed;
exit
