 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FILE_TYPE									   VARCHAR2(20)
 PERCENT_SPACE_USED								   NUMBER
 PERCENT_SPACE_RECLAIMABLE							   NUMBER
 NUMBER_OF_FILES								   NUMBER

