-- Sybase DDLGen Utility/12.5.1/IR/1/I/1.3/ase1251/Wed Sep  3 20:35:37 PDT 2003


-- Confidential property of Sybase, Inc.
-- Copyright 2001, 2002, 2003
-- Sybase, Inc.  All rights reserved.
-- Unpublished rights reserved under U.S. copyright laws.
-- This software contains confidential and trade secret information of Sybase,
-- Inc.   Use,  duplication or disclosure of the software and documentation by
-- the  U.S.  Government  is  subject  to  restrictions set forth in a license
-- agreement  between  the  Government  and  Sybase,  Inc.  or  other  written
-- agreement  specifying  the  Government's rights to use the software and any
-- applicable FAR provisions, for example, FAR 52.227-19.
-- Sybase, Inc. One Sybase Drive, Dublin, CA 94568, USA


-- DDLGen started with the following arguments
-- -Uredback_dbo -Slongmdappu9:8000 -P*** -Dict_web_qa2 -TRI -N% -Oabc 
-- at 02/07/05 18:14:02 GMT



-----------------------------------------------------------------------------
-- Dependent DDL for Object(s)
-----------------------------------------------------------------------------
print '----------- Generating DDL for Foreign Key Constraint: [FK$APP_USER$1] of the Table: [ict_web_qa2.standard.APP_USER]'
go

alter table ict_web_qa2.standard.APP_USER
add constraint FK$APP_USER$1 FOREIGN KEY (LOCATION_ID) REFERENCES ict_web_qa2.standard.EMP_LOCATION(ID)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$APP_USER$2] of the Table: [ict_web_qa2.standard.APP_USER]'
go

alter table ict_web_qa2.standard.APP_USER
add constraint FK$APP_USER$2 FOREIGN KEY (FUNCTION_ID) REFERENCES ict_web_qa2.standard.EMP_FUNCTION(ID)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$APP_USER$3] of the Table: [ict_web_qa2.standard.APP_USER]'
go

alter table ict_web_qa2.standard.APP_USER
add constraint FK$APP_USER$3 FOREIGN KEY (DEPARTMENT_ID) REFERENCES ict_web_qa2.standard.EMP_DEPARTMENT(ID)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_bl_leg_details_id] of the Table: [ict_web_qa2.dbo.BOND_LEG_DETAILS]'
go

alter table ict_web_qa2.dbo.BOND_LEG_DETAILS
add constraint fk_bl_leg_details_id FOREIGN KEY (bl_leg_details_id) REFERENCES ict_web_qa2.dbo.RAVEN_LEG_DETAILS(ld_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [grimis_raven_mapping_grfk] of the Table: [ict_web_qa2.dbo.grimis_raven_mapping]'
go

alter table ict_web_qa2.dbo.grimis_raven_mapping
add constraint grimis_raven_mapping_grfk FOREIGN KEY (grimis_book) REFERENCES ict_web_qa2.dbo.grimis_book(name)
go

print '----------- Generating DDL for Foreign Key Constraint: [grimis_raven_mapping_rafk] of the Table: [ict_web_qa2.dbo.grimis_raven_mapping]'
go

alter table ict_web_qa2.dbo.grimis_raven_mapping
add constraint grimis_raven_mapping_rafk FOREIGN KEY (raven_book) REFERENCES ict_web_qa2.dbo.raven_book(name)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_TRADE_DETAILS$1] of the Table: [ict_web_qa2.dbo.RAVEN_TRADE_DETAILS]'
go

alter table ict_web_qa2.dbo.RAVEN_TRADE_DETAILS
add constraint FK$RAVEN_TRADE_DETAILS$1 FOREIGN KEY (td_report_info_id) REFERENCES ict_web_qa2.dbo.RAVEN_REPORT_INFO(ri_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_PL_TRADELEG$1] of the Table: [ict_web_qa2.dbo.RAVEN_PL_TRADELEG]'
go

alter table ict_web_qa2.dbo.RAVEN_PL_TRADELEG
add constraint FK$RAVEN_PL_TRADELEG$1 FOREIGN KEY (pt_pl_report_id) REFERENCES ict_web_qa2.dbo.RAVEN_PL_REPORT(pr_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_PL_TRADELEG$2] of the Table: [ict_web_qa2.dbo.RAVEN_PL_TRADELEG]'
go

alter table ict_web_qa2.dbo.RAVEN_PL_TRADELEG
add constraint FK$RAVEN_PL_TRADELEG$2 FOREIGN KEY (pt_trade_details_id) REFERENCES ict_web_qa2.dbo.RAVEN_TRADE_DETAILS(td_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_PL_TRADELEG$3] of the Table: [ict_web_qa2.dbo.RAVEN_PL_TRADELEG]'
go

alter table ict_web_qa2.dbo.RAVEN_PL_TRADELEG
add constraint FK$RAVEN_PL_TRADELEG$3 FOREIGN KEY (pt_leg_details_id_tm0) REFERENCES ict_web_qa2.dbo.RAVEN_LEG_DETAILS(ld_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_PL_TRADELEG$4] of the Table: [ict_web_qa2.dbo.RAVEN_PL_TRADELEG]'
go

alter table ict_web_qa2.dbo.RAVEN_PL_TRADELEG
add constraint FK$RAVEN_PL_TRADELEG$4 FOREIGN KEY (pt_leg_details_id_tm1) REFERENCES ict_web_qa2.dbo.RAVEN_LEG_DETAILS(ld_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_PL_TRADELEG$5] of the Table: [ict_web_qa2.dbo.RAVEN_PL_TRADELEG]'
go

alter table ict_web_qa2.dbo.RAVEN_PL_TRADELEG
add constraint FK$RAVEN_PL_TRADELEG$5 FOREIGN KEY (pt_risk_details_id) REFERENCES ict_web_qa2.dbo.RAVEN_RISK_DETAILS(rd_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_PL_TRADELEG$6] of the Table: [ict_web_qa2.dbo.RAVEN_PL_TRADELEG]'
go

alter table ict_web_qa2.dbo.RAVEN_PL_TRADELEG
add constraint FK$RAVEN_PL_TRADELEG$6 FOREIGN KEY (pt_pl_element_type_id) REFERENCES ict_web_qa2.dbo.RAVEN_PL_ELEMENT_TYPES(pe_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [raven_summit_mapping_sufk] of the Table: [ict_web_qa2.dbo.raven_summit_mapping]'
go

alter table ict_web_qa2.dbo.raven_summit_mapping
add constraint raven_summit_mapping_sufk FOREIGN KEY (summit_book) REFERENCES ict_web_qa2.dbo.summit_book(name)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$raven_summit_mapping$1] of the Table: [ict_web_qa2.dbo.raven_summit_mapping]'
go

alter table ict_web_qa2.dbo.raven_summit_mapping
add constraint fk$raven_summit_mapping$1 FOREIGN KEY (raven_book) REFERENCES ict_web_qa2.dbo.raven_book(name)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_credit_trader_area] of the Table: [ict_web_qa2.dbo.credit_trader]'
go

alter table ict_web_qa2.dbo.credit_trader
add constraint fk_credit_trader_area FOREIGN KEY (area_id) REFERENCES ict_web_qa2.dbo.credit_area(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_credit_trader_country] of the Table: [ict_web_qa2.dbo.credit_trader]'
go

alter table ict_web_qa2.dbo.credit_trader
add constraint fk_credit_trader_country FOREIGN KEY (country_id) REFERENCES ict_web_qa2.dbo.credit_country(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_RISK_DETAILS$1] of the Table: [ict_web_qa2.dbo.RAVEN_RISK_DETAILS]'
go

alter table ict_web_qa2.dbo.RAVEN_RISK_DETAILS
add constraint FK$RAVEN_RISK_DETAILS$1 FOREIGN KEY (rd_trade_details_id) REFERENCES ict_web_qa2.dbo.RAVEN_TRADE_DETAILS(td_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_RISK_DETAILS$2] of the Table: [ict_web_qa2.dbo.RAVEN_RISK_DETAILS]'
go

alter table ict_web_qa2.dbo.RAVEN_RISK_DETAILS
add constraint FK$RAVEN_RISK_DETAILS$2 FOREIGN KEY (rd_risk_type_id) REFERENCES ict_web_qa2.dbo.RAVEN_RISK_TYPES(rt_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$USER_ROLE$1] of the Table: [ict_web_qa2.standard.USER_ROLE]'
go

alter table ict_web_qa2.standard.USER_ROLE
add constraint FK$USER_ROLE$1 FOREIGN KEY (USER_ID) REFERENCES ict_web_qa2.standard.APP_USER(ID)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$USER_ROLE$2] of the Table: [ict_web_qa2.standard.USER_ROLE]'
go

alter table ict_web_qa2.standard.USER_ROLE
add constraint FK$USER_ROLE$2 FOREIGN KEY (ROLE_ID) REFERENCES ict_web_qa2.standard.APP_ROLE(ID)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_search_param$1] of the Table: [ict_web_qa2.dbo.static_search_param]'
go

alter table ict_web_qa2.dbo.static_search_param
add constraint fk$static_search_param$1 FOREIGN KEY (search_id) REFERENCES ict_web_qa2.dbo.static_search(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$WATCH_LIST$1] of the Table: [ict_web_qa2.standard.WATCH_LIST]'
go

alter table ict_web_qa2.standard.WATCH_LIST
add constraint FK$WATCH_LIST$1 FOREIGN KEY (OWNER_ID) REFERENCES ict_web_qa2.standard.APP_USER(ID)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$EDS_RISK_DETAILS] of the Table: [ict_web_qa2.dbo.EDS_RISK_DETAILS]'
go

alter table ict_web_qa2.dbo.EDS_RISK_DETAILS
add constraint FK$EDS_RISK_DETAILS FOREIGN KEY (erd_risk_details_id) REFERENCES ict_web_qa2.dbo.RAVEN_RISK_DETAILS(rd_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [raven_spider_mapping_sufk] of the Table: [ict_web_qa2.dbo.raven_spider_mapping]'
go

alter table ict_web_qa2.dbo.raven_spider_mapping
add constraint raven_spider_mapping_sufk FOREIGN KEY (spider_book) REFERENCES ict_web_qa2.dbo.spider_book(name)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$raven_spider_mapping$1] of the Table: [ict_web_qa2.dbo.raven_spider_mapping]'
go

alter table ict_web_qa2.dbo.raven_spider_mapping
add constraint fk$raven_spider_mapping$1 FOREIGN KEY (raven_book) REFERENCES ict_web_qa2.dbo.raven_book(name)
go

print '----------- Generating DDL for Foreign Key Constraint: [sspv_ssp_constraint] of the Table: [ict_web_qa2.dbo.static_search_param_value]'
go

alter table ict_web_qa2.dbo.static_search_param_value
add constraint sspv_ssp_constraint FOREIGN KEY (search_id,param_id) REFERENCES ict_web_qa2.dbo.static_search_param(search_id,id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$WATCH_LIST_ITEM$1] of the Table: [ict_web_qa2.standard.WATCH_LIST_ITEM]'
go

alter table ict_web_qa2.standard.WATCH_LIST_ITEM
add constraint FK$WATCH_LIST_ITEM$1 FOREIGN KEY (WATCH_LIST_ID) REFERENCES ict_web_qa2.standard.WATCH_LIST(ID)
go

print '----------- Generating DDL for Foreign Key Constraint: [treasury_allocations_rafk] of the Table: [ict_web_qa2.dbo.treasury_allocations]'
go

alter table ict_web_qa2.dbo.treasury_allocations
add constraint treasury_allocations_rafk FOREIGN KEY (raven_book) REFERENCES ict_web_qa2.dbo.raven_book(name)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$treasury_allocations] of the Table: [ict_web_qa2.dbo.treasury_allocations]'
go

alter table ict_web_qa2.dbo.treasury_allocations
add constraint fk$treasury_allocations FOREIGN KEY (credit_curve) REFERENCES ict_web_qa2.dbo.static_credit(curve)
go

print '----------- Generating DDL for Foreign Key Constraint: [raven_summit_extra_info_rafk] of the Table: [ict_web_qa2.dbo.raven_summit_extra_info]'
go

alter table ict_web_qa2.dbo.raven_summit_extra_info
add constraint raven_summit_extra_info_rafk FOREIGN KEY (raven_book) REFERENCES ict_web_qa2.dbo.raven_book(name)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$credit_blotter$1] of the Table: [ict_web_qa2.dbo.credit_blotter]'
go

alter table ict_web_qa2.dbo.credit_blotter
add constraint fk$credit_blotter$1 FOREIGN KEY (curve_id) REFERENCES ict_web_qa2.dbo.static_credit(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$raven_book] of the Table: [ict_web_qa2.dbo.raven_book_user_group_mapping]'
go

alter table ict_web_qa2.dbo.raven_book_user_group_mapping
add constraint fk$raven_book FOREIGN KEY (raven_book) REFERENCES ict_web_qa2.dbo.raven_book(name)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$mcdic_request_portolfio$1] of the Table: [ict_web_qa2.dbo.mcdic_request_portolfio]'
go

alter table ict_web_qa2.dbo.mcdic_request_portolfio
add constraint FK$mcdic_request_portolfio$1 FOREIGN KEY (request_filename) REFERENCES ict_web_qa2.dbo.mcdic_request(request_filename)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$curve_instances$2] of the Table: [ict_web_qa2.redback.mktdata_curve_instances]'
go

alter table ict_web_qa2.redback.mktdata_curve_instances
add constraint fk$curve_instances$2 FOREIGN KEY (sc_id) REFERENCES ict_web_qa2.dbo.static_credit(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$mcdic_request_trade$1] of the Table: [ict_web_qa2.dbo.mcdic_request_trade]'
go

alter table ict_web_qa2.dbo.mcdic_request_trade
add constraint FK$mcdic_request_trade$1 FOREIGN KEY (request_filename,portfolio) REFERENCES ict_web_qa2.dbo.mcdic_request_portolfio(request_filename,portfolio)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$curve_spreads$1] of the Table: [ict_web_qa2.redback.mktdata_curve_spreads]'
go

alter table ict_web_qa2.redback.mktdata_curve_spreads
add constraint fk$curve_spreads$1 FOREIGN KEY (mgp_id) REFERENCES ict_web_qa2.redback.mktdata_grid_points(mgp_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$curve_spreads$2] of the Table: [ict_web_qa2.redback.mktdata_curve_spreads]'
go

alter table ict_web_qa2.redback.mktdata_curve_spreads
add constraint fk$curve_spreads$2 FOREIGN KEY (mcs_id) REFERENCES ict_web_qa2.redback.mktdata_curve_spreads_id(mcs_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$mktdata_bucket_level_data$2] of the Table: [ict_web_qa2.redback.mktdata_bucket_level_data]'
go

alter table ict_web_qa2.redback.mktdata_bucket_level_data
add constraint fk$mktdata_bucket_level_data$2 FOREIGN KEY (grid_point_id) REFERENCES ict_web_qa2.redback.mktdata_grid_points(mgp_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$reference_curve$1] of the Table: [ict_web_qa2.redback.mktdata_reference_curve]'
go

alter table ict_web_qa2.redback.mktdata_reference_curve
add constraint fk$reference_curve$1 FOREIGN KEY (reference_id) REFERENCES ict_web_qa2.dbo.static_credit(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$reference_curve$2] of the Table: [ict_web_qa2.redback.mktdata_reference_curve]'
go

alter table ict_web_qa2.redback.mktdata_reference_curve
add constraint fk$reference_curve$2 FOREIGN KEY (derived_id) REFERENCES ict_web_qa2.dbo.static_credit(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$release_sign_off$1] of the Table: [ict_web_qa2.redback.mktdata_release_sign_off]'
go

alter table ict_web_qa2.redback.mktdata_release_sign_off
add constraint fk$release_sign_off$1 FOREIGN KEY (USER_ID) REFERENCES ict_web_qa2.standard.APP_USER(ID)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$spread_def$1] of the Table: [ict_web_qa2.redback.mktdata_spread_def]'
go

alter table ict_web_qa2.redback.mktdata_spread_def
add constraint fk$spread_def$1 FOREIGN KEY (grid_point_id) REFERENCES ict_web_qa2.redback.mktdata_grid_points(mgp_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$spread_def$2] of the Table: [ict_web_qa2.redback.mktdata_spread_def]'
go

alter table ict_web_qa2.redback.mktdata_spread_def
add constraint fk$spread_def$2 FOREIGN KEY (derived_id) REFERENCES ict_web_qa2.dbo.static_credit(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_uploader_report] of the Table: [ict_web_qa2.dbo.UPLOADER_MISSING_TRADE]'
go

alter table ict_web_qa2.dbo.UPLOADER_MISSING_TRADE
add constraint fk_uploader_report FOREIGN KEY (um_report_id) REFERENCES ict_web_qa2.dbo.UPLOADER_REPORT(ur_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$watch_list_group_assoc$2] of the Table: [ict_web_qa2.redback.mktdata_watch_list_group_assoc]'
go

alter table ict_web_qa2.redback.mktdata_watch_list_group_assoc
add constraint fk$watch_list_group_assoc$2 FOREIGN KEY (group_id) REFERENCES ict_web_qa2.redback.mktdata_watch_list_group(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$watch_list_group_assoc$1] of the Table: [ict_web_qa2.redback.mktdata_watch_list_group_assoc]'
go

alter table ict_web_qa2.redback.mktdata_watch_list_group_assoc
add constraint fk$watch_list_group_assoc$1 FOREIGN KEY (watch_list_id) REFERENCES ict_web_qa2.standard.WATCH_LIST(ID)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_PROCESS$1] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_PROCESS]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_PROCESS
add constraint FK$RAVEN_BATCH_PROCESS$1 FOREIGN KEY (type_id) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_PROCESS_TYPE(type_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_ACTION$1] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_ACTION]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_ACTION
add constraint FK$RAVEN_BATCH_ACTION$1 FOREIGN KEY (process_id) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_PROCESS(process_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [pr_archive_1659921035] of the Table: [ict_web_qa2.dbo.pr_archive_security]'
go

alter table ict_web_qa2.dbo.pr_archive_security
add constraint pr_archive_1659921035 FOREIGN KEY (security_id) REFERENCES ict_web_qa2.dbo.pr_security(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_cash_types] of the Table: [ict_web_qa2.dbo.RAVEN_PEND_CASH_FLOWS]'
go

alter table ict_web_qa2.dbo.RAVEN_PEND_CASH_FLOWS
add constraint fk_cash_types FOREIGN KEY (pcf_cash_type_id) REFERENCES ict_web_qa2.dbo.RAVEN_CASH_TYPES(ct_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDBook$1] of the Table: [ict_web_qa2.feeds.GCDBook]'
go

alter table ict_web_qa2.feeds.GCDBook
add constraint FK$GCDBook$1 FOREIGN KEY (GCDRiskSource_Id) REFERENCES ict_web_qa2.feeds.GCDRiskSource(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDBook$2] of the Table: [ict_web_qa2.feeds.GCDBook]'
go

alter table ict_web_qa2.feeds.GCDBook
add constraint FK$GCDBook$2 FOREIGN KEY (GCDRiskApplication_Id) REFERENCES ict_web_qa2.feeds.GCDRiskApplication(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_security] of the Table: [ict_web_qa2.dbo.pr_prices]'
go

alter table ict_web_qa2.dbo.pr_prices
add constraint fk_security FOREIGN KEY (security_id) REFERENCES ict_web_qa2.dbo.pr_security(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_spread_id] of the Table: [ict_web_qa2.dbo.pr_prices]'
go

alter table ict_web_qa2.dbo.pr_prices
add constraint fk_spread_id FOREIGN KEY (spread_id) REFERENCES ict_web_qa2.dbo.pr_security_spread(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [pr_prices_664441491] of the Table: [ict_web_qa2.dbo.pr_prices]'
go

alter table ict_web_qa2.dbo.pr_prices
add constraint pr_prices_664441491 FOREIGN KEY (archive_id) REFERENCES ict_web_qa2.dbo.pr_archive_security(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDBookCount$1] of the Table: [ict_web_qa2.feeds.GCDBookCount]'
go

alter table ict_web_qa2.feeds.GCDBookCount
add constraint FK$GCDBookCount$1 FOREIGN KEY (GCDBook_Id) REFERENCES ict_web_qa2.feeds.GCDBook(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_RUN_STATUS$1] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_RUN_STATUS]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_RUN_STATUS
add constraint FK$RAVEN_BATCH_RUN_STATUS$1 FOREIGN KEY (process_id) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_PROCESS(process_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_RUN_STATUS$2] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_RUN_STATUS]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_RUN_STATUS
add constraint FK$RAVEN_BATCH_RUN_STATUS$2 FOREIGN KEY (status_id) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_STATUS(status_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_credit_book_DW_area] of the Table: [ict_web_qa2.dbo.credit_book_DW]'
go

alter table ict_web_qa2.dbo.credit_book_DW
add constraint fk_credit_book_DW_area FOREIGN KEY (area_id) REFERENCES ict_web_qa2.dbo.credit_area(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_ACTION_STATUS$1] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_ACTION_STATUS]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_ACTION_STATUS
add constraint FK$RAVEN_BATCH_ACTION_STATUS$1 FOREIGN KEY (process_id,run_date) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_RUN_STATUS(process_id,run_date)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_ACTION_STATUS$2] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_ACTION_STATUS]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_ACTION_STATUS
add constraint FK$RAVEN_BATCH_ACTION_STATUS$2 FOREIGN KEY (process_id,action_id) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_ACTION(process_id,action_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_ACTION_STATUS$3] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_ACTION_STATUS]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_ACTION_STATUS
add constraint FK$RAVEN_BATCH_ACTION_STATUS$3 FOREIGN KEY (status_id) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_STATUS(status_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDBookQueue$1] of the Table: [ict_web_qa2.feeds.GCDBookQueue]'
go

alter table ict_web_qa2.feeds.GCDBookQueue
add constraint FK$GCDBookQueue$1 FOREIGN KEY (GCDBook_Id) REFERENCES ict_web_qa2.feeds.GCDBook(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [Security_Structure_Name_FK] of the Table: [ict_web_qa2.dbo.pr_security]'
go

alter table ict_web_qa2.dbo.pr_security
add constraint Security_Structure_Name_FK FOREIGN KEY (structure_fk) REFERENCES ict_web_qa2.dbo.pr_structure(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [pr_securit_888442289] of the Table: [ict_web_qa2.dbo.pr_security]'
go

alter table ict_web_qa2.dbo.pr_security
add constraint pr_securit_888442289 FOREIGN KEY (currency_fk) REFERENCES ict_web_qa2.dbo.gcd_currency(iso_code)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_ACTION_DEPEN$1] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_ACTION_DEPEN]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_ACTION_DEPEN
add constraint FK$RAVEN_BATCH_ACTION_DEPEN$1 FOREIGN KEY (process_id,action_id) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_ACTION(process_id,action_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_ACTION_DEPEN$2] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_ACTION_DEPEN]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_ACTION_DEPEN
add constraint FK$RAVEN_BATCH_ACTION_DEPEN$2 FOREIGN KEY (process_id,depen_action_id) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_ACTION(process_id,action_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [pr_securit_1016442745] of the Table: [ict_web_qa2.dbo.pr_security_bid_presentation]'
go

alter table ict_web_qa2.dbo.pr_security_bid_presentation
add constraint pr_securit_1016442745 FOREIGN KEY (security_fk) REFERENCES ict_web_qa2.dbo.pr_security(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [pr_securit_1032442802] of the Table: [ict_web_qa2.dbo.pr_security_bid_presentation]'
go

alter table ict_web_qa2.dbo.pr_security_bid_presentation
add constraint pr_securit_1032442802 FOREIGN KEY (spread_desc_fk) REFERENCES ict_web_qa2.dbo.pr_spread_description(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_SUBREPORT$1] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_SUBREPORT]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_SUBREPORT
add constraint FK$RAVEN_BATCH_SUBREPORT$1 FOREIGN KEY (process_id) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_PROCESS(process_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_security_coupon] of the Table: [ict_web_qa2.dbo.pr_security_coupon]'
go

alter table ict_web_qa2.dbo.pr_security_coupon
add constraint fk_security_coupon FOREIGN KEY (security_id) REFERENCES ict_web_qa2.dbo.pr_security(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [pr_securit_760441833] of the Table: [ict_web_qa2.dbo.pr_security_coupon]'
go

alter table ict_web_qa2.dbo.pr_security_coupon
add constraint pr_securit_760441833 FOREIGN KEY (archive_id) REFERENCES ict_web_qa2.dbo.pr_archive_security(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_credit_book_area] of the Table: [ict_web_qa2.dbo.credit_book]'
go

alter table ict_web_qa2.dbo.credit_book
add constraint fk_credit_book_area FOREIGN KEY (area_id) REFERENCES ict_web_qa2.dbo.credit_area(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_static_book] of the Table: [ict_web_qa2.dbo.credit_book]'
go

alter table ict_web_qa2.dbo.credit_book
add constraint fk_static_book FOREIGN KEY (static_book_id) REFERENCES ict_web_qa2.dbo.static_book(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDException$1] of the Table: [ict_web_qa2.feeds.GCDException]'
go

alter table ict_web_qa2.feeds.GCDException
add constraint FK$GCDException$1 FOREIGN KEY (GCDBook_Id) REFERENCES ict_web_qa2.feeds.GCDBook(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDException$2] of the Table: [ict_web_qa2.feeds.GCDException]'
go

alter table ict_web_qa2.feeds.GCDException
add constraint FK$GCDException$2 FOREIGN KEY (GCDExceptionType_Id) REFERENCES ict_web_qa2.feeds.GCDExceptionType(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_BATCH_EMAIL$1] of the Table: [ict_web_qa2.dbo.RAVEN_BATCH_EMAIL]'
go

alter table ict_web_qa2.dbo.RAVEN_BATCH_EMAIL
add constraint FK$RAVEN_BATCH_EMAIL$1 FOREIGN KEY (process_id) REFERENCES ict_web_qa2.dbo.RAVEN_BATCH_PROCESS(process_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_RAVEN_TRADE_RISK_1] of the Table: [ict_web_qa2.dbo.RAVEN_TRADE_RISK]'
go

alter table ict_web_qa2.dbo.RAVEN_TRADE_RISK
add constraint fk_RAVEN_TRADE_RISK_1 FOREIGN KEY (tr_id) REFERENCES ict_web_qa2.dbo.RAVEN_TRADE_DETAILS(td_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDExceptionOverride$1] of the Table: [ict_web_qa2.feeds.GCDExceptionOverride]'
go

alter table ict_web_qa2.feeds.GCDExceptionOverride
add constraint FK$GCDExceptionOverride$1 FOREIGN KEY (GCDBook_Id) REFERENCES ict_web_qa2.feeds.GCDBook(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDExceptionOverride$2] of the Table: [ict_web_qa2.feeds.GCDExceptionOverride]'
go

alter table ict_web_qa2.feeds.GCDExceptionOverride
add constraint FK$GCDExceptionOverride$2 FOREIGN KEY (GCDExceptionType_Id) REFERENCES ict_web_qa2.feeds.GCDExceptionType(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_security_spread] of the Table: [ict_web_qa2.dbo.pr_security_spread]'
go

alter table ict_web_qa2.dbo.pr_security_spread
add constraint fk_security_spread FOREIGN KEY (security_fk) REFERENCES ict_web_qa2.dbo.pr_security(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_spd_description] of the Table: [ict_web_qa2.dbo.pr_security_spread]'
go

alter table ict_web_qa2.dbo.pr_security_spread
add constraint fk_spd_description FOREIGN KEY (description_fk) REFERENCES ict_web_qa2.dbo.pr_spread_description(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$EDS_TRADE_DETAILS] of the Table: [ict_web_qa2.dbo.EDS_TRADE_DETAILS]'
go

alter table ict_web_qa2.dbo.EDS_TRADE_DETAILS
add constraint FK$EDS_TRADE_DETAILS FOREIGN KEY (etd_trade_details_id) REFERENCES ict_web_qa2.dbo.RAVEN_TRADE_DETAILS(td_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDBook$1] of the Table: [ict_web_qa2.dbo.GCDBook]'
go

alter table ict_web_qa2.dbo.GCDBook
add constraint FK$GCDBook$1 FOREIGN KEY (GCDRiskSource_Id) REFERENCES ict_web_qa2.dbo.GCDRiskSource(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDBook$2] of the Table: [ict_web_qa2.dbo.GCDBook]'
go

alter table ict_web_qa2.dbo.GCDBook
add constraint FK$GCDBook$2 FOREIGN KEY (GCDRiskApplication_Id) REFERENCES ict_web_qa2.dbo.GCDRiskApplication(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDTradeSourceBook$1] of the Table: [ict_web_qa2.feeds.GCDTradeSourceBook]'
go

alter table ict_web_qa2.feeds.GCDTradeSourceBook
add constraint FK$GCDTradeSourceBook$1 FOREIGN KEY (GCDTradeSource_Id) REFERENCES ict_web_qa2.feeds.GCDTradeSource(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDTradeSourceBook$2] of the Table: [ict_web_qa2.feeds.GCDTradeSourceBook]'
go

alter table ict_web_qa2.feeds.GCDTradeSourceBook
add constraint FK$GCDTradeSourceBook$2 FOREIGN KEY (GCDBook_Id) REFERENCES ict_web_qa2.feeds.GCDBook(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDBookCount$1] of the Table: [ict_web_qa2.dbo.GCDBookCount]'
go

alter table ict_web_qa2.dbo.GCDBookCount
add constraint FK$GCDBookCount$1 FOREIGN KEY (GCDBook_Id) REFERENCES ict_web_qa2.dbo.GCDBook(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$mktdata_curve_def$1] of the Table: [ict_web_qa2.redback.mktdata_curve_def]'
go

alter table ict_web_qa2.redback.mktdata_curve_def
add constraint fk$mktdata_curve_def$1 FOREIGN KEY (derived_sc_id) REFERENCES ict_web_qa2.dbo.static_credit(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$mktdata_curve_def$2] of the Table: [ict_web_qa2.redback.mktdata_curve_def]'
go

alter table ict_web_qa2.redback.mktdata_curve_def
add constraint fk$mktdata_curve_def$2 FOREIGN KEY (base_sc_id) REFERENCES ict_web_qa2.dbo.static_credit(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$1] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$1 FOREIGN KEY (country) REFERENCES ict_web_qa2.dbo.static_country(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$10] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$10 FOREIGN KEY (rating_db) REFERENCES ict_web_qa2.dbo.static_rating_db(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$11] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$11 FOREIGN KEY (credit_event) REFERENCES ict_web_qa2.dbo.static_credit_event(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$12] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$12 FOREIGN KEY (currency) REFERENCES ict_web_qa2.dbo.static_currency(scu_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$13] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$13 FOREIGN KEY (tier) REFERENCES ict_web_qa2.dbo.static_tier(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$14] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$14 FOREIGN KEY (docclause) REFERENCES ict_web_qa2.dbo.static_docclause(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$15] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$15 FOREIGN KEY (underlying_currency) REFERENCES ict_web_qa2.dbo.static_currency(scu_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$2] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$2 FOREIGN KEY (region) REFERENCES ict_web_qa2.dbo.static_region(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$3] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$3 FOREIGN KEY (book) REFERENCES ict_web_qa2.dbo.static_book(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$4] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$4 FOREIGN KEY (db_group) REFERENCES ict_web_qa2.dbo.static_db_group(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$5] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$5 FOREIGN KEY (group3) REFERENCES ict_web_qa2.dbo.static_group3(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$6] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$6 FOREIGN KEY (group4) REFERENCES ict_web_qa2.dbo.static_group4(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$7] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$7 FOREIGN KEY (rating_moodys) REFERENCES ict_web_qa2.dbo.static_rating_moodys(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$8] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$8 FOREIGN KEY (rating_snp) REFERENCES ict_web_qa2.dbo.static_rating_snp(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_credit$9] of the Table: [ict_web_qa2.dbo.static_credit]'
go

alter table ict_web_qa2.dbo.static_credit
add constraint fk$static_credit$9 FOREIGN KEY (rating_rni) REFERENCES ict_web_qa2.dbo.static_rating_rni(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDBookQueue$1] of the Table: [ict_web_qa2.dbo.GCDBookQueue]'
go

alter table ict_web_qa2.dbo.GCDBookQueue
add constraint FK$GCDBookQueue$1 FOREIGN KEY (GCDBook_Id) REFERENCES ict_web_qa2.dbo.GCDBook(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$mktdata_spread_cal$1] of the Table: [ict_web_qa2.redback.mktdata_spread_cal]'
go

alter table ict_web_qa2.redback.mktdata_spread_cal
add constraint fk$mktdata_spread_cal$1 FOREIGN KEY (curve_def_id) REFERENCES ict_web_qa2.redback.mktdata_curve_def(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$mktdata_spread_cal$2] of the Table: [ict_web_qa2.redback.mktdata_spread_cal]'
go

alter table ict_web_qa2.redback.mktdata_spread_cal
add constraint fk$mktdata_spread_cal$2 FOREIGN KEY (grid_point_id) REFERENCES ict_web_qa2.redback.mktdata_grid_points(mgp_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_CASH_FLOWS$1] of the Table: [ict_web_qa2.dbo.RAVEN_CASH_FLOWS]'
go

alter table ict_web_qa2.dbo.RAVEN_CASH_FLOWS
add constraint FK$RAVEN_CASH_FLOWS$1 FOREIGN KEY (cf_cash_type_id) REFERENCES ict_web_qa2.dbo.RAVEN_CASH_TYPES(ct_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDException$1] of the Table: [ict_web_qa2.dbo.GCDException]'
go

alter table ict_web_qa2.dbo.GCDException
add constraint FK$GCDException$1 FOREIGN KEY (GCDBook_Id) REFERENCES ict_web_qa2.dbo.GCDBook(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDException$2] of the Table: [ict_web_qa2.dbo.GCDException]'
go

alter table ict_web_qa2.dbo.GCDException
add constraint FK$GCDException$2 FOREIGN KEY (GCDExceptionType_Id) REFERENCES ict_web_qa2.dbo.GCDExceptionType(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDExceptionOverride$1] of the Table: [ict_web_qa2.dbo.GCDExceptionOverride]'
go

alter table ict_web_qa2.dbo.GCDExceptionOverride
add constraint FK$GCDExceptionOverride$1 FOREIGN KEY (GCDBook_Id) REFERENCES ict_web_qa2.dbo.GCDBook(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDExceptionOverride$2] of the Table: [ict_web_qa2.dbo.GCDExceptionOverride]'
go

alter table ict_web_qa2.dbo.GCDExceptionOverride
add constraint FK$GCDExceptionOverride$2 FOREIGN KEY (GCDExceptionType_Id) REFERENCES ict_web_qa2.dbo.GCDExceptionType(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [raven_watc_wd_lis_1721109222] of the Table: [ict_web_qa2.dbo.raven_watchlist_details]'
go

alter table ict_web_qa2.dbo.raven_watchlist_details
add constraint raven_watc_wd_lis_1721109222 FOREIGN KEY (wd_list_name) REFERENCES ict_web_qa2.dbo.raven_watchlist(rw_list_name)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_FUNDING_VALUES_BR$1] of the Table: [ict_web_qa2.dbo.RAVEN_FUNDING_VALUES_BR]'
go

alter table ict_web_qa2.dbo.RAVEN_FUNDING_VALUES_BR
add constraint FK$RAVEN_FUNDING_VALUES_BR$1 FOREIGN KEY (fv_type_id) REFERENCES ict_web_qa2.dbo.RAVEN_CASH_TYPES(ct_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_risk_errors] of the Table: [ict_web_qa2.dbo.RAVEN_RISK_VALUES]'
go

alter table ict_web_qa2.dbo.RAVEN_RISK_VALUES
add constraint fk_risk_errors FOREIGN KEY (rv_error_id) REFERENCES ict_web_qa2.dbo.RAVEN_RISK_ERRORS(re_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_risk_gridpoints] of the Table: [ict_web_qa2.dbo.RAVEN_RISK_VALUES]'
go

alter table ict_web_qa2.dbo.RAVEN_RISK_VALUES
add constraint fk_risk_gridpoints FOREIGN KEY (rv_gridpoint_id) REFERENCES ict_web_qa2.dbo.RAVEN_RISK_GRIDPOINTS(gp_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_risk_id] of the Table: [ict_web_qa2.dbo.RAVEN_RISK_VALUES]'
go

alter table ict_web_qa2.dbo.RAVEN_RISK_VALUES
add constraint fk_risk_id FOREIGN KEY (rv_risk_details_id) REFERENCES ict_web_qa2.dbo.RAVEN_RISK_DETAILS(rd_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDTradeSourceBook$1] of the Table: [ict_web_qa2.dbo.GCDTradeSourceBook]'
go

alter table ict_web_qa2.dbo.GCDTradeSourceBook
add constraint FK$GCDTradeSourceBook$1 FOREIGN KEY (GCDTradeSource_Id) REFERENCES ict_web_qa2.dbo.GCDTradeSource(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$GCDTradeSourceBook$2] of the Table: [ict_web_qa2.dbo.GCDTradeSourceBook]'
go

alter table ict_web_qa2.dbo.GCDTradeSourceBook
add constraint FK$GCDTradeSourceBook$2 FOREIGN KEY (GCDBook_Id) REFERENCES ict_web_qa2.dbo.GCDBook(Id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_LEG_DETAILS$1] of the Table: [ict_web_qa2.dbo.RAVEN_LEG_DETAILS]'
go

alter table ict_web_qa2.dbo.RAVEN_LEG_DETAILS
add constraint FK$RAVEN_LEG_DETAILS$1 FOREIGN KEY (ld_trade_details_id) REFERENCES ict_web_qa2.dbo.RAVEN_TRADE_DETAILS(td_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_LEG_DETAILS$2] of the Table: [ict_web_qa2.dbo.RAVEN_LEG_DETAILS]'
go

alter table ict_web_qa2.dbo.RAVEN_LEG_DETAILS
add constraint FK$RAVEN_LEG_DETAILS$2 FOREIGN KEY (ld_leg_description_id) REFERENCES ict_web_qa2.dbo.RAVEN_LEG_DESCRIPTION(ld_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_cusip$1] of the Table: [ict_web_qa2.dbo.static_cusip]'
go

alter table ict_web_qa2.dbo.static_cusip
add constraint fk$static_cusip$1 FOREIGN KEY (price_quoting) REFERENCES ict_web_qa2.dbo.static_price_quoting(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk$static_cusip$2] of the Table: [ict_web_qa2.dbo.static_cusip]'
go

alter table ict_web_qa2.dbo.static_cusip
add constraint fk$static_cusip$2 FOREIGN KEY (notional_type) REFERENCES ict_web_qa2.dbo.static_notional_type(id)
go

print '----------- Generating DDL for Foreign Key Constraint: [FK$RAVEN_PL_ELEMENT_TYPES$1] of the Table: [ict_web_qa2.dbo.RAVEN_PL_ELEMENT_TYPES]'
go

alter table ict_web_qa2.dbo.RAVEN_PL_ELEMENT_TYPES
add constraint FK$RAVEN_PL_ELEMENT_TYPES$1 FOREIGN KEY (pe_element_group_id) REFERENCES ict_web_qa2.dbo.RAVEN_PL_ELEMENT_GROUPS(pg_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fx_RAVEN_FUNDING_BALANCE_1] of the Table: [ict_web_qa2.dbo.RAVEN_FUNDING_BALANCE]'
go

alter table ict_web_qa2.dbo.RAVEN_FUNDING_BALANCE
add constraint fx_RAVEN_FUNDING_BALANCE_1 FOREIGN KEY (fb_balance_type_id) REFERENCES ict_web_qa2.dbo.RAVEN_BALANCE_TYPE(bt_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_RAVEN_EXPLAIN_VALUES] of the Table: [ict_web_qa2.dbo.RAVEN_EXPLAIN_VALUES]'
go

alter table ict_web_qa2.dbo.RAVEN_EXPLAIN_VALUES
add constraint fk_RAVEN_EXPLAIN_VALUES FOREIGN KEY (ev_risk_type_id) REFERENCES ict_web_qa2.dbo.RAVEN_RISK_TYPES(rt_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_RAVEN_EXPLAIN_BALANCE_1] of the Table: [ict_web_qa2.dbo.RAVEN_EXPLAIN_BALANCE]'
go

alter table ict_web_qa2.dbo.RAVEN_EXPLAIN_BALANCE
add constraint fk_RAVEN_EXPLAIN_BALANCE_1 FOREIGN KEY (eb_balance_type_id) REFERENCES ict_web_qa2.dbo.RAVEN_BALANCE_TYPE(bt_id)
go

print '----------- Generating DDL for Foreign Key Constraint: [fk_RAVEN_EXPLAIN_BALANCE_2] of the Table: [ict_web_qa2.dbo.RAVEN_EXPLAIN_BALANCE]'
go

alter table ict_web_qa2.dbo.RAVEN_EXPLAIN_BALANCE
add constraint fk_RAVEN_EXPLAIN_BALANCE_2 FOREIGN KEY (eb_risk_type_id) REFERENCES ict_web_qa2.dbo.RAVEN_RISK_TYPES(rt_id)
go



-- DDLGen Completed
-- at 02/07/05 18:14:06 GMT