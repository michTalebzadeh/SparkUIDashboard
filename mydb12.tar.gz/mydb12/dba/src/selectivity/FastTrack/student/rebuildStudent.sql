SET ECHO OFF
REM ******************************************************************
REM   file: rebuildStudent.sql
REM  description: used for recreating the objects and loading data
REM                 into the student schema. CAUTION: Running this
REM                 will remove all of the data and objects used for
REM                 the books.
REM  created February 3, 2000
REM ******************************************************************

@@dropStudent.sql
@@createStudent.sql

