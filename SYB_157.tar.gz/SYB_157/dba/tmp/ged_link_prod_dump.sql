use master
go
set nocount on
go
checkpoint
go
declare @msg char(100), @errorno int
dump tran ged_link_prod with truncate_only
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Tue Jan 22 00:30:13 GMT 2002 db_dump_adsm.ksh Dump of ged_link_prod log failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go
declare @msg char(100), @errorno int
dump database ged_link_prod to "/apps/sybase/dump/lon_gedimg_sql_prd/ged_link_prod.dmp"
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Tue Jan 22 00:30:13 GMT 2002 db_dump_adsm.ksh Dump of ged_link_prod failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go

