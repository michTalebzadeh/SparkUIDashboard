 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 COMPONENT									   VARCHAR2(64)
 OPER_TYPE									   VARCHAR2(13)
 OPER_MODE									   VARCHAR2(9)
 PARAMETER									   VARCHAR2(80)
 INITIAL_SIZE									   NUMBER
 TARGET_SIZE									   NUMBER
 FINAL_SIZE									   NUMBER
 STATUS 									   VARCHAR2(9)
 START_TIME									   DATE
 END_TIME									   DATE

