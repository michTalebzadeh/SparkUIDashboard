 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 THREAD#									   NUMBER
 LOW_SEQUENCE#									   NUMBER
 HIGH_SEQUENCE# 								   NUMBER

