--
--First define a row type that contains the columns we need
--
CREATE OR REPLACE TYPE sales_array_row_type
AS OBJECT
(
	 PROD_ID	NUMBER,
	 CUST_ID	NUMBER,
	 TIME_ID	DATE,
	CHANNEL_ID	NUMBER,
	PROMO_ID	NUMBER,
	QUANTITY_SOLD	NUMBER(10,2),
	AMOUNT_SOLD	NUMBER(10,2)
);
/
-- Create a table type
--
CREATE OR REPLACE TYPE sales_array_table_type AS TABLE OF sales_array_row_type;
/
/*
   Now define a table function which returns a collection containing a subset of the columns from sales table. Table function mimics the table and can be queried later
   using the TABLE function in from clause
*/
CREATE OR REPLACE FUNCTION sales_array 
(
	p_PROD_ID	IN	NUMBER		DEFAULT 0,	
	p_CUST_ID	IN	NUMBER          DEFAULT 0,
	p_TIME_ID	IN	DATE		DEFAULT SYSDATE,
	p_CHANNEL_ID	IN	NUMBER		DEFAULT 0,
	p_PROMO_ID	IN	NUMBER		DEFAULT 0,
	p_QUANTITY_SOLD	IN	NUMBER		DEFAULT 0,
	p_AMOUNT_SOLD	IN	NUMBER		DEFAULT 0
)
RETURN sales_array_table_type PIPELINED -- Pipelining negates the need to build huge collections by piping rows out of the function as they are created,
                                   -- saving memory and allowing subsequent processing to start before all the rows are generated
AS
BEGIN
  FOR rs IN (
		SELECT
			PROD_ID,
			CUST_ID,
			TIME_ID,
			CHANNEL_ID,
			PROMO_ID,
			QUANTITY_SOLD,
			AMOUNT_SOLD
	     	FROM
		 	salesfeed_external_table
	    )
  LOOP
    PIPE ROW(sales_array_row_type(rs.PROD_ID, rs.CUST_ID,rs.TIME_ID,rs.CHANNEL_ID,rs.PROMO_ID,rs.QUANTITY_SOLD,rs.AMOUNT_SOLD));
  END LOOP;
  RETURN;
END;
/
show errors
/
CREATE OR REPLACE FUNCTION sales_regular_array
(
	p_PROD_ID	IN	NUMBER		DEFAULT 0,	
	p_CUST_ID	IN	NUMBER          DEFAULT 0,
	p_TIME_ID	IN	DATE		DEFAULT SYSDATE,
	p_CHANNEL_ID	IN	NUMBER		DEFAULT 0,
	p_PROMO_ID	IN	NUMBER		DEFAULT 0,
	p_QUANTITY_SOLD	IN	NUMBER		DEFAULT 0,
	p_AMOUNT_SOLD	IN	NUMBER		DEFAULT 0
)
RETURN sales_array_table_type 
AS
v_tab sales_array_table_type := sales_array_table_type();
BEGIN
  FOR rs IN (
                SELECT
			PROD_ID,
			CUST_ID,
			TIME_ID,
			CHANNEL_ID,
			PROMO_ID,
			QUANTITY_SOLD,
			AMOUNT_SOLD
                FROM
                        salesfeed_external_table
            )
  LOOP
    v_tab.extend;
    v_tab(v_tab.last) := sales_array_row_type(rs.PROD_ID,rs.CUST_ID,rs.TIME_ID,rs.CHANNEL_ID,rs.PROMO_ID,rs.QUANTITY_SOLD,rs.AMOUNT_SOLD);
  END LOOP;
  RETURN v_tab;
END;
/
show errors
/
/*
SELECT * FROM
(
       SELECT
                sales.cust_id "Customer ID",
                COUNT(sales.amount_sold) "Number of orders",
                SUM(sales.amount_sold) "Total customer's amount",
                AVG(sales.amount_sold) "Average order",
                STDDEV(sales.amount_sold) "Standard deviation"
       FROM
                table(sales_array) t,
                sales
       WHERE
                t.PROD_ID = sales.PROD_ID
       AND
                t.CUST_ID = sales.CUST_ID
       AND
		t.TIME_ID > sales.TIME_ID
       GROUP BY
                sales.CUST_ID
       HAVING
                SUM(sales.amount_sold) > 94000
       AND
                 AVG(sales.amount_sold) < STDDEV(sales.amount_sold)
       ORDER BY
                3 DESC
)
WHERE ROWNUM <=10;
*/
exit
