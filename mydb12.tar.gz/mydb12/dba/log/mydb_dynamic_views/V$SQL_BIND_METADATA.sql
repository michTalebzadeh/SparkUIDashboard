 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ADDRESS									   RAW(4)
 POSITION									   NUMBER
 DATATYPE									   NUMBER
 MAX_LENGTH									   NUMBER
 ARRAY_LEN									   NUMBER
 BIND_NAME									   VARCHAR2(30)

