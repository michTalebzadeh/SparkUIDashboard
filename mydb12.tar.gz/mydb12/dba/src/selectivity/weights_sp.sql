CREATE OR REPLACE PROCEDURE weights_sp
AS
  v_datetaken		        weights.datetaken%TYPE;
  v_weight                      weights.weight%type;
  v_prednisolone		weights.prednisolone%TYPE;
  v_azathioprine		weights.azathioprine%TYPE;
  v_avgweight			weights.weight%type;
  v_rowcount			NUMBER := 0;
  e_rows			EXCEPTION;	
  CURSOR c1 is
  SELECT * FROM WEIGHTS ORDER BY DATETAKEN;
BEGIN
  dbms_output.put_line(CHR(10));
  OPEN c1;
  LOOP
    FETCH c1 INTO
	  v_datetaken
	, v_weight
	, v_prednisolone
	, v_azathioprine;
      v_rowcount := v_rowcount + 1;
      IF MOD(v_rowcount, 8) = 0 THEN
        dbms_output.put_line(CHR(10));
      END IF;
    EXIT WHEN c1%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE( 'Date taken = ' || to_char(v_datetaken, 'dd/mm/yyyy') ||CHR(9)|| '  Weight = ' || v_weight || CHR(9)|| '  Prednisolone = '|| v_prednisolone ||CHR(9)|| ' Azathioprine = ' || v_azathioprine);
  END LOOP;
  CLOSE c1;
END weights_sp;
/
show errors
exit
