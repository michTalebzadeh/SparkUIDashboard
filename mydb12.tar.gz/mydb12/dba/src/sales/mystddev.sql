CREATE OR REPLACE FUNCTION mystddev
RETURN NUMBER
AS
  v_stddev NUMBER;
BEGIN
  SELECT  SQRT((SUM(POWER(AMOUNT_SOLD,2))-(COUNT(1)*POWER(AVG(AMOUNT_SOLD),2)))/(COUNT(1)-1))
  INTO v_stddev
  from    sales;
  RETURN  v_stddev;
  EXCEPTION
    WHEN NO_DATA_FOUND THEN
      DBMS_OUTPUT.PUT_LINE('No record is found');
  END mystddev;
/
show errors
exit
