 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 AGENT_ID									   NUMBER
 MACHINE									   VARCHAR2(64)
 PROCESS									   VARCHAR2(9)
 PROGRAM									   VARCHAR2(48)
 OSUSER 									   VARCHAR2(30)
 STARTTIME									   DATE
 AGENT_TYPE									   NUMBER
 FDS_CLASS_ID									   NUMBER
 FDS_INST_ID									   NUMBER

