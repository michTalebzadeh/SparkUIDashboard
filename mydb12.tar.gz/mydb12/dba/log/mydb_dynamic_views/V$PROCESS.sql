 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ADDR										   RAW(4)
 PID										   NUMBER
 SPID										   VARCHAR2(24)
 PNAME										   VARCHAR2(5)
 USERNAME									   VARCHAR2(15)
 SERIAL#									   NUMBER
 TERMINAL									   VARCHAR2(30)
 PROGRAM									   VARCHAR2(48)
 TRACEID									   VARCHAR2(255)
 TRACEFILE									   VARCHAR2(513)
 BACKGROUND									   VARCHAR2(1)
 LATCHWAIT									   VARCHAR2(8)
 LATCHSPIN									   VARCHAR2(8)
 PGA_USED_MEM									   NUMBER
 PGA_ALLOC_MEM									   NUMBER
 PGA_FREEABLE_MEM								   NUMBER
 PGA_MAX_MEM									   NUMBER

