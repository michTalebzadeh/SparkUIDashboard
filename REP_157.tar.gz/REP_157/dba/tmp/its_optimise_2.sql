            
 ---------- 
 use its
go 

	                                                                                                                                                                    
 
	------------------------------------------------------------------------------------------------------------------------------------------------------------------ 

	 sp_recompile "dbo.cvits_next_rowid"
go
update statistics dbo.cvits_next_rowid
go                                                                                   

	 sp_recompile "dbo.db_security_codes"
go
update statistics dbo.db_security_codes
go                                                                                 

	 sp_recompile "dbo.db_transfer_record"
go
update statistics dbo.db_transfer_record
go                                                                               

	 sp_recompile "dbo.dba_check_rep_delay"
go
update statistics dbo.dba_check_rep_delay
go                                                                             

	 sp_recompile "dbo.dbeq_Schedule"
go
update statistics dbo.dbeq_Schedule
go                                                                                         

	 sp_recompile "dbo.dbeq_market_price"
go
update statistics dbo.dbeq_market_price
go                                                                                 

	 sp_recompile "dbo.dbeq_sm_asset_swap"
go
update statistics dbo.dbeq_sm_asset_swap
go                                                                               

	 sp_recompile "dbo.dbeq_sm_convertible"
go
update statistics dbo.dbeq_sm_convertible
go                                                                             

	 sp_recompile "dbo.dbtrader_secm"
go
update statistics dbo.dbtrader_secm
go                                                                                         

	 sp_recompile "dbo.dmg_fxp_ccymap"
go
update statistics dbo.dmg_fxp_ccymap
go                                                                                       

	 sp_recompile "dbo.dmg_month_codes"
go
update statistics dbo.dmg_month_codes
go                                                                                     

	 sp_recompile "dbo.dmg_tmp_results"
go
update statistics dbo.dmg_tmp_results
go                                                                                     

	 sp_recompile "dbo.dmgcv_sales_permission"
go
update statistics dbo.dmgcv_sales_permission
go                                                                       

	 sp_recompile "dbo.dmgcv_sales_regions"
go
update statistics dbo.dmgcv_sales_regions
go                                                                             

	 sp_recompile "dbo.dmgcv_sales_response"
go
update statistics dbo.dmgcv_sales_response
go                                                                           

	 sp_recompile "dbo.dmgcv_sales_trans"
go
update statistics dbo.dmgcv_sales_trans
go                                                                                 

	 sp_recompile "dbo.euro_rates"
go
update statistics dbo.euro_rates
go                                                                                               

	 sp_recompile "dbo.hts_account"
go
update statistics dbo.hts_account
go                                                                                             

	 sp_recompile "dbo.hts_adjustment"
go
update statistics dbo.hts_adjustment
go                                                                                       

	 sp_recompile "dbo.hts_admin_control"
go
update statistics dbo.hts_admin_control
go                                                                                 

	 sp_recompile "dbo.hts_ae_codes"
go
update statistics dbo.hts_ae_codes
go                                                                                           

	 sp_recompile "dbo.hts_audit_status"
go
update statistics dbo.hts_audit_status
go                                                                                   

	 sp_recompile "dbo.hts_b2b_trade_event"
go
update statistics dbo.hts_b2b_trade_event
go                                                                             

	 sp_recompile "dbo.hts_ba_spread_class"
go
update statistics dbo.hts_ba_spread_class
go                                                                             

	 sp_recompile "dbo.hts_ba_spread_detail"
go
update statistics dbo.hts_ba_spread_detail
go                                                                           

	 sp_recompile "dbo.hts_ba_spread_list"
go
update statistics dbo.hts_ba_spread_list
go                                                                               

	 sp_recompile "dbo.hts_basis_detail"
go
update statistics dbo.hts_basis_detail
go                                                                                   

	 sp_recompile "dbo.hts_basis_list"
go
update statistics dbo.hts_basis_list
go                                                                                       

	 sp_recompile "dbo.hts_bo_event"
go
update statistics dbo.hts_bo_event
go                                                                                           

	 sp_recompile "dbo.hts_borrow_detail"
go
update statistics dbo.hts_borrow_detail
go                                                                                 

	 sp_recompile "dbo.hts_borrow_list"
go
update statistics dbo.hts_borrow_list
go                                                                                     

	 sp_recompile "dbo.hts_bs_codes"
go
update statistics dbo.hts_bs_codes
go                                                                                           

	 sp_recompile "dbo.hts_capreq_basket"
go
update statistics dbo.hts_capreq_basket
go                                                                                 

	 sp_recompile "dbo.hts_capreq_divisors"
go
update statistics dbo.hts_capreq_divisors
go                                                                             

	 sp_recompile "dbo.hts_capreq_overrides"
go
update statistics dbo.hts_capreq_overrides
go                                                                           

	 sp_recompile "dbo.hts_capreq_xref"
go
update statistics dbo.hts_capreq_xref
go                                                                                     

	 sp_recompile "dbo.hts_cash_coll_sched"
go
update statistics dbo.hts_cash_coll_sched
go                                                                             

	 sp_recompile "dbo.hts_ccy_round"
go
update statistics dbo.hts_ccy_round
go                                                                                         

	 sp_recompile "dbo.hts_charge_interval"
go
update statistics dbo.hts_charge_interval
go                                                                             

	 sp_recompile "dbo.hts_charge_rule"
go
update statistics dbo.hts_charge_rule
go                                                                                     

	 sp_recompile "dbo.hts_charge_sched_detail"
go
update statistics dbo.hts_charge_sched_detail
go                                                                     

	 sp_recompile "dbo.hts_charge_sched_list"
go
update statistics dbo.hts_charge_sched_list
go                                                                         

	 sp_recompile "dbo.hts_charge_schedule"
go
update statistics dbo.hts_charge_schedule
go                                                                             

	 sp_recompile "dbo.hts_charge_type"
go
update statistics dbo.hts_charge_type
go                                                                                     

	 sp_recompile "dbo.hts_coll_pool"
go
update statistics dbo.hts_coll_pool
go                                                                                         

	 sp_recompile "dbo.hts_collateral"
go
update statistics dbo.hts_collateral
go                                                                                       

	 sp_recompile "dbo.hts_constituent"
go
update statistics dbo.hts_constituent
go                                                                                     

	 sp_recompile "dbo.hts_corr_detail"
go
update statistics dbo.hts_corr_detail
go                                                                                     

	 sp_recompile "dbo.hts_corr_list"
go
update statistics dbo.hts_corr_list
go                                                                                         

	 sp_recompile "dbo.hts_country"
go
update statistics dbo.hts_country
go                                                                                             

	 sp_recompile "dbo.hts_credit_ratings"
go
update statistics dbo.hts_credit_ratings
go                                                                               

	 sp_recompile "dbo.hts_credit_spreads"
go
update statistics dbo.hts_credit_spreads
go                                                                               

	 sp_recompile "dbo.hts_credit_spreads_list"
go
update statistics dbo.hts_credit_spreads_list
go                                                                     

	 sp_recompile "dbo.hts_customer"
go
update statistics dbo.hts_customer
go                                                                                           

	 sp_recompile "dbo.hts_data_relation"
go
update statistics dbo.hts_data_relation
go                                                                                 

	 sp_recompile "dbo.hts_db_listener"
go
update statistics dbo.hts_db_listener
go                                                                                     

	 sp_recompile "dbo.hts_db_upgrades"
go
update statistics dbo.hts_db_upgrades
go                                                                                     

	 sp_recompile "dbo.hts_dbl_log"
go
update statistics dbo.hts_dbl_log
go                                                                                             

	 sp_recompile "dbo.hts_dbt_fee_map"
go
update statistics dbo.hts_dbt_fee_map
go                                                                                     

	 sp_recompile "dbo.hts_dbt_fi_sec"
go
update statistics dbo.hts_dbt_fi_sec
go                                                                                       

	 sp_recompile "dbo.hts_dbt_system_route"
go
update statistics dbo.hts_dbt_system_route
go                                                                           

	 sp_recompile "dbo.hts_dbt_xfce"
go
update statistics dbo.hts_dbt_xfce
go                                                                                           

	 sp_recompile "dbo.hts_deal"
go
update statistics dbo.hts_deal
go                                                                                                   

	 sp_recompile "dbo.hts_dividend_detail"
go
update statistics dbo.hts_dividend_detail
go                                                                             

	 sp_recompile "dbo.hts_dividend_list"
go
update statistics dbo.hts_dividend_list
go                                                                                 

	 sp_recompile "dbo.hts_dynamic_apps"
go
update statistics dbo.hts_dynamic_apps
go                                                                                   

	 sp_recompile "dbo.hts_emu_conv_event"
go
update statistics dbo.hts_emu_conv_event
go                                                                               

	 sp_recompile "dbo.hts_emu_conv_rule"
go
update statistics dbo.hts_emu_conv_rule
go                                                                                 

	 sp_recompile "dbo.hts_emu_conv_rule_list"
go
update statistics dbo.hts_emu_conv_rule_list
go                                                                       

	 sp_recompile "dbo.hts_eqcd_detail"
go
update statistics dbo.hts_eqcd_detail
go                                                                                     

	 sp_recompile "dbo.hts_event_types"
go
update statistics dbo.hts_event_types
go                                                                                     

	 sp_recompile "dbo.hts_exchange"
go
update statistics dbo.hts_exchange
go                                                                                           

	 sp_recompile "dbo.hts_exec_adj"
go
update statistics dbo.hts_exec_adj
go                                                                                           

	 sp_recompile "dbo.hts_exec_control"
go
update statistics dbo.hts_exec_control
go                                                                                   

	 sp_recompile "dbo.hts_exer_notice"
go
update statistics dbo.hts_exer_notice
go                                                                                     

	 sp_recompile "dbo.hts_fi_sec_master"
go
update statistics dbo.hts_fi_sec_master
go                                                                                 

	 sp_recompile "dbo.hts_filter_columns"
go
update statistics dbo.hts_filter_columns
go                                                                               

	 sp_recompile "dbo.hts_filter_detail"
go
update statistics dbo.hts_filter_detail
go                                                                                 

	 sp_recompile "dbo.hts_filter_list"
go
update statistics dbo.hts_filter_list
go                                                                                     

	 sp_recompile "dbo.hts_fiscal_calendar"
go
update statistics dbo.hts_fiscal_calendar
go                                                                             

	 sp_recompile "dbo.hts_fixings"
go
update statistics dbo.hts_fixings
go                                                                                             

	 sp_recompile "dbo.hts_funding_rates"
go
update statistics dbo.hts_funding_rates
go                                                                                 

	 sp_recompile "dbo.hts_fx_detail"
go
update statistics dbo.hts_fx_detail
go                                                                                         

	 sp_recompile "dbo.hts_fx_list"
go
update statistics dbo.hts_fx_list
go                                                                                             

	 sp_recompile "dbo.hts_gen_otc"
go
update statistics dbo.hts_gen_otc
go                                                                                             

	 sp_recompile "dbo.hts_gen_sec_types"
go
update statistics dbo.hts_gen_sec_types
go                                                                                 

	 sp_recompile "dbo.hts_gotc_rebate_pay_types"
go
update statistics dbo.hts_gotc_rebate_pay_types
go                                                                 

	 sp_recompile "dbo.hts_gotc_schedule"
go
update statistics dbo.hts_gotc_schedule
go                                                                                 

	 sp_recompile "dbo.hts_gotc_trigger_types"
go
update statistics dbo.hts_gotc_trigger_types
go                                                                       

	 sp_recompile "dbo.hts_group"
go
update statistics dbo.hts_group
go                                                                                                 

	 sp_recompile "dbo.hts_group_control"
go
update statistics dbo.hts_group_control
go                                                                                 

	 sp_recompile "dbo.hts_hldGetQty_wrk"
go
update statistics dbo.hts_hldGetQty_wrk
go                                                                                 

	 sp_recompile "dbo.hts_hold_map"
go
update statistics dbo.hts_hold_map
go                                                                                           

	 sp_recompile "dbo.hts_hold_user_data"
go
update statistics dbo.hts_hold_user_data
go                                                                               

	 sp_recompile "dbo.hts_holding_greeks"
go
update statistics dbo.hts_holding_greeks
go                                                                               

	 sp_recompile "dbo.hts_holiday_detail"
go
update statistics dbo.hts_holiday_detail
go                                                                               

	 sp_recompile "dbo.hts_holiday_list"
go
update statistics dbo.hts_holiday_list
go                                                                                   

	 sp_recompile "dbo.hts_industry"
go
update statistics dbo.hts_industry
go                                                                                           

	 sp_recompile "dbo.hts_issuer"
go
update statistics dbo.hts_issuer
go                                                                                               

	 sp_recompile "dbo.hts_legal_entity"
go
update statistics dbo.hts_legal_entity
go                                                                                   

	 sp_recompile "dbo.hts_lim_cmb_type"
go
update statistics dbo.hts_lim_cmb_type
go                                                                                   

	 sp_recompile "dbo.hts_limit_detail"
go
update statistics dbo.hts_limit_detail
go                                                                                   

	 sp_recompile "dbo.hts_limit_field"
go
update statistics dbo.hts_limit_field
go                                                                                     

	 sp_recompile "dbo.hts_limit_list"
go
update statistics dbo.hts_limit_list
go                                                                                       

	 sp_recompile "dbo.hts_limit_monitor_event"
go
update statistics dbo.hts_limit_monitor_event
go                                                                     

	 sp_recompile "dbo.hts_location"
go
update statistics dbo.hts_location
go                                                                                           

	 sp_recompile "dbo.hts_lock"
go
update statistics dbo.hts_lock
go                                                                                                   

	 sp_recompile "dbo.hts_mark"
go
update statistics dbo.hts_mark
go                                                                                                   

	 sp_recompile "dbo.hts_mark_acct"
go
update statistics dbo.hts_mark_acct
go                                                                                         

	 sp_recompile "dbo.hts_market_price"
go
update statistics dbo.hts_market_price
go                                                                                   

	 sp_recompile "dbo.hts_mmkt_usec"
go
update statistics dbo.hts_mmkt_usec
go                                                                                         

	 sp_recompile "dbo.hts_monitor_limit"
go
update statistics dbo.hts_monitor_limit
go                                                                                 

	 sp_recompile "dbo.hts_name_change_notice"
go
update statistics dbo.hts_name_change_notice
go                                                                       

	 sp_recompile "dbo.hts_next_rowid"
go
update statistics dbo.hts_next_rowid
go                                                                                       

	 sp_recompile "dbo.hts_nosplit"
go
update statistics dbo.hts_nosplit
go                                                                                             

	 sp_recompile "dbo.hts_notify_status"
go
update statistics dbo.hts_notify_status
go                                                                                 

	 sp_recompile "dbo.hts_object_limit"
go
update statistics dbo.hts_object_limit
go                                                                                   

	 sp_recompile "dbo.hts_obsolete_objects_wrk"
go
update statistics dbo.hts_obsolete_objects_wrk
go                                                                   

	 sp_recompile "dbo.hts_opt_exer_event"
go
update statistics dbo.hts_opt_exer_event
go                                                                               

	 sp_recompile "dbo.hts_ord_control"
go
update statistics dbo.hts_ord_control
go                                                                                     

	 sp_recompile "dbo.hts_pc_codes"
go
update statistics dbo.hts_pc_codes
go                                                                                           

	 sp_recompile "dbo.hts_perm_control"
go
update statistics dbo.hts_perm_control
go                                                                                   

	 sp_recompile "dbo.hts_pl_archive"
go
update statistics dbo.hts_pl_archive
go                                                                                       

	 sp_recompile "dbo.hts_port_control"
go
update statistics dbo.hts_port_control
go                                                                                   

	 sp_recompile "dbo.hts_price_detail"
go
update statistics dbo.hts_price_detail
go                                                                                   

	 sp_recompile "dbo.hts_price_list"
go
update statistics dbo.hts_price_list
go                                                                                       

	 sp_recompile "dbo.hts_problem_holdings_wrk"
go
update statistics dbo.hts_problem_holdings_wrk
go                                                                   

	 sp_recompile "dbo.hts_profit_loss"
go
update statistics dbo.hts_profit_loss
go                                                                                     

	 sp_recompile "dbo.hts_ran_306"
go
update statistics dbo.hts_ran_306
go                                                                                             

	 sp_recompile "dbo.hts_ran_308"
go
update statistics dbo.hts_ran_308
go                                                                                             

	 sp_recompile "dbo.hts_regulatory_agency"
go
update statistics dbo.hts_regulatory_agency
go                                                                         

	 sp_recompile "dbo.hts_replication_status"
go
update statistics dbo.hts_replication_status
go                                                                       

	 sp_recompile "dbo.hts_restricted_sec"
go
update statistics dbo.hts_restricted_sec
go                                                                               

	 sp_recompile "dbo.hts_reuters_masks"
go
update statistics dbo.hts_reuters_masks
go                                                                                 

	 sp_recompile "dbo.hts_roll_detail"
go
update statistics dbo.hts_roll_detail
go                                                                                     

	 sp_recompile "dbo.hts_roll_list"
go
update statistics dbo.hts_roll_list
go                                                                                         

	 sp_recompile "dbo.hts_scenario_maps"
go
update statistics dbo.hts_scenario_maps
go                                                                                 

	 sp_recompile "dbo.hts_sched_list"
go
update statistics dbo.hts_sched_list
go                                                                                       

	 sp_recompile "dbo.hts_sec_def_attribs"
go
update statistics dbo.hts_sec_def_attribs
go                                                                             

	 sp_recompile "dbo.hts_sec_master"
go
update statistics dbo.hts_sec_master
go                                                                                       

	 sp_recompile "dbo.hts_settle_rule"
go
update statistics dbo.hts_settle_rule
go                                                                                     

	 sp_recompile "dbo.hts_sfailure_event"
go
update statistics dbo.hts_sfailure_event
go                                                                               

	 sp_recompile "dbo.hts_site"
go
update statistics dbo.hts_site
go                                                                                                   

	 sp_recompile "dbo.hts_sm_deriv_detail"
go
update statistics dbo.hts_sm_deriv_detail
go                                                                             

	 sp_recompile "dbo.hts_sm_eqss_detail"
go
update statistics dbo.hts_sm_eqss_detail
go                                                                               

	 sp_recompile "dbo.hts_sm_relation"
go
update statistics dbo.hts_sm_relation
go                                                                                     

	 sp_recompile "dbo.hts_sm_repo"
go
update statistics dbo.hts_sm_repo
go                                                                                             

	 sp_recompile "dbo.hts_sm_repo_sched"
go
update statistics dbo.hts_sm_repo_sched
go                                                                                 

	 sp_recompile "dbo.hts_sm_user_data"
go
update statistics dbo.hts_sm_user_data
go                                                                                   

	 sp_recompile "dbo.hts_splits"
go
update statistics dbo.hts_splits
go                                                                                               

	 sp_recompile "dbo.hts_spot_list"
go
update statistics dbo.hts_spot_list
go                                                                                         

	 sp_recompile "dbo.hts_spx_conv_execs"
go
update statistics dbo.hts_spx_conv_execs
go                                                                               

	 sp_recompile "dbo.hts_spx_conv_ords"
go
update statistics dbo.hts_spx_conv_ords
go                                                                                 

	 sp_recompile "dbo.hts_stock_merger"
go
update statistics dbo.hts_stock_merger
go                                                                                   

	 sp_recompile "dbo.hts_stock_merger_list"
go
update statistics dbo.hts_stock_merger_list
go                                                                         

	 sp_recompile "dbo.hts_stock_spinoff"
go
update statistics dbo.hts_stock_spinoff
go                                                                                 

	 sp_recompile "dbo.hts_stock_spinoff_list"
go
update statistics dbo.hts_stock_spinoff_list
go                                                                       

	 sp_recompile "dbo.hts_stock_split"
go
update statistics dbo.hts_stock_split
go                                                                                     

	 sp_recompile "dbo.hts_swap"
go
update statistics dbo.hts_swap
go                                                                                                   

	 sp_recompile "dbo.hts_swap_detail"
go
update statistics dbo.hts_swap_detail
go                                                                                     

	 sp_recompile "dbo.hts_swap_equity_leg"
go
update statistics dbo.hts_swap_equity_leg
go                                                                             

	 sp_recompile "dbo.hts_swap_event_sched"
go
update statistics dbo.hts_swap_event_sched
go                                                                           

	 sp_recompile "dbo.hts_swap_floating_leg"
go
update statistics dbo.hts_swap_floating_leg
go                                                                         

	 sp_recompile "dbo.hts_swap_leg"
go
update statistics dbo.hts_swap_leg
go                                                                                           

	 sp_recompile "dbo.hts_swap_list"
go
update statistics dbo.hts_swap_list
go                                                                                         

	 sp_recompile "dbo.hts_swap_quanto_leg"
go
update statistics dbo.hts_swap_quanto_leg
go                                                                             

	 sp_recompile "dbo.hts_symbol_refresh_wrk"
go
update statistics dbo.hts_symbol_refresh_wrk
go                                                                       

	 sp_recompile "dbo.hts_table_comment"
go
update statistics dbo.hts_table_comment
go                                                                                 

	 sp_recompile "dbo.hts_table_event"
go
update statistics dbo.hts_table_event
go                                                                                     

	 sp_recompile "dbo.hts_table_info"
go
update statistics dbo.hts_table_info
go                                                                                       

	 sp_recompile "dbo.hts_tax_rules"
go
update statistics dbo.hts_tax_rules
go                                                                                         

	 sp_recompile "dbo.hts_template_detail"
go
update statistics dbo.hts_template_detail
go                                                                             

	 sp_recompile "dbo.hts_template_list"
go
update statistics dbo.hts_template_list
go                                                                                 

	 sp_recompile "dbo.hts_tick_sizes"
go
update statistics dbo.hts_tick_sizes
go                                                                                       

	 sp_recompile "dbo.hts_time_zone"
go
update statistics dbo.hts_time_zone
go                                                                                         

	 sp_recompile "dbo.hts_trader"
go
update statistics dbo.hts_trader
go                                                                                               

	 sp_recompile "dbo.hts_trader_security"
go
update statistics dbo.hts_trader_security
go                                                                             

	 sp_recompile "dbo.hts_trigger_status"
go
update statistics dbo.hts_trigger_status
go                                                                               

	 sp_recompile "dbo.hts_tvol_detail"
go
update statistics dbo.hts_tvol_detail
go                                                                                     

	 sp_recompile "dbo.hts_tvol_list"
go
update statistics dbo.hts_tvol_list
go                                                                                         

	 sp_recompile "dbo.hts_underlying"
go
update statistics dbo.hts_underlying
go                                                                                       

	 sp_recompile "dbo.hts_user_rt_default"
go
update statistics dbo.hts_user_rt_default
go                                                                             

	 sp_recompile "dbo.hts_users"
go
update statistics dbo.hts_users
go                                                                                                 

	 sp_recompile "dbo.hts_var_cross_ref"
go
update statistics dbo.hts_var_cross_ref
go                                                                                 

	 sp_recompile "dbo.hts_volatility_detail"
go
update statistics dbo.hts_volatility_detail
go                                                                         

	 sp_recompile "dbo.hts_volatility_list"
go
update statistics dbo.hts_volatility_list
go                                                                             

	 sp_recompile "dbo.hts_xact_history"
go
update statistics dbo.hts_xact_history
go                                                                                   

	 sp_recompile "dbo.hts_xlateRIC"
go
update statistics dbo.hts_xlateRIC
go                                                                                           

	 sp_recompile "dbo.hts_xrate_detail"
go
update statistics dbo.hts_xrate_detail
go                                                                                   

	 sp_recompile "dbo.hts_xrate_list"
go
update statistics dbo.hts_xrate_list
go                                                                                       

	 sp_recompile "dbo.hts_yc_alg_risk"
go
update statistics dbo.hts_yc_alg_risk
go                                                                                     

	 sp_recompile "dbo.hts_yc_curve"
go
update statistics dbo.hts_yc_curve
go                                                                                           

	 sp_recompile "dbo.hts_yc_hdg_instr"
go
update statistics dbo.hts_yc_hdg_instr
go                                                                                   

	 sp_recompile "dbo.hts_yc_hdg_strat"
go
update statistics dbo.hts_yc_hdg_strat
go                                                                                   

	 sp_recompile "dbo.hts_yc_link_data"
go
update statistics dbo.hts_yc_link_data
go                                                                                   

	 sp_recompile "dbo.hts_yc_mkt_instr"
go
update statistics dbo.hts_yc_mkt_instr
go                                                                                   

	 sp_recompile "dbo.hts_yc_mkt_instr_data"
go
update statistics dbo.hts_yc_mkt_instr_data
go                                                                         

	 sp_recompile "dbo.hts_yc_mkt_instr_hdr"
go
update statistics dbo.hts_yc_mkt_instr_hdr
go                                                                           

	 sp_recompile "dbo.hts_yc_model"
go
update statistics dbo.hts_yc_model
go                                                                                           

	 sp_recompile "dbo.hts_yc_risk_curve"
go
update statistics dbo.hts_yc_risk_curve
go                                                                                 

	 sp_recompile "dbo.hts_yc_risk_curves_view"
go
update statistics dbo.hts_yc_risk_curves_view
go                                                                     

	 sp_recompile "dbo.hts_yc_risk_data"
go
update statistics dbo.hts_yc_risk_data
go                                                                                   

	 sp_recompile "dbo.hts_yc_risk_scenar_view"
go
update statistics dbo.hts_yc_risk_scenar_view
go                                                                     

	 sp_recompile "dbo.hts_yc_risk_scenario"
go
update statistics dbo.hts_yc_risk_scenario
go                                                                           

	 sp_recompile "dbo.hts_yc_scenario"
go
update statistics dbo.hts_yc_scenario
go                                                                                     

	 sp_recompile "dbo.hts_yc_sp"
go
update statistics dbo.hts_yc_sp
go                                                                                                 

	 sp_recompile "dbo.hts_yc_sp_hdr"
go
update statistics dbo.hts_yc_sp_hdr
go                                                                                         

	 sp_recompile "dbo.hts_yc_strip"
go
update statistics dbo.hts_yc_strip
go                                                                                           

	 sp_recompile "dbo.hts_yc_swap_spec"
go
update statistics dbo.hts_yc_swap_spec
go                                                                                   

	 sp_recompile "dbo.hts_yield_detail"
go
update statistics dbo.hts_yield_detail
go                                                                                   

	 sp_recompile "dbo.hts_yield_list"
go
update statistics dbo.hts_yield_list
go                                                                                       

	 sp_recompile "dbo.reconnect_dividends"
go
update statistics dbo.reconnect_dividends
go                                                                             

	 sp_recompile "dbo.rs_lastcommit"
go
update statistics dbo.rs_lastcommit
go                                                                                         

	 sp_recompile "dbo.rs_threads"
go
update statistics dbo.rs_threads
go                                                                                               

	 sp_recompile "dbo.user_location"
go
update statistics dbo.user_location
go                                                                                         

	 sp_recompile "dbo.world_clock"
go
update statistics dbo.world_clock
go                                                                                             
