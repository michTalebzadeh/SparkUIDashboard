 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FACILITY									   VARCHAR2(24)
 SEVERITY									   VARCHAR2(13)
 DEST_ID									   NUMBER
 MESSAGE_NUM									   NUMBER
 ERROR_CODE									   NUMBER
 CALLOUT									   VARCHAR2(3)
 TIMESTAMP									   DATE
 MESSAGE									   VARCHAR2(256)

