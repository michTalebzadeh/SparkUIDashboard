SELECT dbms_result_cache.status() FROM dual;
-- exec dbms_result_cache.flush()
set autotrace traceonly
set timing on
select
        /*+ RESULT_CACHE */
        cust_id "Customer ID",
count(amount_sold) "Number of orders",
sum(amount_sold) "Total customer's amount",
avg(amount_sold) "Average order",
stddev(amount_sold) "Standard deviation"
from ssdtester.sales
group by cust_id
having sum(amount_sold) > 94000
and avg(amount_sold) < stddev(amount_sold)
order by 3 desc;
set timing off
set autotrace off
--select * from v$result_cache_statistics;
--select * from v$result_cache_memory;
--select * from v$result_cache_objects;
SELECT substr(name,1,40) AS name
    ,      substr(type,1,30) AS type
    ,      substr(cache_id,1,40) as CACHED_ID
    ,      row_count
    FROM   v$result_cache_objects
    ORDER  BY
           creation_timestamp;
exit
