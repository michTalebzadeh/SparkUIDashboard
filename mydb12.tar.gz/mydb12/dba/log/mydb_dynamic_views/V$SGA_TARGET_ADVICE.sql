 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SGA_SIZE									   NUMBER
 SGA_SIZE_FACTOR								   NUMBER
 ESTD_DB_TIME									   NUMBER
 ESTD_DB_TIME_FACTOR								   NUMBER
 ESTD_PHYSICAL_READS								   NUMBER

