sp_addlogin "baxtma","majeka","its_ged_prod"
go
sp_addlogin "buscel","majeka","its_ged_prod"
go
sp_addlogin "codydi","majeka","its_ged_prod"
go
sp_addlogin "djamra","majeka","its_ged_prod"
go
sp_addlogin "failju","majeka","its_ged_prod"
go
sp_addlogin "frieth","majeka","its_ged_prod"
go
sp_addlogin "haenur","majeka","its_ged_prod"
go
sp_addlogin "jarkha","majeka","its_ged_prod"
go
sp_addlogin "jungna","majeka","its_ged_prod"
go
sp_addlogin "kleeri","majeka","its_ged_prod"
go
sp_addlogin "krolni","majeka","its_ged_prod"
go
sp_addlogin "neuban","majeka","its_ged_prod"
go
sp_addlogin "rangel","majeka","its_ged_prod"
go
sp_addlogin "schwkl","majeka","its_ged_prod"
go
sp_addlogin "sormme","majeka","its_ged_prod"
go
sp_addlogin "striro","majeka","its_ged_prod"
go
sp_addlogin "uzunan","majeka","its_ged_prod"
go
