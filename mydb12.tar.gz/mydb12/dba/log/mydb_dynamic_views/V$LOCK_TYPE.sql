 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 TYPE										   VARCHAR2(64)
 NAME										   VARCHAR2(64)
 ID1_TAG									   VARCHAR2(64)
 ID2_TAG									   VARCHAR2(64)
 IS_USER									   VARCHAR2(3)
 DESCRIPTION									   VARCHAR2(4000)

