 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 GROUP_NUMBER									   NUMBER
 INSTANCE_NAME									   VARCHAR2(64)
 DB_NAME									   VARCHAR2(8)
 STATUS 									   VARCHAR2(12)
 SOFTWARE_VERSION								   VARCHAR2(60)
 COMPATIBLE_VERSION								   VARCHAR2(60)

