alter system flush buffer_cache;
alter system flush shared_pool;
--ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_t1_tester';
--EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
DECLARE
        TYPE array IS TABLE OF tdash%ROWTYPE INDEX BY BINARY_INTEGER;
        l_data array;
BEGIN
        SELECT
		*
        BULK COLLECT INTO
        l_data
	FROM tdash
	WHERE ROWNUM <= 350000;

	DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT();
        FOR rs IN 1 .. l_data.COUNT
        LOOP
              BEGIN
			INSERT INTO testwrites VALUES l_data(rs);
              EXCEPTION
                WHEN NO_DATA_FOUND THEN NULL;
              END;
	END LOOP;
	COMMIT;
	DBMS_WORKLOAD_REPOSITORY.CREATE_SNAPSHOT();
END;
/
exit
