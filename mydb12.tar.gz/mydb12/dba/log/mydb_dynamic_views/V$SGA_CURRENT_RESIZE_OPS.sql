 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 COMPONENT									   VARCHAR2(64)
 OPER_TYPE									   VARCHAR2(13)
 OPER_MODE									   VARCHAR2(9)
 PARAMETER									   VARCHAR2(80)
 INITIAL_SIZE									   NUMBER
 TARGET_SIZE									   NUMBER
 CURRENT_SIZE									   NUMBER
 START_TIME									   DATE
 LAST_UPDATE_TIME								   DATE

