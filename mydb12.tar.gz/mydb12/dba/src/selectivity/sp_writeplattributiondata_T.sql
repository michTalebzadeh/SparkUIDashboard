--------------------------------------------------------
--  Mich Talebzadeh Enhancements August 2013
--------------------------------------------------------
SET define off;

  CREATE OR REPLACE PROCEDURE sp_writeplattributiondata_T
(
	p_RetCode   out number,
	p_RetString out varchar2
)
IS
	--  Declared variables for logging information
	g_log_id	drd_log.log_id%type;
	v_proc_name	drd_log.procedure_name%TYPE := 'sp_writeplattributiondata';
	v_begin_time	TIMESTAMP(6) WITH TIME ZONE := systimestamp;
	v_params	varchar2(4000);


	--
	--  Data provider procedure to copy PL attribution data from temporary staging table (pl_attribution_temp)
	--  to permanent table (pl_attribution).
	--
	-- get the latest version for a book, cobdate, source system, record type
        -- Parametarised cursoe definition here
	CURSOR c_CheckVersion
	(
	   i_Book           in varchar2,
	   i_CobDate        in date,
	   i_SourceSystem   in varchar2,
	   i_LoadRecordType in varchar2
	)
        IS
	   --
	   SELECT version
	   FROM load_detail lde
	   WHERE lde.cob_date = i_CobDate
	   AND   lde.main_book = i_Book
	   AND   lde.source_system = i_SourceSystem
	   AND   lde.load_record_type = i_LoadRecordType
	   AND   lde.load_detail_id = (
					 SELECT MAX(lde2.load_detail_id)
					 FROM load_detail lde2
					 WHERE lde2.cob_date = i_CobDate
					 AND   lde2.main_book = i_Book
					 AND   lde2.source_system = i_SourceSystem
					 AND   lde2.load_record_type = i_LoadRecordType
				      );
	--
	r_CheckVersion            c_CheckVersion%rowtype;
	--
	nRecordCount              number;
	nLoadDetailId             number;
	--
	-- Copy PL attribution data
	PROCEDURE lp_LoadPLAttributionDetails
	IS
		--
		-- cursor to get details of all books to process from the temp table
		CURSOR c_GetLoadDetails 
                IS
		   SELECT DISTINCT
		       main_book,
		       cob_date,
		       source_system
		   FROM plattr_header_temp;
		--
		r_GetLoadDetails          c_GetLoadDetails%rowtype;
		--
		nVersion                  load_detail.version%type;
		--
	BEGIN
		-- Re-Initializing null for global variable
		v_params :=null;

		--
		-- populate the tables for each book and cob_date
		FOR r_GetLoadDetails IN c_GetLoadDetails
		LOOP

			-- commented above code and added below statement to overwrite v_params variable instead of concatenating
			-- This will resolve the issue of numeric or value error when provider loads lot of main book (>30) in single upload file

			v_params	:= ' main_book=' || r_GetLoadDetails.main_book|| ' cob_date=' || r_GetLoadDetails.cob_date||
					   ' source_system=' || r_GetLoadDetails.source_system|| ' p_LoadRecordType=' || pk_global.cPLAnalyserRecordType;

			-- check version
			OPEN c_CheckVersion
			(
			i_Book           => r_GetLoadDetails.main_book,
			i_CobDate        => r_GetLoadDetails.cob_date,
			i_SourceSystem   => r_GetLoadDetails.source_system,
			i_LoadRecordType => pk_global.cPLAttrStrategicRecType
			);
			--
			-- if first version for book and COB date, assign version 0

			FETCH c_CheckVersion INTO r_CheckVersion;
			IF c_CheckVersion%notfound THEN
			nVersion := pk_global.cInitialVersion;
			ELSE
			nVersion := r_CheckVersion.version + 1;
			END IF;

			--  additional parameter details for debug purpose
			v_params	:= v_params || ' nVersion=' || nVersion;

			CLOSE c_CheckVersion;
			--
			SELECT load_detail_id_seq.NEXTVAL
			INTO nLoadDetailId
			FROM dual;

			--  additional parameter details for debug purpose
			v_params	:= v_params || ' nLoadDetailId=' || nLoadDetailId;

			-- Logging a record for Start of local procedure to load PLAttribution data - lp_LoadPLAttributionDetails
			g_log_id := pk_log.info
				   (
					  p_log_description => 'INFO',
					  p_procedure_name  => v_proc_name,
					  p_log_details     => pk_util.elapsed_time(v_begin_time, systimestamp),
					  p_additional_info => 'Start of local procedure to load PLAttribution data - lp_LoadPLAttributionDetails',
					  p_parameters      => v_params
				   );

			-- (Start)

			INSERT INTO load_detail
			(
				load_detail_id,
				load_record_type,
				main_book,
				cob_date,
				source_system,
				valuation_type,
				load_start_time,
				load_end_time,
				version
			)
			VALUES
			(
				nLoadDetailId,
				pk_global.cPLAttrStrategicRecType,
				r_GetLoadDetails.main_book,
				r_GetLoadDetails.cob_date,
				r_GetLoadDetails.source_system,
				null,   -- valuation_type
				systimestamp,  -- load_start_time
				null,  -- load_end_time
				nVersion  -- version
			);

      UPDATE plattr_header_temp
      SET plattr_header_id = plattr_header_id_seq.NEXTVAL;
			--
			-- populate details for pl attribution
      INSERT into plattr_header_ov
        (plattr_header_id,
         load_detail_id,
         main_book,
         sub_book,
         version,
         latest_version_flag,
         source_system,
         cob_date,
         tcn,
         ref,
         tcnversion,
         plattr_hdr_attr)
        SELECT plattr_header_id,
               nLoadDetailId,
               main_book,
               sub_book,
               nVersion,
               'Y',
               source_system,
               cob_date,
               tcn,
               ref,
               tcnversion,
               plattr_hdr_attr
          FROM plattr_header_temp_ov
         WHERE main_book = r_GetLoadDetails.main_book
           AND cob_date = r_GetLoadDetails.cob_date;

      -- keep a count of Trade records only
		     nRecordCount := sql%rowcount;

      -- Delete null and 0 value records from temp Detail table
      DELETE from plattr_details_temp det
      WHERE ctgy_value is null or ctgy_value = 0;

      -- Logging a record for End of local procedure to load PLAttribution data - lp_LoadPLAttributionDetails
		g_log_id := pk_log.info
			   (
				  p_log_description => 'INFO',
				  p_procedure_name  => v_proc_name,
				  p_log_details     => pk_util.elapsed_time(v_begin_time, systimestamp),
				  p_additional_info => 'Deleted Null and 0 Records:' || sql%rowcount,
				  p_parameters      => v_params
			   );

      INSERT into plattr_details
        (plattr_detail_id,
         plattr_header_id,
         load_detail_id,
         cob_date,
         ref,
         ctgy_label,
         ctgy_ccy,
         ctgy_value)
        SELECT plattr_detail_id_seq.NEXTVAL,
               hdr.plattr_header_id,
               nLoadDetailId,
               det.cob_date,
               det.ref,
               det.ctgy_label,
               det.ctgy_ccy,
               det.ctgy_value
         FROM plattr_details_temp det
         JOIN plattr_header_temp hdr
          ON    (hdr.main_book = det.main_book
                 and hdr.cob_date = det.cob_date
                 and hdr.sub_book = det.sub_book
                 and  hdr.ref = det.ref)
         WHERE det.main_book = r_GetLoadDetails.main_book
           AND det.cob_date = r_GetLoadDetails.cob_date;

		--
		-- UPDATE load_detail with record count

    UPDATE load_detail
       SET number_of_records = nRecordCount, load_end_time = systimestamp
     WHERE load_detail_id = nLoadDetailId;
		--
		-- SET the latest version flag to 'N' for all versions other than the latest
    UPDATE plattr_header
       SET latest_version_flag = 'N'
     WHERE main_book = r_GetLoadDetails.main_book
       AND cob_date = r_GetLoadDetails.cob_date
       AND version != nVersion;

		-- Logging a record for End of local procedure to load PLAttribution data - lp_LoadPLAttributionDetails
		g_log_id := pk_log.info
			   (
				  p_log_description => 'INFO',
				  p_procedure_name  => v_proc_name,
				  p_log_details     => pk_util.elapsed_time(v_begin_time, systimestamp),
				  p_additional_info => 'End of local procedure to load PLAttribution data - lp_LoadPLAttributionDetails',
				  p_parameters      => v_params
			   );

		--
		COMMIT;
		--


	END LOOP;
	--

	EXCEPTION
		WHEN OTHERS THEN
			--  Capturing sql code and error message
			p_RetCode := SQLCODE;
			p_RetString := SUBSTR(SQLERRM, 1, 255);

			-- Rollback for Recursive sub procedure call
			-- if we rollback in case of unique constraint error then it will clear temp table also so do rollback only other than unique constraint
			IF p_RetString NOT LIKE 'ORA-00001%' THEN
				ROLLBACK;
			END IF;

			--  Logging a record for End of local procedure with Error
			g_log_id := pk_log.error
				   (
					  p_log_description => 'ERROR',
					  p_package_name    => NULL,
					  p_procedure_name  => v_proc_name,
					  p_log_details     => p_RetString,
					  p_log_code        => p_RetCode,
					  p_additional_info => 'End of local procedure to load PLAttribution data - lp_LoadPLAttributionDetails',
					  p_parameters      => v_params
				   );

	END lp_LoadPLAttributionDetails;

	--
	-- Remove all records from pl_attribution_temp table
	PROCEDURE lp_ClearTempTable
	IS
	--
	BEGIN
		--  Re-Initializing null for global variable
		v_params :=null;

		--  Logging a record for Start of local procedure to Clear temporary table - lp_ClearTempTable
		g_log_id := pk_log.info
			   (
				  p_log_description => 'INFO',
				  p_procedure_name  => v_proc_name,
				  p_log_details     => pk_util.elapsed_time(v_begin_time, systimestamp),
				  p_additional_info => 'Start of local procedure to Clear temporary table - lp_ClearTempTable',
				  p_parameters      => v_params
			   );

		--
    DELETE FROM plattr_header_temp;
    DELETE FROM plattr_details_temp;
		--

		--  Logging a record for End of local procedure to Clear temporary table - lp_ClearTempTable
		g_log_id := pk_log.info
			   (
				  p_log_description => 'INFO',
				  p_procedure_name  => v_proc_name,
				  p_log_details     => pk_util.elapsed_time(v_begin_time, systimestamp),
				  p_additional_info => 'End of local procedure to Clear temporary table - lp_ClearTempTable',
				  p_parameters      => v_params
			   );

	EXCEPTION
		WHEN OTHERS THEN
			--  Capturing sql code and error message
			p_RetCode := SQLCODE;
			p_RetString := SUBSTR(SQLERRM, 1, 255);

			--  Logging a record for End of local procedure to Clear temporary table - lp_ClearTempTable with Error
			g_log_id := pk_log.error
				   (
					  p_log_description => 'ERROR',
					  p_package_name    => NULL,
					  p_procedure_name  => v_proc_name,
					  p_log_details     => p_RetString,
					  p_log_code        => p_RetCode,
					  p_additional_info => 'End of local procedure to Clear temporary table - lp_ClearTempTable',
					  p_parameters      => v_params
				   );

	END lp_ClearTempTable;
	--

----------------
-- Main body of procedure here
----------------
BEGIN
	--  Initializing null since no parameters in main procedure
	v_params :=null;

	--  Logging a record for start of main procedure
	g_log_id := pk_log.info
		   (
			  p_log_description => 'INFO',
			  p_procedure_name  => v_proc_name,
			  p_log_details     => pk_util.elapsed_time(v_begin_time, systimestamp),
			  p_additional_info => 'Start of Main procedure - sp_writeplattributiondata',
			  p_parameters      => v_params
		   );


	--
	p_RetCode := 0;
	--

	--  Calling lp_LoadPLAttributionDetails procedure recursively  until success to load PLAttribution or error

	LOOP
		-- Re-Initializing variables
		p_RetCode := 0;
		p_RetString := NULL;

		lp_LoadPLAttributionDetails;

		IF p_RetString IS NULL OR  p_RetString NOT LIKE 'ORA-00001%' THEN
			EXIT;
		END IF;
	END LOOP;

	-- clear temporary table
	lp_ClearTempTable;
	--
	commit;
	--

	-- Logging a record for End of main procedure
	g_log_id := pk_log.info
		   (
			  p_log_description => 'INFO',
			  p_procedure_name  => v_proc_name,
			  p_log_details     => pk_util.elapsed_time(v_begin_time, systimestamp),
			  p_additional_info => 'End of Main procedure - sp_writeplattributiondata',
			  p_parameters      => v_params
		   );

EXCEPTION
	when others then
		-- Capturing sql code and error message
		p_RetCode := SQLCODE;
		p_RetString := SUBSTR(SQLERRM, 1, 255);
		--
		rollback;

		-- Logging a record for End of local procedure with Error
		g_log_id := pk_log.error
			   (
				  p_log_description => 'ERROR',
				  p_package_name    => NULL,
				  p_procedure_name  => v_proc_name,
				  p_log_details     => p_RetString,
				  p_log_code        => p_RetCode,
				  p_additional_info => 'End of Main procedure - sp_writeplattributiondata',
				  p_parameters      => v_params
			   );

END sp_writeplattributiondata_T;
/
