 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ALGORITHM_NAME 								   VARCHAR2(64)
 INITIAL_RELEASE								   VARCHAR2(18)
 TERMINAL_RELEASE								   VARCHAR2(18)
 ALGORITHM_DESCRIPTION								   VARCHAR2(64)
 ALGORITHM_COMPATIBILITY							   VARCHAR2(18)
 IS_VALID									   VARCHAR2(3)
 REQUIRES_ACO									   VARCHAR2(3)

