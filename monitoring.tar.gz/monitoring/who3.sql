colum background format a10 heading background
select p.spid , p.pid, substr(p.username,1,20) "os username", s.sid, s.serial#, substr(s.username,1,20) "Login", p.background
from v$process p, v$session s
where s.paddr = p.addr
/
exit
