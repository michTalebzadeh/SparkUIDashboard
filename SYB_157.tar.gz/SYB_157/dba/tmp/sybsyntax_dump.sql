use master
go
set nocount on
go
checkpoint
go
declare @msg char(100), @errorno int
dump tran sybsyntax with truncate_only
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Thu Mar 22 00:59:04 GMT 2001 db_dump_adsm.ksh Dump of sybsyntax log failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go
declare @msg char(100), @errorno int
dump database sybsyntax to "/apps/sybase/dump/lon_gedimg_sql_prd/sybsyntax.dmp.stripe1"
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Thu Mar 22 00:59:04 GMT 2001 db_dump_adsm.ksh Dump of sybsyntax failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go

