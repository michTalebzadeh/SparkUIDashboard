 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 DB_LINK									   VARCHAR2(128)
 OWNER_ID									   NUMBER
 LOGGED_ON									   VARCHAR2(3)
 HETEROGENEOUS									   VARCHAR2(3)
 PROTOCOL									   VARCHAR2(6)
 OPEN_CURSORS									   NUMBER
 IN_TRANSACTION 								   VARCHAR2(3)
 UPDATE_SENT									   VARCHAR2(3)
 COMMIT_POINT_STRENGTH								   NUMBER

