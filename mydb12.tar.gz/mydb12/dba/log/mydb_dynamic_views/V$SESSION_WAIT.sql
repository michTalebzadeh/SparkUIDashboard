 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 SEQ#										   NUMBER
 EVENT										   VARCHAR2(64)
 P1TEXT 									   VARCHAR2(64)
 P1										   NUMBER
 P1RAW										   RAW(8)
 P2TEXT 									   VARCHAR2(64)
 P2										   NUMBER
 P2RAW										   RAW(8)
 P3TEXT 									   VARCHAR2(64)
 P3										   NUMBER
 P3RAW										   RAW(8)
 WAIT_CLASS_ID									   NUMBER
 WAIT_CLASS#									   NUMBER
 WAIT_CLASS									   VARCHAR2(64)
 WAIT_TIME									   NUMBER
 SECONDS_IN_WAIT								   NUMBER
 STATE										   VARCHAR2(19)
 WAIT_TIME_MICRO								   NUMBER
 TIME_REMAINING_MICRO								   NUMBER
 TIME_SINCE_LAST_WAIT_MICRO							   NUMBER

