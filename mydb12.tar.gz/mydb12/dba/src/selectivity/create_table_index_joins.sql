execute dbms_random.seed(0)
DROP TABLE index_joins;
CREATE TABLE index_joins AS
SELECT
  ROWNUM AS c1,
  (ROWNUM + trunc(dbms_random.value(0,1000))) AS c2,
  LPAD('A',255,'A') AS c3
FROM
  DUAL
CONNECT BY
  LEVEL<=10000;
CREATE UNIQUE INDEX ind_c1 ON index_joins(c1);
CREATE INDEX ind_c2 on index_joins(c2);
EXEC DBMS_STATS.GATHER_TABLE_STATS(OWNNAME=>USER,TABNAME=>'INDEX_JOINS',CASCADE=>TRUE) 
--select * from index_joins;
exit
