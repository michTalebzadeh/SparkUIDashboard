--set autotrace traceonly
alter system flush buffer_cache;
set autotrace on
set timing on
select 
	cust_id "Customer ID",
count(amount_sold) "Number of orders",
sum(amount_sold) "Total customer's amount",
avg(amount_sold) "Average order",
case
	when  count (amount_sold) <= 1
  	  then  0
	else  sqrt ( ( sum (amount_sold * amount_sold)
	  	      	     - (count (amount_sold) * avg (amount_sold) * avg (amount_sold))
		 	     )
	       		   / (count (amount_sold) - 1)
			   )
	  end			as "Standard deviation"
from sales
group by cust_id
having sum(amount_sold) > 94000
and avg(amount_sold) < CASE
                         when  count (amount_sold) <= 1
                           then  0
                         else  sqrt ( ( sum (amount_sold * amount_sold)
                                             - (count (amount_sold) * avg (amount_sold) * avg (amount_sold))
                                             )
                                             / (count (amount_sold) - 1)
                                             )
                                end
order by 3 desc;
exit
