/********************************************/
/*------------ temp2 -------------*/
/********************************************/
select 'Started creating temp2 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE SMALLFILE TEMPORARY TABLESPACE "TEMP2" TEMPFILE '/ssddata5/oracle/mydb12/oradata/MYDB12/datafile/temp201.dbf' SIZE 1000M EXTENT MANAGEMENT LOCAL UNIFORM SIZE 1024K;
select 'Finished  creating temp2 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
