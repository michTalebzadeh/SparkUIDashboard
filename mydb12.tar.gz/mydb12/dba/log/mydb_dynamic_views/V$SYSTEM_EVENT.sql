 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 EVENT										   VARCHAR2(64)
 TOTAL_WAITS									   NUMBER
 TOTAL_TIMEOUTS 								   NUMBER
 TIME_WAITED									   NUMBER
 AVERAGE_WAIT									   NUMBER
 TIME_WAITED_MICRO								   NUMBER
 TOTAL_WAITS_FG 								   NUMBER
 TOTAL_TIMEOUTS_FG								   NUMBER
 TIME_WAITED_FG 								   NUMBER
 AVERAGE_WAIT_FG								   NUMBER
 TIME_WAITED_MICRO_FG								   NUMBER
 EVENT_ID									   NUMBER
 WAIT_CLASS_ID									   NUMBER
 WAIT_CLASS#									   NUMBER
 WAIT_CLASS									   VARCHAR2(64)

