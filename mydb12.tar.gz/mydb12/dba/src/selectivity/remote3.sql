ALTER SESSION SET TRACEFILE_IDENTIFIER = 'remote3';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
select OBJECT_ID from syb_testwrites where OBJECT_TYPE = 'XML SCHEMA' order by OBJECT_ID
/
exit
