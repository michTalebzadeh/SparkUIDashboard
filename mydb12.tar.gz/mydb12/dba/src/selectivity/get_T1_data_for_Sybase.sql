--
set echo off        -- suppress showing sql in result set
set feedback off    -- eliminate row count message
set linesize 100    -- make line long enough to hold data
set pagesize 0      -- suppress headings and page breaks
set sqlprompt ''    -- eliminate SQL*Plus prompt from output
--                     other useful parameters
set trimspool on    -- eliminate trailing blanks
spool t1.bcp

SELECT n1 || CHR(9) ||ind_pad|| CHR(9) || n2|| CHR(9)|| small_vc || CHR(9)|| padding
FROM t1;
spool off
exit
