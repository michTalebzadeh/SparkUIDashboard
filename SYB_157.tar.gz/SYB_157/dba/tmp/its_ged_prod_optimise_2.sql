                     
 ------------------- 
 use its_ged_prod
go 
                                                                                                                                                                          
 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ 
 sp_recompile "dbo.dbGED_database_booker_tb"
go
update index statistics dbo.dbGED_database_booker_tb
go                                                                   
 sp_recompile "dbo.dbGED_supportrequest_tb"
go
update index statistics dbo.dbGED_supportrequest_tb
go                                                                     
 sp_recompile "dbo.dbGED_usereq_acctconf_tb"
go
update index statistics dbo.dbGED_usereq_acctconf_tb
go                                                                   
 sp_recompile "dbo.dbGED_usereq_accttype_tb"
go
update index statistics dbo.dbGED_usereq_accttype_tb
go                                                                   
 sp_recompile "dbo.dbGED_usereq_bizarea_tb"
go
update index statistics dbo.dbGED_usereq_bizarea_tb
go                                                                     
 sp_recompile "dbo.dbGED_usereq_confdef_tb"
go
update index statistics dbo.dbGED_usereq_confdef_tb
go                                                                     
 sp_recompile "dbo.dbGED_usereq_groups_tb"
go
update index statistics dbo.dbGED_usereq_groups_tb
go                                                                       
 sp_recompile "dbo.dbGED_usereq_location_tb"
go
update index statistics dbo.dbGED_usereq_location_tb
go                                                                   
 sp_recompile "dbo.dbGED_usereq_new_tb"
go
update index statistics dbo.dbGED_usereq_new_tb
go                                                                             
 sp_recompile "dbo.dbGED_usereq_super_tb"
go
update index statistics dbo.dbGED_usereq_super_tb
go                                                                         
 sp_recompile "dbo.dbGED_userrequest_acctconf_tb"
go
update index statistics dbo.dbGED_userrequest_acctconf_tb
go                                                         
 sp_recompile "dbo.dbGED_userrequest_accttype_tb"
go
update index statistics dbo.dbGED_userrequest_accttype_tb
go                                                         
 sp_recompile "dbo.dbGED_userrequest_bizarea_tb"
go
update index statistics dbo.dbGED_userrequest_bizarea_tb
go                                                           
 sp_recompile "dbo.dbGED_userrequest_confdef_tb"
go
update index statistics dbo.dbGED_userrequest_confdef_tb
go                                                           
 sp_recompile "dbo.dbGED_userrequest_groups_tb"
go
update index statistics dbo.dbGED_userrequest_groups_tb
go                                                             
 sp_recompile "dbo.dbGED_userrequest_location_tb"
go
update index statistics dbo.dbGED_userrequest_location_tb
go                                                         
 sp_recompile "dbo.dbGED_userrequest_new_tb"
go
update index statistics dbo.dbGED_userrequest_new_tb
go                                                                   
 sp_recompile "dbo.dbGED_userrequest_super_tb"
go
update index statistics dbo.dbGED_userrequest_super_tb
go                                                               
 sp_recompile "dbo.dbGED_userrequest_tb"
go
update index statistics dbo.dbGED_userrequest_tb
go                                                                           
 sp_recompile "dbo.dbStageDividend"
go
update index statistics dbo.dbStageDividend
go                                                                                     
 sp_recompile "dbo.dbStageDividend_Old"
go
update index statistics dbo.dbStageDividend_Old
go                                                                             
 sp_recompile "dbo.dbStageRicRef"
go
update index statistics dbo.dbStageRicRef
go                                                                                         
 sp_recompile "dbo.dbStageStock"
go
update index statistics dbo.dbStageStock
go                                                                                           
 sp_recompile "dbo.dbStageStock_Old"
go
update index statistics dbo.dbStageStock_Old
go                                                                                   
 sp_recompile "dbo.dbStar_Input"
go
update index statistics dbo.dbStar_Input
go                                                                                           
 sp_recompile "dbo.dbStar_Input1"
go
update index statistics dbo.dbStar_Input1
go                                                                                         
 sp_recompile "dbo.dbStar_Input_arch"
go
update index statistics dbo.dbStar_Input_arch
go                                                                                 
 sp_recompile "dbo.db_EOD_blotter_extra"
go
update index statistics dbo.db_EOD_blotter_extra
go                                                                           
 sp_recompile "dbo.db_EOD_blotter_sec_data"
go
update index statistics dbo.db_EOD_blotter_sec_data
go                                                                     
 sp_recompile "dbo.db_EOD_blotter_signoff"
go
update index statistics dbo.db_EOD_blotter_signoff
go                                                                       
 sp_recompile "dbo.db_EOD_blotter_status"
go
update index statistics dbo.db_EOD_blotter_status
go                                                                         
 sp_recompile "dbo.db_EOD_blotter_trades"
go
update index statistics dbo.db_EOD_blotter_trades
go                                                                         
 sp_recompile "dbo.db_alternate_code"
go
update index statistics dbo.db_alternate_code
go                                                                                 
 sp_recompile "dbo.db_asian_history"
go
update index statistics dbo.db_asian_history
go                                                                                   
 sp_recompile "dbo.db_average_trade_detail"
go
update index statistics dbo.db_average_trade_detail
go                                                                     
 sp_recompile "dbo.db_average_trade_err"
go
update index statistics dbo.db_average_trade_err
go                                                                           
 sp_recompile "dbo.db_average_trade_list"
go
update index statistics dbo.db_average_trade_list
go                                                                         
 sp_recompile "dbo.db_average_trade_xref"
go
update index statistics dbo.db_average_trade_xref
go                                                                         
 sp_recompile "dbo.db_column_defaults"
go
update index statistics dbo.db_column_defaults
go                                                                               
 sp_recompile "dbo.db_div_tax_rules"
go
update index statistics dbo.db_div_tax_rules
go                                                                                   
 sp_recompile "dbo.db_error_message"
go
update index statistics dbo.db_error_message
go                                                                                   
 sp_recompile "dbo.db_eurex_defaults"
go
update index statistics dbo.db_eurex_defaults
go                                                                                 
 sp_recompile "dbo.db_eurex_xetra_ar_products"
go
update index statistics dbo.db_eurex_xetra_ar_products
go                                                               
 sp_recompile "dbo.db_eurex_xetra_auto_routing"
go
update index statistics dbo.db_eurex_xetra_auto_routing
go                                                             
 sp_recompile "dbo.db_eurex_xetra_trades"
go
update index statistics dbo.db_eurex_xetra_trades
go                                                                         
 sp_recompile "dbo.db_eurex_xetra_trades_archive"
go
update index statistics dbo.db_eurex_xetra_trades_archive
go                                                         
 sp_recompile "dbo.db_feed_gl_average"
go
update index statistics dbo.db_feed_gl_average
go                                                                               
 sp_recompile "dbo.db_imagine_user_dealer_map"
go
update index statistics dbo.db_imagine_user_dealer_map
go                                                               
 sp_recompile "dbo.db_index_vol_to_delete"
go
update index statistics dbo.db_index_vol_to_delete
go                                                                       
 sp_recompile "dbo.db_instr_matching_rule"
go
update index statistics dbo.db_instr_matching_rule
go                                                                       
 sp_recompile "dbo.db_instr_rule_def"
go
update index statistics dbo.db_instr_rule_def
go                                                                                 
 sp_recompile "dbo.db_instr_rule_parameters"
go
update index statistics dbo.db_instr_rule_parameters
go                                                                   
 sp_recompile "dbo.db_instr_server_classes"
go
update index statistics dbo.db_instr_server_classes
go                                                                     
 sp_recompile "dbo.db_instr_valid_sec_cmb"
go
update index statistics dbo.db_instr_valid_sec_cmb
go                                                                       
 sp_recompile "dbo.db_last_message"
go
update index statistics dbo.db_last_message
go                                                                                     
 sp_recompile "dbo.db_mark_errors"
go
update index statistics dbo.db_mark_errors
go                                                                                       
 sp_recompile "dbo.db_month_end_dates"
go
update index statistics dbo.db_month_end_dates
go                                                                               
 sp_recompile "dbo.db_notification_detail"
go
update index statistics dbo.db_notification_detail
go                                                                       
 sp_recompile "dbo.db_orc_auto_routed_products"
go
update index statistics dbo.db_orc_auto_routed_products
go                                                             
 sp_recompile "dbo.db_orc_auto_routing"
go
update index statistics dbo.db_orc_auto_routing
go                                                                             
 sp_recompile "dbo.db_orc_exch_sett_date"
go
update index statistics dbo.db_orc_exch_sett_date
go                                                                         
 sp_recompile "dbo.db_orc_exchange"
go
update index statistics dbo.db_orc_exchange
go                                                                                     
 sp_recompile "dbo.db_orc_exec_id"
go
update index statistics dbo.db_orc_exec_id
go                                                                                       
 sp_recompile "dbo.db_orc_executions"
go
update index statistics dbo.db_orc_executions
go                                                                                 
 sp_recompile "dbo.db_orc_executions_hist"
go
update index statistics dbo.db_orc_executions_hist
go                                                                       
 sp_recompile "dbo.db_orc_heartbeat"
go
update index statistics dbo.db_orc_heartbeat
go                                                                                   
 sp_recompile "dbo.db_orc_imag_warrant_recon"
go
update index statistics dbo.db_orc_imag_warrant_recon
go                                                                 
 sp_recompile "dbo.db_orc_portfolio"
go
update index statistics dbo.db_orc_portfolio
go                                                                                   
 sp_recompile "dbo.db_orc_process_state"
go
update index statistics dbo.db_orc_process_state
go                                                                           
 sp_recompile "dbo.db_orc_sec_exchange"
go
update index statistics dbo.db_orc_sec_exchange
go                                                                             
 sp_recompile "dbo.db_orc_trade_id_map"
go
update index statistics dbo.db_orc_trade_id_map
go                                                                             
 sp_recompile "dbo.db_orc_trade_recon"
go
update index statistics dbo.db_orc_trade_recon
go                                                                               
 sp_recompile "dbo.db_orc_trader"
go
update index statistics dbo.db_orc_trader
go                                                                                         
 sp_recompile "dbo.db_orc_underlying"
go
update index statistics dbo.db_orc_underlying
go                                                                                 
 sp_recompile "dbo.db_orc_warrant_recon"
go
update index statistics dbo.db_orc_warrant_recon
go                                                                           
 sp_recompile "dbo.db_perm_audit"
go
update index statistics dbo.db_perm_audit
go                                                                                         
 sp_recompile "dbo.db_perm_business"
go
update index statistics dbo.db_perm_business
go                                                                                   
 sp_recompile "dbo.db_perm_role"
go
update index statistics dbo.db_perm_role
go                                                                                           
 sp_recompile "dbo.db_perm_special"
go
update index statistics dbo.db_perm_special
go                                                                                     
 sp_recompile "dbo.db_perm_users"
go
update index statistics dbo.db_perm_users
go                                                                                         
 sp_recompile "dbo.db_pre_volatility_detail"
go
update index statistics dbo.db_pre_volatility_detail
go                                                                   
 sp_recompile "dbo.db_pre_volatility_list"
go
update index statistics dbo.db_pre_volatility_list
go                                                                       
 sp_recompile "dbo.db_recon_position_log"
go
update index statistics dbo.db_recon_position_log
go                                                                         
 sp_recompile "dbo.db_recon_trade_log"
go
update index statistics dbo.db_recon_trade_log
go                                                                               
 sp_recompile "dbo.db_rolled_market_prices"
go
update index statistics dbo.db_rolled_market_prices
go                                                                     
 sp_recompile "dbo.db_script_parameters"
go
update index statistics dbo.db_script_parameters
go                                                                           
 sp_recompile "dbo.db_security_codes"
go
update index statistics dbo.db_security_codes
go                                                                                 
 sp_recompile "dbo.db_status_history"
go
update index statistics dbo.db_status_history
go                                                                                 
 sp_recompile "dbo.db_swx_trade_reporting"
go
update index statistics dbo.db_swx_trade_reporting
go                                                                       
 sp_recompile "dbo.db_temp_market_price"
go
update index statistics dbo.db_temp_market_price
go                                                                           
 sp_recompile "dbo.db_tickets"
go
update index statistics dbo.db_tickets
go                                                                                               
 sp_recompile "dbo.db_tickets_approval_options"
go
update index statistics dbo.db_tickets_approval_options
go                                                             
 sp_recompile "dbo.db_tickets_comments"
go
update index statistics dbo.db_tickets_comments
go                                                                             
 sp_recompile "dbo.db_tickets_exec_queue"
go
update index statistics dbo.db_tickets_exec_queue
go                                                                         
 sp_recompile "dbo.db_trader_permissions"
go
update index statistics dbo.db_trader_permissions
go                                                                         
 sp_recompile "dbo.db_trading_account"
go
update index statistics dbo.db_trading_account
go                                                                               
 sp_recompile "dbo.db_trading_book"
go
update index statistics dbo.db_trading_book
go                                                                                     
 sp_recompile "dbo.db_trading_desk"
go
update index statistics dbo.db_trading_desk
go                                                                                     
 sp_recompile "dbo.db_trading_view"
go
update index statistics dbo.db_trading_view
go                                                                                     
 sp_recompile "dbo.db_underlying_transfer"
go
update index statistics dbo.db_underlying_transfer
go                                                                       
 sp_recompile "dbo.db_valid_interface_users"
go
update index statistics dbo.db_valid_interface_users
go                                                                   
 sp_recompile "dbo.db_xetra_defaults"
go
update index statistics dbo.db_xetra_defaults
go                                                                                 
 sp_recompile "dbo.db_xol_master_list"
go
update index statistics dbo.db_xol_master_list
go                                                                               
 sp_recompile "dbo.db_xol_outgoing_ca"
go
update index statistics dbo.db_xol_outgoing_ca
go                                                                               
 sp_recompile "dbo.dba_check_rep_delay"
go
update index statistics dbo.dba_check_rep_delay
go                                                                             
 sp_recompile "dbo.dba_check_sko"
go
update index statistics dbo.dba_check_sko
go                                                                                         
 sp_recompile "dbo.dba_test"
go
update index statistics dbo.dba_test
go                                                                                                   
 sp_recompile "dbo.dba_test1"
go
update index statistics dbo.dba_test1
go                                                                                                 
 sp_recompile "dbo.dbs_COUNTER"
go
update index statistics dbo.dbs_COUNTER
go                                                                                             
 sp_recompile "dbo.dbt_kueu_file"
go
update index statistics dbo.dbt_kueu_file
go                                                                                         
 sp_recompile "dbo.dbt_sec_map"
go
update index statistics dbo.dbt_sec_map
go                                                                                             
 sp_recompile "dbo.dbt_sec_type_mapping"
go
update index statistics dbo.dbt_sec_type_mapping
go                                                                           
 sp_recompile "dbo.dbt_sec_xfce"
go
update index statistics dbo.dbt_sec_xfce
go                                                                                           
 sp_recompile "dbo.dbt_sequence"
go
update index statistics dbo.dbt_sequence
go                                                                                           
 sp_recompile "dbo.dbt_trade_target"
go
update index statistics dbo.dbt_trade_target
go                                                                                   
 sp_recompile "dbo.dbt_trade_target_temp"
go
update index statistics dbo.dbt_trade_target_temp
go                                                                         
 sp_recompile "dbo.dbt_trade_triggers"
go
update index statistics dbo.dbt_trade_triggers
go                                                                               
 sp_recompile "dbo.dbtrader_secm"
go
update index statistics dbo.dbtrader_secm
go                                                                                         
 sp_recompile "dbo.euro_rates"
go
update index statistics dbo.euro_rates
go                                                                                               
 sp_recompile "dbo.exec_queue_errors"
go
update index statistics dbo.exec_queue_errors
go                                                                                 
 sp_recompile "dbo.gedi_admin_status"
go
update index statistics dbo.gedi_admin_status
go                                                                                 
 sp_recompile "dbo.gepg_risk_portfolio"
go
update index statistics dbo.gepg_risk_portfolio
go                                                                             
 sp_recompile "dbo.hts_account"
go
update index statistics dbo.hts_account
go                                                                                             
 sp_recompile "dbo.hts_adjustment"
go
update index statistics dbo.hts_adjustment
go                                                                                       
 sp_recompile "dbo.hts_admin_control"
go
update index statistics dbo.hts_admin_control
go                                                                                 
 sp_recompile "dbo.hts_ae_codes"
go
update index statistics dbo.hts_ae_codes
go                                                                                           
 sp_recompile "dbo.hts_audit_status"
go
update index statistics dbo.hts_audit_status
go                                                                                   
 sp_recompile "dbo.hts_b2b_trade_event"
go
update index statistics dbo.hts_b2b_trade_event
go                                                                             
 sp_recompile "dbo.hts_ba_spread_class"
go
update index statistics dbo.hts_ba_spread_class
go                                                                             
 sp_recompile "dbo.hts_ba_spread_detail"
go
update index statistics dbo.hts_ba_spread_detail
go                                                                           
 sp_recompile "dbo.hts_ba_spread_list"
go
update index statistics dbo.hts_ba_spread_list
go                                                                               
 sp_recompile "dbo.hts_basis_detail"
go
update index statistics dbo.hts_basis_detail
go                                                                                   
 sp_recompile "dbo.hts_basis_list"
go
update index statistics dbo.hts_basis_list
go                                                                                       
 sp_recompile "dbo.hts_bo_event"
go
update index statistics dbo.hts_bo_event
go                                                                                           
 sp_recompile "dbo.hts_borrow_detail"
go
update index statistics dbo.hts_borrow_detail
go                                                                                 
 sp_recompile "dbo.hts_borrow_list"
go
update index statistics dbo.hts_borrow_list
go                                                                                     
 sp_recompile "dbo.hts_bs_codes"
go
update index statistics dbo.hts_bs_codes
go                                                                                           
 sp_recompile "dbo.hts_capreq_basket"
go
update index statistics dbo.hts_capreq_basket
go                                                                                 
 sp_recompile "dbo.hts_capreq_divisors"
go
update index statistics dbo.hts_capreq_divisors
go                                                                             
 sp_recompile "dbo.hts_capreq_overrides"
go
update index statistics dbo.hts_capreq_overrides
go                                                                           
 sp_recompile "dbo.hts_capreq_xref"
go
update index statistics dbo.hts_capreq_xref
go                                                                                     
 sp_recompile "dbo.hts_cash_coll_sched"
go
update index statistics dbo.hts_cash_coll_sched
go                                                                             
 sp_recompile "dbo.hts_ccy_round"
go
update index statistics dbo.hts_ccy_round
go                                                                                         
 sp_recompile "dbo.hts_charge_interval"
go
update index statistics dbo.hts_charge_interval
go                                                                             
 sp_recompile "dbo.hts_charge_rule"
go
update index statistics dbo.hts_charge_rule
go                                                                                     
 sp_recompile "dbo.hts_charge_sched_detail"
go
update index statistics dbo.hts_charge_sched_detail
go                                                                     
 sp_recompile "dbo.hts_charge_sched_list"
go
update index statistics dbo.hts_charge_sched_list
go                                                                         
 sp_recompile "dbo.hts_charge_schedule"
go
update index statistics dbo.hts_charge_schedule
go                                                                             
 sp_recompile "dbo.hts_charge_type"
go
update index statistics dbo.hts_charge_type
go                                                                                     
 sp_recompile "dbo.hts_coll_pool"
go
update index statistics dbo.hts_coll_pool
go                                                                                         
 sp_recompile "dbo.hts_collateral"
go
update index statistics dbo.hts_collateral
go                                                                                       
 sp_recompile "dbo.hts_constituent"
go
update index statistics dbo.hts_constituent
go                                                                                     
 sp_recompile "dbo.hts_corr_detail"
go
update index statistics dbo.hts_corr_detail
go                                                                                     
 sp_recompile "dbo.hts_corr_list"
go
update index statistics dbo.hts_corr_list
go                                                                                         
 sp_recompile "dbo.hts_country"
go
update index statistics dbo.hts_country
go                                                                                             
 sp_recompile "dbo.hts_credit_ratings"
go
update index statistics dbo.hts_credit_ratings
go                                                                               
 sp_recompile "dbo.hts_credit_spreads"
go
update index statistics dbo.hts_credit_spreads
go                                                                               
 sp_recompile "dbo.hts_credit_spreads_list"
go
update index statistics dbo.hts_credit_spreads_list
go                                                                     
 sp_recompile "dbo.hts_customer"
go
update index statistics dbo.hts_customer
go                                                                                           
 sp_recompile "dbo.hts_data_relation"
go
update index statistics dbo.hts_data_relation
go                                                                                 
 sp_recompile "dbo.hts_db_listener"
go
update index statistics dbo.hts_db_listener
go                                                                                     
 sp_recompile "dbo.hts_db_upgrades"
go
update index statistics dbo.hts_db_upgrades
go                                                                                     
 sp_recompile "dbo.hts_dbl_log"
go
update index statistics dbo.hts_dbl_log
go                                                                                             
 sp_recompile "dbo.hts_dbl_trade_log"
go
update index statistics dbo.hts_dbl_trade_log
go                                                                                 
 sp_recompile "dbo.hts_dbt_fee_map"
go
update index statistics dbo.hts_dbt_fee_map
go                                                                                     
 sp_recompile "dbo.hts_dbt_fi_sec"
go
update index statistics dbo.hts_dbt_fi_sec
go                                                                                       
 sp_recompile "dbo.hts_dbt_system_route"
go
update index statistics dbo.hts_dbt_system_route
go                                                                           
 sp_recompile "dbo.hts_dbt_xfce"
go
update index statistics dbo.hts_dbt_xfce
go                                                                                           
 sp_recompile "dbo.hts_deal"
go
update index statistics dbo.hts_deal
go                                                                                                   
 sp_recompile "dbo.hts_dividend_detail"
go
update index statistics dbo.hts_dividend_detail
go                                                                             
 sp_recompile "dbo.hts_dividend_list"
go
update index statistics dbo.hts_dividend_list
go                                                                                 
 sp_recompile "dbo.hts_dynamic_apps"
go
update index statistics dbo.hts_dynamic_apps
go                                                                                   
 sp_recompile "dbo.hts_emu_conv_event"
go
update index statistics dbo.hts_emu_conv_event
go                                                                               
 sp_recompile "dbo.hts_emu_conv_rule"
go
update index statistics dbo.hts_emu_conv_rule
go                                                                                 
 sp_recompile "dbo.hts_emu_conv_rule_list"
go
update index statistics dbo.hts_emu_conv_rule_list
go                                                                       
 sp_recompile "dbo.hts_eqcd_detail"
go
update index statistics dbo.hts_eqcd_detail
go                                                                                     
 sp_recompile "dbo.hts_event_types"
go
update index statistics dbo.hts_event_types
go                                                                                     
 sp_recompile "dbo.hts_exchange"
go
update index statistics dbo.hts_exchange
go                                                                                           
 sp_recompile "dbo.hts_exec_adj"
go
update index statistics dbo.hts_exec_adj
go                                                                                           
 sp_recompile "dbo.hts_exec_control"
go
update index statistics dbo.hts_exec_control
go                                                                                   
 sp_recompile "dbo.hts_exer_notice"
go
update index statistics dbo.hts_exer_notice
go                                                                                     
 sp_recompile "dbo.hts_fi_sec_master"
go
update index statistics dbo.hts_fi_sec_master
go                                                                                 
 sp_recompile "dbo.hts_filter_columns"
go
update index statistics dbo.hts_filter_columns
go                                                                               
 sp_recompile "dbo.hts_filter_detail"
go
update index statistics dbo.hts_filter_detail
go                                                                                 
 sp_recompile "dbo.hts_filter_list"
go
update index statistics dbo.hts_filter_list
go                                                                                     
 sp_recompile "dbo.hts_fiscal_calendar"
go
update index statistics dbo.hts_fiscal_calendar
go                                                                             
 sp_recompile "dbo.hts_fixings"
go
update index statistics dbo.hts_fixings
go                                                                                             
 sp_recompile "dbo.hts_funding_rates"
go
update index statistics dbo.hts_funding_rates
go                                                                                 
 sp_recompile "dbo.hts_fx_detail"
go
update index statistics dbo.hts_fx_detail
go                                                                                         
 sp_recompile "dbo.hts_fx_list"
go
update index statistics dbo.hts_fx_list
go                                                                                             
 sp_recompile "dbo.hts_gen_otc"
go
update index statistics dbo.hts_gen_otc
go                                                                                             
 sp_recompile "dbo.hts_gen_sec_types"
go
update index statistics dbo.hts_gen_sec_types
go                                                                                 
 sp_recompile "dbo.hts_gotc_rebate_pay_types"
go
update index statistics dbo.hts_gotc_rebate_pay_types
go                                                                 
 sp_recompile "dbo.hts_gotc_schedule"
go
update index statistics dbo.hts_gotc_schedule
go                                                                                 
 sp_recompile "dbo.hts_gotc_trigger_types"
go
update index statistics dbo.hts_gotc_trigger_types
go                                                                       
 sp_recompile "dbo.hts_group"
go
update index statistics dbo.hts_group
go                                                                                                 
 sp_recompile "dbo.hts_group_control"
go
update index statistics dbo.hts_group_control
go                                                                                 
 sp_recompile "dbo.hts_hldGetQty_wrk"
go
update index statistics dbo.hts_hldGetQty_wrk
go                                                                                 
 sp_recompile "dbo.hts_hold_map"
go
update index statistics dbo.hts_hold_map
go                                                                                           
 sp_recompile "dbo.hts_hold_user_data"
go
update index statistics dbo.hts_hold_user_data
go                                                                               
 sp_recompile "dbo.hts_holding_greeks"
go
update index statistics dbo.hts_holding_greeks
go                                                                               
 sp_recompile "dbo.hts_holiday_detail"
go
update index statistics dbo.hts_holiday_detail
go                                                                               
 sp_recompile "dbo.hts_holiday_list"
go
update index statistics dbo.hts_holiday_list
go                                                                                   
 sp_recompile "dbo.hts_industry"
go
update index statistics dbo.hts_industry
go                                                                                           
 sp_recompile "dbo.hts_irate_source"
go
update index statistics dbo.hts_irate_source
go                                                                                   
 sp_recompile "dbo.hts_issuer"
go
update index statistics dbo.hts_issuer
go                                                                                               
 sp_recompile "dbo.hts_legal_entity"
go
update index statistics dbo.hts_legal_entity
go                                                                                   
 sp_recompile "dbo.hts_lim_cmb_type"
go
update index statistics dbo.hts_lim_cmb_type
go                                                                                   
 sp_recompile "dbo.hts_limit_detail"
go
update index statistics dbo.hts_limit_detail
go                                                                                   
 sp_recompile "dbo.hts_limit_field"
go
update index statistics dbo.hts_limit_field
go                                                                                     
 sp_recompile "dbo.hts_limit_list"
go
update index statistics dbo.hts_limit_list
go                                                                                       
 sp_recompile "dbo.hts_limit_monitor_event"
go
update index statistics dbo.hts_limit_monitor_event
go                                                                     
 sp_recompile "dbo.hts_location"
go
update index statistics dbo.hts_location
go                                                                                           
 sp_recompile "dbo.hts_lock"
go
update index statistics dbo.hts_lock
go                                                                                                   
 sp_recompile "dbo.hts_mark"
go
update index statistics dbo.hts_mark
go                                                                                                   
 sp_recompile "dbo.hts_mark_acct"
go
update index statistics dbo.hts_mark_acct
go                                                                                         
 sp_recompile "dbo.hts_market_price"
go
update index statistics dbo.hts_market_price
go                                                                                   
 sp_recompile "dbo.hts_mmkt_usec"
go
update index statistics dbo.hts_mmkt_usec
go                                                                                         
 sp_recompile "dbo.hts_monitor_limit"
go
update index statistics dbo.hts_monitor_limit
go                                                                                 
 sp_recompile "dbo.hts_name_change_notice"
go
update index statistics dbo.hts_name_change_notice
go                                                                       
 sp_recompile "dbo.hts_next_rowid"
go
update index statistics dbo.hts_next_rowid
go                                                                                       
 sp_recompile "dbo.hts_nosplit"
go
update index statistics dbo.hts_nosplit
go                                                                                             
 sp_recompile "dbo.hts_notify_status"
go
update index statistics dbo.hts_notify_status
go                                                                                 
 sp_recompile "dbo.hts_object_limit"
go
update index statistics dbo.hts_object_limit
go                                                                                   
 sp_recompile "dbo.hts_obsolete_objects_wrk"
go
update index statistics dbo.hts_obsolete_objects_wrk
go                                                                   
 sp_recompile "dbo.hts_opt_exer_event"
go
update index statistics dbo.hts_opt_exer_event
go                                                                               
 sp_recompile "dbo.hts_ord_control"
go
update index statistics dbo.hts_ord_control
go                                                                                     
 sp_recompile "dbo.hts_pc_codes"
go
update index statistics dbo.hts_pc_codes
go                                                                                           
 sp_recompile "dbo.hts_perm_control"
go
update index statistics dbo.hts_perm_control
go                                                                                   
 sp_recompile "dbo.hts_pl_archive"
go
update index statistics dbo.hts_pl_archive
go                                                                                       
 sp_recompile "dbo.hts_port_control"
go
update index statistics dbo.hts_port_control
go                                                                                   
 sp_recompile "dbo.hts_price_detail"
go
update index statistics dbo.hts_price_detail
go                                                                                   
 sp_recompile "dbo.hts_price_list"
go
update index statistics dbo.hts_price_list
go                                                                                       
 sp_recompile "dbo.hts_problem_holdings_wrk"
go
update index statistics dbo.hts_problem_holdings_wrk
go                                                                   
 sp_recompile "dbo.hts_profit_loss"
go
update index statistics dbo.hts_profit_loss
go                                                                                     
 sp_recompile "dbo.hts_regulatory_agency"
go
update index statistics dbo.hts_regulatory_agency
go                                                                         
 sp_recompile "dbo.hts_replication_status"
go
update index statistics dbo.hts_replication_status
go                                                                       
 sp_recompile "dbo.hts_restricted_sec"
go
update index statistics dbo.hts_restricted_sec
go                                                                               
 sp_recompile "dbo.hts_reuters_masks"
go
update index statistics dbo.hts_reuters_masks
go                                                                                 
 sp_recompile "dbo.hts_rm_ccy_default"
go
update index statistics dbo.hts_rm_ccy_default
go                                                                               
 sp_recompile "dbo.hts_roll_detail"
go
update index statistics dbo.hts_roll_detail
go                                                                                     
 sp_recompile "dbo.hts_roll_list"
go
update index statistics dbo.hts_roll_list
go                                                                                         
 sp_recompile "dbo.hts_scenario_maps"
go
update index statistics dbo.hts_scenario_maps
go                                                                                 
 sp_recompile "dbo.hts_sched_list"
go
update index statistics dbo.hts_sched_list
go                                                                                       
 sp_recompile "dbo.hts_sec_def_attribs"
go
update index statistics dbo.hts_sec_def_attribs
go                                                                             
 sp_recompile "dbo.hts_sec_master"
go
update index statistics dbo.hts_sec_master
go                                                                                       
 sp_recompile "dbo.hts_settle_rule"
go
update index statistics dbo.hts_settle_rule
go                                                                                     
 sp_recompile "dbo.hts_sfailure_event"
go
update index statistics dbo.hts_sfailure_event
go                                                                               
 sp_recompile "dbo.hts_site"
go
update index statistics dbo.hts_site
go                                                                                                   
 sp_recompile "dbo.hts_sm_audit_trail_log"
go
update index statistics dbo.hts_sm_audit_trail_log
go                                                                       
 sp_recompile "dbo.hts_sm_deriv_detail"
go
update index statistics dbo.hts_sm_deriv_detail
go                                                                             
 sp_recompile "dbo.hts_sm_eqss_detail"
go
update index statistics dbo.hts_sm_eqss_detail
go                                                                               
 sp_recompile "dbo.hts_sm_relation"
go
update index statistics dbo.hts_sm_relation
go                                                                                     
 sp_recompile "dbo.hts_sm_repo"
go
update index statistics dbo.hts_sm_repo
go                                                                                             
 sp_recompile "dbo.hts_sm_repo_sched"
go
update index statistics dbo.hts_sm_repo_sched
go                                                                                 
 sp_recompile "dbo.hts_sm_user_data"
go
update index statistics dbo.hts_sm_user_data
go                                                                                   
 sp_recompile "dbo.hts_sp_return_codes"
go
update index statistics dbo.hts_sp_return_codes
go                                                                             
 sp_recompile "dbo.hts_splits"
go
update index statistics dbo.hts_splits
go                                                                                               
 sp_recompile "dbo.hts_spot_list"
go
update index statistics dbo.hts_spot_list
go                                                                                         
 sp_recompile "dbo.hts_stock_merger"
go
update index statistics dbo.hts_stock_merger
go                                                                                   
 sp_recompile "dbo.hts_stock_merger_list"
go
update index statistics dbo.hts_stock_merger_list
go                                                                         
 sp_recompile "dbo.hts_stock_spinoff"
go
update index statistics dbo.hts_stock_spinoff
go                                                                                 
 sp_recompile "dbo.hts_stock_spinoff_list"
go
update index statistics dbo.hts_stock_spinoff_list
go                                                                       
 sp_recompile "dbo.hts_stock_split"
go
update index statistics dbo.hts_stock_split
go                                                                                     
 sp_recompile "dbo.hts_swap"
go
update index statistics dbo.hts_swap
go                                                                                                   
 sp_recompile "dbo.hts_swap_detail"
go
update index statistics dbo.hts_swap_detail
go                                                                                     
 sp_recompile "dbo.hts_swap_equity_leg"
go
update index statistics dbo.hts_swap_equity_leg
go                                                                             
 sp_recompile "dbo.hts_swap_event_sched"
go
update index statistics dbo.hts_swap_event_sched
go                                                                           
 sp_recompile "dbo.hts_swap_floating_leg"
go
update index statistics dbo.hts_swap_floating_leg
go                                                                         
 sp_recompile "dbo.hts_swap_leg"
go
update index statistics dbo.hts_swap_leg
go                                                                                           
 sp_recompile "dbo.hts_swap_list"
go
update index statistics dbo.hts_swap_list
go                                                                                         
 sp_recompile "dbo.hts_swap_quanto_leg"
go
update index statistics dbo.hts_swap_quanto_leg
go                                                                             
 sp_recompile "dbo.hts_symbol_refresh_wrk"
go
update index statistics dbo.hts_symbol_refresh_wrk
go                                                                       
 sp_recompile "dbo.hts_table_comment"
go
update index statistics dbo.hts_table_comment
go                                                                                 
 sp_recompile "dbo.hts_table_info"
go
update index statistics dbo.hts_table_info
go                                                                                       
 sp_recompile "dbo.hts_tax_rules"
go
update index statistics dbo.hts_tax_rules
go                                                                                         
 sp_recompile "dbo.hts_template_detail"
go
update index statistics dbo.hts_template_detail
go                                                                             
 sp_recompile "dbo.hts_template_list"
go
update index statistics dbo.hts_template_list
go                                                                                 
 sp_recompile "dbo.hts_tick_sizes"
go
update index statistics dbo.hts_tick_sizes
go                                                                                       
 sp_recompile "dbo.hts_tickets"
go
update index statistics dbo.hts_tickets
go                                                                                             
 sp_recompile "dbo.hts_time_zone"
go
update index statistics dbo.hts_time_zone
go                                                                                         
 sp_recompile "dbo.hts_trader"
go
update index statistics dbo.hts_trader
go                                                                                               
 sp_recompile "dbo.hts_trader_security"
go
update index statistics dbo.hts_trader_security
go                                                                             
 sp_recompile "dbo.hts_trigger_status"
go
update index statistics dbo.hts_trigger_status
go                                                                               
 sp_recompile "dbo.hts_tvol_detail"
go
update index statistics dbo.hts_tvol_detail
go                                                                                     
 sp_recompile "dbo.hts_tvol_list"
go
update index statistics dbo.hts_tvol_list
go                                                                                         
 sp_recompile "dbo.hts_underlying"
go
update index statistics dbo.hts_underlying
go                                                                                       
 sp_recompile "dbo.hts_user_rt_default"
go
update index statistics dbo.hts_user_rt_default
go                                                                             
 sp_recompile "dbo.hts_users"
go
update index statistics dbo.hts_users
go                                                                                                 
 sp_recompile "dbo.hts_valid_date_patterns"
go
update index statistics dbo.hts_valid_date_patterns
go                                                                     
 sp_recompile "dbo.hts_var_cross_ref"
go
update index statistics dbo.hts_var_cross_ref
go                                                                                 
 sp_recompile "dbo.hts_volatility_detail"
go
update index statistics dbo.hts_volatility_detail
go                                                                         
 sp_recompile "dbo.hts_volatility_list"
go
update index statistics dbo.hts_volatility_list
go                                                                             
 sp_recompile "dbo.hts_xact_history"
go
update index statistics dbo.hts_xact_history
go                                                                                   
 sp_recompile "dbo.hts_xrate_detail"
go
update index statistics dbo.hts_xrate_detail
go                                                                                   
 sp_recompile "dbo.hts_xrate_list"
go
update index statistics dbo.hts_xrate_list
go                                                                                       
 sp_recompile "dbo.hts_yc_alg_risk"
go
update index statistics dbo.hts_yc_alg_risk
go                                                                                     
 sp_recompile "dbo.hts_yc_curve"
go
update index statistics dbo.hts_yc_curve
go                                                                                           
 sp_recompile "dbo.hts_yc_hdg_instr"
go
update index statistics dbo.hts_yc_hdg_instr
go                                                                                   
 sp_recompile "dbo.hts_yc_hdg_strat"
go
update index statistics dbo.hts_yc_hdg_strat
go                                                                                   
 sp_recompile "dbo.hts_yc_link_data"
go
update index statistics dbo.hts_yc_link_data
go                                                                                   
 sp_recompile "dbo.hts_yc_mkt_instr"
go
update index statistics dbo.hts_yc_mkt_instr
go                                                                                   
 sp_recompile "dbo.hts_yc_mkt_instr_data"
go
update index statistics dbo.hts_yc_mkt_instr_data
go                                                                         
 sp_recompile "dbo.hts_yc_mkt_instr_hdr"
go
update index statistics dbo.hts_yc_mkt_instr_hdr
go                                                                           
 sp_recompile "dbo.hts_yc_model"
go
update index statistics dbo.hts_yc_model
go                                                                                           
 sp_recompile "dbo.hts_yc_risk_curve"
go
update index statistics dbo.hts_yc_risk_curve
go                                                                                 
 sp_recompile "dbo.hts_yc_risk_curves_view"
go
update index statistics dbo.hts_yc_risk_curves_view
go                                                                     
 sp_recompile "dbo.hts_yc_risk_data"
go
update index statistics dbo.hts_yc_risk_data
go                                                                                   
 sp_recompile "dbo.hts_yc_risk_scenar_view"
go
update index statistics dbo.hts_yc_risk_scenar_view
go                                                                     
 sp_recompile "dbo.hts_yc_risk_scenario"
go
update index statistics dbo.hts_yc_risk_scenario
go                                                                           
 sp_recompile "dbo.hts_yc_scenario"
go
update index statistics dbo.hts_yc_scenario
go                                                                                     
 sp_recompile "dbo.hts_yc_sp"
go
update index statistics dbo.hts_yc_sp
go                                                                                                 
 sp_recompile "dbo.hts_yc_sp_hdr"
go
update index statistics dbo.hts_yc_sp_hdr
go                                                                                         
 sp_recompile "dbo.hts_yc_strip"
go
update index statistics dbo.hts_yc_strip
go                                                                                           
 sp_recompile "dbo.hts_yc_swap_spec"
go
update index statistics dbo.hts_yc_swap_spec
go                                                                                   
 sp_recompile "dbo.hts_yield_detail"
go
update index statistics dbo.hts_yield_detail
go                                                                                   
 sp_recompile "dbo.hts_yield_list"
go
update index statistics dbo.hts_yield_list
go                                                                                       
 sp_recompile "dbo.mdl_TempBasketUpdate"
go
update index statistics dbo.mdl_TempBasketUpdate
go                                                                           
 sp_recompile "dbo.mdl_borrow_list_tb"
go
update index statistics dbo.mdl_borrow_list_tb
go                                                                               
 sp_recompile "dbo.mdl_dividend_list_tb"
go
update index statistics dbo.mdl_dividend_list_tb
go                                                                           
 sp_recompile "dbo.mdl_portf_colnames_tb"
go
update index statistics dbo.mdl_portf_colnames_tb
go                                                                         
 sp_recompile "dbo.mdl_volatility_detail_tb"
go
update index statistics dbo.mdl_volatility_detail_tb
go                                                                   
 sp_recompile "dbo.mdl_volatility_list_tb"
go
update index statistics dbo.mdl_volatility_list_tb
go                                                                       
 sp_recompile "dbo.nw_mark_side_code"
go
update index statistics dbo.nw_mark_side_code
go                                                                                 
 sp_recompile "dbo.reconnect_dividends"
go
update index statistics dbo.reconnect_dividends
go                                                                             
 sp_recompile "dbo.reconstructed_dividends"
go
update index statistics dbo.reconstructed_dividends
go                                                                     
 sp_recompile "dbo.rs_lastcommit"
go
update index statistics dbo.rs_lastcommit
go                                                                                         
 sp_recompile "dbo.rs_threads"
go
update index statistics dbo.rs_threads
go                                                                                               
 sp_recompile "dbo.s"
go
update index statistics dbo.s
go                                                                                                                 
 sp_recompile "dbo.ss"
go
update index statistics dbo.ss
go                                                                                                               
 sp_recompile "dbo.t_ICONCDRImport"
go
update index statistics dbo.t_ICONCDRImport
go                                                                                     
 sp_recompile "dbo.t_ICONCDRLookup"
go
update index statistics dbo.t_ICONCDRLookup
go                                                                                     
 sp_recompile "dbo.t_ICONFeedControl"
go
update index statistics dbo.t_ICONFeedControl
go                                                                                 
 sp_recompile "dbo.t_ICONFilesInfo"
go
update index statistics dbo.t_ICONFilesInfo
go                                                                                     
 sp_recompile "dbo.t_ICONPrepareTradeFile"
go
update index statistics dbo.t_ICONPrepareTradeFile
go                                                                       
 sp_recompile "dbo.t_ICONTradesCompare"
go
update index statistics dbo.t_ICONTradesCompare
go                                                                             
 sp_recompile "dbo.t_ICONTradesSentDetail"
go
update index statistics dbo.t_ICONTradesSentDetail
go                                                                       
 sp_recompile "dbo.t_ICONTradesTemp"
go
update index statistics dbo.t_ICONTradesTemp
go                                                                                   
 sp_recompile "dbo.t_init_ICONPrepareTradeFile"
go
update index statistics dbo.t_init_ICONPrepareTradeFile
go                                                             
 sp_recompile "dbo.t_init_ICONTradesSentDetail"
go
update index statistics dbo.t_init_ICONTradesSentDetail
go                                                             
 sp_recompile "dbo.t_init_ImportCDR"
go
update index statistics dbo.t_init_ImportCDR
go                                                                                   
 sp_recompile "dbo.temp_cdr"
go
update index statistics dbo.temp_cdr
go                                                                                                   
 sp_recompile "dbo.temp_rics"
go
update index statistics dbo.temp_rics
go                                                                                                 
 sp_recompile "dbo.temp_user_list"
go
update index statistics dbo.temp_user_list
go                                                                                       
 sp_recompile "dbo.user_location"
go
update index statistics dbo.user_location
go                                                                                         
 sp_recompile "dbo.world_clock"
go
update index statistics dbo.world_clock
go                                                                                             
