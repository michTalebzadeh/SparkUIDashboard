--
------> Database test <------
--
CREATE SUBSCRIPTION test_dp
FOR DATABASE REPLICATION DEFINITION test_dd
WITH PRIMARY AT lon_gen_sql_tst7.test
WITH REPLICATE AT lon_gen_sql_tst6.test
WITHOUT MATERIALIZATION
go
