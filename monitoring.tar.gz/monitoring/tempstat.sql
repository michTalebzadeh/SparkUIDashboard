prompt
Prompt +--------------------------------------+
Prompt | Tempstat from V$TEMPSTAT, V$TEMPFILE |
Prompt +--------------------------------------+

select substr(d.name,1,50) name, f.phyrds "PhysicalReads",
       DECODE(t.tot_phys_reads,0,0,100*f.phyrds/t.tot_phys_reads) "Read %",
       f.phywrts "PhysicalWrites",
       DECODE(t.tot_phys_writes,0,0,100*f.phywrts/t.tot_phys_writes) "Write %"
from   v$tempfile d, v$tempstat f, 
       (select sum(phyrds) tot_phys_reads,
               sum(phywrts) tot_phys_writes 
        from v$tempstat) t
where  d.file# = f.file#
order  by 3 desc
/
exit
