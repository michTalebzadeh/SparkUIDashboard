drop table plan_table;
CREATE TABLE plan_table
 (
  statement_id               VARCHAR2(30),
  timestamp                  DATE,
  remarks                    VARCHAR2(80),
  operation                  VARCHAR2(30),
  options                    VARCHAR2(30),
  object_node                VARCHAR2(128),
  object_owner               VARCHAR2(30),
  object_name                VARCHAR2(30),
  object_instance            NUMBER,
  object_type                VARCHAR2(30),
  optimizer                  VARCHAR2(255),
  search_columns             NUMBER,
  id                         NUMBER,
  parent_id                  NUMBER,
  position                   NUMBER,
  other                      LONG
 )
/
set echo on

delete from plan_table
 where statement_id = 'MINE';
commit;
COL operation   FORMAT A30
COL options     FORMAT A15
COL object_name FORMAT A20
EXPLAIN PLAN set statement_id = 'MINE' for
/* ------ Your SQL here ------*/
select/* + INDEX(test_pk) */ * 
  from scott.test
	where grade = 100;

/*----------------------------*/
/

set echo off

select operation, options, object_name
  from plan_table
 where statement_id = 'MINE'
start with id = 0
connect by prior id=parent_id and prior statement_id = statement_id;
set echo on
/
exit 


