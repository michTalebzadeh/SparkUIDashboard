alter system flush buffer_cache;
alter system flush shared_pool;
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'scratchpad_insert_tdash';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
insert into scratchpad.tdash
select * from ssdtester.tdash
where object_name < 'abc';
commit;
exit
