column object format a30 heading Object
select s.username, a.object, a.type from v$access a, v$session s
where a.sid = s.sid
and s.type = 'USER'
and s.username NOT in ('SYS','SYSTEM')
ORDER BY  a.type, a.object
/
exit
