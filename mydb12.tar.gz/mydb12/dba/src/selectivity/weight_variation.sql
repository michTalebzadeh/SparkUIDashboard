select to_char(datetaken, 'yyyy-mm-dd') AS datetaken, weight from weights order by 1;
exit
