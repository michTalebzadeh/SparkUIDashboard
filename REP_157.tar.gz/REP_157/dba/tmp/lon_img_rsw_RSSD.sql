set nocount on
go
use master
go
select "use master " + "
go"
select "use lon_img_rsw_RSSD " + " 
go"
select "update statistics " + name + " 
go" + " 
sp_recompile " + name + " 
go" 
from lon_img_rsw_RSSD..sysobjects 
where type = "U" 
order by name 
go 

 
