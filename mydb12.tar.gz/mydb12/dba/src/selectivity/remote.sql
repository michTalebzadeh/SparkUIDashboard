DECLARE
	--v_build_vc "testview"@syb_157."build_vc"%TYPE;        
	--v_probe_vc "testview"@syb_157."probe_vc"%TYPE;        
        CURSOR c IS SELECT * from "testview"@syb_157;
	v_c c%ROWTYPE;
BEGIN
        OPEN c;
        LOOP
          FETCH c INTO v_c;
	  EXIT WHEN c%NOTFOUND;
          dbms_output.put_line('build_vc is '||v_c."build_vc"||' ,probe_vc is '||v_c."probe_vc");
        END LOOP;
END;
/
exit
