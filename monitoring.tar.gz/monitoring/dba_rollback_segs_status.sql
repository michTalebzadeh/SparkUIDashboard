select
	segment_name AS "Name",
	owner AS "Owner",
	tablespace_name AS "Tablespace",
	initial_extent AS "Ini",
	next_extent AS "Next",
	min_extents  AS "Min",
	status AS "Status"
from
	dba_rollback_segs
/
exit
