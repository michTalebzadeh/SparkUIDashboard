 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 STAT_NAME									   VARCHAR2(64)
 VALUE										   NUMBER
 OSSTAT_ID									   NUMBER
 COMMENTS									   VARCHAR2(64)
 CUMULATIVE									   VARCHAR2(3)

