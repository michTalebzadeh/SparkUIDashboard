 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 SERIAL#									   NUMBER
 WAIT_CLASS_ID									   NUMBER
 WAIT_CLASS#									   NUMBER
 WAIT_CLASS									   VARCHAR2(64)
 TOTAL_WAITS									   NUMBER
 TIME_WAITED									   NUMBER

