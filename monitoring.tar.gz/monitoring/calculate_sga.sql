--it's pretty easy to calculate sga manually. use the formulas
--version 8     
-- SGA = ((db_block_buffers * block size) + (shared_pool_size + large_pool_size + log_buffers) + 1MB     

--version 8i    
-- SGA= ((db_block_buffers * block size) + (shared_pool_size + large_pool_size + java_pool_size + log_buffers) + 1MB  

--version 9i
--SGA = (db_cache_size + db_keep_cache_size + db_recycle_cache_size + db_nk_cache_size)  + (shared_pool_size + large_pool_size + java_pool_size + redo_log_buffers) + 1MB  
set heading off feedback off serveroutput on linesize 132
SELECT
	name||' = '||
	round(value/1024/1024)||'MB'
FROM
	v$parameter
WHERE
	name in
		(
		 'db_cache_size',
		 'db_keep_cache_size',
		 'db_recycle_cache_size',
		 'db_nk_cache_size',
		 'shared_pool_size',
		 'large_pool_size',
		 'java_pool_size',
		 'log_buffer'
		)
ORDER BY
	name
;
SELECT
	round(sum(value/1024/1024))+1||'MB'
FROM
        v$parameter
WHERE
        name in
                (
                 'db_cache_size',
                 'db_keep_cache_size',
                 'db_recycle_cache_size',
                 'db_nk_cache_size',
                 'shared_pool_size',
                 'large_pool_size',
                 'java_pool_size',
                 'log_buffer'
                )
;
exit
