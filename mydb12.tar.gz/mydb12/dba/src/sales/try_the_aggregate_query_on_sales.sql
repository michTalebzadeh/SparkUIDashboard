--set autotrace traceonly
ALTER SYSTEM FLUSH BUFFER_CACHE;
set autotrace on
set timing on
select 
--	/*+ RESULT_CACHE */
	cust_id "Customer ID",
count(amount_sold) "Number of orders",
sum(amount_sold) "Total customer's amount",
avg(amount_sold) "Average order",
stddev(amount_sold) "Standard deviation"
from sales
group by cust_id
having sum(amount_sold) > 94000
and avg(amount_sold) < stddev(amount_sold)
order by 3 desc;
exit

