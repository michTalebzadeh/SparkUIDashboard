 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 TABLE_NAME									   VARCHAR2(30)
 INDEX_NUMBER									   NUMBER
 COLUMN_NAME									   VARCHAR2(30)
 COLUMN_POSITION								   NUMBER

