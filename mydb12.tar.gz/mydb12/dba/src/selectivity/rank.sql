SELECT *
     FROM (
    SELECT to_char(datetaken,'dd-mon-yyyy') AS datetaken, weight, RANK() OVER (ORDER BY weight) as rank
          from scratchpad.weights
       )
     WHERE rank <= 10
;
exit
