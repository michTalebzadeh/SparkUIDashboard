REM ***********************************************************************
REM          file: readme.txt
REM   description: Describes the files and steps used to create
REM                  the student schema
REM                This group of the setup scripts should be used for
REM                  the starting point of the Oracle Interactive
REM                  Workbooks. Note that because of some last minute
REM                  upgrades that were put into the student.tab script
REM                  after the books went to print, the column and table
REM                  comments that these script create may not match
REM                  exactly those that are shown in the table
REM                  descriptions provided in some of the Oracle 
REM                  Interactive Workbooks.
REM       created: February 8, 2000
REM ***********************************************************************

1. Steps to create the student schema
2. Steps to build student schema objects and load associated data
3. Steps to rebuild the student schema
4. List of files used in the create and rebuild steps

Note: These instructions will work in Windows and UNIX environments and 
      should work in just about any other OS environment.


*** ********************************* ***
 1. Steps to create the student schema
*** ********************************* ***
   A. Prior to creating the student schema objects and loading data into them, it
      is necessary to create the student schema (a place/account/user in the database
      that will hold the objects and data). The default account and password for
      this book are STUDENT and LEARN respectively.
   B. If a DBA is managing your Oracle database, ask them to create an account
      for you named student with a password of learn.
   C. If you need to create the account yourself, follow these steps
      C.1 In SQL*Plus, connect to your database as SYSTEM (the default password is MANAGER)
      C.2 Issue the following statement to find the names of the tablespaces in your database.
          Note: Tablespaces are areas that hold database objects in an Oracle database. If you
          are not familiar with tablespaces right now, don't worry.

          SELECT tablespace_name
            FROM dba_tablespaces
           ORDER BY tablespace_name;

      C.3 In the resulting list you need to find two particular tablespaces
          C.3.a A tablespace used as the default place to store your objects. The
                name of this tablespace will vary depending on your operating 
                system platform and your Oracle database version. Your DEFAULT
                TABLESPACE will have a name similar to one of the following:
                        
                        USERS
                        USER_DATA
                        USR

         C.3.b A tablespace known as the TEMPORARY TABLESPACE. Typical names for
               TEMPORARY TABLESPACEs are:
 
                        TEMP 
                        TEMPORARY
                        TEMPORARY_DATA

      C.4 Once you have found your DEFAULT TABLESPACE and TEMPORARY TABLESPACE names
          write them down for the next step. 
          C.4.a Note that the most common two names will be USERS and TEMP.

   D. Now you are ready to create the STUDENT database account.
      D.1 Still logged on as SYSTEM/MANAGER from step C above, issue the following
          statement, substituting the tablespace names from steps C.3.a and C.3.b:

          CREATE USER student IDENTIFIED by learn
            DEFAULT TABLESPACE <name from step C.3.a>
            TEMPORARY TABLESPACE <name from step C.3.b>;
    
      D.2 Your final statement should look similar to the following:

          CREATE USER student IDENTIFIED by learn
            DEFAULT TABLESPACE users
            TEMPORARY TABLESPACE temp;

   E. Now you need to give the student account the ability to use the database. 
      E.1 Issue the following statement while connected through SQL*Plus as
          SYSTEM/MANAGER:

          GRANT CONNECT, RESOURCE TO student;

   F. Test that you can connect as the student account.
      F.1 Issue the following statements in SQL*Plus to connect as student
       
          CONNECT student/learn
          SHOW USER
           
      F.2 After issuing the SHOW USER command, you should receive the following message:

          USER is "STUDENT"

*** ************************************************************** ***
 2. Steps to build student schema objects and load associated data
*** ************************************************************** ***

   A. Open SQL*Plus and connect to the database as STUDENT/LEARN
   B. Write down the location of the create and insert scripts 
      Note: those scripts should be located in the same place as
      the readme.txt file you are reading right now.
      B.2 A common place that you may have your scripts is C:\guest\schemasetup.
   C. Using the C:\guest\schemasetup directory as an example, issue the following
      in SQL*Plus:

        @C:\guest\schemasetup\createStudent.sql

   D. When the script is done running, it will show a list of counts 
      representing the number of rows it created for each table. Compare
      that list on screen with the following list. The two lists should
      match.      
    
    
                 Count of COURSE Table:        30
                 
                 Count of ENROLLMENT Table:       226

                 Count of GRADE Table:      2004

                 Count of GRADE_CONVERSION Table:        15

                 Count of GRADE_TYPE Table:         6

                 Count of GRADE_TYPE_WEIGHT Table:       300

                 Count of INSTRUCTOR Table:        10

                 Count of SECTION Table:        78

                 Count of SECTION Table:       268

                 Count of SECTION Table:       227

*** *********************************** ***
 3. Steps to rebuild the student schema
*** *********************************** ***
   A. Following these steps will rebuild the objects in the student schema.
      You may wish to perform this step if you want to return the student
      schema objects to their pristine state. This is especially useful after
      you have worked through the chapters that focus on data manipulation.
      For example, if you have just been working on DELETing data, you may 
      wish to restore that data to practice SELECTing the data.
   B. Open SQL*Plus and connect to the database as STUDENT/LEARN
   C. Write down the location of the create and insert scripts 
      Note: those scripts should be located in the same place as
      the readme.txt file you are reading right now.
      B.2 A common place that you may have your scripts is C:\guest\schemasetup.
   D. Using the C:\guest\schemasetup directory as an example, issue the following
      in SQL*Plus:

        @C:\guest\schemasetup\rebuildStudent.sql

      Caution: Running this script removes all the objects created for 
               work with these books. At the beginning of this script,
               you are prompted with the opportunity to stop processing
               or continue processing. To stop the removal process you
               should press CTRL+C; to continue, press <RETURN>.

   E. When the script is done running, it will show a list of counts 
      representing the number of rows it created for each table. Compare
      that list on screen with the following list. The two lists should
      match.      
    
    
                 Count of COURSE Table:        30
                 
                 Count of ENROLLMENT Table:       226

                 Count of GRADE Table:      2004

                 Count of GRADE_CONVERSION Table:        15

                 Count of GRADE_TYPE Table:         6

                 Count of GRADE_TYPE_WEIGHT Table:       300

                 Count of INSTRUCTOR Table:        10

                 Count of SECTION Table:        78

                 Count of SECTION Table:       268

                 Count of SECTION Table:       227


*** ************************************************** ***
 4. List of files used in the create and rebuild steps
*** ************************************************** ***
   A. The following is a list of the files used in the 
      steps 1 - 3 above.
     A.1   createStudent.sql            The primary script that runs the 
                                          other create scripts
     A.2   dropStudent.sql              A script that drops student objects
     A.3   finalCount.sql               Provides a count of rows in the
                                          student schema tables
    *A.4   insertCourse.sql             Inserts COURSE data
    *A.5   insertEnrollment.sql         Inserts ENROLLMENT data
    *A.6   insertGrade.sql              Inserts GRADE data
    *A.7   insertGradeconversion.sql    Inserts GRADE_CONVERSION data
    *A.8   insertGradetype.sql          Inserts GRADE_TYPE data
    *A.9   insertGradetypeweight.sql    Inserts GRADE_TYPE_WEIGHT data
    *A.10  insertInstructor.sql         Inserts INSTRUCTOR data
    *A.11  insertSection.sql            Inserts SECTION data
    *A.12  insertStudent.sql            Inserts STUDENT data
    *A.13  insertZipcode.sql            Inserts ZIPCODE data
     A.14  readme.txt                   The file you are currently reading (This file)
     A.15  rebuildStudent.sql           The script to run for recreating and reloading
                                          the student schema tables
    *A.16  student.con                  Creates the student schema constraints
    *A.17  student.ind                  Creates the student schema indexes    
    *A.18  student.sqs                  Creates the student schema sequences
    *A.19  student.tab                  Creates the student schema tables
     A.20  schemaDiagramV03.zip         This file contains image files of the student
                                          schema.
    * Filenames marked with an asterisk create log files that can be reviewed
        for errors after the script has completed.
