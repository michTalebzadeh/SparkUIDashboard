set autotrace on
set timing on
DECLARE
	type array is table of tdash%rowtype index by binary_integer;
	l_data array;
	l_rec tdash%rowtype;
BEGIN
	SELECT
         	a.*
	BULK COLLECT INTO
	l_data
  	FROM tdash a;

	FOR i IN 1 .. l_data.count
	LOOP
		BEGIN
			SELECT * INTO l_rec FROM tdash WHERE object_id = l_data(i).object_id;
		EXCEPTION
		  WHEN NO_DATA_FOUND THEN NULL;
		END;
	END LOOP;
END;
/
exit
