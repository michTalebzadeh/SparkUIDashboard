 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FILE_NO									   NUMBER
 FILETYPE_ID									   NUMBER
 FILETYPE_NAME									   VARCHAR2(28)
 SMALL_READ_MEGABYTES								   NUMBER
 SMALL_WRITE_MEGABYTES								   NUMBER
 LARGE_READ_MEGABYTES								   NUMBER
 LARGE_WRITE_MEGABYTES								   NUMBER
 SMALL_READ_REQS								   NUMBER
 SMALL_WRITE_REQS								   NUMBER
 SMALL_SYNC_READ_REQS								   NUMBER
 LARGE_READ_REQS								   NUMBER
 LARGE_WRITE_REQS								   NUMBER
 SMALL_READ_SERVICETIME 							   NUMBER
 SMALL_WRITE_SERVICETIME							   NUMBER
 SMALL_SYNC_READ_LATENCY							   NUMBER
 LARGE_READ_SERVICETIME 							   NUMBER
 LARGE_WRITE_SERVICETIME							   NUMBER
 ASYNCH_IO									   VARCHAR2(9)
 ACCESS_METHOD									   VARCHAR2(11)
 RETRIES_ON_ERROR								   NUMBER

