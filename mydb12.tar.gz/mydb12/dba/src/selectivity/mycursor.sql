set serveroutput on size unlimited 
DECLARE
  v_owner tdash.owner%TYPE;
  v_object_name tdash.object_name%TYPE;
  v_object_type tdash.object_type%TYPE;
  CURSOR c
  IS	SELECT owner, object_name, object_type FROM tdash WHERE ROWNUM <=1000;
BEGIN
  DBMS_OUTPUT.ENABLE(10000000); 
  OPEN c;
  LOOP
    FETCH c INTO v_owner, v_object_name, v_object_type;
    EXIT WHEN c%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE(chr(10) ||v_owner||' '||v_object_name||' '||v_object_type);
  END LOOP;
  CLOSE c;
EXCEPTION
  WHEN OTHERS THEN
  IF c%ISOPEN THEN
    CLOSE c;
    RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM,true);
  END IF;
END;
/
show error
exit
