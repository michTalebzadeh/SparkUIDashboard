DECLARE
  TYPE currency_table IS TABLE OF currency.description%type INDEX BY currency.code%type;
  ccy_array  currency_table;
BEGIN
  FOR rs in (select code, description from currency)
  LOOP
    ccy_array(rs.code) := rs.description;
  END LOOP;
  DBMS_OUTPUT.PUT_LINE(CHR(10));
  DBMS_OUTPUT.PUT_LINE ('The ccy array has ' || ccy_array.COUNT || ' elements');
  DBMS_OUTPUT.PUT_LINE ('The code GBP represents :' || ccy_array('GBP'));
EXCEPTION
  WHEN NO_DATA_FOUND THEN NULL;
END;
/
exit
