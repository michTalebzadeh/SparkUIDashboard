--
------> Database test <------
--
CREATE SUBSCRIPTION test_dp
FOR DATABASE REPLICATION DEFINITION test_dd
WITH PRIMARY AT lon_gen_sql_tst1.test
WITH REPLICATE AT lon_gen_sql_tst5.test
WITHOUT MATERIALIZATION
go
