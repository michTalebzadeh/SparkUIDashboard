 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FREE_SPACE									   NUMBER
 AVG_FREE_SIZE									   NUMBER
 FREE_COUNT									   NUMBER
 MAX_FREE_SIZE									   NUMBER
 USED_SPACE									   NUMBER
 AVG_USED_SIZE									   NUMBER
 USED_COUNT									   NUMBER
 MAX_USED_SIZE									   NUMBER
 REQUESTS									   NUMBER
 REQUEST_MISSES 								   NUMBER
 LAST_MISS_SIZE 								   NUMBER
 MAX_MISS_SIZE									   NUMBER
 REQUEST_FAILURES								   NUMBER
 LAST_FAILURE_SIZE								   NUMBER
 ABORTED_REQUEST_THRESHOLD							   NUMBER
 ABORTED_REQUESTS								   NUMBER
 LAST_ABORTED_SIZE								   NUMBER

