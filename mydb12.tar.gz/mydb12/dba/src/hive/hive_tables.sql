set echo off
set linesize 180
set colsep '|'
set pagesize 40
set heading on
clear breaks
clear computes
break on DBName skip 1  on report skip 2

--col fname heading "Filename" format a90
--col fnum heading "#" format 999
col owner  heading Owner format a15
col Tablename heading Table|Name format a15
col DBName heading Database|Name format a15
col TBL_TYPE heading Table|Type format a15
SELECT
          t.owner AS Owner
	, d.NAME AS DBName
	, t.TBL_NAME AS Tablename
	, TBL_TYPE
FROM tbls t, dbs d
WHERE
	  t.DB_ID = d.DB_ID
AND
	  TBL_TYPE IN ('MANAGED_TABLE','EXTERNAL_TABLE')
ORDER BY 1,2
/
exit
