use master
go
set nocount on
go
-- Turn on traceflag for ignoring syslogs table
dbcc traceon(2512)
go

declare @msg char(100), @errorno int
dbcc checkdb(skeleton)
select @errorno=@@error
if @errorno != 0
begin
select @msg="ERROR: Fri Jul  2 18:01:59 BST 2004 db_dbcc.ksh Dbcc of 'skeleton' failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
print @msg
end
dbcc traceoff(2512)
print "Info: Fri Jul  2 18:01:59 BST 2004 db_dbcc.ksh Finished check 'checkdb' for database 'skeleton'"
go

use master
go
set nocount on
go
-- Turn on traceflag for ignoring syslogs table
dbcc traceon(2512)
go

declare @msg char(100), @errorno int
dbcc checkalloc(skeleton)
select @errorno=@@error
if @errorno != 0
begin
select @msg="ERROR: Fri Jul  2 18:01:59 BST 2004 db_dbcc.ksh Dbcc of 'skeleton' failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
print @msg
end
dbcc traceoff(2512)
print "Info: Fri Jul  2 18:01:59 BST 2004 db_dbcc.ksh Finished check 'checkalloc' for database 'skeleton'"
go

use master
go
set nocount on
go
-- Turn on traceflag for ignoring syslogs table
dbcc traceon(2512)
go

declare @msg char(100), @errorno int
dbcc checkcatalog(skeleton)
select @errorno=@@error
if @errorno != 0
begin
select @msg="ERROR: Fri Jul  2 18:01:59 BST 2004 db_dbcc.ksh Dbcc of 'skeleton' failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
print @msg
end
dbcc traceoff(2512)
print "Info: Fri Jul  2 18:01:59 BST 2004 db_dbcc.ksh Finished check 'checkcatalog' for database 'skeleton'"
go

