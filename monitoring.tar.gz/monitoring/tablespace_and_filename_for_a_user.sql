select distinct t.tablespace_name,f.file_name from dba_tables t, dba_data_files f where t.owner = 'HR'
and  t.tablespace_name = f.tablespace_name
/
