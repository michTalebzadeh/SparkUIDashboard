set serveroutput on linesize 132
col object_name heading Object format a30 truncate
select object_name,
       object_type,
       --TO_CHAR(created, 'yyyy/mm/dd hh24:mi:ss') "When Created",
       TO_CHAR(last_ddl_time, 'yyyy/mm/dd hh24:mi:ss') "When Modified",
       status
FROM
	user_objects
       order by last_ddl_time,
                object_name;
exit
