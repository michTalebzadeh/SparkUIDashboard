use master
go
set nocount on
go
declare @msg char(100),
        @errorno int
dump tran lon_img_rsw_RSSD with truncate_only
select @errorno=@@error
if @errorno != 0
begin
        select @msg="Error: Wed Apr 15 23:01:06 BST 1998 db_dump.ksh Dump of lon_img_rsw_RSSD log failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go
declare @msg char(100),
        @errorno int
dump database lon_img_rsw_RSSD to lon_img_rsw_RSSD_dump
select @errorno=@@error
if @errorno != 0
begin
        select @msg="Error: Wed Apr 15 23:01:06 BST 1998 db_dump.ksh Dump of lon_img_rsw_RSSD failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go
