drop table nulltest;
CREATE TABLE  nulltest
 (
  OWNER           varchar2(30)                  NULL,
  OBJECT_NAME     varchar2(128)                 NULL,
  SUBOBJECT_NAME  varchar2(30)                  NULL,
  OBJECT_ID       NUMBER                       NULL,
  DATA_OBJECT_ID  NUMBER                       NULL,
  OBJECT_TYPE     varchar2(19)                  NULL,
  CREATED         date                     NULL,
  LAST_DDL_TIME   date                     NULL,
  TIMESTAMP       varchar2(19)                  NULL,
  STATUS          varchar2(7)                   NULL,
  TEMPORARY       varchar2(1)                   NULL,
  GENERATED       varchar2(1)                   NULL,
  SECONDARY       varchar2(1)                   NULL,
  NAMESPACE       NUMBER                       NULL,
  EDITION_NAME    varchar2(30)                  NULL
 )
tablespace app1;
