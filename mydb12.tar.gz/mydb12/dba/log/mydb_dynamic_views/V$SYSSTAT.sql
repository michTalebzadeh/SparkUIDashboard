 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 STATISTIC#									   NUMBER
 NAME										   VARCHAR2(64)
 CLASS										   NUMBER
 VALUE										   NUMBER
 STAT_ID									   NUMBER

