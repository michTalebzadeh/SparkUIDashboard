DROP TABLE t1;
CREATE TABLE t1
AS
SELECT *
FROM
   (
     SELECT * 
       FROM all_objects
       WHERE rownum <=60000
   ) V1,
   (
     SELECT 
       rownum RN
     FROM
       dual
     CONNECT BY
     LEVEL <=200
    )
/
EXEC DBMS_STATS.GATHER_TABLE_STATS(ownname=>user,tabname=>'T1',estimate_percent=>100)
SELECT
    num_rows
  , blocks
FROM
  user_tables
WHERE
  table_name ='T1';
exit  
