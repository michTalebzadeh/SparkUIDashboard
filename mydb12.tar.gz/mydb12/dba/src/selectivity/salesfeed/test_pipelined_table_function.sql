--exec dbms_monitor.session_trace_enable( waits=>true );
--ALTER SESSION SET TRACEFILE_IDENTIFIER = 'PTF';
set autotrace on
set timing on
SELECT COUNT(1) FROM  TABLE(sales_array);
exit
