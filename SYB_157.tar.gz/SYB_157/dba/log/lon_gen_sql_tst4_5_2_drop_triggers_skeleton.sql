                 
 use skeleton
go 

                                                                                                                                                                                                                                                                                 
 drop trigger delBOSettInst
go                                                                                                                                                                                                                                                   
 drop trigger delcxcdevt
go                                                                                                                                                                                                                                                      
 drop trigger delcxcfcevt
go                                                                                                                                                                                                                                                     
 drop trigger delcxcontxt
go                                                                                                                                                                                                                                                     
 drop trigger delcxevents
go                                                                                                                                                                                                                                                     
 drop trigger delcxfutfdvdate
go                                                                                                                                                                                                                                                 
 drop trigger delcxinvdtl
go                                                                                                                                                                                                                                                     
 drop trigger delcxinventory
go                                                                                                                                                                                                                                                  
 drop trigger delcxswpevt
go                                                                                                                                                                                                                                                     
 drop trigger delcxswpfxa
go                                                                                                                                                                                                                                                     
 drop trigger deldef_average
go                                                                                                                                                                                                                                                  
 drop trigger deldef_future
go                                                                                                                                                                                                                                                   
 drop trigger delemu_can_cor
go                                                                                                                                                                                                                                                  
 drop trigger deleqcorpact
go                                                                                                                                                                                                                                                    
 drop trigger deleqstkevt
go                                                                                                                                                                                                                                                     
 drop trigger delexinsdef
go                                                                                                                                                                                                                                                     
 drop trigger delexstktyp
go                                                                                                                                                                                                                                                     
 drop trigger delfxsplitres
go                                                                                                                                                                                                                                                   
 drop trigger delgroupprofile
go                                                                                                                                                                                                                                                 
 drop trigger delhistixderevt
go                                                                                                                                                                                                                                                 
 drop trigger delixbndinv
go                                                                                                                                                                                                                                                     
 drop trigger delixcfcevt
go                                                                                                                                                                                                                                                     
 drop trigger delixdercpi
go                                                                                                                                                                                                                                                     
 drop trigger delixderdef
go                                                                                                                                                                                                                                                     
 drop trigger delixderevt
go                                                                                                                                                                                                                                                     
 drop trigger delixderhol
go                                                                                                                                                                                                                                                     
 drop trigger delixderrei
go                                                                                                                                                                                                                                                     
 drop trigger delixgiss
go                                                                                                                                                                                                                                                       
 drop trigger delixinsmkm
go                                                                                                                                                                                                                                                     
 drop trigger delixldtmp
go                                                                                                                                                                                                                                                      
 drop trigger delixmmkzc
go                                                                                                                                                                                                                                                      
 drop trigger delixozccurve
go                                                                                                                                                                                                                                                   
 drop trigger delixozcfra
go                                                                                                                                                                                                                                                     
 drop trigger delixozchol
go                                                                                                                                                                                                                                                     
 drop trigger delixozcswap
go                                                                                                                                                                                                                                                    
 drop trigger delixozcweight
go                                                                                                                                                                                                                                                  
 drop trigger delixpayrec
go                                                                                                                                                                                                                                                     
 drop trigger delixratgsel
go                                                                                                                                                                                                                                                    
 drop trigger delixrinvbk
go                                                                                                                                                                                                                                                     
 drop trigger delixrpcevt
go                                                                                                                                                                                                                                                     
 drop trigger delixrpcomt
go                                                                                                                                                                                                                                                     
 drop trigger delixrpevt
go                                                                                                                                                                                                                                                      
 drop trigger delixrpinst
go                                                                                                                                                                                                                                                     
 drop trigger delixrppool
go                                                                                                                                                                                                                                                     
 drop trigger delixsumimrghist
go                                                                                                                                                                                                                                                
 drop trigger delixsumimrgtrns
go                                                                                                                                                                                                                                                
 drop trigger delixswpbrk
go                                                                                                                                                                                                                                                     
 drop trigger delixswpcpn
go                                                                                                                                                                                                                                                     
 drop trigger delixswpevt
go                                                                                                                                                                                                                                                     
 drop trigger delixswpopt
go                                                                                                                                                                                                                                                     
 drop trigger delixvolcur
go                                                                                                                                                                                                                                                     
 drop trigger delixwavarc
go                                                                                                                                                                                                                                                     
 drop trigger delixwavnum
go                                                                                                                                                                                                                                                     
 drop trigger delmanvalue
go                                                                                                                                                                                                                                                     
 drop trigger deloptexrlog
go                                                                                                                                                                                                                                                    
 drop trigger delprtr_group
go                                                                                                                                                                                                                                                   
 drop trigger delsbcancsh
go                                                                                                                                                                                                                                                     
 drop trigger delsbcnfevt
go                                                                                                                                                                                                                                                     
 drop trigger delsbcnftrk
go                                                                                                                                                                                                                                                     
 drop trigger delsbpaytrk
go                                                                                                                                                                                                                                                     
 drop trigger delsbrecipt
go                                                                                                                                                                                                                                                     
 drop trigger delsbretevt
go                                                                                                                                                                                                                                                     
 drop trigger delsbverify
go                                                                                                                                                                                                                                                     
 drop trigger delsecurity_config
go                                                                                                                                                                                                                                              
 drop trigger delswap_cltr_side
go                                                                                                                                                                                                                                               
 drop trigger delswap_tmpl_dayrul
go                                                                                                                                                                                                                                             
 drop trigger delswap_tmpl_fff
go                                                                                                                                                                                                                                                
 drop trigger delsyavcont
go                                                                                                                                                                                                                                                     
 drop trigger delsyavspot
go                                                                                                                                                                                                                                                     
 drop trigger delsybaddat
go                                                                                                                                                                                                                                                     
 drop trigger delsybndcpn
go                                                                                                                                                                                                                                                     
 drop trigger delsybuscet
go                                                                                                                                                                                                                                                     
 drop trigger delsycancor
go                                                                                                                                                                                                                                                     
 drop trigger delsycancorrect
go                                                                                                                                                                                                                                                 
 drop trigger delsycffix
go                                                                                                                                                                                                                                                      
 drop trigger delsyclarc
go                                                                                                                                                                                                                                                      
 drop trigger delsycnfhed
go                                                                                                                                                                                                                                                     
 drop trigger delsycntr20
go                                                                                                                                                                                                                                                     
 drop trigger delsycombo
go                                                                                                                                                                                                                                                      
 drop trigger delsycurpair
go                                                                                                                                                                                                                                                    
 drop trigger delsydeskbook
go                                                                                                                                                                                                                                                   
 drop trigger delsydeskvalues
go                                                                                                                                                                                                                                                 
 drop trigger delsyextcsh
go                                                                                                                                                                                                                                                     
 drop trigger delsyextol_def
go                                                                                                                                                                                                                                                  
 drop trigger delsyfutinf
go                                                                                                                                                                                                                                                     
 drop trigger delsylimsubdef
go                                                                                                                                                                                                                                                  
 drop trigger delsylimterm
go                                                                                                                                                                                                                                                    
 drop trigger delsylimviolate
go                                                                                                                                                                                                                                                 
 drop trigger delsymaptn
go                                                                                                                                                                                                                                                      
 drop trigger delsyphyfee
go                                                                                                                                                                                                                                                     
 drop trigger delsyremark
go                                                                                                                                                                                                                                                     
 drop trigger delsyrp_acpt_ver
go                                                                                                                                                                                                                                                
 drop trigger delsytrans_bar
go                                                                                                                                                                                                                                                  
 drop trigger delsytrans_corp
go                                                                                                                                                                                                                                                 
 drop trigger delsytrans_dig
go                                                                                                                                                                                                                                                  
 drop trigger delsytrans_rel
go                                                                                                                                                                                                                                                  
 drop trigger delsytrans_tax
go                                                                                                                                                                                                                                                  
 drop trigger delsytrdoc
go                                                                                                                                                                                                                                                      
 drop trigger delsytrdtransfer
go                                                                                                                                                                                                                                                
 drop trigger delsytrspot
go                                                                                                                                                                                                                                                     
 drop trigger delsyverify
go                                                                                                                                                                                                                                                     
 drop trigger delsyverify_evt
go                                                                                                                                                                                                                                                 
 drop trigger deltrdefext_fields
go                                                                                                                                                                                                                                              
 drop trigger deltrdefext_values
go                                                                                                                                                                                                                                              
 drop trigger deltrext_values
go                                                                                                                                                                                                                                                 
 drop trigger deltrextend_fields
go                                                                                                                                                                                                                                              
 drop trigger deltrextend_set
go                                                                                                                                                                                                                                                 
 drop trigger deltrextend_values
go                                                                                                                                                                                                                                              
 drop trigger deltrlink
go                                                                                                                                                                                                                                                       
 drop trigger deluditradeval
go                                                                                                                                                                                                                                                  
 drop trigger delzccash
go                                                                                                                                                                                                                                                       
 drop trigger delzccurve
go                                                                                                                                                                                                                                                      
 drop trigger delzcdef
go                                                                                                                                                                                                                                                        
 drop trigger delzcfra
go                                                                                                                                                                                                                                                        
 drop trigger delzchol
go                                                                                                                                                                                                                                                        
 drop trigger delzcswap
go                                                                                                                                                                                                                                                       
 drop trigger delzcweight
go                                                                                                                                                                                                                                                     
 drop trigger insBOSettInst
go                                                                                                                                                                                                                                                   
 drop trigger insapi_dgmsgs_tofnx
go                                                                                                                                                                                                                                             
 drop trigger inscommodity
go                                                                                                                                                                                                                                                    
 drop trigger inscxblt2i_list
go                                                                                                                                                                                                                                                 
 drop trigger inscxblt2i_marsk
go                                                                                                                                                                                                                                                
 drop trigger inscxblt2i_pos
go                                                                                                                                                                                                                                                  
 drop trigger inscxblt2i_rats
go                                                                                                                                                                                                                                                 
 drop trigger inscxblt2i_state
go                                                                                                                                                                                                                                                
 drop trigger inscxblt2i_trd
go                                                                                                                                                                                                                                                  
 drop trigger inscxcdevt
go                                                                                                                                                                                                                                                      
 drop trigger inscxcfcevt
go                                                                                                                                                                                                                                                     
 drop trigger inscxcontxt
go                                                                                                                                                                                                                                                     
 drop trigger inscxedp
go                                                                                                                                                                                                                                                        
 drop trigger inscxevents
go                                                                                                                                                                                                                                                     
 drop trigger inscxfutfdvdate
go                                                                                                                                                                                                                                                 
 drop trigger inscxinvdtl
go                                                                                                                                                                                                                                                     
 drop trigger inscxinventory
go                                                                                                                                                                                                                                                  
 drop trigger inscxswpevt
go                                                                                                                                                                                                                                                     
 drop trigger inscxswpfxa
go                                                                                                                                                                                                                                                     
 drop trigger insdef_average
go                                                                                                                                                                                                                                                  
 drop trigger insdef_future
go                                                                                                                                                                                                                                                   
 drop trigger insemu_can_cor
go                                                                                                                                                                                                                                                  
 drop trigger inseqcorpact
go                                                                                                                                                                                                                                                    
 drop trigger insexinsdef
go                                                                                                                                                                                                                                                     
 drop trigger insfxsplitres
go                                                                                                                                                                                                                                                   
 drop trigger insgroupprofile
go                                                                                                                                                                                                                                                 
 drop trigger inshistixderevt
go                                                                                                                                                                                                                                                 
 drop trigger insixbndinv
go                                                                                                                                                                                                                                                     
 drop trigger insixcfcevt
go                                                                                                                                                                                                                                                     
 drop trigger insixdercpi
go                                                                                                                                                                                                                                                     
 drop trigger insixderdef
go                                                                                                                                                                                                                                                     
 drop trigger insixderevt
go                                                                                                                                                                                                                                                     
 drop trigger insixderhol
go                                                                                                                                                                                                                                                     
 drop trigger insixderrei
go                                                                                                                                                                                                                                                     
 drop trigger insixgiss
go                                                                                                                                                                                                                                                       
 drop trigger insixinsmkm
go                                                                                                                                                                                                                                                     
 drop trigger insixldtmp
go                                                                                                                                                                                                                                                      
 drop trigger insixmmkinf
go                                                                                                                                                                                                                                                     
 drop trigger insixmmkzc
go                                                                                                                                                                                                                                                      
 drop trigger insixozccurve
go                                                                                                                                                                                                                                                   
 drop trigger insixozcfra
go                                                                                                                                                                                                                                                     
 drop trigger insixozchol
go                                                                                                                                                                                                                                                     
 drop trigger insixozcswap
go                                                                                                                                                                                                                                                    
 drop trigger insixozcweight
go                                                                                                                                                                                                                                                  
 drop trigger insixpayrec
go                                                                                                                                                                                                                                                     
 drop trigger insixratgdef
go                                                                                                                                                                                                                                                    
 drop trigger insixratgsel
go                                                                                                                                                                                                                                                    
 drop trigger insixrinvbk
go                                                                                                                                                                                                                                                     
 drop trigger insixrpcevt
go                                                                                                                                                                                                                                                     
 drop trigger insixrpcomt
go                                                                                                                                                                                                                                                     
 drop trigger insixrpevt
go                                                                                                                                                                                                                                                      
 drop trigger insixrpinst
go                                                                                                                                                                                                                                                     
 drop trigger insixrppool
go                                                                                                                                                                                                                                                     
 drop trigger insixsumimrghist
go                                                                                                                                                                                                                                                
 drop trigger insixsumimrgtrns
go                                                                                                                                                                                                                                                
 drop trigger insixswapbond
go                                                                                                                                                                                                                                                   
 drop trigger insixswpbrk
go                                                                                                                                                                                                                                                     
 drop trigger insixswpcpn
go                                                                                                                                                                                                                                                     
 drop trigger insixswpevt
go                                                                                                                                                                                                                                                     
 drop trigger insixswpopt
go                                                                                                                                                                                                                                                     
 drop trigger insixvolcur
go                                                                                                                                                                                                                                                     
 drop trigger insixwavarc
go                                                                                                                                                                                                                                                     
 drop trigger insixwavnum
go                                                                                                                                                                                                                                                     
 drop trigger insixwildcard
go                                                                                                                                                                                                                                                   
 drop trigger insmanvalue
go                                                                                                                                                                                                                                                     
 drop trigger insoptexrlog
go                                                                                                                                                                                                                                                    
 drop trigger insreu_reject
go                                                                                                                                                                                                                                                   
 drop trigger insrtcurconfig
go                                                                                                                                                                                                                                                  
 drop trigger inssbcancsh
go                                                                                                                                                                                                                                                     
 drop trigger inssbcnfevt
go                                                                                                                                                                                                                                                     
 drop trigger inssbcnftrk
go                                                                                                                                                                                                                                                     
 drop trigger inssbpaytrk
go                                                                                                                                                                                                                                                     
 drop trigger inssbretevt
go                                                                                                                                                                                                                                                     
 drop trigger inssbverify
go                                                                                                                                                                                                                                                     
 drop trigger inssecurity_config
go                                                                                                                                                                                                                                              
 drop trigger insswap_cltr_side
go                                                                                                                                                                                                                                               
 drop trigger insswap_tmpl_dayrul
go                                                                                                                                                                                                                                             
 drop trigger insswap_tmpl_fff
go                                                                                                                                                                                                                                                
 drop trigger inssyavcont
go                                                                                                                                                                                                                                                     
 drop trigger inssyavspot
go                                                                                                                                                                                                                                                     
 drop trigger inssybaddat
go                                                                                                                                                                                                                                                     
 drop trigger inssybndcpn
go                                                                                                                                                                                                                                                     
 drop trigger inssybook
go                                                                                                                                                                                                                                                       
 drop trigger inssycancorrect
go                                                                                                                                                                                                                                                 
 drop trigger inssycffix
go                                                                                                                                                                                                                                                      
 drop trigger inssyclarc
go                                                                                                                                                                                                                                                      
 drop trigger inssycnfhed
go                                                                                                                                                                                                                                                     
 drop trigger inssycntr
go                                                                                                                                                                                                                                                       
 drop trigger inssycntr20
go                                                                                                                                                                                                                                                     
 drop trigger inssycombo
go                                                                                                                                                                                                                                                      
 drop trigger inssycurpair
go                                                                                                                                                                                                                                                    
 drop trigger inssydeskvalues
go                                                                                                                                                                                                                                                 
 drop trigger inssyextcsh
go                                                                                                                                                                                                                                                     
 drop trigger inssyextol_def
go                                                                                                                                                                                                                                                  
 drop trigger inssyfutinf
go                                                                                                                                                                                                                                                     
 drop trigger inssylimterm
go                                                                                                                                                                                                                                                    
 drop trigger inssymaptn
go                                                                                                                                                                                                                                                      
 drop trigger inssyphyfee
go                                                                                                                                                                                                                                                     
 drop trigger inssypurp
go                                                                                                                                                                                                                                                       
 drop trigger inssyremark
go                                                                                                                                                                                                                                                     
 drop trigger inssytrans_bar
go                                                                                                                                                                                                                                                  
 drop trigger inssytrans_corp
go                                                                                                                                                                                                                                                 
 drop trigger inssytrans_dig
go                                                                                                                                                                                                                                                  
 drop trigger inssytrans_rel
go                                                                                                                                                                                                                                                  
 drop trigger inssytrans_tax
go                                                                                                                                                                                                                                                  
 drop trigger inssytrdoc
go                                                                                                                                                                                                                                                      
 drop trigger inssytrdtransfer
go                                                                                                                                                                                                                                                
 drop trigger inssytrspot
go                                                                                                                                                                                                                                                     
 drop trigger inssyverify
go                                                                                                                                                                                                                                                     
 drop trigger inssyverify_evt
go                                                                                                                                                                                                                                                 
 drop trigger instrdefext_fields
go                                                                                                                                                                                                                                              
 drop trigger instrdefext_values
go                                                                                                                                                                                                                                              
 drop trigger instrext_values
go                                                                                                                                                                                                                                                 
 drop trigger instrextend_fields
go                                                                                                                                                                                                                                              
 drop trigger instrextend_set
go                                                                                                                                                                                                                                                 
 drop trigger instrextend_values
go                                                                                                                                                                                                                                              
 drop trigger instrlink
go                                                                                                                                                                                                                                                       
 drop trigger insuditradeval
go                                                                                                                                                                                                                                                  
 drop trigger insuser_group
go                                                                                                                                                                                                                                                   
 drop trigger updBOSettInst
go                                                                                                                                                                                                                                                   
 drop trigger updcommodity
go                                                                                                                                                                                                                                                    
 drop trigger updcprisklt
go                                                                                                                                                                                                                                                     
 drop trigger updcurrency_def
go                                                                                                                                                                                                                                                 
 drop trigger updcxcdevt
go                                                                                                                                                                                                                                                      
 drop trigger updcxcfcevt
go                                                                                                                                                                                                                                                     
 drop trigger updcxcontxt
go                                                                                                                                                                                                                                                     
 drop trigger updcxevents
go                                                                                                                                                                                                                                                     
 drop trigger updcxfutfdvdate
go                                                                                                                                                                                                                                                 
 drop trigger updcxinvdtl
go                                                                                                                                                                                                                                                     
 drop trigger updcxinventory
go                                                                                                                                                                                                                                                  
 drop trigger updcxprstrike
go                                                                                                                                                                                                                                                   
 drop trigger updcxprvj
go                                                                                                                                                                                                                                                       
 drop trigger updcxswpevt
go                                                                                                                                                                                                                                                     
 drop trigger updcxswpfxa
go                                                                                                                                                                                                                                                     
 drop trigger upddef_average
go                                                                                                                                                                                                                                                  
 drop trigger upddef_ccypair
go                                                                                                                                                                                                                                                  
 drop trigger upddef_currency
go                                                                                                                                                                                                                                                 
 drop trigger upddef_future
go                                                                                                                                                                                                                                                   
 drop trigger updemu_can_cor
go                                                                                                                                                                                                                                                  
 drop trigger updeqcorpact
go                                                                                                                                                                                                                                                    
 drop trigger updexec_map
go                                                                                                                                                                                                                                                     
 drop trigger updexinsdef
go                                                                                                                                                                                                                                                     
 drop trigger updfxsplitres
go                                                                                                                                                                                                                                                   
 drop trigger updhistixderevt
go                                                                                                                                                                                                                                                 
 drop trigger updixbndinv
go                                                                                                                                                                                                                                                     
 drop trigger updixbndtyp
go                                                                                                                                                                                                                                                     
 drop trigger updixcfcevt
go                                                                                                                                                                                                                                                     
 drop trigger updixdercpi
go                                                                                                                                                                                                                                                     
 drop trigger updixderdef
go                                                                                                                                                                                                                                                     
 drop trigger updixderevt
go                                                                                                                                                                                                                                                     
 drop trigger updixderhol
go                                                                                                                                                                                                                                                     
 drop trigger updixderrei
go                                                                                                                                                                                                                                                     
 drop trigger updixgiss
go                                                                                                                                                                                                                                                       
 drop trigger updixinsexchmm_rs
go                                                                                                                                                                                                                                               
 drop trigger updixldtmp
go                                                                                                                                                                                                                                                      
 drop trigger updixmmkinf
go                                                                                                                                                                                                                                                     
 drop trigger updixmmkzc
go                                                                                                                                                                                                                                                      
 drop trigger updixozccurve
go                                                                                                                                                                                                                                                   
 drop trigger updixozcfra
go                                                                                                                                                                                                                                                     
 drop trigger updixozchol
go                                                                                                                                                                                                                                                     
 drop trigger updixozcswap
go                                                                                                                                                                                                                                                    
 drop trigger updixozcweight
go                                                                                                                                                                                                                                                  
 drop trigger updixpayrec
go                                                                                                                                                                                                                                                     
 drop trigger updixratgsel
go                                                                                                                                                                                                                                                    
 drop trigger updixrinvbk
go                                                                                                                                                                                                                                                     
 drop trigger updixrpcevt
go                                                                                                                                                                                                                                                     
 drop trigger updixrpcomt
go                                                                                                                                                                                                                                                     
 drop trigger updixrpevt
go                                                                                                                                                                                                                                                      
 drop trigger updixrpinst
go                                                                                                                                                                                                                                                     
 drop trigger updixrppool
go                                                                                                                                                                                                                                                     
 drop trigger updixsimdef
go                                                                                                                                                                                                                                                     
 drop trigger updixsimrt
go                                                                                                                                                                                                                                                      
 drop trigger updixsumimrghist
go                                                                                                                                                                                                                                                
 drop trigger updixsumimrgtrns
go                                                                                                                                                                                                                                                
 drop trigger updixswapbond
go                                                                                                                                                                                                                                                   
 drop trigger updixswpbrk
go                                                                                                                                                                                                                                                     
 drop trigger updixswpcpn
go                                                                                                                                                                                                                                                     
 drop trigger updixswpevt
go                                                                                                                                                                                                                                                     
 drop trigger updixswpopt
go                                                                                                                                                                                                                                                     
 drop trigger updixvolcur
go                                                                                                                                                                                                                                                     
 drop trigger updixwavarc
go                                                                                                                                                                                                                                                     
 drop trigger updixwavnum
go                                                                                                                                                                                                                                                     
 drop trigger updixwildcard
go                                                                                                                                                                                                                                                   
 drop trigger updmanvalue
go                                                                                                                                                                                                                                                     
 drop trigger updoptexrlog
go                                                                                                                                                                                                                                                    
 drop trigger updrtcurconfig
go                                                                                                                                                                                                                                                  
 drop trigger updsbcancsh
go                                                                                                                                                                                                                                                     
 drop trigger updsbcnfevt
go                                                                                                                                                                                                                                                     
 drop trigger updsbcnftrk
go                                                                                                                                                                                                                                                     
 drop trigger updsbpaytrk
go                                                                                                                                                                                                                                                     
 drop trigger updsbretevt
go                                                                                                                                                                                                                                                     
 drop trigger updsbverify
go                                                                                                                                                                                                                                                     
 drop trigger updsecurity_config
go                                                                                                                                                                                                                                              
 drop trigger updswap_cltr_side
go                                                                                                                                                                                                                                               
 drop trigger updswap_tmpl_dayrul
go                                                                                                                                                                                                                                             
 drop trigger updswap_tmpl_fff
go                                                                                                                                                                                                                                                
 drop trigger updsyavcont
go                                                                                                                                                                                                                                                     
 drop trigger updsyavspot
go                                                                                                                                                                                                                                                     
 drop trigger updsybaddat
go                                                                                                                                                                                                                                                     
 drop trigger updsybndcpn
go                                                                                                                                                                                                                                                     
 drop trigger updsybook
go                                                                                                                                                                                                                                                       
 drop trigger updsycancor
go                                                                                                                                                                                                                                                     
 drop trigger updsycancorrect
go                                                                                                                                                                                                                                                 
 drop trigger updsycffix
go                                                                                                                                                                                                                                                      
 drop trigger updsyclarc
go                                                                                                                                                                                                                                                      
 drop trigger updsycnfhed
go                                                                                                                                                                                                                                                     
 drop trigger updsycntr
go                                                                                                                                                                                                                                                       
 drop trigger updsycntr20
go                                                                                                                                                                                                                                                     
 drop trigger updsycombo
go                                                                                                                                                                                                                                                      
 drop trigger updsycurpair
go                                                                                                                                                                                                                                                    
 drop trigger updsydeskvalues
go                                                                                                                                                                                                                                                 
 drop trigger updsyextcsh
go                                                                                                                                                                                                                                                     
 drop trigger updsyfutinf
go                                                                                                                                                                                                                                                     
 drop trigger updsyfuture
go                                                                                                                                                                                                                                                     
 drop trigger updsyfutval
go                                                                                                                                                                                                                                                     
 drop trigger updsyfutval_rs
go                                                                                                                                                                                                                                                  
 drop trigger updsylimgrp
go                                                                                                                                                                                                                                                     
 drop trigger updsymaptn
go                                                                                                                                                                                                                                                      
 drop trigger updsyoptval_rs
go                                                                                                                                                                                                                                                  
 drop trigger updsyphyfee
go                                                                                                                                                                                                                                                     
 drop trigger updsypurp
go                                                                                                                                                                                                                                                       
 drop trigger updsyremark
go                                                                                                                                                                                                                                                     
 drop trigger updsysched
go                                                                                                                                                                                                                                                      
 drop trigger updsytrans_bar
go                                                                                                                                                                                                                                                  
 drop trigger updsytrans_corp
go                                                                                                                                                                                                                                                 
 drop trigger updsytrans_dig
go                                                                                                                                                                                                                                                  
 drop trigger updsytrans_rel
go                                                                                                                                                                                                                                                  
 drop trigger updsytrans_tax
go                                                                                                                                                                                                                                                  
 drop trigger updsytrdoc
go                                                                                                                                                                                                                                                      
 drop trigger updsytrdtransfer
go                                                                                                                                                                                                                                                
 drop trigger updsytrspot
go                                                                                                                                                                                                                                                     
 drop trigger updsyverify
go                                                                                                                                                                                                                                                     
 drop trigger updsyverify_evt
go                                                                                                                                                                                                                                                 
 drop trigger updtrdefext_fields
go                                                                                                                                                                                                                                              
 drop trigger updtrdefext_values
go                                                                                                                                                                                                                                              
 drop trigger updtrext_values
go                                                                                                                                                                                                                                                 
 drop trigger updtrextend_fields
go                                                                                                                                                                                                                                              
 drop trigger updtrextend_set
go                                                                                                                                                                                                                                                 
 drop trigger updtrextend_values
go                                                                                                                                                                                                                                              
 drop trigger updtrlink
go                                                                                                                                                                                                                                                       
 drop trigger upduditradeval
go                                                                                                                                                                                                                                                  
 drop trigger updzccash
go                                                                                                                                                                                                                                                       
 drop trigger updzccurve
go                                                                                                                                                                                                                                                      
 drop trigger updzcdef
go                                                                                                                                                                                                                                                        
 drop trigger updzcfra
go                                                                                                                                                                                                                                                        
 drop trigger updzchol
go                                                                                                                                                                                                                                                        
 drop trigger updzcswap
go                                                                                                                                                                                                                                                       
 drop trigger updzcweight
go                                                                                                                                                                                                                                                     

