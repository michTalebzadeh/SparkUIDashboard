online database ledom
go
use ledom
go
dbcc settrunc(ltm,ignore)
go
