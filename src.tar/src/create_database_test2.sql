USE master
go

CREATE DATABASE test2
      ON datadev02_HDD = 100
     LOG ON logdev03_HDD = 50
FOR LOAD
go
ALTER DATABASE test2
     ON datadev02_HDD = 500
     LOG ON logdev03_HDD = 250
       , logdev03_HDD = 800
FOR LOAD
go
ALTER DATABASE test2
     ON datadev02_HDD = 442
       , datadev02_HDD = 58
     LOG ON logdev03_HDD = 1000
       , logdev03_HDD = 4000
FOR LOAD
go
ALTER DATABASE test2
     ON datadev02_HDD = 9568
FOR LOAD
go


