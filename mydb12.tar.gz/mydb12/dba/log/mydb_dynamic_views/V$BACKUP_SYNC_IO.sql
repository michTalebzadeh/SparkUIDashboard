 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 SERIAL 									   NUMBER
 USE_COUNT									   NUMBER
 RMAN_STATUS_RECID								   NUMBER
 RMAN_STATUS_STAMP								   NUMBER
 DEVICE_TYPE									   VARCHAR2(17)
 TYPE										   VARCHAR2(9)
 STATUS 									   VARCHAR2(11)
 FILENAME									   VARCHAR2(513)
 SET_COUNT									   NUMBER
 SET_STAMP									   NUMBER
 BUFFER_SIZE									   NUMBER
 BUFFER_COUNT									   NUMBER
 TOTAL_BYTES									   NUMBER
 OPEN_TIME									   DATE
 CLOSE_TIME									   DATE
 ELAPSED_TIME									   NUMBER
 MAXOPENFILES									   NUMBER
 BYTES										   NUMBER
 EFFECTIVE_BYTES_PER_SECOND							   NUMBER
 IO_COUNT									   NUMBER
 IO_TIME_TOTAL									   NUMBER
 IO_TIME_MAX									   NUMBER
 DISCRETE_BYTES_PER_SECOND							   NUMBER

