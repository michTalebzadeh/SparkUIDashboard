create or replace function mystddev
(
        i_table_name      IN      varchar2(30) DEFAULT NULL,
        i_column_name     IN      varchar2(30) DEFAULT NULL
)
RETURN FLOAT
AS
  e_table_name	EXCEPTION;
  e_column_name EXCEPTION;
BEGIN
  BEGIN		-- Input parameter validation
    -- check for inputs
    IF i_table_name IS NULL
    THEN
      RAISE e_table_name;
    END IF;
    IF i_column_name is NULL
    THEN
      RAISE e_column_name
    IF i_nr <= 1
    END IF;
  EXCEPTION
    WHEN e_table_name
    THEN
      DBMS_OUTPUT.PUT_LINE('mystddev: Missing/empty parameter, must supply table name');
      RETURN -1;
    WHEN e_column_name
    THEN
      DBMS_OUTPUT.PUT_LINE('mystddev: Missing/empty parameter, must supply column name');
      RETURN -1;
  END;		-- End input parameter validation
  BEGIN		-- Check that row exists in next_rowid 
    :
    SELECT nxr_name
    INTO v_table_name
    FROM hts_next_rowid
    WHERE nxr_name = i_table_name;
  EXCEPTION
    WHEN NO_DATA_FOUND
    THEN
      DBMS_OUTPUT.PUT_LINE('mystddev_sp: No record found in hts_next_rowid table for '||i_table_name||'!');
      RETURN -101;
  END;         -- end check that row exists in next_rowid
--
  BEGIN        -- Begin update block
    UPDATE hts_next_rowid
    SET nxr_next_rowid = nxr_next_rowid + v_nr
    WHERE nxr_name = i_table_name
    RETURNING nxr_next_rowid - v_nr INTO v_nxr_next_rowid;
    IF SQL%ROWCOUNT = 0 OR SQLCODE != 0
    THEN
      RAISE e_update;
    END IF;
    COMMIT;
    RETURN v_nxr_next_rowid;
  EXCEPTION
    WHEN e_update
    THEN
      DBMS_OUTPUT.PUT_LINE('mystddev_sp: Could not update nxr_next_rowid in hts_next_rowid table for '||i_table_name||'!');
      ROLLBACK;
      RETURN -100;
    WHEN OTHERS
    THEN
      RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM,true);
      RETURN -100;
  END;		-- End update block
--
EXCEPTION
  WHEN OTHERS
  THEN
        DBMS_OUTPUT.PUT('Exception encountered! (');
        DBMS_OUTPUT.PUT_LINE(SQLCODE || '): ' || SQLERRM);
	RETURN -100;
END mystddev;
/
