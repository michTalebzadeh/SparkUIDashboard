use skeleton
go
if exists(select 1 from sysobjects where name = 'test1_insert_sp' and type = 'P')
begin
        print "dropping procedure test1_insert_sp"
        drop procedure test1_insert_sp
end
go
CREATE PROCEDURE test1_insert_sp
(
	@rows	int		= null
)
AS
BEGIN
  DECLARE @rows_inserted	int
  DECLARE @now		datetime
  DECLARE @test1Id	int
  SELECT @now = getdate()
  SELECT @rows_inserted = 0

  IF @rows IS NULL
    SELECT @rows = 1000
  WHILE (@rows_inserted <@rows)
  BEGIN
  --  BEGIN TRAN
    EXECUTE @test1Id = get_next_rowid_sp "test1",1
    --print "Got new test1_id = %1!", @test1Id 
    INSERT test1
    (
      test1_id,
      test1_def1,
      test1_def2,
      test1_dt_stamp,
      test1_user_stamp
    )
    VALUES
    (
      @test1Id,
      @@servername,
      'my crap',
      getdate(),
      suser_name()
    )
    if @@error != 0 or @@transtate = 3
    begin
      select 'problem inserting into test1'
      if @@trancount > 0 rollback tran
        return -1
    end
     commit tran
    SELECT @rows_inserted = @rows_inserted + 1
    --IF @rows_inserted%1000 = 0
    --  commit tran
  END
END
go
sp_help test1_insert_sp
go
exit
