 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 HS_SESSION_ID									   NUMBER
 AGENT_ID									   NUMBER
 SID										   NUMBER
 DB_LINK									   VARCHAR2(128)
 DB_LINK_OWNER									   NUMBER
 STARTTIME									   DATE

