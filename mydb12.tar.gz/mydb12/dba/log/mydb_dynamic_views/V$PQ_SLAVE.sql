 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SLAVE_NAME									   VARCHAR2(4)
 STATUS 									   VARCHAR2(4)
 SESSIONS									   NUMBER
 IDLE_TIME_CUR									   NUMBER
 BUSY_TIME_CUR									   NUMBER
 CPU_SECS_CUR									   NUMBER
 MSGS_SENT_CUR									   NUMBER
 MSGS_RCVD_CUR									   NUMBER
 IDLE_TIME_TOTAL								   NUMBER
 BUSY_TIME_TOTAL								   NUMBER
 CPU_SECS_TOTAL 								   NUMBER
 MSGS_SENT_TOTAL								   NUMBER
 MSGS_RCVD_TOTAL								   NUMBER

