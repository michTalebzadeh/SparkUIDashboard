execute dbms_random.seed(0)
DROP TABLE dummy2;
CREATE TABLE dummy2
TABLESPACE APP1
AS
WITH GENERATOR AS (
    SELECT            rownum            id
    FROM        dual
    CONNECT BY
                rownum <= 1000
)
SELECT
       rownum                                          id
     , trunc((rownum - 1) / 1000)                clustered
     , mod(rownum - 1,1000)                      scattered
     , trunc(dbms_random.value(0,1000))          randomised
     , substr(dbms_random.string('A',15),1,15)   random_string
     , lpad(rownum,10)                           rownumchar
     , rpad('x',10,'x')                          xchar
     , trunc(dbms_random.value(0,5))             n1
FROM
    generator   g1,
    generator   g2
;
ALTER TABLE dummy2 ADD CONSTRAINT dummy2_pk PRIMARY KEY(id);
select count(1) from dummy2;
exit
