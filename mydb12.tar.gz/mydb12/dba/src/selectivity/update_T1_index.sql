exec dbms_monitor.session_trace_enable( waits=>true );
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'index';
update T1
set padding = rpad('y',199)||'x'
where   n1 = 2
and	ind_pad <= rpad('x',39)||'x'
and     n2      < 3;
exec dbms_monitor.session_trace_disable;
exit
