SELECT sid, substr(event,1,40) AS event,total_waits, time_waited
FROM v$session_event
where 
	event IN ('Disk file operations I/O','db file scattered read','db file sequential read','direct path read')
and
	total_waits> 0
and
	 time_waited> 0
ORDER BY 2,4;
exit
