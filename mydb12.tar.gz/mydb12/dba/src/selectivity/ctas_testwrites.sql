alter system flush buffer_cache;
alter system flush shared_pool;
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'ssdtester_ctas_testwrites';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
CREATE TABLE testwrites
AS SELECT * FROM tdash
WHERE ROWNUM <= 1000000;
commit;
exit
