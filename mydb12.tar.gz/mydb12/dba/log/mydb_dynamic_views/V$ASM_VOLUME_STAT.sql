 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 GROUP_NUMBER									   NUMBER
 VOLUME_NAME									   VARCHAR2(30)
 COMPOUND_INDEX 								   NUMBER
 VOLUME_NUMBER									   NUMBER
 READS										   NUMBER
 WRITES 									   NUMBER
 READ_ERRS									   NUMBER
 WRITE_ERRS									   NUMBER
 READ_TIME									   NUMBER
 WRITE_TIME									   NUMBER
 BYTES_READ									   NUMBER
 BYTES_WRITTEN									   NUMBER

