 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   NUMBER
 SEQ#										   NUMBER
 EVENT# 									   NUMBER
 EVENT										   VARCHAR2(64)
 P1TEXT 									   VARCHAR2(64)
 P1										   NUMBER
 P2TEXT 									   VARCHAR2(64)
 P2										   NUMBER
 P3TEXT 									   VARCHAR2(64)
 P3										   NUMBER
 WAIT_TIME									   NUMBER
 WAIT_TIME_MICRO								   NUMBER
 TIME_SINCE_LAST_WAIT_MICRO							   NUMBER

