use master
go
sp_sysmon "02:00:00"
go
exit
