 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 CLIENTID									   NUMBER
 OPENOWNEROPAQUE								   VARCHAR2(2000)
 OPENSTATEID									   RAW(16)
 FILEHANDLE									   RAW(32)
 OPENSEQUENCEID 								   NUMBER
 OPENREAD									   VARCHAR2(5)
 OPENWRITE									   VARCHAR2(5)
 SHAREACCESS									   VARCHAR2(15)
 SHAREDENY									   VARCHAR2(13)
 CONFIRMED									   VARCHAR2(5)

