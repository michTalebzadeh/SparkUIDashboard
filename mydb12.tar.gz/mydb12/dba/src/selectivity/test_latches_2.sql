ALTER SESSION SET TRACEFILE_IDENTIFIER = 'latch_test_2';
clear screen

insert into t9 values ( 1,1 );
alter table t9 move;
EXEC DBMS_STATS.GATHER_TABLE_STATS( USER, 'T9' );
select x, dbms_rowid.rowid_block_number(rowid) from t9;
create index t9_idx on t9(x);
commit;
pause
clear screen
variable a refcursor
variable b refcursor
variable c refcursor
ALTER SESSION SET EVENTS '10046 TRACE NAME CONTEXT FOREVER, LEVEL 12';


begin
    open :a for select /*+ FIRST_ROWS */ * from t9 a where x > 1;
    open :b for select /*+ FIRST_ROWS */ * from t9 b where x > 1;
    open :c for select /*+ FIRST_ROWS */ * from t9 c where x > 1;
end;
/


pause
clear screen

print a


pause
clear screen

begin
    for i in 1 .. 10000
    loop
        update t9 set x = x where x = 1;
        commit;
    end loop;
end;
/

pause
clear screen

print b
print c
pause
clear screen
exit
