ALTER DATABASE   ADD LOGFILE GROUP 4 ('/ssdsdc1/oracle/mydb12/MYDB12/logfile/redo4a.log','/data6/oracle/mydb12/logfile/redo4b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 5 ('/ssdsdc1/oracle/mydb12/MYDB12/logfile/redo5a.log','/data6/oracle/mydb12/logfile/redo5b.log')      SIZE 1000M REUSE;
ALTER DATABASE   ADD LOGFILE GROUP 6 ('/ssdsdc1/oracle/mydb12/MYDB12/logfile/redo6a.log','/data6/oracle/mydb12/logfile/redo6b.log')      SIZE 1000M REUSE;
