@$HOME/abc
set head off
set pagesize 0
SELECT to_char(rownum+3)||')'||rpad(r.name,17)||rpad(to_char(p.pid),11)||
       rpad(s.sid,6)||rpad(p.spid,11)||rpad(nvl(p.username,'NO TRANSACTION'),17)||
       rpad(p.terminal,8)
FROM  v$lock l, v$process p, v$rollname r, v$session s
WHERE l.sid = s.sid(+) AND p.addr = s.paddr AND
      l.type(+)='TX' AND l.lmode(+)= 6 AND
      trunc(l.id1(+)/65536)=r.usn
UNION
SELECT '2) ROLLBACK SEG;ORACLE PID;SYSTEM PID; SID; TRANSACTION TERMINAL' FROM dual
UNION SELECT '1)' FROM dual
UNION SELECT '3) -------------------------------------------------------' FROM dual
ORDER BY 1
/
exit

