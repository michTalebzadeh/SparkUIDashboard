 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 METRICS_ID									   NUMBER
 METRICS_GROUP_ID								   NUMBER
 OPERATOR_MASK									   NUMBER
 OBJECT_TYPE									   VARCHAR2(64)
 ALERT_REASON_ID								   NUMBER
 METRIC_VALUE_TYPE								   NUMBER

