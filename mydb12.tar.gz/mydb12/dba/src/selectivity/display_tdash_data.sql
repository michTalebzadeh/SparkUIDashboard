DECLARE
v_rc sys_refcursor;
v_object_name tdash.object_name%TYPE;
v_object_type tdash.object_type%TYPE;
BEGIN
  v_rc  := get_tdash_data_fn('MICH');
  LOOP
    FETCH v_rc INTO v_object_name, v_object_type;
    EXIT WHEN v_rc%NOTFOUND;
    DBMS_OUTPUT.PUT_LINE(chr(10)||v_rc%ROWCOUNT||' '||v_object_name||' '||v_object_type);
  END LOOP;
EXCEPTION
  WHEN OTHERS THEN
  IF v_rc%ISOPEN THEN
    CLOSE v_rc;
    RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM,true);
  END IF;
END;
/
exit
