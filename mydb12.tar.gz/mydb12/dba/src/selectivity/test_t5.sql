alter system flush buffer_cache;
ALTER SESSION SET OPTIMIZER_INDEX_COST_ADJ=10;
--ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_t5_index_hint';
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test_t5_INDEX_COST_ADJ';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
--select /*+ index (t5, t5_i1) */ padding from t5 where n1 != 0
select padding from t5 where n1 != 0
/
exit
