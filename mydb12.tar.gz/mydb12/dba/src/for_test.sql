create table test_metadata ( ddl_statement varchar2(4000) ); 
/ 
CREATE OR REPLACE PROCEDURE for_test AS
  clob_variable CLOB := empty_clob();
BEGIN
  FOR i IN (SELECT u.index_name, u.table_owner
              FROM user_indexes u)
  LOOP
    SELECT DBMS_METADATA.GET_DDL('INDEX', i.index_name, i.table_owner)
      INTO clob_variable
      FROM dual;
    INSERT INTO test_metadata
    VALUES
      (clob_variable);
  END LOOP;
END for_test;
/
exit
