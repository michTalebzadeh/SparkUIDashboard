 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 OWNER										   VARCHAR2(31)
 TABNAME									   VARCHAR2(31)
 INDEXNAME									   VARCHAR2(31)
 SUBNAME									   VARCHAR2(31)
 MESSAGE_NUM									   NUMBER
 MESSAGE									   VARCHAR2(4000)

