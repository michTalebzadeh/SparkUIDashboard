use master
go
set nocount on
go
checkpoint
go

declare @msg char(100), @errorno int
dump tran dbccdb with truncate_only
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Tue Jun 27 00:38:07 BST 2000 db_dump_adsm.ksh Dump of dbccdb log failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go

declare @msg char(100), @errorno int
dump database dbccdb to "/apps/sybase/dump/lon_gedimg_sql_prd/dbccdb.dmp.stripe1"
select @errorno=@@error

if @errorno != 0
begin
        select @msg="ERROR: Tue Jun 27 00:38:07 BST 2000 db_dump_adsm.ksh Dump of dbccdb failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
        print @msg
end
go

