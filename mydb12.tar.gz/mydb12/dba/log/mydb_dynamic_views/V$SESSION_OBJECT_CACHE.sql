 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 PINS										   NUMBER
 HITS										   NUMBER
 TRUE_HITS									   NUMBER
 HIT_RATIO									   NUMBER
 TRUE_HIT_RATIO 								   NUMBER
 OBJECT_REFRESHES								   NUMBER
 CACHE_REFRESHES								   NUMBER
 OBJECT_FLUSHES 								   NUMBER
 CACHE_FLUSHES									   NUMBER
 CACHE_SHRINKS									   NUMBER
 CACHED_OBJECTS 								   NUMBER
 PINNED_OBJECTS 								   NUMBER
 CACHE_SIZE									   NUMBER
 OPTIMAL_SIZE									   NUMBER
 MAXIMUM_SIZE									   NUMBER

