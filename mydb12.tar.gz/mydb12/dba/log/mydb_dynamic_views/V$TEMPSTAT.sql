 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FILE#										   NUMBER
 PHYRDS 									   NUMBER
 PHYWRTS									   NUMBER
 PHYBLKRD									   NUMBER
 PHYBLKWRT									   NUMBER
 SINGLEBLKRDS									   NUMBER
 READTIM									   NUMBER
 WRITETIM									   NUMBER
 SINGLEBLKRDTIM 								   NUMBER
 AVGIOTIM									   NUMBER
 LSTIOTIM									   NUMBER
 MINIOTIM									   NUMBER
 MAXIORTM									   NUMBER
 MAXIOWTM									   NUMBER

