@login
accept owner prompt "Enter the OWNER of object you wish to view: "
declare
        v_owner         varchar2(30) := upper('&owner');
begin
  dbms_output.put_line('Started dbms_schema stats for schema ' || v_owner ||' at '||to_char(sysdate, 'yyyy/mm/dd hh24:mm:ss')||chr(10));
  --dbms_stats.gather_schema_stats(ownname => v_owner, estimate_percent => 5, cascade => true);
  dbms_stats.gather_schema_stats(ownname => v_owner, cascade => true);
  dbms_output.put_line(chr(10)||'Finished dbms_schema stats for schema ' || v_owner ||' at '||to_char(sysdate, 'yyyy/mm/dd hh24:mm:ss'));
end;
/
exit
