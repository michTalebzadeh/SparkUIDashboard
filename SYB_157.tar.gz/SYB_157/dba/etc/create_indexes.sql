if exists (select 1 from sysindexes where name = 'hts_dbt_xfce_ind')
drop index hts_dbt_xfce.hts_dbt_xfce_ind
go

create nonclustered index  hts_dbt_xfce_ind 
on hts_dbt_xfce (td_order_number, td_tran_dbt4_status, td_tran_trax_status)
go

create nonclustered index  hts_dbt_xfce_ind_date 
on hts_dbt_xfce (td_level_1_date)
go
