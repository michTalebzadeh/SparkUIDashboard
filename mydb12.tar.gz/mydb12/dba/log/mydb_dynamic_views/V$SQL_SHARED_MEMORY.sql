 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SQL_TEXT									   VARCHAR2(1000)
 SQL_FULLTEXT									   CLOB
 HASH_VALUE									   NUMBER
 SQL_ID 									   VARCHAR2(13)
 HEAP_DESC									   RAW(4)
 STRUCTURE									   VARCHAR2(16)
 FUNCTION									   VARCHAR2(16)
 CHUNK_COM									   VARCHAR2(16)
 CHUNK_PTR									   RAW(4)
 CHUNK_SIZE									   NUMBER
 ALLOC_CLASS									   VARCHAR2(8)
 CHUNK_TYPE									   NUMBER
 SUBHEAP_DESC									   RAW(4)

