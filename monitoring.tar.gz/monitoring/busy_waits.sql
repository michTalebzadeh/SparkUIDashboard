prompt
Prompt +-----------------------------------+
Prompt | Buffer busy waits FROM V$WAITSTAT |
Prompt +-----------------------------------+

select * from V$WAITSTAT
	order by time desc;
prompt
Prompt +-----------------------------------------+
Prompt | additional information what block types |
Prompt | in which files are causing contention   |
Prompt | FROM X$KCBFWAIT, V$DATAFILE             |
Prompt +-----------------------------------------+

select substr(name,1,50) name, count
from x$kcbfwait, v$datafile
where file# = indx + 1
and   count > 0
order by count desc
/
exit
