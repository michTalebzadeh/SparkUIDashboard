select sql_text,
          executions,
          to_char((((disk_reads+buffer_gets)/executions) * 8192)/1048576,
                     '9,999,999,990.00')  as total_gets_per_exec_mb,
          to_char((( disk_reads             /executions) * 8192)/1048576,
                     '9,999,999,990.00')  as disk_reads_per_exec_mb,
          to_char((( buffer_gets            /executions) * 8192)/1048576,
                     '9,999,999,990.00')  as buffer_gets_per_exec_mb,
          parsing_user_id
   from   v$sqlarea
   where  executions > 0
   order by 6 desc
/
exit
