create user mtalebz1 identified by London99
default tablespace app1_ssduser temporary tablespace temp2;
grant dba to mtalebz1;
exit

