use master
go

declare @msg char(100), @errorno int
dump tran its_ged_prod to "/apps/sybase/dump/lon_gedimg_sql_prd/tran/its_ged_prod_trandump_45.trn"
select @errorno=@@error
if @errorno != 0
begin
        select @msg="ERROR: Sat Sep 23 10:20:00 BST 2000 run_trandump.ksh Failed tran dump for " + @@servername + ".its_ged_prod with error number " + convert(char(5),@errorno)
        print @msg
end
go
