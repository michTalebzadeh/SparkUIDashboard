set long 10000
select 'create or replace trigger '|| description,
trigger_body
from user_triggers;
exit
