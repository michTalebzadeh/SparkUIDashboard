 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 RECOMMENDATION_ID								   NUMBER
 FDG_ID 									   NUMBER
 RUN_ID 									   NUMBER
 NAME										   VARCHAR2(32)
 TYPE										   VARCHAR2(7)
 RANK										   NUMBER
 TIME_DETECTED									   TIMESTAMP(6)
 EXECUTED									   TIMESTAMP(6)
 STATUS 									   VARCHAR2(7)
 DESCRIPTION									   VARCHAR2(1024)
 REPAIR_SCRIPT									   VARCHAR2(512)

