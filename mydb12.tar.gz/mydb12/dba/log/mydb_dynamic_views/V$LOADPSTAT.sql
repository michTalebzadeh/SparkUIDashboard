 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 OWNER										   VARCHAR2(31)
 TABNAME									   VARCHAR2(31)
 PARTNAME									   VARCHAR2(31)
 LOADED 									   NUMBER

