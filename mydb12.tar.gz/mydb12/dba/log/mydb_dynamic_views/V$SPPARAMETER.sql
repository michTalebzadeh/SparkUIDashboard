 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SID										   VARCHAR2(80)
 NAME										   VARCHAR2(80)
 TYPE										   VARCHAR2(11)
 VALUE										   VARCHAR2(255)
 DISPLAY_VALUE									   VARCHAR2(255)
 ISSPECIFIED									   VARCHAR2(6)
 ORDINAL									   NUMBER
 UPDATE_COMMENT 								   VARCHAR2(255)

