--ALTER SESSION SET STATISTICS_LEVEL='ALL';
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'test';
alter session set events '10949 trace name context forever, level 1';
DECLARE
	type mich_array is table of t1%rowtype index by binary_integer;
	l_data mich_array;
	l_rec t%rowtype;
BEGIN
	SELECT
         	*
	BULK COLLECT INTO
	l_data
  	FROM t1 ;   -- million row table
	EXCEPTION
 	  WHEN  OTHERS THEN
           DBMS_OUTPUT.PUT_LINE(to_char(SQLCODE) || ' - ' || substr(SQLERRM,1,200));

END;
/
exit
