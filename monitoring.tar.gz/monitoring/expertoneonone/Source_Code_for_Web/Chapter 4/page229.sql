select rowid from emp
intersect
select rowid from dept;

