use its_ged_prod
go
sp_adduser "baxtma","baxtma"
go
sp_adduser "buscel","buscel"
go
sp_adduser "codydi","codydi"
go
sp_adduser "djamra","djamra"
go
sp_adduser "failju","failju"
go
sp_adduser "frieth","frieth"
go
sp_adduser "haenur","haenur"
go
sp_adduser "jarkha","jarkha"
go
sp_adduser "jungna","jungna"
go
sp_adduser "kleeri","kleeri"
go
sp_adduser "krolni","krolni"
go
sp_adduser "neuban","neuban"
go
sp_adduser "rangel","rangel"
go
sp_adduser "schwkl","schwkl"
go
sp_adduser "sormme","sormme"
go
sp_adduser "striro","striro"
go
sp_adduser "uzunan","uzunan"
go
