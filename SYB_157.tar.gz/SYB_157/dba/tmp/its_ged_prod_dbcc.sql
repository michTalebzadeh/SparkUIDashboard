use master
go
set nocount on
go
-- Turn on traceflag for ignoring syslogs table
dbcc traceon(2512)
go

declare @msg char(100), @errorno int
dbcc checkdb(its_ged_prod)
select @errorno=@@error
if @errorno != 0
begin
select @msg="ERROR: Thu Feb 20 11:00:40 GMT 2003 db_dbcc.ksh Dbcc of 'its_ged_prod' failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
print @msg
end
dbcc traceoff(2512)
print "Info: Thu Feb 20 11:00:40 GMT 2003 db_dbcc.ksh Finished check 'checkdb' for database 'its_ged_prod'"
go

use master
go
set nocount on
go
-- Turn on traceflag for ignoring syslogs table
dbcc traceon(2512)
go

declare @msg char(100), @errorno int
dbcc checkalloc(its_ged_prod)
select @errorno=@@error
if @errorno != 0
begin
select @msg="ERROR: Thu Feb 20 11:00:40 GMT 2003 db_dbcc.ksh Dbcc of 'its_ged_prod' failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
print @msg
end
dbcc traceoff(2512)
print "Info: Thu Feb 20 11:00:40 GMT 2003 db_dbcc.ksh Finished check 'checkalloc' for database 'its_ged_prod'"
go

use master
go
set nocount on
go
-- Turn on traceflag for ignoring syslogs table
dbcc traceon(2512)
go

declare @msg char(100), @errorno int
dbcc checkcatalog(its_ged_prod)
select @errorno=@@error
if @errorno != 0
begin
select @msg="ERROR: Thu Feb 20 11:00:40 GMT 2003 db_dbcc.ksh Dbcc of 'its_ged_prod' failed for server" + @@servername + " with error number " + convert(char(5),@errorno)
print @msg
end
dbcc traceoff(2512)
print "Info: Thu Feb 20 11:00:40 GMT 2003 db_dbcc.ksh Finished check 'checkcatalog' for database 'its_ged_prod'"
go

