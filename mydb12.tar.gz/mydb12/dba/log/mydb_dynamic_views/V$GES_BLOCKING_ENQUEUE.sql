 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 HANDLE 									   RAW(4)
 GRANT_LEVEL									   VARCHAR2(9)
 REQUEST_LEVEL									   VARCHAR2(9)
 RESOURCE_NAME1 								   VARCHAR2(30)
 RESOURCE_NAME2 								   VARCHAR2(30)
 PID										   NUMBER
 TRANSACTION_ID0								   NUMBER
 TRANSACTION_ID1								   NUMBER
 GROUP_ID									   NUMBER
 OPEN_OPT_DEADLOCK								   NUMBER
 OPEN_OPT_PERSISTENT								   NUMBER
 OPEN_OPT_PROCESS_OWNED 							   NUMBER
 OPEN_OPT_NO_XID								   NUMBER
 CONVERT_OPT_GETVALUE								   NUMBER
 CONVERT_OPT_PUTVALUE								   NUMBER
 CONVERT_OPT_NOVALUE								   NUMBER
 CONVERT_OPT_DUBVALUE								   NUMBER
 CONVERT_OPT_NOQUEUE								   NUMBER
 CONVERT_OPT_EXPRESS								   NUMBER
 CONVERT_OPT_NODEADLOCKWAIT							   NUMBER
 CONVERT_OPT_NODEADLOCKBLOCK							   NUMBER
 WHICH_QUEUE									   NUMBER
 STATE										   VARCHAR2(64)
 AST_EVENT0									   NUMBER
 OWNER_NODE									   NUMBER
 BLOCKED									   NUMBER
 BLOCKER									   NUMBER

