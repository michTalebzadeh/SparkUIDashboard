-- log in as scott/tiger
--
set echo on

delete from plan_table
 where statement_id = 'MINE';
commit;
COL operation   FORMAT A30
COL options     FORMAT A15
COL object_name FORMAT A20
EXPLAIN PLAN set statement_id = 'MINE' for
/* ------ Your SQL here ------*/
select *
from emp e, test s
where empno = 7369
and e.sal = s.losal
and s.losal between 1000 and 10000
/*----------------------------*/
/

set echo off

select operation, options, object_name
  from plan_table
 where statement_id = 'MINE'
start with id = 0
connect by prior id=parent_id and prior statement_id = statement_id;
set echo on
exit
