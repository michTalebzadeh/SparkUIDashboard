/********************************************/
/*------------ cache_administration_user_tablespace -------------*/
/********************************************/
select 'Started creating cache_administration_user_tablespace tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE SMALLFILE TABLESPACE "TTSYS_USER_TABLESPACE" DATAFILE '+ORACLE_DG' SIZE 1000M AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED LOGGING
 EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO; 
select 'Finished  creating cache_administration_user_tablespace tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
