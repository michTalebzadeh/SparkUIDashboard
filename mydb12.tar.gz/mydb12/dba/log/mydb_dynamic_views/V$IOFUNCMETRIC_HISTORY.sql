 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 BEGIN_TIME									   DATE
 END_TIME									   DATE
 INTSIZE_CSEC									   NUMBER
 FUNCTION_ID									   NUMBER
 FUNCTION_NAME									   VARCHAR2(18)
 SMALL_READ_MBPS								   NUMBER
 SMALL_WRITE_MBPS								   NUMBER
 LARGE_READ_MBPS								   NUMBER
 LARGE_WRITE_MBPS								   NUMBER
 SMALL_READ_IOPS								   NUMBER
 SMALL_WRITE_IOPS								   NUMBER
 LARGE_READ_IOPS								   NUMBER
 LARGE_WRITE_IOPS								   NUMBER
 AVG_WAIT_TIME									   NUMBER

