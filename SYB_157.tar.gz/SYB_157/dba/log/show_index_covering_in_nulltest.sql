use imdb1
go
set switch on 3604
go
set showplan on
go
set literal_autoparam off
go
declare @d1 bigdatetime, @d2 bigdatetime
select @d1=current_bigdatetime()
select count(*) from nulltest where OWNER = 'SYS' and OBJECT_NAME = 'sun/tools/tree/ForStatement'
select @d2=current_bigdatetime()
select datediff(us,@d1,@d2) AS "time taken in microseconds"
go
exit
