set nocount on
go
use its_ged_prod
go
select "Started  update stats on table CUSTOMERS on " +convert(varchar(25),getdate(),100)
go
sp_spaceused CUSTOMERS   
go
update statistics CUSTOMERS
go
update index statistics CUSTOMERS
go
sp_recompile CUSTOMERS
go
select "Finished update stats on table CUSTOMERS on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table ITEMS on " +convert(varchar(25),getdate(),100)
go
sp_spaceused ITEMS   
go
update statistics ITEMS
go
update index statistics ITEMS
go
sp_recompile ITEMS
go
select "Finished update stats on table ITEMS on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table ORDERS on " +convert(varchar(25),getdate(),100)
go
sp_spaceused ORDERS   
go
update statistics ORDERS
go
update index statistics ORDERS
go
sp_recompile ORDERS
go
select "Finished update stats on table ORDERS on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table ORDER_ITEMS on " +convert(varchar(25),getdate(),100)
go
sp_spaceused ORDER_ITEMS   
go
update statistics ORDER_ITEMS
go
update index statistics ORDER_ITEMS
go
sp_recompile ORDER_ITEMS
go
select "Finished update stats on table ORDER_ITEMS on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table T1 on " +convert(varchar(25),getdate(),100)
go
sp_spaceused T1   
go
update statistics T1
go
update index statistics T1
go
sp_recompile T1
go
select "Finished update stats on table T1 on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table abc on " +convert(varchar(25),getdate(),100)
go
sp_spaceused abc   
go
update statistics abc
go
update index statistics abc
go
sp_recompile abc
go
select "Finished update stats on table abc on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table bp on " +convert(varchar(25),getdate(),100)
go
sp_spaceused bp   
go
update statistics bp
go
update index statistics bp
go
sp_recompile bp
go
select "Finished update stats on table bp on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table bp_hist on " +convert(varchar(25),getdate(),100)
go
sp_spaceused bp_hist   
go
update statistics bp_hist
go
update index statistics bp_hist
go
sp_recompile bp_hist
go
select "Finished update stats on table bp_hist on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_acctflow_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_acctflow_tb   
go
update statistics dbGED_acctflow_tb
go
update index statistics dbGED_acctflow_tb
go
sp_recompile dbGED_acctflow_tb
go
select "Finished update stats on table dbGED_acctflow_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_database_booker_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_database_booker_tb   
go
update statistics dbGED_database_booker_tb
go
update index statistics dbGED_database_booker_tb
go
sp_recompile dbGED_database_booker_tb
go
select "Finished update stats on table dbGED_database_booker_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_supportrequest_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_supportrequest_tb   
go
update statistics dbGED_supportrequest_tb
go
update index statistics dbGED_supportrequest_tb
go
sp_recompile dbGED_supportrequest_tb
go
select "Finished update stats on table dbGED_supportrequest_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_usereq_acctconf_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_usereq_acctconf_tb   
go
update statistics dbGED_usereq_acctconf_tb
go
update index statistics dbGED_usereq_acctconf_tb
go
sp_recompile dbGED_usereq_acctconf_tb
go
select "Finished update stats on table dbGED_usereq_acctconf_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_usereq_accttype_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_usereq_accttype_tb   
go
update statistics dbGED_usereq_accttype_tb
go
update index statistics dbGED_usereq_accttype_tb
go
sp_recompile dbGED_usereq_accttype_tb
go
select "Finished update stats on table dbGED_usereq_accttype_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_usereq_bizarea_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_usereq_bizarea_tb   
go
update statistics dbGED_usereq_bizarea_tb
go
update index statistics dbGED_usereq_bizarea_tb
go
sp_recompile dbGED_usereq_bizarea_tb
go
select "Finished update stats on table dbGED_usereq_bizarea_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_usereq_confdef_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_usereq_confdef_tb   
go
update statistics dbGED_usereq_confdef_tb
go
update index statistics dbGED_usereq_confdef_tb
go
sp_recompile dbGED_usereq_confdef_tb
go
select "Finished update stats on table dbGED_usereq_confdef_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_usereq_groups_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_usereq_groups_tb   
go
update statistics dbGED_usereq_groups_tb
go
update index statistics dbGED_usereq_groups_tb
go
sp_recompile dbGED_usereq_groups_tb
go
select "Finished update stats on table dbGED_usereq_groups_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_usereq_location_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_usereq_location_tb   
go
update statistics dbGED_usereq_location_tb
go
update index statistics dbGED_usereq_location_tb
go
sp_recompile dbGED_usereq_location_tb
go
select "Finished update stats on table dbGED_usereq_location_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_usereq_super_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_usereq_super_tb   
go
update statistics dbGED_usereq_super_tb
go
update index statistics dbGED_usereq_super_tb
go
sp_recompile dbGED_usereq_super_tb
go
select "Finished update stats on table dbGED_usereq_super_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbGED_userreq_new_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbGED_userreq_new_tb   
go
update statistics dbGED_userreq_new_tb
go
update index statistics dbGED_userreq_new_tb
go
sp_recompile dbGED_userreq_new_tb
go
select "Finished update stats on table dbGED_userreq_new_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbJobStatus on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbJobStatus   
go
update statistics dbJobStatus
go
update index statistics dbJobStatus
go
sp_recompile dbJobStatus
go
select "Finished update stats on table dbJobStatus on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbStageDividend on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbStageDividend   
go
update statistics dbStageDividend
go
update index statistics dbStageDividend
go
sp_recompile dbStageDividend
go
select "Finished update stats on table dbStageDividend on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbStageDividend_Old on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbStageDividend_Old   
go
update statistics dbStageDividend_Old
go
update index statistics dbStageDividend_Old
go
sp_recompile dbStageDividend_Old
go
select "Finished update stats on table dbStageDividend_Old on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbStageRicRef on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbStageRicRef   
go
update statistics dbStageRicRef
go
update index statistics dbStageRicRef
go
sp_recompile dbStageRicRef
go
select "Finished update stats on table dbStageRicRef on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbStageStock on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbStageStock   
go
update statistics dbStageStock
go
update index statistics dbStageStock
go
sp_recompile dbStageStock
go
select "Finished update stats on table dbStageStock on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbStageStock_Old on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbStageStock_Old   
go
update statistics dbStageStock_Old
go
update index statistics dbStageStock_Old
go
sp_recompile dbStageStock_Old
go
select "Finished update stats on table dbStageStock_Old on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbStar_Input on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbStar_Input   
go
update statistics dbStar_Input
go
update index statistics dbStar_Input
go
sp_recompile dbStar_Input
go
select "Finished update stats on table dbStar_Input on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbStar_Input1 on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbStar_Input1   
go
update statistics dbStar_Input1
go
update index statistics dbStar_Input1
go
sp_recompile dbStar_Input1
go
select "Finished update stats on table dbStar_Input1 on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbStar_Input_arch on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbStar_Input_arch   
go
update statistics dbStar_Input_arch
go
update index statistics dbStar_Input_arch
go
sp_recompile dbStar_Input_arch
go
select "Finished update stats on table dbStar_Input_arch on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_EOD_blotter_extra on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_EOD_blotter_extra   
go
update statistics db_EOD_blotter_extra
go
update index statistics db_EOD_blotter_extra
go
sp_recompile db_EOD_blotter_extra
go
select "Finished update stats on table db_EOD_blotter_extra on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_EOD_blotter_sec_data on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_EOD_blotter_sec_data   
go
update statistics db_EOD_blotter_sec_data
go
update index statistics db_EOD_blotter_sec_data
go
sp_recompile db_EOD_blotter_sec_data
go
select "Finished update stats on table db_EOD_blotter_sec_data on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_EOD_blotter_signoff on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_EOD_blotter_signoff   
go
update statistics db_EOD_blotter_signoff
go
update index statistics db_EOD_blotter_signoff
go
sp_recompile db_EOD_blotter_signoff
go
select "Finished update stats on table db_EOD_blotter_signoff on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_EOD_blotter_status on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_EOD_blotter_status   
go
update statistics db_EOD_blotter_status
go
update index statistics db_EOD_blotter_status
go
sp_recompile db_EOD_blotter_status
go
select "Finished update stats on table db_EOD_blotter_status on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_EOD_blotter_trades on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_EOD_blotter_trades   
go
update statistics db_EOD_blotter_trades
go
update index statistics db_EOD_blotter_trades
go
sp_recompile db_EOD_blotter_trades
go
select "Finished update stats on table db_EOD_blotter_trades on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_YC_Upload_Ccys on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_YC_Upload_Ccys   
go
update statistics db_YC_Upload_Ccys
go
update index statistics db_YC_Upload_Ccys
go
sp_recompile db_YC_Upload_Ccys
go
select "Finished update stats on table db_YC_Upload_Ccys on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_alternate_code on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_alternate_code   
go
update statistics db_alternate_code
go
update index statistics db_alternate_code
go
sp_recompile db_alternate_code
go
select "Finished update stats on table db_alternate_code on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_applix_indices on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_applix_indices   
go
update statistics db_applix_indices
go
update index statistics db_applix_indices
go
sp_recompile db_applix_indices
go
select "Finished update stats on table db_applix_indices on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_asian_history on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_asian_history   
go
update statistics db_asian_history
go
update index statistics db_asian_history
go
sp_recompile db_asian_history
go
select "Finished update stats on table db_asian_history on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_autolaunchLedgers on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_autolaunchLedgers   
go
update statistics db_autolaunchLedgers
go
update index statistics db_autolaunchLedgers
go
sp_recompile db_autolaunchLedgers
go
select "Finished update stats on table db_autolaunchLedgers on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_autolaunchUsers on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_autolaunchUsers   
go
update statistics db_autolaunchUsers
go
update index statistics db_autolaunchUsers
go
sp_recompile db_autolaunchUsers
go
select "Finished update stats on table db_autolaunchUsers on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_average_trade_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_average_trade_detail   
go
update statistics db_average_trade_detail
go
update index statistics db_average_trade_detail
go
sp_recompile db_average_trade_detail
go
select "Finished update stats on table db_average_trade_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_average_trade_err on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_average_trade_err   
go
update statistics db_average_trade_err
go
update index statistics db_average_trade_err
go
sp_recompile db_average_trade_err
go
select "Finished update stats on table db_average_trade_err on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_average_trade_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_average_trade_list   
go
update statistics db_average_trade_list
go
update index statistics db_average_trade_list
go
sp_recompile db_average_trade_list
go
select "Finished update stats on table db_average_trade_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_average_trade_xref on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_average_trade_xref   
go
update statistics db_average_trade_xref
go
update index statistics db_average_trade_xref
go
sp_recompile db_average_trade_xref
go
select "Finished update stats on table db_average_trade_xref on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_error on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_error   
go
update statistics db_avg_error
go
update index statistics db_avg_error
go
sp_recompile db_avg_error
go
select "Finished update stats on table db_avg_error on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_exec_xref on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_exec_xref   
go
update statistics db_avg_exec_xref
go
update index statistics db_avg_exec_xref
go
sp_recompile db_avg_exec_xref
go
select "Finished update stats on table db_avg_exec_xref on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_exec_xref_audit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_exec_xref_audit   
go
update statistics db_avg_exec_xref_audit
go
update index statistics db_avg_exec_xref_audit
go
sp_recompile db_avg_exec_xref_audit
go
select "Finished update stats on table db_avg_exec_xref_audit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_netting_grp on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_netting_grp   
go
update statistics db_avg_netting_grp
go
update index statistics db_avg_netting_grp
go
sp_recompile db_avg_netting_grp
go
select "Finished update stats on table db_avg_netting_grp on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_netting_grp_audit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_netting_grp_audit   
go
update statistics db_avg_netting_grp_audit
go
update index statistics db_avg_netting_grp_audit
go
sp_recompile db_avg_netting_grp_audit
go
select "Finished update stats on table db_avg_netting_grp_audit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_rule on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_rule   
go
update statistics db_avg_rule
go
update index statistics db_avg_rule
go
sp_recompile db_avg_rule
go
select "Finished update stats on table db_avg_rule on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_rule_audit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_rule_audit   
go
update statistics db_avg_rule_audit
go
update index statistics db_avg_rule_audit
go
sp_recompile db_avg_rule_audit
go
select "Finished update stats on table db_avg_rule_audit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_rule_except_audit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_rule_except_audit   
go
update statistics db_avg_rule_except_audit
go
update index statistics db_avg_rule_except_audit
go
sp_recompile db_avg_rule_except_audit
go
select "Finished update stats on table db_avg_rule_except_audit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_rule_exception on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_rule_exception   
go
update statistics db_avg_rule_exception
go
update index statistics db_avg_rule_exception
go
sp_recompile db_avg_rule_exception
go
select "Finished update stats on table db_avg_rule_exception on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_rule_set on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_rule_set   
go
update statistics db_avg_rule_set
go
update index statistics db_avg_rule_set
go
sp_recompile db_avg_rule_set
go
select "Finished update stats on table db_avg_rule_set on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_rule_set_audit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_rule_set_audit   
go
update statistics db_avg_rule_set_audit
go
update index statistics db_avg_rule_set_audit
go
sp_recompile db_avg_rule_set_audit
go
select "Finished update stats on table db_avg_rule_set_audit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_rule_type on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_rule_type   
go
update statistics db_avg_rule_type
go
update index statistics db_avg_rule_type
go
sp_recompile db_avg_rule_type
go
select "Finished update stats on table db_avg_rule_type on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_trade on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_trade   
go
update statistics db_avg_trade
go
update index statistics db_avg_trade
go
sp_recompile db_avg_trade
go
select "Finished update stats on table db_avg_trade on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_avg_trade_audit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_avg_trade_audit   
go
update statistics db_avg_trade_audit
go
update index statistics db_avg_trade_audit
go
sp_recompile db_avg_trade_audit
go
select "Finished update stats on table db_avg_trade_audit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_calendar_map on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_calendar_map   
go
update statistics db_calendar_map
go
update index statistics db_calendar_map
go
sp_recompile db_calendar_map
go
select "Finished update stats on table db_calendar_map on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_column_defaults on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_column_defaults   
go
update statistics db_column_defaults
go
update index statistics db_column_defaults
go
sp_recompile db_column_defaults
go
select "Finished update stats on table db_column_defaults on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_curve_missing_map on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_curve_missing_map   
go
update statistics db_curve_missing_map
go
update index statistics db_curve_missing_map
go
sp_recompile db_curve_missing_map
go
select "Finished update stats on table db_curve_missing_map on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_div_tax_rules on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_div_tax_rules   
go
update statistics db_div_tax_rules
go
update index statistics db_div_tax_rules
go
sp_recompile db_div_tax_rules
go
select "Finished update stats on table db_div_tax_rules on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_error_message on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_error_message   
go
update statistics db_error_message
go
update index statistics db_error_message
go
sp_recompile db_error_message
go
select "Finished update stats on table db_error_message on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_eurex_defaults on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_eurex_defaults   
go
update statistics db_eurex_defaults
go
update index statistics db_eurex_defaults
go
sp_recompile db_eurex_defaults
go
select "Finished update stats on table db_eurex_defaults on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_eurex_xetra_ar_prod on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_eurex_xetra_ar_prod   
go
update statistics db_eurex_xetra_ar_prod
go
update index statistics db_eurex_xetra_ar_prod
go
sp_recompile db_eurex_xetra_ar_prod
go
select "Finished update stats on table db_eurex_xetra_ar_prod on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_eurex_xetra_routing on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_eurex_xetra_routing   
go
update statistics db_eurex_xetra_routing
go
update index statistics db_eurex_xetra_routing
go
sp_recompile db_eurex_xetra_routing
go
select "Finished update stats on table db_eurex_xetra_routing on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_eurex_xetra_trades on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_eurex_xetra_trades   
go
update statistics db_eurex_xetra_trades
go
update index statistics db_eurex_xetra_trades
go
sp_recompile db_eurex_xetra_trades
go
select "Finished update stats on table db_eurex_xetra_trades on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_eurex_xetra_trades_arc on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_eurex_xetra_trades_arc   
go
update statistics db_eurex_xetra_trades_arc
go
update index statistics db_eurex_xetra_trades_arc
go
sp_recompile db_eurex_xetra_trades_arc
go
select "Finished update stats on table db_eurex_xetra_trades_arc on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_excep_price_env on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_excep_price_env   
go
update statistics db_excep_price_env
go
update index statistics db_excep_price_env
go
sp_recompile db_excep_price_env
go
select "Finished update stats on table db_excep_price_env on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_feed_gl_average on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_feed_gl_average   
go
update statistics db_feed_gl_average
go
update index statistics db_feed_gl_average
go
sp_recompile db_feed_gl_average
go
select "Finished update stats on table db_feed_gl_average on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_hold_overrides on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_hold_overrides   
go
update statistics db_hold_overrides
go
update index statistics db_hold_overrides
go
sp_recompile db_hold_overrides
go
select "Finished update stats on table db_hold_overrides on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_imagine_user_dealer_map on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_imagine_user_dealer_map   
go
update statistics db_imagine_user_dealer_map
go
update index statistics db_imagine_user_dealer_map
go
sp_recompile db_imagine_user_dealer_map
go
select "Finished update stats on table db_imagine_user_dealer_map on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_index_vol_to_delete on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_index_vol_to_delete   
go
update statistics db_index_vol_to_delete
go
update index statistics db_index_vol_to_delete
go
sp_recompile db_index_vol_to_delete
go
select "Finished update stats on table db_index_vol_to_delete on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_instr_matching_rule on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_instr_matching_rule   
go
update statistics db_instr_matching_rule
go
update index statistics db_instr_matching_rule
go
sp_recompile db_instr_matching_rule
go
select "Finished update stats on table db_instr_matching_rule on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_instr_rule_def on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_instr_rule_def   
go
update statistics db_instr_rule_def
go
update index statistics db_instr_rule_def
go
sp_recompile db_instr_rule_def
go
select "Finished update stats on table db_instr_rule_def on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_instr_rule_parameters on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_instr_rule_parameters   
go
update statistics db_instr_rule_parameters
go
update index statistics db_instr_rule_parameters
go
sp_recompile db_instr_rule_parameters
go
select "Finished update stats on table db_instr_rule_parameters on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_instr_server_classes on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_instr_server_classes   
go
update statistics db_instr_server_classes
go
update index statistics db_instr_server_classes
go
sp_recompile db_instr_server_classes
go
select "Finished update stats on table db_instr_server_classes on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_instr_valid_sec_cmb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_instr_valid_sec_cmb   
go
update statistics db_instr_valid_sec_cmb
go
update index statistics db_instr_valid_sec_cmb
go
sp_recompile db_instr_valid_sec_cmb
go
select "Finished update stats on table db_instr_valid_sec_cmb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_last_message on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_last_message   
go
update statistics db_last_message
go
update index statistics db_last_message
go
sp_recompile db_last_message
go
select "Finished update stats on table db_last_message on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_loginInformations on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_loginInformations   
go
update statistics db_loginInformations
go
update index statistics db_loginInformations
go
sp_recompile db_loginInformations
go
select "Finished update stats on table db_loginInformations on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_mark_errors on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_mark_errors   
go
update statistics db_mark_errors
go
update index statistics db_mark_errors
go
sp_recompile db_mark_errors
go
select "Finished update stats on table db_mark_errors on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_month_end_dates on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_month_end_dates   
go
update statistics db_month_end_dates
go
update index statistics db_month_end_dates
go
sp_recompile db_month_end_dates
go
select "Finished update stats on table db_month_end_dates on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_notification_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_notification_detail   
go
update statistics db_notification_detail
go
update index statistics db_notification_detail
go
sp_recompile db_notification_detail
go
select "Finished update stats on table db_notification_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_auto_routed_products on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_auto_routed_products   
go
update statistics db_orc_auto_routed_products
go
update index statistics db_orc_auto_routed_products
go
sp_recompile db_orc_auto_routed_products
go
select "Finished update stats on table db_orc_auto_routed_products on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_auto_routing on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_auto_routing   
go
update statistics db_orc_auto_routing
go
update index statistics db_orc_auto_routing
go
sp_recompile db_orc_auto_routing
go
select "Finished update stats on table db_orc_auto_routing on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_exch_sett_date on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_exch_sett_date   
go
update statistics db_orc_exch_sett_date
go
update index statistics db_orc_exch_sett_date
go
sp_recompile db_orc_exch_sett_date
go
select "Finished update stats on table db_orc_exch_sett_date on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_exchange on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_exchange   
go
update statistics db_orc_exchange
go
update index statistics db_orc_exchange
go
sp_recompile db_orc_exchange
go
select "Finished update stats on table db_orc_exchange on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_exec_id on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_exec_id   
go
update statistics db_orc_exec_id
go
update index statistics db_orc_exec_id
go
sp_recompile db_orc_exec_id
go
select "Finished update stats on table db_orc_exec_id on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_executions on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_executions   
go
update statistics db_orc_executions
go
update index statistics db_orc_executions
go
sp_recompile db_orc_executions
go
select "Finished update stats on table db_orc_executions on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_executions_hist on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_executions_hist   
go
update statistics db_orc_executions_hist
go
update index statistics db_orc_executions_hist
go
sp_recompile db_orc_executions_hist
go
select "Finished update stats on table db_orc_executions_hist on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_heartbeat on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_heartbeat   
go
update statistics db_orc_heartbeat
go
update index statistics db_orc_heartbeat
go
sp_recompile db_orc_heartbeat
go
select "Finished update stats on table db_orc_heartbeat on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_imag_warrant_recon on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_imag_warrant_recon   
go
update statistics db_orc_imag_warrant_recon
go
update index statistics db_orc_imag_warrant_recon
go
sp_recompile db_orc_imag_warrant_recon
go
select "Finished update stats on table db_orc_imag_warrant_recon on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_portfolio on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_portfolio   
go
update statistics db_orc_portfolio
go
update index statistics db_orc_portfolio
go
sp_recompile db_orc_portfolio
go
select "Finished update stats on table db_orc_portfolio on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_process_state on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_process_state   
go
update statistics db_orc_process_state
go
update index statistics db_orc_process_state
go
sp_recompile db_orc_process_state
go
select "Finished update stats on table db_orc_process_state on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_sec_exchange on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_sec_exchange   
go
update statistics db_orc_sec_exchange
go
update index statistics db_orc_sec_exchange
go
sp_recompile db_orc_sec_exchange
go
select "Finished update stats on table db_orc_sec_exchange on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_trade_id_map on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_trade_id_map   
go
update statistics db_orc_trade_id_map
go
update index statistics db_orc_trade_id_map
go
sp_recompile db_orc_trade_id_map
go
select "Finished update stats on table db_orc_trade_id_map on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_trade_recon on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_trade_recon   
go
update statistics db_orc_trade_recon
go
update index statistics db_orc_trade_recon
go
sp_recompile db_orc_trade_recon
go
select "Finished update stats on table db_orc_trade_recon on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_trader on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_trader   
go
update statistics db_orc_trader
go
update index statistics db_orc_trader
go
sp_recompile db_orc_trader
go
select "Finished update stats on table db_orc_trader on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_underlying on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_underlying   
go
update statistics db_orc_underlying
go
update index statistics db_orc_underlying
go
sp_recompile db_orc_underlying
go
select "Finished update stats on table db_orc_underlying on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_orc_warrant_recon on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_orc_warrant_recon   
go
update statistics db_orc_warrant_recon
go
update index statistics db_orc_warrant_recon
go
sp_recompile db_orc_warrant_recon
go
select "Finished update stats on table db_orc_warrant_recon on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_perm_audit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_perm_audit   
go
update statistics db_perm_audit
go
update index statistics db_perm_audit
go
sp_recompile db_perm_audit
go
select "Finished update stats on table db_perm_audit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_perm_bus_cat on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_perm_bus_cat   
go
update statistics db_perm_bus_cat
go
update index statistics db_perm_bus_cat
go
sp_recompile db_perm_bus_cat
go
select "Finished update stats on table db_perm_bus_cat on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_perm_business on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_perm_business   
go
update statistics db_perm_business
go
update index statistics db_perm_business
go
sp_recompile db_perm_business
go
select "Finished update stats on table db_perm_business on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_perm_its_ged_prod on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_perm_its_ged_prod   
go
update statistics db_perm_its_ged_prod
go
update index statistics db_perm_its_ged_prod
go
sp_recompile db_perm_its_ged_prod
go
select "Finished update stats on table db_perm_its_ged_prod on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_perm_request on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_perm_request   
go
update statistics db_perm_request
go
update index statistics db_perm_request
go
sp_recompile db_perm_request
go
select "Finished update stats on table db_perm_request on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_perm_resources on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_perm_resources   
go
update statistics db_perm_resources
go
update index statistics db_perm_resources
go
sp_recompile db_perm_resources
go
select "Finished update stats on table db_perm_resources on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_perm_role on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_perm_role   
go
update statistics db_perm_role
go
update index statistics db_perm_role
go
sp_recompile db_perm_role
go
select "Finished update stats on table db_perm_role on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_perm_supervisor on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_perm_supervisor   
go
update statistics db_perm_supervisor
go
update index statistics db_perm_supervisor
go
sp_recompile db_perm_supervisor
go
select "Finished update stats on table db_perm_supervisor on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_perm_users on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_perm_users   
go
update statistics db_perm_users
go
update index statistics db_perm_users
go
sp_recompile db_perm_users
go
select "Finished update stats on table db_perm_users on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_pre_volatility_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_pre_volatility_detail   
go
update statistics db_pre_volatility_detail
go
update index statistics db_pre_volatility_detail
go
sp_recompile db_pre_volatility_detail
go
select "Finished update stats on table db_pre_volatility_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_pre_volatility_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_pre_volatility_list   
go
update statistics db_pre_volatility_list
go
update index statistics db_pre_volatility_list
go
sp_recompile db_pre_volatility_list
go
select "Finished update stats on table db_pre_volatility_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_recon_position_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_recon_position_log   
go
update statistics db_recon_position_log
go
update index statistics db_recon_position_log
go
sp_recompile db_recon_position_log
go
select "Finished update stats on table db_recon_position_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_recon_trade_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_recon_trade_log   
go
update statistics db_recon_trade_log
go
update index statistics db_recon_trade_log
go
sp_recompile db_recon_trade_log
go
select "Finished update stats on table db_recon_trade_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_request_its_ged_prods on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_request_its_ged_prods   
go
update statistics db_request_its_ged_prods
go
update index statistics db_request_its_ged_prods
go
sp_recompile db_request_its_ged_prods
go
select "Finished update stats on table db_request_its_ged_prods on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_rolled_market_prices on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_rolled_market_prices   
go
update statistics db_rolled_market_prices
go
update index statistics db_rolled_market_prices
go
sp_recompile db_rolled_market_prices
go
select "Finished update stats on table db_rolled_market_prices on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_script_parameters on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_script_parameters   
go
update statistics db_script_parameters
go
update index statistics db_script_parameters
go
sp_recompile db_script_parameters
go
select "Finished update stats on table db_script_parameters on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_sec_def_attribs_wotan on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_sec_def_attribs_wotan   
go
update statistics db_sec_def_attribs_wotan
go
update index statistics db_sec_def_attribs_wotan
go
sp_recompile db_sec_def_attribs_wotan
go
select "Finished update stats on table db_sec_def_attribs_wotan on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_security_codes on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_security_codes   
go
update statistics db_security_codes
go
update index statistics db_security_codes
go
sp_recompile db_security_codes
go
select "Finished update stats on table db_security_codes on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_status_history on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_status_history   
go
update statistics db_status_history
go
update index statistics db_status_history
go
sp_recompile db_status_history
go
select "Finished update stats on table db_status_history on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_swx_trade_reporting on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_swx_trade_reporting   
go
update statistics db_swx_trade_reporting
go
update index statistics db_swx_trade_reporting
go
sp_recompile db_swx_trade_reporting
go
select "Finished update stats on table db_swx_trade_reporting on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_temp_market_price on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_temp_market_price   
go
update statistics db_temp_market_price
go
update index statistics db_temp_market_price
go
sp_recompile db_temp_market_price
go
select "Finished update stats on table db_temp_market_price on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_tickets on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_tickets   
go
update statistics db_tickets
go
update index statistics db_tickets
go
sp_recompile db_tickets
go
select "Finished update stats on table db_tickets on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_tickets_approval_options on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_tickets_approval_options   
go
update statistics db_tickets_approval_options
go
update index statistics db_tickets_approval_options
go
sp_recompile db_tickets_approval_options
go
select "Finished update stats on table db_tickets_approval_options on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_tickets_comments on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_tickets_comments   
go
update statistics db_tickets_comments
go
update index statistics db_tickets_comments
go
sp_recompile db_tickets_comments
go
select "Finished update stats on table db_tickets_comments on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_tickets_exec_queue on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_tickets_exec_queue   
go
update statistics db_tickets_exec_queue
go
update index statistics db_tickets_exec_queue
go
sp_recompile db_tickets_exec_queue
go
select "Finished update stats on table db_tickets_exec_queue on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_tickets_status_history on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_tickets_status_history   
go
update statistics db_tickets_status_history
go
update index statistics db_tickets_status_history
go
sp_recompile db_tickets_status_history
go
select "Finished update stats on table db_tickets_status_history on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_tickets_t_user on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_tickets_t_user   
go
update statistics db_tickets_t_user
go
update index statistics db_tickets_t_user
go
sp_recompile db_tickets_t_user
go
select "Finished update stats on table db_tickets_t_user on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_tickets_user on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_tickets_user   
go
update statistics db_tickets_user
go
update index statistics db_tickets_user
go
sp_recompile db_tickets_user
go
select "Finished update stats on table db_tickets_user on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_trader_permissions on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_trader_permissions   
go
update statistics db_trader_permissions
go
update index statistics db_trader_permissions
go
sp_recompile db_trader_permissions
go
select "Finished update stats on table db_trader_permissions on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_trading_account on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_trading_account   
go
update statistics db_trading_account
go
update index statistics db_trading_account
go
sp_recompile db_trading_account
go
select "Finished update stats on table db_trading_account on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_trading_book on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_trading_book   
go
update statistics db_trading_book
go
update index statistics db_trading_book
go
sp_recompile db_trading_book
go
select "Finished update stats on table db_trading_book on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_trading_desk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_trading_desk   
go
update statistics db_trading_desk
go
update index statistics db_trading_desk
go
sp_recompile db_trading_desk
go
select "Finished update stats on table db_trading_desk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_trading_view on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_trading_view   
go
update statistics db_trading_view
go
update index statistics db_trading_view
go
sp_recompile db_trading_view
go
select "Finished update stats on table db_trading_view on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_trading_webview on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_trading_webview   
go
update statistics db_trading_webview
go
update index statistics db_trading_webview
go
sp_recompile db_trading_webview
go
select "Finished update stats on table db_trading_webview on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_ts_adjustment on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_ts_adjustment   
go
update statistics db_ts_adjustment
go
update index statistics db_ts_adjustment
go
sp_recompile db_ts_adjustment
go
select "Finished update stats on table db_ts_adjustment on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_ts_client on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_ts_client   
go
update statistics db_ts_client
go
update index statistics db_ts_client
go
sp_recompile db_ts_client
go
select "Finished update stats on table db_ts_client on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_ts_rt_config on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_ts_rt_config   
go
update statistics db_ts_rt_config
go
update index statistics db_ts_rt_config
go
sp_recompile db_ts_rt_config
go
select "Finished update stats on table db_ts_rt_config on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_ts_source on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_ts_source   
go
update statistics db_ts_source
go
update index statistics db_ts_source
go
sp_recompile db_ts_source
go
select "Finished update stats on table db_ts_source on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_ts_xml_req_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_ts_xml_req_detail   
go
update statistics db_ts_xml_req_detail
go
update index statistics db_ts_xml_req_detail
go
sp_recompile db_ts_xml_req_detail
go
select "Finished update stats on table db_ts_xml_req_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_ts_xml_request on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_ts_xml_request   
go
update statistics db_ts_xml_request
go
update index statistics db_ts_xml_request
go
sp_recompile db_ts_xml_request
go
select "Finished update stats on table db_ts_xml_request on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_ts_xml_res_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_ts_xml_res_detail   
go
update statistics db_ts_xml_res_detail
go
update index statistics db_ts_xml_res_detail
go
sp_recompile db_ts_xml_res_detail
go
select "Finished update stats on table db_ts_xml_res_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_ts_xml_response on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_ts_xml_response   
go
update statistics db_ts_xml_response
go
update index statistics db_ts_xml_response
go
sp_recompile db_ts_xml_response
go
select "Finished update stats on table db_ts_xml_response on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_valid_interface_users on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_valid_interface_users   
go
update statistics db_valid_interface_users
go
update index statistics db_valid_interface_users
go
sp_recompile db_valid_interface_users
go
select "Finished update stats on table db_valid_interface_users on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_volatility_ancillary on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_volatility_ancillary   
go
update statistics db_volatility_ancillary
go
update index statistics db_volatility_ancillary
go
sp_recompile db_volatility_ancillary
go
select "Finished update stats on table db_volatility_ancillary on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_xetra_defaults on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_xetra_defaults   
go
update statistics db_xetra_defaults
go
update index statistics db_xetra_defaults
go
sp_recompile db_xetra_defaults
go
select "Finished update stats on table db_xetra_defaults on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_xol_master_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_xol_master_list   
go
update statistics db_xol_master_list
go
update index statistics db_xol_master_list
go
sp_recompile db_xol_master_list
go
select "Finished update stats on table db_xol_master_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table db_xol_outgoing_ca on " +convert(varchar(25),getdate(),100)
go
sp_spaceused db_xol_outgoing_ca   
go
update statistics db_xol_outgoing_ca
go
update index statistics db_xol_outgoing_ca
go
sp_recompile db_xol_outgoing_ca
go
select "Finished update stats on table db_xol_outgoing_ca on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dba__rep_delay on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dba__rep_delay   
go
update statistics dba__rep_delay
go
update index statistics dba__rep_delay
go
sp_recompile dba__rep_delay
go
select "Finished update stats on table dba__rep_delay on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dba_check_rep_delay on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dba_check_rep_delay   
go
update statistics dba_check_rep_delay
go
update index statistics dba_check_rep_delay
go
sp_recompile dba_check_rep_delay
go
select "Finished update stats on table dba_check_rep_delay on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dba_check_sko on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dba_check_sko   
go
update statistics dba_check_sko
go
update index statistics dba_check_sko
go
sp_recompile dba_check_sko
go
select "Finished update stats on table dba_check_sko on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dba_test on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dba_test   
go
update statistics dba_test
go
update index statistics dba_test
go
sp_recompile dba_test
go
select "Finished update stats on table dba_test on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dba_test1 on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dba_test1   
go
update statistics dba_test1
go
update index statistics dba_test1
go
sp_recompile dba_test1
go
select "Finished update stats on table dba_test1 on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbs_COUNTER on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbs_COUNTER   
go
update statistics dbs_COUNTER
go
update index statistics dbs_COUNTER
go
sp_recompile dbs_COUNTER
go
select "Finished update stats on table dbs_COUNTER on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbt_kueu_file on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbt_kueu_file   
go
update statistics dbt_kueu_file
go
update index statistics dbt_kueu_file
go
sp_recompile dbt_kueu_file
go
select "Finished update stats on table dbt_kueu_file on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbt_sec_map on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbt_sec_map   
go
update statistics dbt_sec_map
go
update index statistics dbt_sec_map
go
sp_recompile dbt_sec_map
go
select "Finished update stats on table dbt_sec_map on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbt_sec_type_mapping on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbt_sec_type_mapping   
go
update statistics dbt_sec_type_mapping
go
update index statistics dbt_sec_type_mapping
go
sp_recompile dbt_sec_type_mapping
go
select "Finished update stats on table dbt_sec_type_mapping on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbt_sec_xfce on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbt_sec_xfce   
go
update statistics dbt_sec_xfce
go
update index statistics dbt_sec_xfce
go
sp_recompile dbt_sec_xfce
go
select "Finished update stats on table dbt_sec_xfce on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbt_sequence on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbt_sequence   
go
update statistics dbt_sequence
go
update index statistics dbt_sequence
go
sp_recompile dbt_sequence
go
select "Finished update stats on table dbt_sequence on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbt_trade_target on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbt_trade_target   
go
update statistics dbt_trade_target
go
update index statistics dbt_trade_target
go
sp_recompile dbt_trade_target
go
select "Finished update stats on table dbt_trade_target on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbt_trade_target_temp on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbt_trade_target_temp   
go
update statistics dbt_trade_target_temp
go
update index statistics dbt_trade_target_temp
go
sp_recompile dbt_trade_target_temp
go
select "Finished update stats on table dbt_trade_target_temp on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbt_trade_triggers on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbt_trade_triggers   
go
update statistics dbt_trade_triggers
go
update index statistics dbt_trade_triggers
go
sp_recompile dbt_trade_triggers
go
select "Finished update stats on table dbt_trade_triggers on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table dbtrader_secm on " +convert(varchar(25),getdate(),100)
go
sp_spaceused dbtrader_secm   
go
update statistics dbtrader_secm
go
update index statistics dbtrader_secm
go
sp_recompile dbtrader_secm
go
select "Finished update stats on table dbtrader_secm on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table euro_rates on " +convert(varchar(25),getdate(),100)
go
sp_spaceused euro_rates   
go
update statistics euro_rates
go
update index statistics euro_rates
go
sp_recompile euro_rates
go
select "Finished update stats on table euro_rates on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table exec_queue_errors on " +convert(varchar(25),getdate(),100)
go
sp_spaceused exec_queue_errors   
go
update statistics exec_queue_errors
go
update index statistics exec_queue_errors
go
sp_recompile exec_queue_errors
go
select "Finished update stats on table exec_queue_errors on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table gedi_admin_status on " +convert(varchar(25),getdate(),100)
go
sp_spaceused gedi_admin_status   
go
update statistics gedi_admin_status
go
update index statistics gedi_admin_status
go
sp_recompile gedi_admin_status
go
select "Finished update stats on table gedi_admin_status on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table gepg_risk_portfolio on " +convert(varchar(25),getdate(),100)
go
sp_spaceused gepg_risk_portfolio   
go
update statistics gepg_risk_portfolio
go
update index statistics gepg_risk_portfolio
go
sp_recompile gepg_risk_portfolio
go
select "Finished update stats on table gepg_risk_portfolio on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_account on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_account   
go
update statistics hts_account
go
update index statistics hts_account
go
sp_recompile hts_account
go
select "Finished update stats on table hts_account on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_action_profile on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_action_profile   
go
update statistics hts_action_profile
go
update index statistics hts_action_profile
go
sp_recompile hts_action_profile
go
select "Finished update stats on table hts_action_profile on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_action_profile_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_action_profile_list   
go
update statistics hts_action_profile_list
go
update index statistics hts_action_profile_list
go
sp_recompile hts_action_profile_list
go
select "Finished update stats on table hts_action_profile_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_adj_audit_trail_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_adj_audit_trail_log   
go
update statistics hts_adj_audit_trail_log
go
update index statistics hts_adj_audit_trail_log
go
sp_recompile hts_adj_audit_trail_log
go
select "Finished update stats on table hts_adj_audit_trail_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_adj_event_detail_wrk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_adj_event_detail_wrk   
go
update statistics hts_adj_event_detail_wrk
go
update index statistics hts_adj_event_detail_wrk
go
sp_recompile hts_adj_event_detail_wrk
go
select "Finished update stats on table hts_adj_event_detail_wrk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_adjustment on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_adjustment   
go
update statistics hts_adjustment
go
update index statistics hts_adjustment
go
sp_recompile hts_adjustment
go
select "Finished update stats on table hts_adjustment on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_adjustment_user_data on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_adjustment_user_data   
go
update statistics hts_adjustment_user_data
go
update index statistics hts_adjustment_user_data
go
sp_recompile hts_adjustment_user_data
go
select "Finished update stats on table hts_adjustment_user_data on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_ae_codes on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_ae_codes   
go
update statistics hts_ae_codes
go
update index statistics hts_ae_codes
go
sp_recompile hts_ae_codes
go
select "Finished update stats on table hts_ae_codes on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_audit_status on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_audit_status   
go
update statistics hts_audit_status
go
update index statistics hts_audit_status
go
sp_recompile hts_audit_status
go
select "Finished update stats on table hts_audit_status on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_auto_quote on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_auto_quote   
go
update statistics hts_auto_quote
go
update index statistics hts_auto_quote
go
sp_recompile hts_auto_quote
go
select "Finished update stats on table hts_auto_quote on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_b2b_trade_event on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_b2b_trade_event   
go
update statistics hts_b2b_trade_event
go
update index statistics hts_b2b_trade_event
go
sp_recompile hts_b2b_trade_event
go
select "Finished update stats on table hts_b2b_trade_event on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_ba_spread_class on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_ba_spread_class   
go
update statistics hts_ba_spread_class
go
update index statistics hts_ba_spread_class
go
sp_recompile hts_ba_spread_class
go
select "Finished update stats on table hts_ba_spread_class on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_ba_spread_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_ba_spread_detail   
go
update statistics hts_ba_spread_detail
go
update index statistics hts_ba_spread_detail
go
sp_recompile hts_ba_spread_detail
go
select "Finished update stats on table hts_ba_spread_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_ba_spread_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_ba_spread_list   
go
update statistics hts_ba_spread_list
go
update index statistics hts_ba_spread_list
go
sp_recompile hts_ba_spread_list
go
select "Finished update stats on table hts_ba_spread_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_balance_transfer_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_balance_transfer_log   
go
update statistics hts_balance_transfer_log
go
update index statistics hts_balance_transfer_log
go
sp_recompile hts_balance_transfer_log
go
select "Finished update stats on table hts_balance_transfer_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_basis_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_basis_detail   
go
update statistics hts_basis_detail
go
update index statistics hts_basis_detail
go
sp_recompile hts_basis_detail
go
select "Finished update stats on table hts_basis_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_basis_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_basis_list   
go
update statistics hts_basis_list
go
update index statistics hts_basis_list
go
sp_recompile hts_basis_list
go
select "Finished update stats on table hts_basis_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_bo_event on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_bo_event   
go
update statistics hts_bo_event
go
update index statistics hts_bo_event
go
sp_recompile hts_bo_event
go
select "Finished update stats on table hts_bo_event on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_borrow_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_borrow_detail   
go
update statistics hts_borrow_detail
go
update index statistics hts_borrow_detail
go
sp_recompile hts_borrow_detail
go
select "Finished update stats on table hts_borrow_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_borrow_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_borrow_list   
go
update statistics hts_borrow_list
go
update index statistics hts_borrow_list
go
sp_recompile hts_borrow_list
go
select "Finished update stats on table hts_borrow_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_broker on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_broker   
go
update statistics hts_broker
go
update index statistics hts_broker
go
sp_recompile hts_broker
go
select "Finished update stats on table hts_broker on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_broker_settle_rule on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_broker_settle_rule   
go
update statistics hts_broker_settle_rule
go
update index statistics hts_broker_settle_rule
go
sp_recompile hts_broker_settle_rule
go
select "Finished update stats on table hts_broker_settle_rule on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_broker_user_data on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_broker_user_data   
go
update statistics hts_broker_user_data
go
update index statistics hts_broker_user_data
go
sp_recompile hts_broker_user_data
go
select "Finished update stats on table hts_broker_user_data on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_bs_codes on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_bs_codes   
go
update statistics hts_bs_codes
go
update index statistics hts_bs_codes
go
sp_recompile hts_bs_codes
go
select "Finished update stats on table hts_bs_codes on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_ca_event on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_ca_event   
go
update statistics hts_ca_event
go
update index statistics hts_ca_event
go
sp_recompile hts_ca_event
go
select "Finished update stats on table hts_ca_event on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_capreq_basket on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_capreq_basket   
go
update statistics hts_capreq_basket
go
update index statistics hts_capreq_basket
go
sp_recompile hts_capreq_basket
go
select "Finished update stats on table hts_capreq_basket on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_capreq_divisors on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_capreq_divisors   
go
update statistics hts_capreq_divisors
go
update index statistics hts_capreq_divisors
go
sp_recompile hts_capreq_divisors
go
select "Finished update stats on table hts_capreq_divisors on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_capreq_overrides on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_capreq_overrides   
go
update statistics hts_capreq_overrides
go
update index statistics hts_capreq_overrides
go
sp_recompile hts_capreq_overrides
go
select "Finished update stats on table hts_capreq_overrides on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_capreq_xref on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_capreq_xref   
go
update statistics hts_capreq_xref
go
update index statistics hts_capreq_xref
go
sp_recompile hts_capreq_xref
go
select "Finished update stats on table hts_capreq_xref on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_cash_coll_sched on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_cash_coll_sched   
go
update statistics hts_cash_coll_sched
go
update index statistics hts_cash_coll_sched
go
sp_recompile hts_cash_coll_sched
go
select "Finished update stats on table hts_cash_coll_sched on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_ccy_round on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_ccy_round   
go
update statistics hts_ccy_round
go
update index statistics hts_ccy_round
go
sp_recompile hts_ccy_round
go
select "Finished update stats on table hts_ccy_round on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_charge_interval on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_charge_interval   
go
update statistics hts_charge_interval
go
update index statistics hts_charge_interval
go
sp_recompile hts_charge_interval
go
select "Finished update stats on table hts_charge_interval on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_charge_rule on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_charge_rule   
go
update statistics hts_charge_rule
go
update index statistics hts_charge_rule
go
sp_recompile hts_charge_rule
go
select "Finished update stats on table hts_charge_rule on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_charge_sched_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_charge_sched_detail   
go
update statistics hts_charge_sched_detail
go
update index statistics hts_charge_sched_detail
go
sp_recompile hts_charge_sched_detail
go
select "Finished update stats on table hts_charge_sched_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_charge_sched_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_charge_sched_list   
go
update statistics hts_charge_sched_list
go
update index statistics hts_charge_sched_list
go
sp_recompile hts_charge_sched_list
go
select "Finished update stats on table hts_charge_sched_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_charge_schedule on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_charge_schedule   
go
update statistics hts_charge_schedule
go
update index statistics hts_charge_schedule
go
sp_recompile hts_charge_schedule
go
select "Finished update stats on table hts_charge_schedule on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_charge_type on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_charge_type   
go
update statistics hts_charge_type
go
update index statistics hts_charge_type
go
sp_recompile hts_charge_type
go
select "Finished update stats on table hts_charge_type on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_coll_pool on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_coll_pool   
go
update statistics hts_coll_pool
go
update index statistics hts_coll_pool
go
sp_recompile hts_coll_pool
go
select "Finished update stats on table hts_coll_pool on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_collateral on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_collateral   
go
update statistics hts_collateral
go
update index statistics hts_collateral
go
sp_recompile hts_collateral
go
select "Finished update stats on table hts_collateral on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_constituent on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_constituent   
go
update statistics hts_constituent
go
update index statistics hts_constituent
go
sp_recompile hts_constituent
go
select "Finished update stats on table hts_constituent on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_corr_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_corr_detail   
go
update statistics hts_corr_detail
go
update index statistics hts_corr_detail
go
sp_recompile hts_corr_detail
go
select "Finished update stats on table hts_corr_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_corr_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_corr_list   
go
update statistics hts_corr_list
go
update index statistics hts_corr_list
go
sp_recompile hts_corr_list
go
select "Finished update stats on table hts_corr_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_country on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_country   
go
update statistics hts_country
go
update index statistics hts_country
go
sp_recompile hts_country
go
select "Finished update stats on table hts_country on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_credit_ratings on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_credit_ratings   
go
update statistics hts_credit_ratings
go
update index statistics hts_credit_ratings
go
sp_recompile hts_credit_ratings
go
select "Finished update stats on table hts_credit_ratings on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_credit_spreads on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_credit_spreads   
go
update statistics hts_credit_spreads
go
update index statistics hts_credit_spreads
go
sp_recompile hts_credit_spreads
go
select "Finished update stats on table hts_credit_spreads on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_credit_spreads_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_credit_spreads_list   
go
update statistics hts_credit_spreads_list
go
update index statistics hts_credit_spreads_list
go
sp_recompile hts_credit_spreads_list
go
select "Finished update stats on table hts_credit_spreads_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_customer on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_customer   
go
update statistics hts_customer
go
update index statistics hts_customer
go
sp_recompile hts_customer
go
select "Finished update stats on table hts_customer on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_customer_usage on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_customer_usage   
go
update statistics hts_customer_usage
go
update index statistics hts_customer_usage
go
sp_recompile hts_customer_usage
go
select "Finished update stats on table hts_customer_usage on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_data_relation on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_data_relation   
go
update statistics hts_data_relation
go
update index statistics hts_data_relation
go
sp_recompile hts_data_relation
go
select "Finished update stats on table hts_data_relation on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_db_listener on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_db_listener   
go
update statistics hts_db_listener
go
update index statistics hts_db_listener
go
sp_recompile hts_db_listener
go
select "Finished update stats on table hts_db_listener on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_db_upgrades on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_db_upgrades   
go
update statistics hts_db_upgrades
go
update index statistics hts_db_upgrades
go
sp_recompile hts_db_upgrades
go
select "Finished update stats on table hts_db_upgrades on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dbl_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dbl_log   
go
update statistics hts_dbl_log
go
update index statistics hts_dbl_log
go
sp_recompile hts_dbl_log
go
select "Finished update stats on table hts_dbl_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dbl_trade_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dbl_trade_log   
go
update statistics hts_dbl_trade_log
go
update index statistics hts_dbl_trade_log
go
sp_recompile hts_dbl_trade_log
go
select "Finished update stats on table hts_dbl_trade_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dbt_fee_map on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dbt_fee_map   
go
update statistics hts_dbt_fee_map
go
update index statistics hts_dbt_fee_map
go
sp_recompile hts_dbt_fee_map
go
select "Finished update stats on table hts_dbt_fee_map on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dbt_fi_sec on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dbt_fi_sec   
go
update statistics hts_dbt_fi_sec
go
update index statistics hts_dbt_fi_sec
go
sp_recompile hts_dbt_fi_sec
go
select "Finished update stats on table hts_dbt_fi_sec on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dbt_system_route on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dbt_system_route   
go
update statistics hts_dbt_system_route
go
update index statistics hts_dbt_system_route
go
sp_recompile hts_dbt_system_route
go
select "Finished update stats on table hts_dbt_system_route on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dbt_xfce on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dbt_xfce   
go
update statistics hts_dbt_xfce
go
update index statistics hts_dbt_xfce
go
sp_recompile hts_dbt_xfce
go
select "Finished update stats on table hts_dbt_xfce on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_deal on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_deal   
go
update statistics hts_deal
go
update index statistics hts_deal
go
sp_recompile hts_deal
go
select "Finished update stats on table hts_deal on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dividend_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dividend_detail   
go
update statistics hts_dividend_detail
go
update index statistics hts_dividend_detail
go
sp_recompile hts_dividend_detail
go
select "Finished update stats on table hts_dividend_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dividend_detail_arc on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dividend_detail_arc   
go
update statistics hts_dividend_detail_arc
go
update index statistics hts_dividend_detail_arc
go
sp_recompile hts_dividend_detail_arc
go
select "Finished update stats on table hts_dividend_detail_arc on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dividend_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dividend_list   
go
update statistics hts_dividend_list
go
update index statistics hts_dividend_list
go
sp_recompile hts_dividend_list
go
select "Finished update stats on table hts_dividend_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dividend_list_arc on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dividend_list_arc   
go
update statistics hts_dividend_list_arc
go
update index statistics hts_dividend_list_arc
go
sp_recompile hts_dividend_list_arc
go
select "Finished update stats on table hts_dividend_list_arc on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dividend_status_ref on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dividend_status_ref   
go
update statistics hts_dividend_status_ref
go
update index statistics hts_dividend_status_ref
go
sp_recompile hts_dividend_status_ref
go
select "Finished update stats on table hts_dividend_status_ref on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dividend_type_ref on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dividend_type_ref   
go
update statistics hts_dividend_type_ref
go
update index statistics hts_dividend_type_ref
go
sp_recompile hts_dividend_type_ref
go
select "Finished update stats on table hts_dividend_type_ref on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dynamic_apps on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dynamic_apps   
go
update statistics hts_dynamic_apps
go
update index statistics hts_dynamic_apps
go
sp_recompile hts_dynamic_apps
go
select "Finished update stats on table hts_dynamic_apps on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_dynrule_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_dynrule_list   
go
update statistics hts_dynrule_list
go
update index statistics hts_dynrule_list
go
sp_recompile hts_dynrule_list
go
select "Finished update stats on table hts_dynrule_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_emu_conv_event on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_emu_conv_event   
go
update statistics hts_emu_conv_event
go
update index statistics hts_emu_conv_event
go
sp_recompile hts_emu_conv_event
go
select "Finished update stats on table hts_emu_conv_event on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_eqcd_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_eqcd_detail   
go
update statistics hts_eqcd_detail
go
update index statistics hts_eqcd_detail
go
sp_recompile hts_eqcd_detail
go
select "Finished update stats on table hts_eqcd_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_event_types on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_event_types   
go
update statistics hts_event_types
go
update index statistics hts_event_types
go
sp_recompile hts_event_types
go
select "Finished update stats on table hts_event_types on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_exchange on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_exchange   
go
update statistics hts_exchange
go
update index statistics hts_exchange
go
sp_recompile hts_exchange
go
select "Finished update stats on table hts_exchange on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_exchange_settle_rules on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_exchange_settle_rules   
go
update statistics hts_exchange_settle_rules
go
update index statistics hts_exchange_settle_rules
go
sp_recompile hts_exchange_settle_rules
go
select "Finished update stats on table hts_exchange_settle_rules on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_exchange_snap_status on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_exchange_snap_status   
go
update statistics hts_exchange_snap_status
go
update index statistics hts_exchange_snap_status
go
sp_recompile hts_exchange_snap_status
go
select "Finished update stats on table hts_exchange_snap_status on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_exec_adj on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_exec_adj   
go
update statistics hts_exec_adj
go
update index statistics hts_exec_adj
go
sp_recompile hts_exec_adj
go
select "Finished update stats on table hts_exec_adj on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_exec_adj_defaults on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_exec_adj_defaults   
go
update statistics hts_exec_adj_defaults
go
update index statistics hts_exec_adj_defaults
go
sp_recompile hts_exec_adj_defaults
go
select "Finished update stats on table hts_exec_adj_defaults on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_exec_adj_event_detail_wrk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_exec_adj_event_detail_wrk   
go
update statistics hts_exec_adj_event_detail_wrk
go
update index statistics hts_exec_adj_event_detail_wrk
go
sp_recompile hts_exec_adj_event_detail_wrk
go
select "Finished update stats on table hts_exec_adj_event_detail_wrk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_exec_control on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_exec_control   
go
update statistics hts_exec_control
go
update index statistics hts_exec_control
go
sp_recompile hts_exec_control
go
select "Finished update stats on table hts_exec_control on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_exer_notice on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_exer_notice   
go
update statistics hts_exer_notice
go
update index statistics hts_exer_notice
go
sp_recompile hts_exer_notice
go
select "Finished update stats on table hts_exer_notice on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_fi_sec_master on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_fi_sec_master   
go
update statistics hts_fi_sec_master
go
update index statistics hts_fi_sec_master
go
sp_recompile hts_fi_sec_master
go
select "Finished update stats on table hts_fi_sec_master on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_filter_columns on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_filter_columns   
go
update statistics hts_filter_columns
go
update index statistics hts_filter_columns
go
sp_recompile hts_filter_columns
go
select "Finished update stats on table hts_filter_columns on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_filter_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_filter_detail   
go
update statistics hts_filter_detail
go
update index statistics hts_filter_detail
go
sp_recompile hts_filter_detail
go
select "Finished update stats on table hts_filter_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_filter_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_filter_list   
go
update statistics hts_filter_list
go
update index statistics hts_filter_list
go
sp_recompile hts_filter_list
go
select "Finished update stats on table hts_filter_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_fiscal_calendar on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_fiscal_calendar   
go
update statistics hts_fiscal_calendar
go
update index statistics hts_fiscal_calendar
go
sp_recompile hts_fiscal_calendar
go
select "Finished update stats on table hts_fiscal_calendar on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_fixings on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_fixings   
go
update statistics hts_fixings
go
update index statistics hts_fixings
go
sp_recompile hts_fixings
go
select "Finished update stats on table hts_fixings on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_formula_rule_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_formula_rule_detail   
go
update statistics hts_formula_rule_detail
go
update index statistics hts_formula_rule_detail
go
sp_recompile hts_formula_rule_detail
go
select "Finished update stats on table hts_formula_rule_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_formula_rule_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_formula_rule_list   
go
update statistics hts_formula_rule_list
go
update index statistics hts_formula_rule_list
go
sp_recompile hts_formula_rule_list
go
select "Finished update stats on table hts_formula_rule_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_forward_yield_type_ref on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_forward_yield_type_ref   
go
update statistics hts_forward_yield_type_ref
go
update index statistics hts_forward_yield_type_ref
go
sp_recompile hts_forward_yield_type_ref
go
select "Finished update stats on table hts_forward_yield_type_ref on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_funding_rates on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_funding_rates   
go
update statistics hts_funding_rates
go
update index statistics hts_funding_rates
go
sp_recompile hts_funding_rates
go
select "Finished update stats on table hts_funding_rates on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_fx_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_fx_detail   
go
update statistics hts_fx_detail
go
update index statistics hts_fx_detail
go
sp_recompile hts_fx_detail
go
select "Finished update stats on table hts_fx_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_fx_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_fx_list   
go
update statistics hts_fx_list
go
update index statistics hts_fx_list
go
sp_recompile hts_fx_list
go
select "Finished update stats on table hts_fx_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_gen_otc on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_gen_otc   
go
update statistics hts_gen_otc
go
update index statistics hts_gen_otc
go
sp_recompile hts_gen_otc
go
select "Finished update stats on table hts_gen_otc on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_gen_sec_types on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_gen_sec_types   
go
update statistics hts_gen_sec_types
go
update index statistics hts_gen_sec_types
go
sp_recompile hts_gen_sec_types
go
select "Finished update stats on table hts_gen_sec_types on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_genfilter_cells on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_genfilter_cells   
go
update statistics hts_genfilter_cells
go
update index statistics hts_genfilter_cells
go
sp_recompile hts_genfilter_cells
go
select "Finished update stats on table hts_genfilter_cells on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_genfilter_columns on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_genfilter_columns   
go
update statistics hts_genfilter_columns
go
update index statistics hts_genfilter_columns
go
sp_recompile hts_genfilter_columns
go
select "Finished update stats on table hts_genfilter_columns on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_genfilter_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_genfilter_detail   
go
update statistics hts_genfilter_detail
go
update index statistics hts_genfilter_detail
go
sp_recompile hts_genfilter_detail
go
select "Finished update stats on table hts_genfilter_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_gotc_rebate_pay_types on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_gotc_rebate_pay_types   
go
update statistics hts_gotc_rebate_pay_types
go
update index statistics hts_gotc_rebate_pay_types
go
sp_recompile hts_gotc_rebate_pay_types
go
select "Finished update stats on table hts_gotc_rebate_pay_types on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_gotc_schedule on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_gotc_schedule   
go
update statistics hts_gotc_schedule
go
update index statistics hts_gotc_schedule
go
sp_recompile hts_gotc_schedule
go
select "Finished update stats on table hts_gotc_schedule on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_gotc_trigger_types on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_gotc_trigger_types   
go
update statistics hts_gotc_trigger_types
go
update index statistics hts_gotc_trigger_types
go
sp_recompile hts_gotc_trigger_types
go
select "Finished update stats on table hts_gotc_trigger_types on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_group on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_group   
go
update statistics hts_group
go
update index statistics hts_group
go
sp_recompile hts_group
go
select "Finished update stats on table hts_group on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_group_control on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_group_control   
go
update statistics hts_group_control
go
update index statistics hts_group_control
go
sp_recompile hts_group_control
go
select "Finished update stats on table hts_group_control on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_historical_prices on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_historical_prices   
go
update statistics hts_historical_prices
go
update index statistics hts_historical_prices
go
sp_recompile hts_historical_prices
go
select "Finished update stats on table hts_historical_prices on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_hldGetQty_wrk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_hldGetQty_wrk   
go
update statistics hts_hldGetQty_wrk
go
update index statistics hts_hldGetQty_wrk
go
sp_recompile hts_hldGetQty_wrk
go
select "Finished update stats on table hts_hldGetQty_wrk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_hold_audit_trail_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_hold_audit_trail_log   
go
update statistics hts_hold_audit_trail_log
go
update index statistics hts_hold_audit_trail_log
go
sp_recompile hts_hold_audit_trail_log
go
select "Finished update stats on table hts_hold_audit_trail_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_hold_map on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_hold_map   
go
update statistics hts_hold_map
go
update index statistics hts_hold_map
go
sp_recompile hts_hold_map
go
select "Finished update stats on table hts_hold_map on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_hold_user_data on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_hold_user_data   
go
update statistics hts_hold_user_data
go
update index statistics hts_hold_user_data
go
sp_recompile hts_hold_user_data
go
select "Finished update stats on table hts_hold_user_data on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_holding_greeks on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_holding_greeks   
go
update statistics hts_holding_greeks
go
update index statistics hts_holding_greeks
go
sp_recompile hts_holding_greeks
go
select "Finished update stats on table hts_holding_greeks on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_holiday_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_holiday_detail   
go
update statistics hts_holiday_detail
go
update index statistics hts_holiday_detail
go
sp_recompile hts_holiday_detail
go
select "Finished update stats on table hts_holiday_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_holiday_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_holiday_list   
go
update statistics hts_holiday_list
go
update index statistics hts_holiday_list
go
sp_recompile hts_holiday_list
go
select "Finished update stats on table hts_holiday_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_id_pool_wrk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_id_pool_wrk   
go
update statistics hts_id_pool_wrk
go
update index statistics hts_id_pool_wrk
go
sp_recompile hts_id_pool_wrk
go
select "Finished update stats on table hts_id_pool_wrk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_industry on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_industry   
go
update statistics hts_industry
go
update index statistics hts_industry
go
sp_recompile hts_industry
go
select "Finished update stats on table hts_industry on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_irate_source on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_irate_source   
go
update statistics hts_irate_source
go
update index statistics hts_irate_source
go
sp_recompile hts_irate_source
go
select "Finished update stats on table hts_irate_source on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_issuer on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_issuer   
go
update statistics hts_issuer
go
update index statistics hts_issuer
go
sp_recompile hts_issuer
go
select "Finished update stats on table hts_issuer on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_issuer_related_view on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_issuer_related_view   
go
update statistics hts_issuer_related_view
go
update index statistics hts_issuer_related_view
go
sp_recompile hts_issuer_related_view
go
select "Finished update stats on table hts_issuer_related_view on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_legacy_stock_split on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_legacy_stock_split   
go
update statistics hts_legacy_stock_split
go
update index statistics hts_legacy_stock_split
go
sp_recompile hts_legacy_stock_split
go
select "Finished update stats on table hts_legacy_stock_split on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_legal_entity on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_legal_entity   
go
update statistics hts_legal_entity
go
update index statistics hts_legal_entity
go
sp_recompile hts_legal_entity
go
select "Finished update stats on table hts_legal_entity on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_lim_cmb_type on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_lim_cmb_type   
go
update statistics hts_lim_cmb_type
go
update index statistics hts_lim_cmb_type
go
sp_recompile hts_lim_cmb_type
go
select "Finished update stats on table hts_lim_cmb_type on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_limit_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_limit_detail   
go
update statistics hts_limit_detail
go
update index statistics hts_limit_detail
go
sp_recompile hts_limit_detail
go
select "Finished update stats on table hts_limit_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_limit_field on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_limit_field   
go
update statistics hts_limit_field
go
update index statistics hts_limit_field
go
sp_recompile hts_limit_field
go
select "Finished update stats on table hts_limit_field on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_limit_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_limit_list   
go
update statistics hts_limit_list
go
update index statistics hts_limit_list
go
sp_recompile hts_limit_list
go
select "Finished update stats on table hts_limit_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_limit_monitor_event on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_limit_monitor_event   
go
update statistics hts_limit_monitor_event
go
update index statistics hts_limit_monitor_event
go
sp_recompile hts_limit_monitor_event
go
select "Finished update stats on table hts_limit_monitor_event on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_location on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_location   
go
update statistics hts_location
go
update index statistics hts_location
go
sp_recompile hts_location
go
select "Finished update stats on table hts_location on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_location_tz on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_location_tz   
go
update statistics hts_location_tz
go
update index statistics hts_location_tz
go
sp_recompile hts_location_tz
go
select "Finished update stats on table hts_location_tz on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_lock on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_lock   
go
update statistics hts_lock
go
update index statistics hts_lock
go
sp_recompile hts_lock
go
select "Finished update stats on table hts_lock on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_mark on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_mark   
go
update statistics hts_mark
go
update index statistics hts_mark
go
sp_recompile hts_mark
go
select "Finished update stats on table hts_mark on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_mark_acct on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_mark_acct   
go
update statistics hts_mark_acct
go
update index statistics hts_mark_acct
go
sp_recompile hts_mark_acct
go
select "Finished update stats on table hts_mark_acct on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_market_price on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_market_price   
go
update statistics hts_market_price
go
update index statistics hts_market_price
go
sp_recompile hts_market_price
go
select "Finished update stats on table hts_market_price on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_mmkt_usec on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_mmkt_usec   
go
update statistics hts_mmkt_usec
go
update index statistics hts_mmkt_usec
go
sp_recompile hts_mmkt_usec
go
select "Finished update stats on table hts_mmkt_usec on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_monitor_limit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_monitor_limit   
go
update statistics hts_monitor_limit
go
update index statistics hts_monitor_limit
go
sp_recompile hts_monitor_limit
go
select "Finished update stats on table hts_monitor_limit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_name_change_notice on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_name_change_notice   
go
update statistics hts_name_change_notice
go
update index statistics hts_name_change_notice
go
sp_recompile hts_name_change_notice
go
select "Finished update stats on table hts_name_change_notice on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_next_rowid on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_next_rowid   
go
update statistics hts_next_rowid
go
update index statistics hts_next_rowid
go
sp_recompile hts_next_rowid
go
select "Finished update stats on table hts_next_rowid on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_nosplit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_nosplit   
go
update statistics hts_nosplit
go
update index statistics hts_nosplit
go
sp_recompile hts_nosplit
go
select "Finished update stats on table hts_nosplit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_object_limit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_object_limit   
go
update statistics hts_object_limit
go
update index statistics hts_object_limit
go
sp_recompile hts_object_limit
go
select "Finished update stats on table hts_object_limit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_obsolete_objects_wrk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_obsolete_objects_wrk   
go
update statistics hts_obsolete_objects_wrk
go
update index statistics hts_obsolete_objects_wrk
go
sp_recompile hts_obsolete_objects_wrk
go
select "Finished update stats on table hts_obsolete_objects_wrk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_opt_exer_event on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_opt_exer_event   
go
update statistics hts_opt_exer_event
go
update index statistics hts_opt_exer_event
go
sp_recompile hts_opt_exer_event
go
select "Finished update stats on table hts_opt_exer_event on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_ord_control on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_ord_control   
go
update statistics hts_ord_control
go
update index statistics hts_ord_control
go
sp_recompile hts_ord_control
go
select "Finished update stats on table hts_ord_control on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_order_groups_wrk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_order_groups_wrk   
go
update statistics hts_order_groups_wrk
go
update index statistics hts_order_groups_wrk
go
sp_recompile hts_order_groups_wrk
go
select "Finished update stats on table hts_order_groups_wrk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_ordhdg_group_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_ordhdg_group_detail   
go
update statistics hts_ordhdg_group_detail
go
update index statistics hts_ordhdg_group_detail
go
sp_recompile hts_ordhdg_group_detail
go
select "Finished update stats on table hts_ordhdg_group_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_ordhdg_group_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_ordhdg_group_list   
go
update statistics hts_ordhdg_group_list
go
update index statistics hts_ordhdg_group_list
go
sp_recompile hts_ordhdg_group_list
go
select "Finished update stats on table hts_ordhdg_group_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_pc_codes on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_pc_codes   
go
update statistics hts_pc_codes
go
update index statistics hts_pc_codes
go
sp_recompile hts_pc_codes
go
select "Finished update stats on table hts_pc_codes on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_perm_control on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_perm_control   
go
update statistics hts_perm_control
go
update index statistics hts_perm_control
go
sp_recompile hts_perm_control
go
select "Finished update stats on table hts_perm_control on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_pl_archive on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_pl_archive   
go
update statistics hts_pl_archive
go
update index statistics hts_pl_archive
go
sp_recompile hts_pl_archive
go
select "Finished update stats on table hts_pl_archive on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_port_control on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_port_control   
go
update statistics hts_port_control
go
update index statistics hts_port_control
go
sp_recompile hts_port_control
go
select "Finished update stats on table hts_port_control on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_price_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_price_detail   
go
update statistics hts_price_detail
go
update index statistics hts_price_detail
go
sp_recompile hts_price_detail
go
select "Finished update stats on table hts_price_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_price_env on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_price_env   
go
update statistics hts_price_env
go
update index statistics hts_price_env
go
sp_recompile hts_price_env
go
select "Finished update stats on table hts_price_env on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_price_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_price_list   
go
update statistics hts_price_list
go
update index statistics hts_price_list
go
sp_recompile hts_price_list
go
select "Finished update stats on table hts_price_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_problem_holdings_wrk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_problem_holdings_wrk   
go
update statistics hts_problem_holdings_wrk
go
update index statistics hts_problem_holdings_wrk
go
sp_recompile hts_problem_holdings_wrk
go
select "Finished update stats on table hts_problem_holdings_wrk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_profit_loss on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_profit_loss   
go
update statistics hts_profit_loss
go
update index statistics hts_profit_loss
go
sp_recompile hts_profit_loss
go
select "Finished update stats on table hts_profit_loss on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_quote_rule on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_quote_rule   
go
update statistics hts_quote_rule
go
update index statistics hts_quote_rule
go
sp_recompile hts_quote_rule
go
select "Finished update stats on table hts_quote_rule on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_quote_rule_spreads on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_quote_rule_spreads   
go
update statistics hts_quote_rule_spreads
go
update index statistics hts_quote_rule_spreads
go
sp_recompile hts_quote_rule_spreads
go
select "Finished update stats on table hts_quote_rule_spreads on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_registry on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_registry   
go
update statistics hts_registry
go
update index statistics hts_registry
go
sp_recompile hts_registry
go
select "Finished update stats on table hts_registry on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_regulatory_agency on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_regulatory_agency   
go
update statistics hts_regulatory_agency
go
update index statistics hts_regulatory_agency
go
sp_recompile hts_regulatory_agency
go
select "Finished update stats on table hts_regulatory_agency on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_replication_status on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_replication_status   
go
update statistics hts_replication_status
go
update index statistics hts_replication_status
go
sp_recompile hts_replication_status
go
select "Finished update stats on table hts_replication_status on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_restricted_sec on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_restricted_sec   
go
update statistics hts_restricted_sec
go
update index statistics hts_restricted_sec
go
sp_recompile hts_restricted_sec
go
select "Finished update stats on table hts_restricted_sec on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_reuters_masks on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_reuters_masks   
go
update statistics hts_reuters_masks
go
update index statistics hts_reuters_masks
go
sp_recompile hts_reuters_masks
go
select "Finished update stats on table hts_reuters_masks on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_rights_issue on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_rights_issue   
go
update statistics hts_rights_issue
go
update index statistics hts_rights_issue
go
sp_recompile hts_rights_issue
go
select "Finished update stats on table hts_rights_issue on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_rights_issue_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_rights_issue_log   
go
update statistics hts_rights_issue_log
go
update index statistics hts_rights_issue_log
go
sp_recompile hts_rights_issue_log
go
select "Finished update stats on table hts_rights_issue_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_rights_issue_status on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_rights_issue_status   
go
update statistics hts_rights_issue_status
go
update index statistics hts_rights_issue_status
go
sp_recompile hts_rights_issue_status
go
select "Finished update stats on table hts_rights_issue_status on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_rm_ccy_default on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_rm_ccy_default   
go
update statistics hts_rm_ccy_default
go
update index statistics hts_rm_ccy_default
go
sp_recompile hts_rm_ccy_default
go
select "Finished update stats on table hts_rm_ccy_default on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_roll_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_roll_detail   
go
update statistics hts_roll_detail
go
update index statistics hts_roll_detail
go
sp_recompile hts_roll_detail
go
select "Finished update stats on table hts_roll_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_roll_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_roll_list   
go
update statistics hts_roll_list
go
update index statistics hts_roll_list
go
sp_recompile hts_roll_list
go
select "Finished update stats on table hts_roll_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_scenario_maps on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_scenario_maps   
go
update statistics hts_scenario_maps
go
update index statistics hts_scenario_maps
go
sp_recompile hts_scenario_maps
go
select "Finished update stats on table hts_scenario_maps on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sched_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sched_list   
go
update statistics hts_sched_list
go
update index statistics hts_sched_list
go
sp_recompile hts_sched_list
go
select "Finished update stats on table hts_sched_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sec_comment on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sec_comment   
go
update statistics hts_sec_comment
go
update index statistics hts_sec_comment
go
sp_recompile hts_sec_comment
go
select "Finished update stats on table hts_sec_comment on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sec_def_attribs on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sec_def_attribs   
go
update statistics hts_sec_def_attribs
go
update index statistics hts_sec_def_attribs
go
sp_recompile hts_sec_def_attribs
go
select "Finished update stats on table hts_sec_def_attribs on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sec_master on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sec_master   
go
update statistics hts_sec_master
go
update index statistics hts_sec_master
go
sp_recompile hts_sec_master
go
select "Finished update stats on table hts_sec_master on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_send_to_bo_codes on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_send_to_bo_codes   
go
update statistics hts_send_to_bo_codes
go
update index statistics hts_send_to_bo_codes
go
sp_recompile hts_send_to_bo_codes
go
select "Finished update stats on table hts_send_to_bo_codes on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_settle_rule on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_settle_rule   
go
update statistics hts_settle_rule
go
update index statistics hts_settle_rule
go
sp_recompile hts_settle_rule
go
select "Finished update stats on table hts_settle_rule on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sfailure_event on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sfailure_event   
go
update statistics hts_sfailure_event
go
update index statistics hts_sfailure_event
go
sp_recompile hts_sfailure_event
go
select "Finished update stats on table hts_sfailure_event on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_site on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_site   
go
update statistics hts_site
go
update index statistics hts_site
go
sp_recompile hts_site
go
select "Finished update stats on table hts_site on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_audit_trail_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_audit_trail_log   
go
update statistics hts_sm_audit_trail_log
go
update index statistics hts_sm_audit_trail_log
go
sp_recompile hts_sm_audit_trail_log
go
select "Finished update stats on table hts_sm_audit_trail_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_ba_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_ba_detail   
go
update statistics hts_sm_ba_detail
go
update index statistics hts_sm_ba_detail
go
sp_recompile hts_sm_ba_detail
go
select "Finished update stats on table hts_sm_ba_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_binary_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_binary_detail   
go
update statistics hts_sm_binary_detail
go
update index statistics hts_sm_binary_detail
go
sp_recompile hts_sm_binary_detail
go
select "Finished update stats on table hts_sm_binary_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_cfd on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_cfd   
go
update statistics hts_sm_cfd
go
update index statistics hts_sm_cfd
go
sp_recompile hts_sm_cfd
go
select "Finished update stats on table hts_sm_cfd on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_combo on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_combo   
go
update statistics hts_sm_combo
go
update index statistics hts_sm_combo
go
sp_recompile hts_sm_combo
go
select "Finished update stats on table hts_sm_combo on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_deriv_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_deriv_detail   
go
update statistics hts_sm_deriv_detail
go
update index statistics hts_sm_deriv_detail
go
sp_recompile hts_sm_deriv_detail
go
select "Finished update stats on table hts_sm_deriv_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_eqss_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_eqss_detail   
go
update statistics hts_sm_eqss_detail
go
update index statistics hts_sm_eqss_detail
go
sp_recompile hts_sm_eqss_detail
go
select "Finished update stats on table hts_sm_eqss_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_relation on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_relation   
go
update statistics hts_sm_relation
go
update index statistics hts_sm_relation
go
sp_recompile hts_sm_relation
go
select "Finished update stats on table hts_sm_relation on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_repo on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_repo   
go
update statistics hts_sm_repo
go
update index statistics hts_sm_repo
go
sp_recompile hts_sm_repo
go
select "Finished update stats on table hts_sm_repo on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_repo_sched on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_repo_sched   
go
update statistics hts_sm_repo_sched
go
update index statistics hts_sm_repo_sched
go
sp_recompile hts_sm_repo_sched
go
select "Finished update stats on table hts_sm_repo_sched on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_stripbond_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_stripbond_detail   
go
update statistics hts_sm_stripbond_detail
go
update index statistics hts_sm_stripbond_detail
go
sp_recompile hts_sm_stripbond_detail
go
select "Finished update stats on table hts_sm_stripbond_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_user_data on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_user_data   
go
update statistics hts_sm_user_data
go
update index statistics hts_sm_user_data
go
sp_recompile hts_sm_user_data
go
select "Finished update stats on table hts_sm_user_data on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sm_usymbol_view on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sm_usymbol_view   
go
update statistics hts_sm_usymbol_view
go
update index statistics hts_sm_usymbol_view
go
sp_recompile hts_sm_usymbol_view
go
select "Finished update stats on table hts_sm_usymbol_view on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_snap_status on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_snap_status   
go
update statistics hts_snap_status
go
update index statistics hts_snap_status
go
sp_recompile hts_snap_status
go
select "Finished update stats on table hts_snap_status on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_sp_return_codes on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_sp_return_codes   
go
update statistics hts_sp_return_codes
go
update index statistics hts_sp_return_codes
go
sp_recompile hts_sp_return_codes
go
select "Finished update stats on table hts_sp_return_codes on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_split on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_split   
go
update statistics hts_split
go
update index statistics hts_split
go
sp_recompile hts_split
go
select "Finished update stats on table hts_split on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_split_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_split_log   
go
update statistics hts_split_log
go
update index statistics hts_split_log
go
sp_recompile hts_split_log
go
select "Finished update stats on table hts_split_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_split_status on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_split_status   
go
update statistics hts_split_status
go
update index statistics hts_split_status
go
sp_recompile hts_split_status
go
select "Finished update stats on table hts_split_status on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_spot_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_spot_list   
go
update statistics hts_spot_list
go
update index statistics hts_spot_list
go
sp_recompile hts_spot_list
go
select "Finished update stats on table hts_spot_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_stock_merger on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_stock_merger   
go
update statistics hts_stock_merger
go
update index statistics hts_stock_merger
go
sp_recompile hts_stock_merger
go
select "Finished update stats on table hts_stock_merger on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_stock_merger_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_stock_merger_list   
go
update statistics hts_stock_merger_list
go
update index statistics hts_stock_merger_list
go
sp_recompile hts_stock_merger_list
go
select "Finished update stats on table hts_stock_merger_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_stock_spinoff on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_stock_spinoff   
go
update statistics hts_stock_spinoff
go
update index statistics hts_stock_spinoff
go
sp_recompile hts_stock_spinoff
go
select "Finished update stats on table hts_stock_spinoff on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_stock_spinoff_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_stock_spinoff_list   
go
update statistics hts_stock_spinoff_list
go
update index statistics hts_stock_spinoff_list
go
sp_recompile hts_stock_spinoff_list
go
select "Finished update stats on table hts_stock_spinoff_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_strategy on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_strategy   
go
update statistics hts_strategy
go
update index statistics hts_strategy
go
sp_recompile hts_strategy
go
select "Finished update stats on table hts_strategy on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_strategy_component on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_strategy_component   
go
update statistics hts_strategy_component
go
update index statistics hts_strategy_component
go
sp_recompile hts_strategy_component
go
select "Finished update stats on table hts_strategy_component on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_strategy_group on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_strategy_group   
go
update statistics hts_strategy_group
go
update index statistics hts_strategy_group
go
sp_recompile hts_strategy_group
go
select "Finished update stats on table hts_strategy_group on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap   
go
update statistics hts_swap
go
update index statistics hts_swap
go
sp_recompile hts_swap
go
select "Finished update stats on table hts_swap on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap_basket_reset on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap_basket_reset   
go
update statistics hts_swap_basket_reset
go
update index statistics hts_swap_basket_reset
go
sp_recompile hts_swap_basket_reset
go
select "Finished update stats on table hts_swap_basket_reset on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap_detail   
go
update statistics hts_swap_detail
go
update index statistics hts_swap_detail
go
sp_recompile hts_swap_detail
go
select "Finished update stats on table hts_swap_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap_div_sched on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap_div_sched   
go
update statistics hts_swap_div_sched
go
update index statistics hts_swap_div_sched
go
sp_recompile hts_swap_div_sched
go
select "Finished update stats on table hts_swap_div_sched on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap_equity_leg on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap_equity_leg   
go
update statistics hts_swap_equity_leg
go
update index statistics hts_swap_equity_leg
go
sp_recompile hts_swap_equity_leg
go
select "Finished update stats on table hts_swap_equity_leg on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap_event_sched on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap_event_sched   
go
update statistics hts_swap_event_sched
go
update index statistics hts_swap_event_sched
go
sp_recompile hts_swap_event_sched
go
select "Finished update stats on table hts_swap_event_sched on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap_floating_leg on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap_floating_leg   
go
update statistics hts_swap_floating_leg
go
update index statistics hts_swap_floating_leg
go
sp_recompile hts_swap_floating_leg
go
select "Finished update stats on table hts_swap_floating_leg on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap_leg on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap_leg   
go
update statistics hts_swap_leg
go
update index statistics hts_swap_leg
go
sp_recompile hts_swap_leg
go
select "Finished update stats on table hts_swap_leg on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap_list   
go
update statistics hts_swap_list
go
update index statistics hts_swap_list
go
sp_recompile hts_swap_list
go
select "Finished update stats on table hts_swap_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap_quanto_leg on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap_quanto_leg   
go
update statistics hts_swap_quanto_leg
go
update index statistics hts_swap_quanto_leg
go
sp_recompile hts_swap_quanto_leg
go
select "Finished update stats on table hts_swap_quanto_leg on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_swap_sched_filt on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_swap_sched_filt   
go
update statistics hts_swap_sched_filt
go
update index statistics hts_swap_sched_filt
go
sp_recompile hts_swap_sched_filt
go
select "Finished update stats on table hts_swap_sched_filt on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_symbol_refresh_wrk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_symbol_refresh_wrk   
go
update statistics hts_symbol_refresh_wrk
go
update index statistics hts_symbol_refresh_wrk
go
sp_recompile hts_symbol_refresh_wrk
go
select "Finished update stats on table hts_symbol_refresh_wrk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_system_status on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_system_status   
go
update statistics hts_system_status
go
update index statistics hts_system_status
go
sp_recompile hts_system_status
go
select "Finished update stats on table hts_system_status on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_table_comment on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_table_comment   
go
update statistics hts_table_comment
go
update index statistics hts_table_comment
go
sp_recompile hts_table_comment
go
select "Finished update stats on table hts_table_comment on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_table_info on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_table_info   
go
update statistics hts_table_info
go
update index statistics hts_table_info
go
sp_recompile hts_table_info
go
select "Finished update stats on table hts_table_info on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_tax_rules on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_tax_rules   
go
update statistics hts_tax_rules
go
update index statistics hts_tax_rules
go
sp_recompile hts_tax_rules
go
select "Finished update stats on table hts_tax_rules on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_template_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_template_detail   
go
update statistics hts_template_detail
go
update index statistics hts_template_detail
go
sp_recompile hts_template_detail
go
select "Finished update stats on table hts_template_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_template_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_template_list   
go
update statistics hts_template_list
go
update index statistics hts_template_list
go
sp_recompile hts_template_list
go
select "Finished update stats on table hts_template_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_tick_size_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_tick_size_list   
go
update statistics hts_tick_size_list
go
update index statistics hts_tick_size_list
go
sp_recompile hts_tick_size_list
go
select "Finished update stats on table hts_tick_size_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_tick_sizes on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_tick_sizes   
go
update statistics hts_tick_sizes
go
update index statistics hts_tick_sizes
go
sp_recompile hts_tick_sizes
go
select "Finished update stats on table hts_tick_sizes on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_tickets on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_tickets   
go
update statistics hts_tickets
go
update index statistics hts_tickets
go
sp_recompile hts_tickets
go
select "Finished update stats on table hts_tickets on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_time_zone on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_time_zone   
go
update statistics hts_time_zone
go
update index statistics hts_time_zone
go
sp_recompile hts_time_zone
go
select "Finished update stats on table hts_time_zone on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_trade_alloc_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_trade_alloc_log   
go
update statistics hts_trade_alloc_log
go
update index statistics hts_trade_alloc_log
go
sp_recompile hts_trade_alloc_log
go
select "Finished update stats on table hts_trade_alloc_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_trade_event_detail_wrk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_trade_event_detail_wrk   
go
update statistics hts_trade_event_detail_wrk
go
update index statistics hts_trade_event_detail_wrk
go
sp_recompile hts_trade_event_detail_wrk
go
select "Finished update stats on table hts_trade_event_detail_wrk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_trade_involvement on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_trade_involvement   
go
update statistics hts_trade_involvement
go
update index statistics hts_trade_involvement
go
sp_recompile hts_trade_involvement
go
select "Finished update stats on table hts_trade_involvement on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_trade_involvement_ref on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_trade_involvement_ref   
go
update statistics hts_trade_involvement_ref
go
update index statistics hts_trade_involvement_ref
go
sp_recompile hts_trade_involvement_ref
go
select "Finished update stats on table hts_trade_involvement_ref on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_trader on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_trader   
go
update statistics hts_trader
go
update index statistics hts_trader
go
sp_recompile hts_trader
go
select "Finished update stats on table hts_trader on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_trader_security on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_trader_security   
go
update statistics hts_trader_security
go
update index statistics hts_trader_security
go
sp_recompile hts_trader_security
go
select "Finished update stats on table hts_trader_security on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_trigger_status on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_trigger_status   
go
update statistics hts_trigger_status
go
update index statistics hts_trigger_status
go
sp_recompile hts_trigger_status
go
select "Finished update stats on table hts_trigger_status on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_tvol_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_tvol_detail   
go
update statistics hts_tvol_detail
go
update index statistics hts_tvol_detail
go
sp_recompile hts_tvol_detail
go
select "Finished update stats on table hts_tvol_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_tvol_detail_arc on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_tvol_detail_arc   
go
update statistics hts_tvol_detail_arc
go
update index statistics hts_tvol_detail_arc
go
sp_recompile hts_tvol_detail_arc
go
select "Finished update stats on table hts_tvol_detail_arc on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_tvol_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_tvol_list   
go
update statistics hts_tvol_list
go
update index statistics hts_tvol_list
go
sp_recompile hts_tvol_list
go
select "Finished update stats on table hts_tvol_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_tvol_list_arc on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_tvol_list_arc   
go
update statistics hts_tvol_list_arc
go
update index statistics hts_tvol_list_arc
go
sp_recompile hts_tvol_list_arc
go
select "Finished update stats on table hts_tvol_list_arc on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_underlying on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_underlying   
go
update statistics hts_underlying
go
update index statistics hts_underlying
go
sp_recompile hts_underlying
go
select "Finished update stats on table hts_underlying on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_user on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_user   
go
update statistics hts_user
go
update index statistics hts_user
go
sp_recompile hts_user
go
select "Finished update stats on table hts_user on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_user_company on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_user_company   
go
update statistics hts_user_company
go
update index statistics hts_user_company
go
sp_recompile hts_user_company
go
select "Finished update stats on table hts_user_company on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_user_info on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_user_info   
go
update statistics hts_user_info
go
update index statistics hts_user_info
go
sp_recompile hts_user_info
go
select "Finished update stats on table hts_user_info on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_user_log on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_user_log   
go
update statistics hts_user_log
go
update index statistics hts_user_log
go
sp_recompile hts_user_log
go
select "Finished update stats on table hts_user_log on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_user_message on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_user_message   
go
update statistics hts_user_message
go
update index statistics hts_user_message
go
sp_recompile hts_user_message
go
select "Finished update stats on table hts_user_message on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_user_rt_default on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_user_rt_default   
go
update statistics hts_user_rt_default
go
update index statistics hts_user_rt_default
go
sp_recompile hts_user_rt_default
go
select "Finished update stats on table hts_user_rt_default on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_users on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_users   
go
update statistics hts_users
go
update index statistics hts_users
go
sp_recompile hts_users
go
select "Finished update stats on table hts_users on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_valid_date_patterns on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_valid_date_patterns   
go
update statistics hts_valid_date_patterns
go
update index statistics hts_valid_date_patterns
go
sp_recompile hts_valid_date_patterns
go
select "Finished update stats on table hts_valid_date_patterns on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_var_cross_ref on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_var_cross_ref   
go
update statistics hts_var_cross_ref
go
update index statistics hts_var_cross_ref
go
sp_recompile hts_var_cross_ref
go
select "Finished update stats on table hts_var_cross_ref on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_volatility_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_volatility_detail   
go
update statistics hts_volatility_detail
go
update index statistics hts_volatility_detail
go
sp_recompile hts_volatility_detail
go
select "Finished update stats on table hts_volatility_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_volatility_detail_arc on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_volatility_detail_arc   
go
update statistics hts_volatility_detail_arc
go
update index statistics hts_volatility_detail_arc
go
sp_recompile hts_volatility_detail_arc
go
select "Finished update stats on table hts_volatility_detail_arc on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_volatility_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_volatility_list   
go
update statistics hts_volatility_list
go
update index statistics hts_volatility_list
go
sp_recompile hts_volatility_list
go
select "Finished update stats on table hts_volatility_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_volatility_list_arc on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_volatility_list_arc   
go
update statistics hts_volatility_list_arc
go
update index statistics hts_volatility_list_arc
go
sp_recompile hts_volatility_list_arc
go
select "Finished update stats on table hts_volatility_list_arc on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_xact_history on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_xact_history   
go
update statistics hts_xact_history
go
update index statistics hts_xact_history
go
sp_recompile hts_xact_history
go
select "Finished update stats on table hts_xact_history on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_xrate_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_xrate_detail   
go
update statistics hts_xrate_detail
go
update index statistics hts_xrate_detail
go
sp_recompile hts_xrate_detail
go
select "Finished update stats on table hts_xrate_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_xrate_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_xrate_list   
go
update statistics hts_xrate_list
go
update index statistics hts_xrate_list
go
sp_recompile hts_xrate_list
go
select "Finished update stats on table hts_xrate_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_alg_risk on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_alg_risk   
go
update statistics hts_yc_alg_risk
go
update index statistics hts_yc_alg_risk
go
sp_recompile hts_yc_alg_risk
go
select "Finished update stats on table hts_yc_alg_risk on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_cred_agency on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_cred_agency   
go
update statistics hts_yc_cred_agency
go
update index statistics hts_yc_cred_agency
go
sp_recompile hts_yc_cred_agency
go
select "Finished update stats on table hts_yc_cred_agency on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_cred_i2s_map on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_cred_i2s_map   
go
update statistics hts_yc_cred_i2s_map
go
update index statistics hts_yc_cred_i2s_map
go
sp_recompile hts_yc_cred_i2s_map
go
select "Finished update stats on table hts_yc_cred_i2s_map on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_cred_level on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_cred_level   
go
update statistics hts_yc_cred_level
go
update index statistics hts_yc_cred_level
go
sp_recompile hts_yc_cred_level
go
select "Finished update stats on table hts_yc_cred_level on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_cred_matrix on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_cred_matrix   
go
update statistics hts_yc_cred_matrix
go
update index statistics hts_yc_cred_matrix
go
sp_recompile hts_yc_cred_matrix
go
select "Finished update stats on table hts_yc_cred_matrix on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_curve on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_curve   
go
update statistics hts_yc_curve
go
update index statistics hts_yc_curve
go
sp_recompile hts_yc_curve
go
select "Finished update stats on table hts_yc_curve on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_hdg_instr on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_hdg_instr   
go
update statistics hts_yc_hdg_instr
go
update index statistics hts_yc_hdg_instr
go
sp_recompile hts_yc_hdg_instr
go
select "Finished update stats on table hts_yc_hdg_instr on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_hdg_strat on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_hdg_strat   
go
update statistics hts_yc_hdg_strat
go
update index statistics hts_yc_hdg_strat
go
sp_recompile hts_yc_hdg_strat
go
select "Finished update stats on table hts_yc_hdg_strat on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_link_data on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_link_data   
go
update statistics hts_yc_link_data
go
update index statistics hts_yc_link_data
go
sp_recompile hts_yc_link_data
go
select "Finished update stats on table hts_yc_link_data on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_mkt_instr on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_mkt_instr   
go
update statistics hts_yc_mkt_instr
go
update index statistics hts_yc_mkt_instr
go
sp_recompile hts_yc_mkt_instr
go
select "Finished update stats on table hts_yc_mkt_instr on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_mkt_instr_data on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_mkt_instr_data   
go
update statistics hts_yc_mkt_instr_data
go
update index statistics hts_yc_mkt_instr_data
go
sp_recompile hts_yc_mkt_instr_data
go
select "Finished update stats on table hts_yc_mkt_instr_data on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_mkt_instr_hdr on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_mkt_instr_hdr   
go
update statistics hts_yc_mkt_instr_hdr
go
update index statistics hts_yc_mkt_instr_hdr
go
sp_recompile hts_yc_mkt_instr_hdr
go
select "Finished update stats on table hts_yc_mkt_instr_hdr on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_model on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_model   
go
update statistics hts_yc_model
go
update index statistics hts_yc_model
go
sp_recompile hts_yc_model
go
select "Finished update stats on table hts_yc_model on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_risk_curve on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_risk_curve   
go
update statistics hts_yc_risk_curve
go
update index statistics hts_yc_risk_curve
go
sp_recompile hts_yc_risk_curve
go
select "Finished update stats on table hts_yc_risk_curve on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_risk_curves_view on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_risk_curves_view   
go
update statistics hts_yc_risk_curves_view
go
update index statistics hts_yc_risk_curves_view
go
sp_recompile hts_yc_risk_curves_view
go
select "Finished update stats on table hts_yc_risk_curves_view on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_risk_data on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_risk_data   
go
update statistics hts_yc_risk_data
go
update index statistics hts_yc_risk_data
go
sp_recompile hts_yc_risk_data
go
select "Finished update stats on table hts_yc_risk_data on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_risk_scenar_view on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_risk_scenar_view   
go
update statistics hts_yc_risk_scenar_view
go
update index statistics hts_yc_risk_scenar_view
go
sp_recompile hts_yc_risk_scenar_view
go
select "Finished update stats on table hts_yc_risk_scenar_view on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_risk_scenario on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_risk_scenario   
go
update statistics hts_yc_risk_scenario
go
update index statistics hts_yc_risk_scenario
go
sp_recompile hts_yc_risk_scenario
go
select "Finished update stats on table hts_yc_risk_scenario on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_scenario on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_scenario   
go
update statistics hts_yc_scenario
go
update index statistics hts_yc_scenario
go
sp_recompile hts_yc_scenario
go
select "Finished update stats on table hts_yc_scenario on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_sp on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_sp   
go
update statistics hts_yc_sp
go
update index statistics hts_yc_sp
go
sp_recompile hts_yc_sp
go
select "Finished update stats on table hts_yc_sp on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_sp_hdr on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_sp_hdr   
go
update statistics hts_yc_sp_hdr
go
update index statistics hts_yc_sp_hdr
go
sp_recompile hts_yc_sp_hdr
go
select "Finished update stats on table hts_yc_sp_hdr on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_strip on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_strip   
go
update statistics hts_yc_strip
go
update index statistics hts_yc_strip
go
sp_recompile hts_yc_strip
go
select "Finished update stats on table hts_yc_strip on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yc_swap_spec on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yc_swap_spec   
go
update statistics hts_yc_swap_spec
go
update index statistics hts_yc_swap_spec
go
sp_recompile hts_yc_swap_spec
go
select "Finished update stats on table hts_yc_swap_spec on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yield_detail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yield_detail   
go
update statistics hts_yield_detail
go
update index statistics hts_yield_detail
go
sp_recompile hts_yield_detail
go
select "Finished update stats on table hts_yield_detail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table hts_yield_list on " +convert(varchar(25),getdate(),100)
go
sp_spaceused hts_yield_list   
go
update statistics hts_yield_list
go
update index statistics hts_yield_list
go
sp_recompile hts_yield_list
go
select "Finished update stats on table hts_yield_list on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table lic_feature on " +convert(varchar(25),getdate(),100)
go
sp_spaceused lic_feature   
go
update statistics lic_feature
go
update index statistics lic_feature
go
sp_recompile lic_feature
go
select "Finished update stats on table lic_feature on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table lic_usage on " +convert(varchar(25),getdate(),100)
go
sp_spaceused lic_usage   
go
update statistics lic_usage
go
update index statistics lic_usage
go
sp_recompile lic_usage
go
select "Finished update stats on table lic_usage on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_TempBasketUpdate on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_TempBasketUpdate   
go
update statistics mdl_TempBasketUpdate
go
update index statistics mdl_TempBasketUpdate
go
sp_recompile mdl_TempBasketUpdate
go
select "Finished update stats on table mdl_TempBasketUpdate on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_borrow_list_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_borrow_list_tb   
go
update statistics mdl_borrow_list_tb
go
update index statistics mdl_borrow_list_tb
go
sp_recompile mdl_borrow_list_tb
go
select "Finished update stats on table mdl_borrow_list_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_dividend_list_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_dividend_list_tb   
go
update statistics mdl_dividend_list_tb
go
update index statistics mdl_dividend_list_tb
go
sp_recompile mdl_dividend_list_tb
go
select "Finished update stats on table mdl_dividend_list_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_portf_colnames_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_portf_colnames_tb   
go
update statistics mdl_portf_colnames_tb
go
update index statistics mdl_portf_colnames_tb
go
sp_recompile mdl_portf_colnames_tb
go
select "Finished update stats on table mdl_portf_colnames_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_volatility_detail_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_volatility_detail_tb   
go
update statistics mdl_volatility_detail_tb
go
update index statistics mdl_volatility_detail_tb
go
sp_recompile mdl_volatility_detail_tb
go
select "Finished update stats on table mdl_volatility_detail_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_volatility_list_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_volatility_list_tb   
go
update statistics mdl_volatility_list_tb
go
update index statistics mdl_volatility_list_tb
go
sp_recompile mdl_volatility_list_tb
go
select "Finished update stats on table mdl_volatility_list_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_yc_curve_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_yc_curve_tb   
go
update statistics mdl_yc_curve_tb
go
update index statistics mdl_yc_curve_tb
go
sp_recompile mdl_yc_curve_tb
go
select "Finished update stats on table mdl_yc_curve_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_yc_sp_hdr_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_yc_sp_hdr_tb   
go
update statistics mdl_yc_sp_hdr_tb
go
update index statistics mdl_yc_sp_hdr_tb
go
sp_recompile mdl_yc_sp_hdr_tb
go
select "Finished update stats on table mdl_yc_sp_hdr_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_yc_sp_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_yc_sp_tb   
go
update statistics mdl_yc_sp_tb
go
update index statistics mdl_yc_sp_tb
go
sp_recompile mdl_yc_sp_tb
go
select "Finished update stats on table mdl_yc_sp_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_yc_strip_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_yc_strip_tb   
go
update statistics mdl_yc_strip_tb
go
update index statistics mdl_yc_strip_tb
go
sp_recompile mdl_yc_strip_tb
go
select "Finished update stats on table mdl_yc_strip_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table mdl_yc_swap_spec_tb on " +convert(varchar(25),getdate(),100)
go
sp_spaceused mdl_yc_swap_spec_tb   
go
update statistics mdl_yc_swap_spec_tb
go
update index statistics mdl_yc_swap_spec_tb
go
sp_recompile mdl_yc_swap_spec_tb
go
select "Finished update stats on table mdl_yc_swap_spec_tb on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table next_rowid on " +convert(varchar(25),getdate(),100)
go
sp_spaceused next_rowid   
go
update statistics next_rowid
go
update index statistics next_rowid
go
sp_recompile next_rowid
go
select "Finished update stats on table next_rowid on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table nw_mark_side_code on " +convert(varchar(25),getdate(),100)
go
sp_spaceused nw_mark_side_code   
go
update statistics nw_mark_side_code
go
update index statistics nw_mark_side_code
go
sp_recompile nw_mark_side_code
go
select "Finished update stats on table nw_mark_side_code on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table reconnect_dividends on " +convert(varchar(25),getdate(),100)
go
sp_spaceused reconnect_dividends   
go
update statistics reconnect_dividends
go
update index statistics reconnect_dividends
go
sp_recompile reconnect_dividends
go
select "Finished update stats on table reconnect_dividends on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table reconstructed_dividends on " +convert(varchar(25),getdate(),100)
go
sp_spaceused reconstructed_dividends   
go
update statistics reconstructed_dividends
go
update index statistics reconstructed_dividends
go
sp_recompile reconstructed_dividends
go
select "Finished update stats on table reconstructed_dividends on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table rs_lastcommit on " +convert(varchar(25),getdate(),100)
go
sp_spaceused rs_lastcommit   
go
update statistics rs_lastcommit
go
update index statistics rs_lastcommit
go
sp_recompile rs_lastcommit
go
select "Finished update stats on table rs_lastcommit on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table rs_threads on " +convert(varchar(25),getdate(),100)
go
sp_spaceused rs_threads   
go
update statistics rs_threads
go
update index statistics rs_threads
go
sp_recompile rs_threads
go
select "Finished update stats on table rs_threads on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table s on " +convert(varchar(25),getdate(),100)
go
sp_spaceused s   
go
update statistics s
go
update index statistics s
go
sp_recompile s
go
select "Finished update stats on table s on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table ss on " +convert(varchar(25),getdate(),100)
go
sp_spaceused ss   
go
update statistics ss
go
update index statistics ss
go
sp_recompile ss
go
select "Finished update stats on table ss on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table sysobjects_1192 on " +convert(varchar(25),getdate(),100)
go
sp_spaceused sysobjects_1192   
go
update statistics sysobjects_1192
go
update index statistics sysobjects_1192
go
sp_recompile sysobjects_1192
go
select "Finished update stats on table sysobjects_1192 on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table sysobjects_ori on " +convert(varchar(25),getdate(),100)
go
sp_spaceused sysobjects_ori   
go
update statistics sysobjects_ori
go
update index statistics sysobjects_ori
go
sp_recompile sysobjects_ori
go
select "Finished update stats on table sysobjects_ori on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table sysprocedures_1192 on " +convert(varchar(25),getdate(),100)
go
sp_spaceused sysprocedures_1192   
go
update statistics sysprocedures_1192
go
update index statistics sysprocedures_1192
go
sp_recompile sysprocedures_1192
go
select "Finished update stats on table sysprocedures_1192 on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table sysprocedures_ori on " +convert(varchar(25),getdate(),100)
go
sp_spaceused sysprocedures_ori   
go
update statistics sysprocedures_ori
go
update index statistics sysprocedures_ori
go
sp_recompile sysprocedures_ori
go
select "Finished update stats on table sysprocedures_ori on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_ICONCDRImport on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_ICONCDRImport   
go
update statistics t_ICONCDRImport
go
update index statistics t_ICONCDRImport
go
sp_recompile t_ICONCDRImport
go
select "Finished update stats on table t_ICONCDRImport on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_ICONCDRLookup on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_ICONCDRLookup   
go
update statistics t_ICONCDRLookup
go
update index statistics t_ICONCDRLookup
go
sp_recompile t_ICONCDRLookup
go
select "Finished update stats on table t_ICONCDRLookup on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_ICONFeedControl on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_ICONFeedControl   
go
update statistics t_ICONFeedControl
go
update index statistics t_ICONFeedControl
go
sp_recompile t_ICONFeedControl
go
select "Finished update stats on table t_ICONFeedControl on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_ICONFilesInfo on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_ICONFilesInfo   
go
update statistics t_ICONFilesInfo
go
update index statistics t_ICONFilesInfo
go
sp_recompile t_ICONFilesInfo
go
select "Finished update stats on table t_ICONFilesInfo on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_ICONPrepareTradeFile on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_ICONPrepareTradeFile   
go
update statistics t_ICONPrepareTradeFile
go
update index statistics t_ICONPrepareTradeFile
go
sp_recompile t_ICONPrepareTradeFile
go
select "Finished update stats on table t_ICONPrepareTradeFile on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_ICONTradesCompare on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_ICONTradesCompare   
go
update statistics t_ICONTradesCompare
go
update index statistics t_ICONTradesCompare
go
sp_recompile t_ICONTradesCompare
go
select "Finished update stats on table t_ICONTradesCompare on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_ICONTradesSentDetail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_ICONTradesSentDetail   
go
update statistics t_ICONTradesSentDetail
go
update index statistics t_ICONTradesSentDetail
go
sp_recompile t_ICONTradesSentDetail
go
select "Finished update stats on table t_ICONTradesSentDetail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_ICONTradesTemp on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_ICONTradesTemp   
go
update statistics t_ICONTradesTemp
go
update index statistics t_ICONTradesTemp
go
sp_recompile t_ICONTradesTemp
go
select "Finished update stats on table t_ICONTradesTemp on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_init_ICONPrepareTradeFile on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_init_ICONPrepareTradeFile   
go
update statistics t_init_ICONPrepareTradeFile
go
update index statistics t_init_ICONPrepareTradeFile
go
sp_recompile t_init_ICONPrepareTradeFile
go
select "Finished update stats on table t_init_ICONPrepareTradeFile on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_init_ICONTradesSentDetail on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_init_ICONTradesSentDetail   
go
update statistics t_init_ICONTradesSentDetail
go
update index statistics t_init_ICONTradesSentDetail
go
sp_recompile t_init_ICONTradesSentDetail
go
select "Finished update stats on table t_init_ICONTradesSentDetail on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table t_init_ImportCDR on " +convert(varchar(25),getdate(),100)
go
sp_spaceused t_init_ImportCDR   
go
update statistics t_init_ImportCDR
go
update index statistics t_init_ImportCDR
go
sp_recompile t_init_ImportCDR
go
select "Finished update stats on table t_init_ImportCDR on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table table_a on " +convert(varchar(25),getdate(),100)
go
sp_spaceused table_a   
go
update statistics table_a
go
update index statistics table_a
go
sp_recompile table_a
go
select "Finished update stats on table table_a on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table table_b on " +convert(varchar(25),getdate(),100)
go
sp_spaceused table_b   
go
update statistics table_b
go
update index statistics table_b
go
sp_recompile table_b
go
select "Finished update stats on table table_b on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table temp_cdr on " +convert(varchar(25),getdate(),100)
go
sp_spaceused temp_cdr   
go
update statistics temp_cdr
go
update index statistics temp_cdr
go
sp_recompile temp_cdr
go
select "Finished update stats on table temp_cdr on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table temp_group_control on " +convert(varchar(25),getdate(),100)
go
sp_spaceused temp_group_control   
go
update statistics temp_group_control
go
update index statistics temp_group_control
go
sp_recompile temp_group_control
go
select "Finished update stats on table temp_group_control on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table temp_perms on " +convert(varchar(25),getdate(),100)
go
sp_spaceused temp_perms   
go
update statistics temp_perms
go
update index statistics temp_perms
go
sp_recompile temp_perms
go
select "Finished update stats on table temp_perms on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table temp_rics on " +convert(varchar(25),getdate(),100)
go
sp_spaceused temp_rics   
go
update statistics temp_rics
go
update index statistics temp_rics
go
sp_recompile temp_rics
go
select "Finished update stats on table temp_rics on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table test1 on " +convert(varchar(25),getdate(),100)
go
sp_spaceused test1   
go
update statistics test1
go
update index statistics test1
go
sp_recompile test1
go
select "Finished update stats on table test1 on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table test2 on " +convert(varchar(25),getdate(),100)
go
sp_spaceused test2   
go
update statistics test2
go
update index statistics test2
go
sp_recompile test2
go
select "Finished update stats on table test2 on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table user_location on " +convert(varchar(25),getdate(),100)
go
sp_spaceused user_location   
go
update statistics user_location
go
update index statistics user_location
go
sp_recompile user_location
go
select "Finished update stats on table user_location on " +convert(varchar(25),getdate(),100)
go
select "Started  update stats on table world_clock on " +convert(varchar(25),getdate(),100)
go
sp_spaceused world_clock   
go
update statistics world_clock
go
update index statistics world_clock
go
sp_recompile world_clock
go
select "Finished update stats on table world_clock on " +convert(varchar(25),getdate(),100)
go
exit
