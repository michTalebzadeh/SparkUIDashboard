CREATE OR REPLACE PROCEDURE populate_T2_sp
(
	i_rows	IN		NUMBER
)
AS
  v_rowcount			NUMBER(12) := 0;
  v_T2Id			NUMBER(37) := NULL;
  e_rows			EXCEPTION;	
  e_insert_T2			EXCEPTION;
BEGIN
  BEGIN			-- Input parameter validation
    -- Check for inputs
    IF i_rows <= 0
    THEN
      RAISE e_rows;
    END IF;
  EXCEPTION
    WHEN e_rows THEN
      DBMS_OUTPUT.PUT_LINE('Cannot have null value for no of records to generate!');
  END; 
  BEGIN
    dbms_random.seed(0);
    SELECT NVL(MAX(small_vc),0)+1 INTO v_T2Id from T2;
    for v_records IN 1..i_rows LOOP
      INSERT INTO T2
      (
        n1,
        ind_pad,
	n2,
	small_vc,
	padding
      )
      VALUES
      (
	trunc(dbms_random.value(0,25)),
	rpad('x',39)||'x',
	trunc(dbms_random.value(0,20)),
	lpad(v_T2Id,10,'0'),
        rpad('x',199)||'x'
      );
      IF SQL%ROWCOUNT = 0 OR SQLCODE <> 0
      THEN
        RAISE e_insert_T2;
      END IF;
      v_rowcount := v_rowcount + 1;
      v_T2Id := v_T2Id + 1; 
      --dbms_output.put_line(chr(10)||'v_T2Id = '|| v_T2Id);
      IF MOD(v_rowcount, 10000) = 0 THEN
        --dbms_output.put_line('v_rowcount = '|| v_rowcount ||' ,committing!');
        COMMIT;
      END IF;
    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN e_insert_T2 THEN
      DBMS_OUTPUT.PUT_LINE('Could not insert into T2');
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM,true);
  END;
END populate_T2_sp;
/
exit
