CREATE OR REPLACE PROCEDURE populate_T1_sp
(
	i_rows	IN		NUMBER
)
AS
  v_rowcount			NUMBER(12) := 0;
  v_T1Id			NUMBER(37) := NULL;
  e_rows			EXCEPTION;	
  e_GET_NEXT_ROWID_T1	EXCEPTION;
  e_insert_T1		EXCEPTION;
BEGIN
  BEGIN			-- Input parameter validation
    -- Check for inputs
    IF i_rows <= 0
    THEN
      RAISE e_rows;
    END IF;
  EXCEPTION
    WHEN e_rows THEN
      DBMS_OUTPUT.PUT_LINE('Cannot have null value for no of records to generate!');
  END; 
  BEGIN
    dbms_random.seed(0);
    --FOR c1 IN c_Updating_Default_Values LOOP
    for v_records IN 1..i_rows LOOP
      v_T1Id  := GET_NEXT_ROWID(i_table_name => 'T1', i_nr => 1);
      IF v_T1Id < 0
      THEN
        RAISE e_GET_NEXT_ROWID_T1;
      END IF;
      v_rowcount := v_rowcount + 1;
      INSERT INTO T1
      (
        n1,
        ind_pad,
	n2,
	small_vc,
	padding
      )
      VALUES
      (
	trunc(dbms_random.value(0,25)),
	rpad('x',40),
	trunc(dbms_random.value(0,20)),
	'C'||to_char(v_T1Id),
        rpad('x',200)
      );
      IF SQL%ROWCOUNT = 0 OR SQLCODE <> 0
      THEN
        RAISE e_insert_T1;
      END IF;
      v_rowcount := v_rowcount + SQL%ROWCOUNT;
      --dbms_output.put_line(chr(10)||'v_T1Id = '|| v_T1Id);
      -- Now populate ORDERS table
      IF MOD(v_rowcount, 10000) = 0 THEN
        --dbms_output.put_line('v_rowcount = '|| v_rowcount ||' ,committing!');
        COMMIT;
      END IF;
    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN e_GET_NEXT_ROWID_T1 THEN
      DBMS_OUTPUT.PUT_LINE('Could not get next_rowid value for table T1');
    WHEN e_insert_T1 THEN
      DBMS_OUTPUT.PUT_LINE('Could not insert into T1');
    WHEN OTHERS THEN
      RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM,true);
  END;
END populate_T1_sp;
/
exit
