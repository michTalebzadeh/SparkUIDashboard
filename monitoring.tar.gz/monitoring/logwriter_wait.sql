prompt
Prompt +-------------------------------------------------+
Prompt | Wait Events Concerning LGWR FROM V$SYSTEM_EVENT |
Prompt +-------------------------------------------------+

SELECT SUBSTR(EVENT,1,50) "EVENT",
       TOTAL_WAITS,
       TOTAL_TIMEOUTS,
       TIME_WAITED,
       AVERAGE_WAIT,
       TIME_WAITED_MICRO,
       EVENT_ID
FROM v$system_event
WHERE event LIKE '%log%'
ORDER BY time_waited DESC
/
exit
