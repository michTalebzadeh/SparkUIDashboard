drop database ASEIMDB
go
create inmemory database ASEIMDB
use ASEIMDB_template as template
on ASEIMDB_data01='4000M'
log on ASEIMDB_log01='1000M'
with durability = no_recovery
go
sp_helpdb ASEIMDB
go

