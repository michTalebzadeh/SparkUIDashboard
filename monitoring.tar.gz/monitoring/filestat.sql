prompt
Prompt +--------------------------------------+
Prompt | Filestat from V$FILESTAT, V$DATAFILE |
Prompt +--------------------------------------+

select substr(d.name,1,50) name, f.phyrds "PhysicalReads",
       DECODE(t.tot_phys_reads,0,0,100*f.phyrds/t.tot_phys_reads) "Read %",
       f.phywrts "PhysicalWrites",
       DECODE(t.tot_phys_writes,0,0,100*f.phywrts/t.tot_phys_writes) "Write %"
from   v$datafile d, v$filestat f, 
       (select sum(phyrds)  tot_phys_reads,
               sum(phywrts) tot_phys_writes 
        from v$filestat) t
where  d.file# = f.file#
order  by 3 desc
/
exit
