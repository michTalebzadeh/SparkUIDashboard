create inmemory database imdb1
use imdb1_template as template
on imdb1_datadev01='800M'
log on imdb1_logdev01='200M'
with durability = no_recovery
go

