 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 TASK_NAME									   VARCHAR2(32)
 TASK_NUMBER									   NUMBER
 TASK_TYPE									   VARCHAR2(40)
 TASK_SUBMIT_TIME								   TIMESTAMP(3) WITH TIME ZONE
 TASK_READY_TIME								   TIMESTAMP(3) WITH TIME ZONE
 TASK_EXPIRY_TIME								   TIMESTAMP(3) WITH TIME ZONE
 TASK_START_TIME								   TIMESTAMP(3) WITH TIME ZONE
 TASK_STATUS									   VARCHAR2(32)
 SERVER_NAME									   VARCHAR2(48)
 MAX_RETRIES									   NUMBER
 NUM_RUNS									   NUMBER
 NUM_FAILURES									   NUMBER

