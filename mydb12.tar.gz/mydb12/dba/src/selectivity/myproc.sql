--
-- Mich Talebzadeh 15/08/2013
--
set define off;

CREATE OR REPLACE PROCEDURE myproc
IS
v_params varchar2(132);
-----------------------------------------------------------------
-- define the cursor
CURSOR c_get_object_type
(
        i_owner 	in varchar2,
	i_object_type	in varchar2
)
IS
  SELECT
        owner,
        object_type,
	object_name,
	object_id
	FROM tdash
	 WHERE owner = i_owner
	AND object_type = i_object_type;

----------------------------------------------------------------
-- define proc to use the cursor
--
PROCEDURE myproc
IS
r_get_object_type	c_get_object_type%ROWTYPE;

BEGIN
LOOP
  FETCH c_get_object_type into r_get_object_type;
  EXIT when c_get_object_type%NOTFOUND;
  v_params := r_get_object_type.owner||' '||r_get_object_type.object_name||' '||r_get_object_type.object_type||' '||r_get_object_type.object_id;
  dbms_output.put_line(v_params);
END LOOP;
EXCEPTION
  WHEN OTHERS THEN
    RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM,true);
END myproc;

BEGIN
  OPEN c_get_object_type
  (
	i_owner	      =>	'MICH',
	i_object_type =>	'TABLE'
  );
  myproc;
  CLOSE c_get_object_type;

  dbms_output.put_line('----------------------------------------------------------');

  OPEN c_get_object_type
  (
	i_owner	      =>	'MICH',
	i_object_type =>	'PROCEDURE'
  );
  myproc;
  CLOSE c_get_object_type;
EXCEPTION
  WHEN OTHERS THEN
  IF c_get_object_type%ISOPEN THEN
    CLOSE c_get_object_type;
    RAISE_APPLICATION_ERROR(SQLCODE,SQLERRM,true);
  END IF;
END myproc;
/
show error
exit
