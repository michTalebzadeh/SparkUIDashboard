set linesize 150
col a heading "Table's|Allocated|Space" format             99,999,999,999
col b heading "Space|Above|HWM" format                     999,999,999
col c heading "Bytes|Allocated|to Used|Blocks" format      99,999,999,999
col d heading "Actual|Bytes|Consumed|by Table" format      99,999,999,999
col e heading "Recoverable|Swiss Cheese|Upon Reorg" format                 99,999,999,999
col f heading "Calculated|Free-space|Reservation|within|Used Blocks" format        999,999,999
col g heading "Estimated|Free-Space|Consumption|within|Used Blocks" format 99,999,999,999
col h heading "Swiss-|Cheese|Percent" format 999.99
col i heading "Table|Name" format a26
select     t1.owner||'.'||table_name I
   ,blocks*8192 a
   ,empty_blocks*8192 b
   -- ,((blocks-empty_blocks)*8192) c -- Bytes Above HWM
   ,((blocks-empty_blocks)*8192)*(pct_free/100) f
   ,(num_rows*avg_row_len) d
   ,decode(sign((((blocks-empty_blocks)*8192)*(1-(pct_free/100)))-(num_rows*avg_row_len)) -- end SIGN function
     ,-1,((((blocks-empty_blocks)*8192)*(1-(pct_free/100)))-(num_rows*avg_row_len))*-1 -- net 0 recoverable if net
                                              -- free_space consumption
     ,0,0 -- calculated 0 free-space usage
     ,1,0
         ) g -- logical free-space consumption is 0 when there is net Swiss Cheese
   ,decode(sign((((blocks-empty_blocks)*8192)*(1-(pct_free/100)))-
           (num_rows*avg_row_len))
           ,-1,0 -- net 0 recoverable if net free_space consumption
           ,0,0  -- calculated 0 recoverable
           ,1,(((blocks-empty_blocks)*8192)*(1-(pct_free/100)))-(num_rows*avg_row_len))
           e
   ,decode(sign((((blocks-empty_blocks)*8192)*(1-(pct_free/100)))-(num_rows*avg_row_len))
           ,-1,0 -- net 0 recoverable if net free_space consumption
           ,0,0  -- calculated 0 recoverable
           ,1,((((blocks-empty_blocks)*8192)*(1-(pct_free/100)))-(num_rows*avg_row_len)) / (((blocks-empty_blocks)*8192))*100
           )h
   from    dba_tables t1
           , (select owner, segment_name
                   from dba_extents
                   group by owner,segment_name
                   having count(*) > 1) t2
   where t1.owner = t2.owner and t1.table_name=t2.segment_name
     and ((((blocks-empty_blocks)*8192)*(1-(pct_free/100)))-(num_rows*avg_row_len))
           / (((blocks-empty_blocks)*8192))*100 > 0;
