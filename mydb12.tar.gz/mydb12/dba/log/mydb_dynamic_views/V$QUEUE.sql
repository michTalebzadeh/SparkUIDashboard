 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 PADDR										   RAW(4)
 TYPE										   VARCHAR2(10)
 QUEUED 									   NUMBER
 WAIT										   NUMBER
 TOTALQ 									   NUMBER

