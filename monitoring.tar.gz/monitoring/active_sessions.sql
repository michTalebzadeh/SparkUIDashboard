column sidserial format a10
column command format a20
column sql_text format a64
column machine format a20
set pagesize 999
set verify off
set linesize 260
break on username skip 1 on sidserial on process on command on program on machine on osuser on status
-- break on command
select substr(s.username,1,10) username
        , s.sid||','|| s.serial# sidserial
        , s.process, s.program, s.machine, s.osuser, s.status
        ,decode(s.command
                ,1,'Create Table'
                ,2,'Insert'
                ,3,'Select'
                ,4,'Create Cluster'
                ,5,'Alter Cluster'
                ,6,'Update'
                ,7,'Delete'
                ,8,'Drop'
                ,9,'Create Index'
                ,10,'Drop Index'
                ,11,'Alter Index'
                ,12,'Drop Table'
                ,15,'Alter Table'
                ,17,'Grant'
                ,18,'Revoke'
                ,19,'Create Synonym'
                ,20,'Drop Synonym'
                ,21,'Create View'
                ,22,'Drop View'
                ,26,'Lock Table'
                ,27,'No Operation'
                ,28,'Rename'
                ,29,'Comment'
                ,30,'Audit'
                ,31,'NoAudit'
                ,32,'Create External DB'
                ,33,'Drop External DB'
                ,34,'Create Database'
                ,35,'Alter Database'
                ,36,'Create Rollback Seg'
                ,37,'Alter Rollback Seg'
                ,38,'Drop Rollback Seg'
                ,39,'Create Tablespace'
                ,40,'Alter Tablespace'
                ,41,'Drop Tablespace'
                ,42,'Alter Session'
                ,43,'Alter User'
                ,44,'Commit'
                ,45,'Rollback'
                ,46,'Savepoint'
                ,'Dont Know') command
        ,t.sql_text
from    v$session s, v$sqltext t
where    s.sql_address = t.address(+)
and    s.sql_hash_value = t.hash_value(+)
and    username is not null
order by username, sidserial, command, s.program
        , s.machine, s.osuser, s.status, t.piece
/
exit


