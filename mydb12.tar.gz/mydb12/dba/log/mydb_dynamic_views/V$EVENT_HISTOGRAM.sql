 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 EVENT# 									   NUMBER
 EVENT										   VARCHAR2(64)
 WAIT_TIME_MILLI								   NUMBER
 WAIT_COUNT									   NUMBER
 LAST_UPDATE_TIME								   VARCHAR2(64)

