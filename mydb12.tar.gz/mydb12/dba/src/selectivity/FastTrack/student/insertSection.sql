REM ******************************************************************
REM   file: insertSection.sql
REM  description: used for loading Section data
REM  created January 30, 2000
REM ******************************************************************

ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MON-RR';

SET DEFINE OFF
SPOOL insertSection.log

INSERT INTO section VALUES (79,350,3,'14-APR-99','L509',107,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                          
INSERT INTO section VALUES (80,10,2,'24-APR-99','L214',102,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (81,20,2,'24-JUL-99','L210',103,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (82,20,4,'03-MAY-99','L214',104,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (83,20,7,'11-JUN-99','L509',105,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (84,20,8,'11-JUN-99','L210',106,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (85,25,1,'14-JUL-99','M311',107,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (86,25,2,'10-JUN-99','L210',108,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (87,25,3,'14-APR-99','L507',101,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (88,25,4,'04-MAY-99','L214',102,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (89,25,5,'15-MAY-99','L509',103,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (90,25,6,'12-JUN-99','L509',104,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (91,25,7,'12-JUN-99','L210',105,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (92,25,8,'13-JUN-99','L509',106,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (93,25,9,'13-JUN-99','L507',107,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                           
INSERT INTO section VALUES (94,146,2,'24-JUL-99','L507',102,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                          
INSERT INTO section VALUES (95,147,1,'14-APR-99','L509',103,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                          
INSERT INTO section VALUES (96,204,1,'14-APR-99','L210',104,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                          
INSERT INTO section VALUES (97,210,1,'07-MAY-99','L507',105,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                          
INSERT INTO section VALUES (98,220,1,'15-APR-99','L509',106,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                          
INSERT INTO section VALUES (99,230,1,'07-MAY-99','L500',107,12,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                          
INSERT INTO section VALUES (100,230,2,'09-JUN-99','L214',108,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (101,240,1,'16-APR-99','L509',101,10,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (102,240,2,'24-MAY-99','L214',102,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (103,310,1,'29-APR-99','L507',103,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (104,330,1,'14-JUL-99','L511',104,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (105,350,1,'09-MAY-99','L509',105,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (106,350,2,'03-JUN-99','L214',106,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (107,130,1,'14-JUL-99','L507',103,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (108,420,1,'07-MAY-99','M311',108,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (109,450,1,'14-APR-99','L507',101,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (110,134,2,'10-JUN-99','L509',102,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (111,134,3,'08-APR-00','L509',103,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (112,135,1,'16-MAY-99','L509',104,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (113,135,2,'02-JUN-99','L214',105,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (114,135,3,'15-APR-99','L509',106,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (115,135,4,'07-MAY-99','M200',107,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (116,140,1,'14-JUL-99','L509',108,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (117,140,2,'02-JUN-99','L210',101,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (118,140,3,'09-MAY-99','L507',102,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (119,142,1,'14-JUL-99','L211',103,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (120,142,2,'10-JUN-99','L214',104,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (121,142,3,'09-APR-99','L507',105,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (122,144,2,'15-APR-99','L214',106,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (123,145,1,'14-JUL-99','L214',107,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (124,145,3,'09-MAY-99','L210',108,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (125,146,1,'29-APR-99','L509',101,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (126,124,1,'14-JUL-99','M500',102,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (127,124,2,'24-JUL-99','H310',103,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (128,124,3,'09-APR-99','L214',104,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (129,124,4,'07-MAY-99','L210',105,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (130,125,1,'22-MAY-99','L509',106,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (131,125,2,'24-JUL-99','L509',107,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (132,125,3,'09-APR-99','L214',108,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (133,125,4,'03-MAY-99','L211',101,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (134,125,6,'11-JUN-99','L507',102,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (135,130,2,'15-APR-99','L214',104,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (136,130,3,'24-APR-99','L509',105,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (137,130,4,'03-MAY-99','L509',106,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (138,132,1,'21-MAY-99','L509',107,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (139,132,3,'09-JUN-99','L509',108,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (140,134,1,'16-APR-99','L509',101,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (141,100,1,'14-APR-99','L214',102,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (142,100,2,'24-JUL-99','L500',103,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (143,100,3,'03-JUN-99','L509',104,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (144,100,4,'04-MAY-99','L507',105,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (145,100,5,'15-MAY-99','L214',106,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (146,120,1,'16-MAY-99','L507',107,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (147,120,2,'24-JUL-99','L206',108,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (148,120,3,'24-MAY-99','L509',101,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (149,120,4,'04-MAY-99','L509',102,15,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (150,120,5,'15-MAY-99','L210',103,25,'CBRENNAN','02-JAN-99','CBRENNAN','02-JAN-99');                                                                                         
INSERT INTO section VALUES (151,120,7,'12-JUN-99','L507',104,25,'CBRENNAN','02-JAN-99','CBRENNAN','10-FEB-99');                                                                                         
INSERT INTO section VALUES (152,122,1,'29-APR-99','M311',105,25,'CBRENNAN','02-JAN-99','CBRENNAN','10-FEB-99');                                                                                         
INSERT INTO section VALUES (153,122,2,'24-JUL-99','L211',106,15,'CBRENNAN','02-JAN-99','CBRENNAN','10-FEB-99');                                                                                         
INSERT INTO section VALUES (154,122,3,'21-MAY-99','L507',107,25,'CBRENNAN','02-JAN-99','CBRENNAN','10-FEB-99');                                                                                         
INSERT INTO section VALUES (155,122,4,'04-MAY-99','L210',108,15,'CBRENNAN','02-JAN-99','ARISCHER','02-MAR-99');                                                                                         
INSERT INTO section VALUES (156,122,5,'15-MAY-99','L507',101,25,'CBRENNAN','02-JAN-99','ARISCHER','02-MAR-99');                                                                                         

COMMIT;

SPOOL OFF

