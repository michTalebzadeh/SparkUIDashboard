               
 ------------- 
 use tempdb
go 

	                                                                                                                                                                    
 
	------------------------------------------------------------------------------------------------------------------------------------------------------------------ 

	 sp_recompile "guest.#det_id______00000140000922715"
go
update statistics guest.#det_id______00000140000922715
go                                                   

	 sp_recompile "guest.#det_id______00000220000925895"
go
update statistics guest.#det_id______00000220000925895
go                                                   

	 sp_recompile "guest.#det_id______00000400000919796"
go
update statistics guest.#det_id______00000400000919796
go                                                   

	 sp_recompile "guest.#set_portf___00000140000922715"
go
update statistics guest.#set_portf___00000140000922715
go                                                   

	 sp_recompile "guest.#set_portf___00000220000925895"
go
update statistics guest.#set_portf___00000220000925895
go                                                   

	 sp_recompile "guest.#set_portf___00000400000919796"
go
update statistics guest.#set_portf___00000400000919796
go                                                   

	 sp_recompile "guest.#sm_pool_____00000140000922715"
go
update statistics guest.#sm_pool_____00000140000922715
go                                                   

	 sp_recompile "guest.#sm_pool_____00000220000925895"
go
update statistics guest.#sm_pool_____00000220000925895
go                                                   

	 sp_recompile "guest.#sm_pool_____00000400000919796"
go
update statistics guest.#sm_pool_____00000400000919796
go                                                   

	 sp_recompile "guest.#sm_pool_all_00000140000922715"
go
update statistics guest.#sm_pool_all_00000140000922715
go                                                   

	 sp_recompile "guest.#sm_pool_all_00000220000925895"
go
update statistics guest.#sm_pool_all_00000220000925895
go                                                   

	 sp_recompile "guest.#sm_pool_all_00000400000919796"
go
update statistics guest.#sm_pool_all_00000400000919796
go                                                   

	 sp_recompile "guest.#sm_pool_cumu00000140000922715"
go
update statistics guest.#sm_pool_cumu00000140000922715
go                                                   

	 sp_recompile "guest.#sm_pool_cumu00000220000925895"
go
update statistics guest.#sm_pool_cumu00000220000925895
go                                                   

	 sp_recompile "guest.#sm_pool_cumu00000400000919796"
go
update statistics guest.#sm_pool_cumu00000400000919796
go                                                   
