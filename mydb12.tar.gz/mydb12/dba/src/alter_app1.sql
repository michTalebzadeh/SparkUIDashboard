/********************************************/
/*------------ APP1 -------------*/
/********************************************/
select 'Started altering APP1 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
ALTER TABLESPACE "APP1" ADD DATAFILE '/data6/oracle/mydb12/oradata/MYDB12/datafile/app02.dbf' SIZE 30G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE "APP1" ADD DATAFILE '/data6/oracle/mydb12/oradata/MYDB12/datafile/app03.dbf' SIZE 30G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE "APP1" ADD DATAFILE '/data6/oracle/mydb12/oradata/MYDB12/datafile/app04.dbf' SIZE 20G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
select 'Finished  altering APP1 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
