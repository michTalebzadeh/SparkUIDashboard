                      
 -------------------- 
 use ged_link_prod
go 
                                                                                                                                                                          
 ------------------------------------------------------------------------------------------------------------------------------------------------------------------------ 
 sp_recompile "dbo.db_bym_trader"
go
update index statistics dbo.db_bym_trader
go                                                                                         
 sp_recompile "dbo.db_feed_gl_auto_routing"
go
update index statistics dbo.db_feed_gl_auto_routing
go                                                                     
 sp_recompile "dbo.db_feed_gl_control"
go
update index statistics dbo.db_feed_gl_control
go                                                                               
 sp_recompile "dbo.db_feed_gl_exchange"
go
update index statistics dbo.db_feed_gl_exchange
go                                                                             
 sp_recompile "dbo.db_feed_gl_fee"
go
update index statistics dbo.db_feed_gl_fee
go                                                                                       
 sp_recompile "dbo.db_feed_gl_security"
go
update index statistics dbo.db_feed_gl_security
go                                                                             
 sp_recompile "dbo.db_feed_gl_security_routing"
go
update index statistics dbo.db_feed_gl_security_routing
go                                                             
 sp_recompile "dbo.db_feed_gl_trade"
go
update index statistics dbo.db_feed_gl_trade
go                                                                                   
 sp_recompile "dbo.db_feed_gl_trade_archive"
go
update index statistics dbo.db_feed_gl_trade_archive
go                                                                   
 sp_recompile "dbo.db_feed_gl_trader"
go
update index statistics dbo.db_feed_gl_trader
go                                                                                 
 sp_recompile "dbo.db_orc_contracts"
go
update index statistics dbo.db_orc_contracts
go                                                                                   
 sp_recompile "dbo.db_orc_get_underlyings"
go
update index statistics dbo.db_orc_get_underlyings
go                                                                       
 sp_recompile "dbo.db_orc_kind_mapping"
go
update index statistics dbo.db_orc_kind_mapping
go                                                                             
 sp_recompile "dbo.db_orc_market_mapping"
go
update index statistics dbo.db_orc_market_mapping
go                                                                         
