drop database hivedb
go
create database hivedb on datadev01_HDD = 100 log on logdev01_HDD = 50
go
exec sp_dboption hivedb, 'select',true
exec sp_dboption hivedb, 'trunc.',true
go
use hivedb
go
sp_addalias hiveuser,dbo
go
sp_helpdb hivedb
go
exit`
