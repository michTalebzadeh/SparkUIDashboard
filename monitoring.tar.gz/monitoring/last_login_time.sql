Following is my code to report all logins for an Oracle instance. (Item #2 in Jee's response, above.) If you do not want SYS to own the login table and trigger, you are certainly welcome to change my code. The code, as written, does depend upon at least SELECT access on V$SESSION.

REM ************************************************************
REM David L. Hunt (file author) distributes this and other 
REM files/scripts for educational purposes only, to illustrate the 
REM use or application of various computing techniques. The author
REM makes no warranty regarding this script's fitness for any 
REM specific industrial application nor is 
REM there any claim that this or any similarly-distributed scripts 
REM are error free or should be used for any purpose other than
REM illustration.
REM 
REM Please contact the author via email (dave@dasages.com) when 
REM you have comments, suggestions, and/or difficulties with this
REM script.
REM
REM [Please keep the above disclaimer and the embedded electronic 
REM  documentation with this script.]
REM ************************************************************
REM The DROP, CREATE table, CREATE function, and CREATE trigger
REM    depend upon DROP and CREATE privileges on the SYS schema.
REM ************************************************************
drop table sys.logins 
/*    Above DROP produces error on first-time script run. 
    DROP Allows errror-free subsequent runs. */
/
create table sys.logins
    (login_time        date
    ,OS_User_name        varchar2(100)
    ,Machine_Terminal    varchar2(100)
    ,Oracle_User_name    varchar2(30)
    ,Session_ID        number)
/*    Above creates SYS-owned login-audit table */
/
create or replace function sys.get_session_info
        (sess_id    in number
        , info_type in varchar2) return varchar2
    is
        w_osuser    varchar2(100);
        w_machine    varchar2(100);
        w_user        varchar2(100);
    begin
        Select    osuser, machine, user into
                w_osuser, w_machine, w_user
            from v$session
            where audsid = sess_id;
        if    upper(info_type) = 'OSUSER' then
            return w_osuser;
        elsif    upper(info_type) = 'MACHINE' then
            return w_machine;
        elsif    upper(info_type) = 'USER' then
            return w_user;
        end if;
    end;
/*    Above function accesses session information */
/
CREATE OR REPLACE TRIGGER sys.logontrigger
AFTER LOGON ON DATABASE
BEGIN
    INSERT INTO logins
        (LOGIN_TIME
        ,OS_USER_NAME
        ,MACHINE_TERMINAL
        ,ORACLE_USER_NAME
        ,SESSION_ID
        )
        VALUES
        (sysdate
        ,get_session_info(userenv('sessionid'),'OSUSER')
        ,get_session_info(userenv('sessionid'),'MACHINE')
        ,get_session_info(userenv('sessionid'),'USER')
        ,userenv('sessionid'));
END;
/*    Above trigger audits all database logins */
/
REM ***************************************************************
REM Script produces formatted report of logins, sorted by date/time.
REM ***************************************************************
col a heading "Login Date/Time" format a26
col b heading "Oracle|Session|ID" format 9999999
col c heading "OS User Login Name" format a20
col d heading "Login Machine/|Terminal Name" format a25
col e heading "Oracle User Name" format a20
select    to_char(login_time,'YYYY-Mon-DD (Dy) hh24:mi:ss') a
    ,Session_ID b
    ,os_user_name c
    ,machine_terminal d
    ,Oracle_user_name e
from sys.logins
order by login_time
/
exit
