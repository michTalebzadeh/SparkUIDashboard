drop table attribute;
CREATE TABLE attribute
(
	  OBJECT_ID		NUMBER
         ,ATTRIBUTE		VARCHAR2(32)
)
ORGANIZATION EXTERNAL
(
        TYPE ORACLE_LOADER
        DEFAULT DIRECTORY selectivity_directory
        ACCESS PARAMETERS
        (
                RECORDS DELIMITED BY newline
                FIELDS TERMINATED BY '\t'
       	        MISSING FIELD VALUES ARE NULL
       	        ( 	  
			 OBJECT_ID
			,ATTRIBUTE
		)
        )
        LOCATION ('ATTRIBUTE.bcp')
)
REJECT LIMIT 0
/
exit
