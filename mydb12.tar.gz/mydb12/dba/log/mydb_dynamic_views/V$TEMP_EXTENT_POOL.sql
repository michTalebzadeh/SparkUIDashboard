 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 TABLESPACE_NAME							  NOT NULL VARCHAR2(30)
 FILE_ID									   NUMBER
 EXTENTS_CACHED 								   NUMBER
 EXTENTS_USED									   NUMBER
 BLOCKS_CACHED									   NUMBER
 BLOCKS_USED									   NUMBER
 BYTES_CACHED									   NUMBER
 BYTES_USED									   NUMBER
 RELATIVE_FNO									   NUMBER

