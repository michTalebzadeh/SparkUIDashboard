set echo off
set feedback off
set linesize 100
set pagesize 0 
set head off
set sqlprompt '' 
set trimspool on
spool on
spool /backup/oracle/feeds/salesfeed.dat
select PROD_ID||'	'||CUST_ID||'	'||TIME_ID||'	'||CHANNEL_ID||'	'||PROMO_ID||'	'||QUANTITY_SOLD||'	'||AMOUNT_SOLD
FROM salesfeed;
spool off
exit
