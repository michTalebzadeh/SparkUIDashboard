alter system flush buffer_cache;
alter system flush shared_pool;
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'ssdtester_oltp';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
BEGIN
    FOR i in 1 .. 5
    LOOP
    BEGIN
	EXECUTE IMMEDIATE 'TRUNCATE TABLE testwrites';
	INSERT INTO testwrites
	SELECT * FROM tdash WHERE ROWNUM <= 1000000;
	commit;
        DELETE FROM testwrites
        WHERE ROWNUM >900000;
        COMMIT;
        INSERT INTO testwrites
        SELECT * FROM tdash
        WHERE ROWNUM > 900000;
        COMMIT;
        UPDATE testwrites
        SET PADDING1 = RPAD('y',4000,'y')
        WHERE object_id BETWEEN 10000 AND 200000;
        COMMIT;
        DELETE FROM testwrites
        WHERE object_id BETWEEN 210000 AND 220000;
        COMMIT;
        INSERT INTO testwrites
        SELECT * FROM tdash WHERE object_id BETWEEN 210000 and 220000;
        COMMIT;
        UPDATE testwrites
        SET PADDING1 = RPAD('x',4000,'x')
        WHERE object_id BETWEEN 1 AND 200000;
        COMMIT;
    END;
    END LOOP;
END;
/
exit
