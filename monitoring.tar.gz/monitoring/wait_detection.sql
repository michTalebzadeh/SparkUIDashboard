COLUMN event FORMAT a60 HEADING EVENT
prompt
Prompt +----------------------------------------------------+
Prompt | Real wait events ordered by time_waited            |
Prompt | Extracted from V$SYSTEM_EVENT                      |
Prompt +----------------------------------------------------+

COLUMN ttl_wait_time	FORMAT 999999999999 HEADING 'Wait Time/ms'
SELECT	EVENT,
	TOTAL_WAITS,
	TOTAL_TIMEOUTS,
	AVERAGE_WAIT,
	TIME_WAITED
FROM V$SYSTEM_EVENT
WHERE EVENT NOT IN
(
	'smon timer',
	'pmon timer',
	'rdbms ipc message',
	'Null event',
	'parallel query dequeue',
	'pipe get',
	'client message',
	'SQL*Net message to client',
	'SQL*Net message from client',
	'SQL*Net more data from client',
	'dispatcher timer',
	'virtual circuit status',
	'lock manager wait for remote message',
	'PX Idle Wait'
)
ORDER BY time_waited
DESC
/
CLEAR COLUMN
CLEAR BREAKS
TTITLE OFF
SET LINES 80
SET TRIMS on
SET PAGES 9000
COLUMN sid              FORMAT 999999  HEADING 'DB SID'
COLUMN username     	FORMAT a15      HEADING 'User'
COLUMN ttl_wait_time	FORMAT 999999999999 HEADING 'Wait Time/ms'

Prompt +---------------------------------------------------------------+
Prompt |  Who is waiting most from V$ACTIVE_SESSION_HISTORY, V$SESSION |
Prompt +---------------------------------------------------------------+

select b.sid,
       b.username,
       (sum(a.wait_time +
           a.time_waited))/1000. ttl_wait_time
from v$active_session_history a,
     v$session b
where a.sample_time between sysdate - 60/2880 and sysdate
and a.session_id = b.sid
and  b.username is not null
AND b.sid NOT IN (select sid from v$mystat where rownum=1)
group by b.sid, b.username
order by 3
/
CLEAR COLUMN
CLEAR BREAKS
SET LINESIZE 145
SET PAGESIZE 132
COLUMN user_id          FORMAT 999999  HEADING 'User ID'
COLUMN username     	FORMAT a15      HEADING 'User'
COLUMN sql              FORMAT a999 word_wrapped
COLUMN ttl_wait_time	FORMAT 999999999999 HEADING 'Total Wait Time/ms'

Prompt +-----------------------------------------------------------------------------------------------------+
Prompt |  What SQL is currently using the most resources from V$ACTIVE_SESSION_HISTORY, V$SQLAREA, DBA_USERS |
Prompt +-----------------------------------------------------------------------------------------------------+

select a.user_id,
       c.username,
       substr(b.sql_text,1,999) sql,
       (sum(a.wait_time +
           a.time_waited))/1000. ttl_wait_time
from   v$active_session_history a,
       v$sqlarea b,
       dba_users c
where  a.sample_time between sysdate - 60/2880 and sysdate
and a.sql_id = b.sql_id
and a.user_id = c.user_id
AND a.session_id NOT IN (select sid from v$mystat where rownum=1)
group by a.user_id, b.sql_text, c.username
order by 4
/
CLEAR COLUMN
CLEAR BREAKS
SET LINES 80
SET TRIMS on
SET LINESIZE 145
SET PAGESIZE 132
COLUMN object_name  FORMAT a30     HEADING 'Object Name'
COLUMN object_type  FORMAT a10     HEADING 'Type'
COLUMN event       FORMAT a50     HEADING 'Event'
COLUMN ttl_wait_time	FORMAT 999999999999 HEADING 'Total Wait Time/ms'

Prompt +-------------------------------------------------------------------------------------------+
Prompt |  What Object causing the highest resource wait from V$ACTIVE_SESSION_HISIORY, dba_objects |
Prompt +-------------------------------------------------------------------------------------------+

select b.object_name,
       b.object_type,
       a.event,
       (sum(a.wait_time +
           a.time_waited))/1000. ttl_wait_time
from v$active_session_history a,
     dba_objects b
where a.sample_time between sysdate - 60/2880 and sysdate
and a.current_obj# = b.object_id
AND a.session_id NOT IN (select sid from v$mystat where rownum=1)
group by b.object_name, b.object_type, a.event
/
exit
