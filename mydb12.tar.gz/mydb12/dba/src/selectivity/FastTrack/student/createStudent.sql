REM ******************************************************************
REM   file: createStudent.sql
REM  description: used for creating the objects and loading data
REM                 into the student schema
REM  created February 2, 2000
REM ******************************************************************

SET ECHO OFF

@@student.tab
@@student.ind
@@insertCourse.sql
@@insertEnrollment.sql
@@insertGrade.sql
@@insertGradeconversion.sql
@@insertGradetype.sql
@@insertGradetypeweight.sql
@@insertInstructor.sql
@@insertSection.sql
@@insertStudent.sql
@@insertZipcode.sql
@@student.con
@@student.sqs
SET ECHO OFF
CLEAR SCREEN
PROMPT ** ************************************************** **
PROMPT ** To make sure that your schema was loaded properly, **
PROMPT **   compare these counts with those listed in the    **
PROMPT **   readme.txt file (Step 2.D).                      **
PROMPT ** ************************************************** **
@@finalCount.sql


