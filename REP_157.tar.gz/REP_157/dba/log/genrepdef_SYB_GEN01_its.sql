--
------> table its.filenet_prefundimage <------
--
DROP REPLICATION DEFINITION filenet_prefundimage_pd
go
CREATE REPLICATION DEFINITION filenet_prefundimage_pd
WITH PRIMARY AT SYB_GEN01.its
WITH ALL TABLES NAMED "filenet_prefundimage"
(
  "f_pritime" varchar
longsysname  
, "uf000" varchar
longsysname  
, "uf001" varchar
longsysname  
, "uf002" varchar
longsysname  
, "uf003" varchar
longsysname  
, "img_capt_dttm" datetime  
, "tran_typ_cd" char (1) 
, "proc_dttm" datetime  
, "crte_dttm" datetime  
)
PRIMARY KEY (
  "filenet_prefundimage_id"                                                                                                                                                                                                                                         
)
SEND STANDBY REPLICATION DEFINITION COLUMNS
REPLICATE MINIMAL COLUMNS
go
