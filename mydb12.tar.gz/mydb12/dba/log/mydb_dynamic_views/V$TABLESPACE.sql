 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 TS#										   NUMBER
 NAME										   VARCHAR2(30)
 INCLUDED_IN_DATABASE_BACKUP							   VARCHAR2(3)
 BIGFILE									   VARCHAR2(3)
 FLASHBACK_ON									   VARCHAR2(3)
 ENCRYPT_IN_BACKUP								   VARCHAR2(3)

