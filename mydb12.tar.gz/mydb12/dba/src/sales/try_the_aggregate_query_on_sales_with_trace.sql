ALTER SYSTEM FLUSH BUFFER_CACHE;
ALTER SYSTEM FLUSH SHARED_POOL;
--ALTER SESSION SET STATISTICS_LEVEL='ALL';
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'sales_with_trace';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
select
--      /*+ RESULT_CACHE */
        cust_id "Customer ID",
count(amount_sold) "Number of orders",
sum(amount_sold) "Total customer's amount",
avg(amount_sold) "Average order",
stddev(amount_sold) "Standard deviation"
from sales
group by cust_id
having sum(amount_sold) > 94000
and avg(amount_sold) < stddev(amount_sold)
order by 3 desc;
exit
