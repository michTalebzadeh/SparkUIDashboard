ALTER TABLESPACE tbs10g READ WRITE;
SELECT tablespace_name, plugged_in, status
FROM   dba_tablespaces
WHERE  tablespace_name = 'TBS10G';
select count(1) from tbs10g_user.test_tab;
exit
