/********************************************/
/*------------ tools -------------*/
/********************************************/
select 'Started creating tools tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE SMALLFILE TABLESPACE "TOOLS" DATAFILE '/ssddata2/oracle/mydb/tools.dbf' SIZE 100M AUTOEXTEND ON NEXT 10M MAXSIZE UNLIMITED LOGGING
 EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO; 
select 'Finished  creating tools tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
