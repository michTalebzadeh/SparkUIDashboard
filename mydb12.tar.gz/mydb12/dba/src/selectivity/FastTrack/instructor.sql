declare v_name varchar2(70);
v_total number;
begin
select i.first_name||' '||i.last_name, count(*)
into v_name, v_total
from instructor i
inner join section s on (i.instructor_id = s.instructor_id)
where i.instructor_id = s.instructor_id
 and i.instructor_id = 102
group by i.first_name|| ' '|| i.last_name;
dbms_output.put_line(chr(10));
dbms_output.put_line ('Instructore '||v_name|| ' teaches '|| v_total|| ' courses');
exception
when no_data_found then
  dbms_output.put_line ('missing data');
end;
/
exit
