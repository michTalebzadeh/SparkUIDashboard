 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SESSION_ID									   NUMBER
 AGGREGATE_CACHE_HITS								   NUMBER
 AGGREGATE_CACHE_MISSES 							   NUMBER
 SESSION_CACHE_HITS								   NUMBER
 SESSION_CACHE_MISSES								   NUMBER
 POOL_HITS									   NUMBER
 POOL_MISSES									   NUMBER
 POOL_NEW_PAGES 								   NUMBER
 POOL_RECLAIMED_PAGES								   NUMBER
 CACHE_WRITES									   NUMBER
 POOL_SIZE									   NUMBER
 CURR_DML_COMMAND								   VARCHAR2(64)
 PREV_DML_COMMAND								   VARCHAR2(64)
 AGGR_FUNC_LOGICAL_NA								   NUMBER
 AGGR_FUNC_PRECOMPUTE								   NUMBER
 AGGR_FUNC_CALCS								   NUMBER

