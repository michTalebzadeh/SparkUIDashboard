 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 TRANSIENT_INCIDENT_LIFETIME							   NUMBER
 CRITICAL_FACTOR								   NUMBER
 WARNING_FACTOR 								   NUMBER
 WEIGHT_FACTOR									   NUMBER
 MODIFICATION_TIME								   TIMESTAMP(13) WITH TIME ZONE

