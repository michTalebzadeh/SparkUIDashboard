CREATE OR REPLACE TYPE T1Type AS OBJECT (
	n1	 NUMBER(5),
	PADDING  VARCHAR2(200)
);
/
CREATE OR REPLACE TYPE T1TypeSet AS TABLE OF T1Type;
/
CREATE OR REPLACE PACKAGE refcur_pkg IS
 TYPE refcur_t IS REF CURSOR RETURN T1%ROWTYPE;
END refcur_pkg;
/
CREATE OR REPLACE FUNCTION T1pivot(
p refcur_pkg.refcur_t)
RETURN T1TypeSet AUTHID DEFINER PIPELINED IS
 out_rec  T1Type := T1Type(NULL,NULL);
 in_rec   p%ROWTYPE;
BEGIN
  LOOP
    FETCH p INTO in_rec;
    EXIT WHEN p%NOTFOUND;

    out_rec.n1 := in_rec.T1;
    out_rec.padding := in_rec.padding;
    PIPE ROW(out_rec);

    out_rec.PriceType := 'C';
    out_rec.price := in_rec.Close_Price;
    PIPE ROW(out_rec);
  END LOOP;
  CLOSE p;
  RETURN;
END stockpivot;
/
exit
