SET PAGES 66
SET LINES 132
BREAK ON grantee SKIP 1
SELECT
	a.grantee,
	'Object Grant' AS grant_type,
	b.privilege,
	b.grantable AS "Grant Option"
FROM	dba_role_privs a,
	dba_tab_privs b
WHERE	a.grantee = b.grantee
UNION
SELECT
	a.grantee,
	'System Grant' AS grant_type,
	b.privilege,
	b.admin_option AS "Grant Option"
FROM	dba_role_privs a,
	dba_sys_privs b
WHERE	a.grantee = b.grantee
UNION
SELECT
	a.grantee,
	'Role' AS grant_type,
	a.granted_role,
	a.admin_option AS "Grant Option"
FROM	dba_role_privs a
ORDER BY 1, 2
/
exit
