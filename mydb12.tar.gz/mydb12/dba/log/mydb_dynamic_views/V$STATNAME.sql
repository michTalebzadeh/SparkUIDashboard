 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 STATISTIC#									   NUMBER
 NAME										   VARCHAR2(64)
 CLASS										   NUMBER
 STAT_ID									   NUMBER

