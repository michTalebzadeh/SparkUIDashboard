/********************************************/
/*------------ HIVETEST -------------*/
/********************************************/
select 'Started creating HIVETEST tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE TABLESPACE "HIVETEST" DATAFILE '/ssdsdc1/oracle/mydb12/MYDB12/datafile/HIVETEST.dbf' SIZE 100M AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED LOGGING
 EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO; 
select 'Finished  creating HIVETEST tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
