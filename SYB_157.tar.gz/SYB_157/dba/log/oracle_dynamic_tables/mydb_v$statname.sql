use imdb1_template
go
set quoted_identifier on
go
if exists(select 1 from sysobjects where type = 'U' and name = 'MYDB_V$STATNAME')
  drop table MYDB_V$STATNAME
go
create existing table MYDB_V$STATNAME
(
 STATISTIC#                                                                        BIGINT NULL,
 NAME                                                                              VARCHAR(64) NULL,
 CLASS                                                                             BIGINT NULL,
 STAT_ID                                                                           BIGINT NULL,
)
at 'DCORACLE..sys.v_$statname'
go
sp_help MYDB_V$STATNAME
go
