CREATE PROCEDURE
           get_next_rowid_sp
              @table_name    db_obj_name_t,
              @nr            int           = 1
AS                                      
BEGIN
      SET  nocount  ON                  -- performance enhancement
                                        -- check arguments passed
       IF  (ISNULL(@table_name, "") = "")
           BEGIN
                PRINT  "get_next_rowid_sp:  Must supply argument @table_name"
               RETURN  -1
           END
                                        -- check the table exists
       IF  NOT EXISTS (   SELECT  1
                            FROM  next_rowid
                           WHERE  nxr_name = @table_name)
           BEGIN
                PRINT  "get_next_rowid_sp:  '%1!' does not have an entry in 'next_rowid'",
                       @table_name
               RETURN  -101
           END
       IF  (ISNULL(@nr, 0) < 1)         -- make sure value is set correctly
               SELECT  @nr = 1
  DECLARE  @rv  int,
           @tc  int
                                        -- start a transaction to prevent
                                        -- another process from reading an
                                        -- incorrect value
                                        -- determine if we need to open a new
                                        -- transaction or do a savepoint
   SELECT  @tc = @@trancount
       IF  (@tc > 0)
           SAVE TRANSACTION
                       get_next_rowid_sp_trans
     ELSE
           BEGIN TRANSACTION
                       get_next_rowid_sp_trans
   UPDATE  next_rowid
      SET  nxr_next_rowid = nxr_next_rowid + @nr
    WHERE  nxr_name = @table_name
       IF  (@@error != 0)
           BEGIN
                PRINT  "get_next_rowid_sp:  UPDATE failed"
           ROLLBACK TRANSACTION
                       get_next_rowid_sp_trans
               RETURN  -100
           END
   SELECT  @rv = nxr_next_rowid - @nr
     FROM  next_rowid
    WHERE  nxr_name = @table_name
       IF  (@tc = 0)
           COMMIT TRANSACTION
                      get_next_rowid_sp_trans
   RETURN  @rv
END
go
