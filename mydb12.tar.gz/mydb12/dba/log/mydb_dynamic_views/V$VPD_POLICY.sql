 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ADDRESS									   RAW(4)
 PARADDR									   RAW(4)
 SQL_HASH									   NUMBER
 SQL_ID 									   VARCHAR2(13)
 CHILD_NUMBER									   NUMBER
 OBJECT_OWNER									   VARCHAR2(30)
 OBJECT_NAME									   VARCHAR2(30)
 POLICY_GROUP									   VARCHAR2(30)
 POLICY 									   VARCHAR2(30)
 POLICY_FUNCTION_OWNER								   VARCHAR2(30)
 PREDICATE									   VARCHAR2(4000)

