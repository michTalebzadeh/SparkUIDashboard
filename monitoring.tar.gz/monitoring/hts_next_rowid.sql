 CREATE TABLE  next_rowid
 (
  nxr_name        varchar(30)                NOT NULL,
  nxr_next_rowid  integer                    NOT NULL
 )
 create unique clustered index nxr_name_ind on dbo.next_rowid (nxr_name)                                                                
 create unique nonclustered index nxr_id_ind on dbo.next_rowid (nxr_id)                                                                 
go

