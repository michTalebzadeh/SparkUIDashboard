--Run this as user scott
@login
drop sequence scott.test_frag_seq
/
CREATE SEQUENCE scott.test_frag_seq
    MINVALUE 1
    MAXVALUE 999999999999999999999999999
    START WITH  1
    INCREMENT BY  1
    CACHE 20; 
drop table test_frag
/
create table test_frag
	(
		tab_key		number,
		big_column	varchar2(4000)
	)
	tablespace asm_test
;
declare
	v_Count	integer := 1;
	v_MaxRecords	integer := 10000000;
begin
  dbms_output.put_line ('Starting inserting records in table test_frag at '||to_char(sysdate, 'YYYY MM DD HH24:MM:SS'));
  loop
	insert into test_frag
	values
		(
		  test_frag_seq.nextval,
		  ' '
		);
	v_Count := v_Count+1;
 	if MOD(v_Count, 1000) = 0	-- do not blow up the log!
	then
		commit;
  		dbms_output.put_line ('Committed '||V_count||' records at '||to_char(sysdate, 'YYYY MM DD HH24:MM:SS'));
	end if;

	if v_Count > v_MaxRecords
	then
		dbms_output.put_line (v_MaxRecords||' records inserted at '||to_char(sysdate, 'YYYY MM DD HH24:MM:SS'));
		exit;
	end if;
   end loop;
end;
/
exit
/
