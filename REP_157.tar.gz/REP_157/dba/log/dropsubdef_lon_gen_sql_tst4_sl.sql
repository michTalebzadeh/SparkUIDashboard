--
------> table its_ged_prod.dbGED_usereq_acctconf_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_acctconf_tb_sl for dbGED_usereq_acctconf_tb_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_accttype_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_accttype_tb_sl for dbGED_usereq_accttype_tb_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_bizarea_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_bizarea_tb_sl for dbGED_usereq_bizarea_tb_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_confdef_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_confdef_tb_sl for dbGED_usereq_confdef_tb_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_groups_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_groups_tb_sl for dbGED_usereq_groups_tb_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_location_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_location_tb_sl for dbGED_usereq_location_tb_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_usereq_super_tb <------
--
DROP SUBSCRIPTION dbGED_usereq_super_tb_sl for dbGED_usereq_super_tb_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbGED_userreq_new_tb <------
--
DROP SUBSCRIPTION dbGED_userreq_new_tb_sl for dbGED_userreq_new_tb_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbJobStatus <------
--
DROP SUBSCRIPTION dbJobStatus_sl for dbJobStatus_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStageDividend <------
--
DROP SUBSCRIPTION dbStageDividend_sl for dbStageDividend_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStageDividend_Old <------
--
DROP SUBSCRIPTION dbStageDividend_Old_sl for dbStageDividend_Old_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStageRicRef <------
--
DROP SUBSCRIPTION dbStageRicRef_sl for dbStageRicRef_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStageStock <------
--
DROP SUBSCRIPTION dbStageStock_sl for dbStageStock_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStageStock_Old <------
--
DROP SUBSCRIPTION dbStageStock_Old_sl for dbStageStock_Old_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStar_Input <------
--
DROP SUBSCRIPTION dbStar_Input_sl for dbStar_Input_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbStar_Input1 <------
--
DROP SUBSCRIPTION dbStar_Input1_sl for dbStar_Input1_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_EOD_blotter_extra <------
--
DROP SUBSCRIPTION db_EOD_blotter_extra_sl for db_EOD_blotter_extra_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_EOD_blotter_sec_data <------
--
DROP SUBSCRIPTION db_EOD_blotter_sec_data_sl for db_EOD_blotter_sec_data_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_EOD_blotter_signoff <------
--
DROP SUBSCRIPTION db_EOD_blotter_signoff_sl for db_EOD_blotter_signoff_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_EOD_blotter_status <------
--
DROP SUBSCRIPTION db_EOD_blotter_status_sl for db_EOD_blotter_status_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_EOD_blotter_trades <------
--
DROP SUBSCRIPTION db_EOD_blotter_trades_sl for db_EOD_blotter_trades_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_YC_Upload_Ccys <------
--
DROP SUBSCRIPTION db_YC_Upload_Ccys_sl for db_YC_Upload_Ccys_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_alternate_code <------
--
DROP SUBSCRIPTION db_alternate_code_sl for db_alternate_code_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_asian_history <------
--
DROP SUBSCRIPTION db_asian_history_sl for db_asian_history_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_autolaunchLedgers <------
--
DROP SUBSCRIPTION db_autolaunchLedgers_sl for db_autolaunchLedgers_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_autolaunchUsers <------
--
DROP SUBSCRIPTION db_autolaunchUsers_sl for db_autolaunchUsers_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_average_trade_err <------
--
DROP SUBSCRIPTION db_average_trade_err_sl for db_average_trade_err_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_average_trade_list <------
--
DROP SUBSCRIPTION db_average_trade_list_sl for db_average_trade_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_average_trade_xref <------
--
DROP SUBSCRIPTION db_average_trade_xref_sl for db_average_trade_xref_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_error <------
--
DROP SUBSCRIPTION db_avg_error_sl for db_avg_error_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_exec_xref <------
--
DROP SUBSCRIPTION db_avg_exec_xref_sl for db_avg_exec_xref_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_exec_xref_audit <------
--
DROP SUBSCRIPTION db_avg_exec_xref_audit_sl for db_avg_exec_xref_audit_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_netting_grp <------
--
DROP SUBSCRIPTION db_avg_netting_grp_sl for db_avg_netting_grp_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_netting_grp_audit <------
--
DROP SUBSCRIPTION db_avg_netting_grp_audit_sl for db_avg_netting_grp_audit_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule <------
--
DROP SUBSCRIPTION db_avg_rule_sl for db_avg_rule_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_audit <------
--
DROP SUBSCRIPTION db_avg_rule_audit_sl for db_avg_rule_audit_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_except_audit <------
--
DROP SUBSCRIPTION db_avg_rule_except_audit_sl for db_avg_rule_except_audit_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_exception <------
--
DROP SUBSCRIPTION db_avg_rule_exception_sl for db_avg_rule_exception_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_set <------
--
DROP SUBSCRIPTION db_avg_rule_set_sl for db_avg_rule_set_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_set_audit <------
--
DROP SUBSCRIPTION db_avg_rule_set_audit_sl for db_avg_rule_set_audit_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_rule_type <------
--
DROP SUBSCRIPTION db_avg_rule_type_sl for db_avg_rule_type_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_trade <------
--
DROP SUBSCRIPTION db_avg_trade_sl for db_avg_trade_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_avg_trade_audit <------
--
DROP SUBSCRIPTION db_avg_trade_audit_sl for db_avg_trade_audit_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_calendar_map <------
--
DROP SUBSCRIPTION db_calendar_map_sl for db_calendar_map_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_column_defaults <------
--
DROP SUBSCRIPTION db_column_defaults_sl for db_column_defaults_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_curve_missing_map <------
--
DROP SUBSCRIPTION db_curve_missing_map_sl for db_curve_missing_map_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_div_tax_rules <------
--
DROP SUBSCRIPTION db_div_tax_rules_sl for db_div_tax_rules_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_error_message <------
--
DROP SUBSCRIPTION db_error_message_sl for db_error_message_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_eurex_defaults <------
--
DROP SUBSCRIPTION db_eurex_defaults_sl for db_eurex_defaults_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_eurex_xetra_ar_prod <------
--
DROP SUBSCRIPTION db_eurex_xetra_ar_prod_sl for db_eurex_xetra_ar_prod_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_eurex_xetra_routing <------
--
DROP SUBSCRIPTION db_eurex_xetra_routing_sl for db_eurex_xetra_routing_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_eurex_xetra_trades <------
--
DROP SUBSCRIPTION db_eurex_xetra_trades_sl for db_eurex_xetra_trades_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_eurex_xetra_trades_arc <------
--
DROP SUBSCRIPTION db_eurex_xetra_trades_arc_sl for db_eurex_xetra_trades_arc_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_excep_price_env <------
--
DROP SUBSCRIPTION db_excep_price_env_sl for db_excep_price_env_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_imagine_user_dealer_map <------
--
DROP SUBSCRIPTION db_imagine_user_dealer_map_sl for db_imagine_user_dealer_map_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_last_message <------
--
DROP SUBSCRIPTION db_last_message_sl for db_last_message_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_mark_errors <------
--
DROP SUBSCRIPTION db_mark_errors_sl for db_mark_errors_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_auto_routed_products <------
--
DROP SUBSCRIPTION db_orc_auto_routed_products_sl for db_orc_auto_routed_products_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_auto_routing <------
--
DROP SUBSCRIPTION db_orc_auto_routing_sl for db_orc_auto_routing_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_exch_sett_date <------
--
DROP SUBSCRIPTION db_orc_exch_sett_date_sl for db_orc_exch_sett_date_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_exchange <------
--
DROP SUBSCRIPTION db_orc_exchange_sl for db_orc_exchange_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_exec_id <------
--
DROP SUBSCRIPTION db_orc_exec_id_sl for db_orc_exec_id_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_executions <------
--
DROP SUBSCRIPTION db_orc_executions_sl for db_orc_executions_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_executions_hist <------
--
DROP SUBSCRIPTION db_orc_executions_hist_sl for db_orc_executions_hist_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_heartbeat <------
--
DROP SUBSCRIPTION db_orc_heartbeat_sl for db_orc_heartbeat_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_imag_warrant_recon <------
--
DROP SUBSCRIPTION db_orc_imag_warrant_recon_sl for db_orc_imag_warrant_recon_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_portfolio <------
--
DROP SUBSCRIPTION db_orc_portfolio_sl for db_orc_portfolio_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_process_state <------
--
DROP SUBSCRIPTION db_orc_process_state_sl for db_orc_process_state_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_sec_exchange <------
--
DROP SUBSCRIPTION db_orc_sec_exchange_sl for db_orc_sec_exchange_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_trade_id_map <------
--
DROP SUBSCRIPTION db_orc_trade_id_map_sl for db_orc_trade_id_map_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_trade_recon <------
--
DROP SUBSCRIPTION db_orc_trade_recon_sl for db_orc_trade_recon_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_trader <------
--
DROP SUBSCRIPTION db_orc_trader_sl for db_orc_trader_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_underlying <------
--
DROP SUBSCRIPTION db_orc_underlying_sl for db_orc_underlying_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_orc_warrant_recon <------
--
DROP SUBSCRIPTION db_orc_warrant_recon_sl for db_orc_warrant_recon_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_audit <------
--
DROP SUBSCRIPTION db_perm_audit_sl for db_perm_audit_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_bus_cat <------
--
DROP SUBSCRIPTION db_perm_bus_cat_sl for db_perm_bus_cat_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_business <------
--
DROP SUBSCRIPTION db_perm_business_sl for db_perm_business_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_resources <------
--
DROP SUBSCRIPTION db_perm_resources_sl for db_perm_resources_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_role <------
--
DROP SUBSCRIPTION db_perm_role_sl for db_perm_role_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_supervisor <------
--
DROP SUBSCRIPTION db_perm_supervisor_sl for db_perm_supervisor_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_perm_users <------
--
DROP SUBSCRIPTION db_perm_users_sl for db_perm_users_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_pre_volatility_detail <------
--
DROP SUBSCRIPTION db_pre_volatility_detail_sl for db_pre_volatility_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_recon_position_log <------
--
DROP SUBSCRIPTION db_recon_position_log_sl for db_recon_position_log_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_recon_trade_log <------
--
DROP SUBSCRIPTION db_recon_trade_log_sl for db_recon_trade_log_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_rolled_market_prices <------
--
DROP SUBSCRIPTION db_rolled_market_prices_sl for db_rolled_market_prices_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_script_parameters <------
--
DROP SUBSCRIPTION db_script_parameters_sl for db_script_parameters_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_security_codes <------
--
DROP SUBSCRIPTION db_security_codes_sl for db_security_codes_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_status_history <------
--
DROP SUBSCRIPTION db_status_history_sl for db_status_history_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_swx_trade_reporting <------
--
DROP SUBSCRIPTION db_swx_trade_reporting_sl for db_swx_trade_reporting_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_temp_market_price <------
--
DROP SUBSCRIPTION db_temp_market_price_sl for db_temp_market_price_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets <------
--
DROP SUBSCRIPTION db_tickets_sl for db_tickets_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets_approval_options <------
--
DROP SUBSCRIPTION db_tickets_approval_options_sl for db_tickets_approval_options_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets_comments <------
--
DROP SUBSCRIPTION db_tickets_comments_sl for db_tickets_comments_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets_exec_queue <------
--
DROP SUBSCRIPTION db_tickets_exec_queue_sl for db_tickets_exec_queue_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets_status_history <------
--
DROP SUBSCRIPTION db_tickets_status_history_sl for db_tickets_status_history_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_tickets_user <------
--
DROP SUBSCRIPTION db_tickets_user_sl for db_tickets_user_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trader_permissions <------
--
DROP SUBSCRIPTION db_trader_permissions_sl for db_trader_permissions_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trading_account <------
--
DROP SUBSCRIPTION db_trading_account_sl for db_trading_account_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trading_book <------
--
DROP SUBSCRIPTION db_trading_book_sl for db_trading_book_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trading_desk <------
--
DROP SUBSCRIPTION db_trading_desk_sl for db_trading_desk_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trading_view <------
--
DROP SUBSCRIPTION db_trading_view_sl for db_trading_view_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_trading_webview <------
--
DROP SUBSCRIPTION db_trading_webview_sl for db_trading_webview_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_ts_adjustment <------
--
DROP SUBSCRIPTION db_ts_adjustment_sl for db_ts_adjustment_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_valid_interface_users <------
--
DROP SUBSCRIPTION db_valid_interface_users_sl for db_valid_interface_users_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_volatility_ancillary <------
--
DROP SUBSCRIPTION db_volatility_ancillary_sl for db_volatility_ancillary_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_xetra_defaults <------
--
DROP SUBSCRIPTION db_xetra_defaults_sl for db_xetra_defaults_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_xol_master_list <------
--
DROP SUBSCRIPTION db_xol_master_list_sl for db_xol_master_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.db_xol_outgoing_ca <------
--
DROP SUBSCRIPTION db_xol_outgoing_ca_sl for db_xol_outgoing_ca_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dba_check_rep_delay <------
--
DROP SUBSCRIPTION dba_check_rep_delay_sl for dba_check_rep_delay_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbs_COUNTER <------
--
DROP SUBSCRIPTION dbs_COUNTER_sl for dbs_COUNTER_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_kueu_file <------
--
DROP SUBSCRIPTION dbt_kueu_file_sl for dbt_kueu_file_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_sec_map <------
--
DROP SUBSCRIPTION dbt_sec_map_sl for dbt_sec_map_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_sec_type_mapping <------
--
DROP SUBSCRIPTION dbt_sec_type_mapping_sl for dbt_sec_type_mapping_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_sequence <------
--
DROP SUBSCRIPTION dbt_sequence_sl for dbt_sequence_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_trade_target <------
--
DROP SUBSCRIPTION dbt_trade_target_sl for dbt_trade_target_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_trade_target_temp <------
--
DROP SUBSCRIPTION dbt_trade_target_temp_sl for dbt_trade_target_temp_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbt_trade_triggers <------
--
DROP SUBSCRIPTION dbt_trade_triggers_sl for dbt_trade_triggers_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.dbtrader_secm <------
--
DROP SUBSCRIPTION dbtrader_secm_sl for dbtrader_secm_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.euro_rates <------
--
DROP SUBSCRIPTION euro_rates_sl for euro_rates_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.exec_queue_errors <------
--
DROP SUBSCRIPTION exec_queue_errors_sl for exec_queue_errors_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.gedi_admin_status <------
--
DROP SUBSCRIPTION gedi_admin_status_sl for gedi_admin_status_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_account <------
--
DROP SUBSCRIPTION hts_account_sl for hts_account_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_action_profile <------
--
DROP SUBSCRIPTION hts_action_profile_sl for hts_action_profile_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_action_profile_list <------
--
DROP SUBSCRIPTION hts_action_profile_list_sl for hts_action_profile_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_adjustment <------
--
DROP SUBSCRIPTION hts_adjustment_sl for hts_adjustment_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_adjustment_user_data <------
--
DROP SUBSCRIPTION hts_adjustment_user_data_sl for hts_adjustment_user_data_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ae_codes <------
--
DROP SUBSCRIPTION hts_ae_codes_sl for hts_ae_codes_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_audit_status <------
--
DROP SUBSCRIPTION hts_audit_status_sl for hts_audit_status_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_auto_quote <------
--
DROP SUBSCRIPTION hts_auto_quote_sl for hts_auto_quote_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_b2b_trade_event <------
--
DROP SUBSCRIPTION hts_b2b_trade_event_sl for hts_b2b_trade_event_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ba_spread_class <------
--
DROP SUBSCRIPTION hts_ba_spread_class_sl for hts_ba_spread_class_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ba_spread_detail <------
--
DROP SUBSCRIPTION hts_ba_spread_detail_sl for hts_ba_spread_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ba_spread_list <------
--
DROP SUBSCRIPTION hts_ba_spread_list_sl for hts_ba_spread_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_balance_transfer_log <------
--
DROP SUBSCRIPTION hts_balance_transfer_log_sl for hts_balance_transfer_log_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_basis_detail <------
--
DROP SUBSCRIPTION hts_basis_detail_sl for hts_basis_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_basis_list <------
--
DROP SUBSCRIPTION hts_basis_list_sl for hts_basis_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_bo_event <------
--
DROP SUBSCRIPTION hts_bo_event_sl for hts_bo_event_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_borrow_detail <------
--
DROP SUBSCRIPTION hts_borrow_detail_sl for hts_borrow_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_borrow_list <------
--
DROP SUBSCRIPTION hts_borrow_list_sl for hts_borrow_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_broker <------
--
DROP SUBSCRIPTION hts_broker_sl for hts_broker_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_broker_user_data <------
--
DROP SUBSCRIPTION hts_broker_user_data_sl for hts_broker_user_data_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_bs_codes <------
--
DROP SUBSCRIPTION hts_bs_codes_sl for hts_bs_codes_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ca_event <------
--
DROP SUBSCRIPTION hts_ca_event_sl for hts_ca_event_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_capreq_basket <------
--
DROP SUBSCRIPTION hts_capreq_basket_sl for hts_capreq_basket_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_capreq_divisors <------
--
DROP SUBSCRIPTION hts_capreq_divisors_sl for hts_capreq_divisors_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_capreq_overrides <------
--
DROP SUBSCRIPTION hts_capreq_overrides_sl for hts_capreq_overrides_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_capreq_xref <------
--
DROP SUBSCRIPTION hts_capreq_xref_sl for hts_capreq_xref_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_cash_coll_sched <------
--
DROP SUBSCRIPTION hts_cash_coll_sched_sl for hts_cash_coll_sched_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ccy_round <------
--
DROP SUBSCRIPTION hts_ccy_round_sl for hts_ccy_round_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_interval <------
--
DROP SUBSCRIPTION hts_charge_interval_sl for hts_charge_interval_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_rule <------
--
DROP SUBSCRIPTION hts_charge_rule_sl for hts_charge_rule_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_sched_detail <------
--
DROP SUBSCRIPTION hts_charge_sched_detail_sl for hts_charge_sched_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_sched_list <------
--
DROP SUBSCRIPTION hts_charge_sched_list_sl for hts_charge_sched_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_schedule <------
--
DROP SUBSCRIPTION hts_charge_schedule_sl for hts_charge_schedule_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_charge_type <------
--
DROP SUBSCRIPTION hts_charge_type_sl for hts_charge_type_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_coll_pool <------
--
DROP SUBSCRIPTION hts_coll_pool_sl for hts_coll_pool_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_collateral <------
--
DROP SUBSCRIPTION hts_collateral_sl for hts_collateral_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_constituent <------
--
DROP SUBSCRIPTION hts_constituent_sl for hts_constituent_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_corr_detail <------
--
DROP SUBSCRIPTION hts_corr_detail_sl for hts_corr_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_corr_list <------
--
DROP SUBSCRIPTION hts_corr_list_sl for hts_corr_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_country <------
--
DROP SUBSCRIPTION hts_country_sl for hts_country_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_credit_ratings <------
--
DROP SUBSCRIPTION hts_credit_ratings_sl for hts_credit_ratings_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_credit_spreads <------
--
DROP SUBSCRIPTION hts_credit_spreads_sl for hts_credit_spreads_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_credit_spreads_list <------
--
DROP SUBSCRIPTION hts_credit_spreads_list_sl for hts_credit_spreads_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_customer <------
--
DROP SUBSCRIPTION hts_customer_sl for hts_customer_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_customer_usage <------
--
DROP SUBSCRIPTION hts_customer_usage_sl for hts_customer_usage_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_data_relation <------
--
DROP SUBSCRIPTION hts_data_relation_sl for hts_data_relation_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbl_log <------
--
DROP SUBSCRIPTION hts_dbl_log_sl for hts_dbl_log_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbl_trade_log <------
--
DROP SUBSCRIPTION hts_dbl_trade_log_sl for hts_dbl_trade_log_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbt_fee_map <------
--
DROP SUBSCRIPTION hts_dbt_fee_map_sl for hts_dbt_fee_map_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbt_fi_sec <------
--
DROP SUBSCRIPTION hts_dbt_fi_sec_sl for hts_dbt_fi_sec_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbt_system_route <------
--
DROP SUBSCRIPTION hts_dbt_system_route_sl for hts_dbt_system_route_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dbt_xfce <------
--
DROP SUBSCRIPTION hts_dbt_xfce_sl for hts_dbt_xfce_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_deal <------
--
DROP SUBSCRIPTION hts_deal_sl for hts_deal_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dividend_detail <------
--
DROP SUBSCRIPTION hts_dividend_detail_sl for hts_dividend_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dividend_list <------
--
DROP SUBSCRIPTION hts_dividend_list_sl for hts_dividend_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dynamic_apps <------
--
DROP SUBSCRIPTION hts_dynamic_apps_sl for hts_dynamic_apps_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_dynrule_list <------
--
DROP SUBSCRIPTION hts_dynrule_list_sl for hts_dynrule_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_emu_conv_event <------
--
DROP SUBSCRIPTION hts_emu_conv_event_sl for hts_emu_conv_event_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_eqcd_detail <------
--
DROP SUBSCRIPTION hts_eqcd_detail_sl for hts_eqcd_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_event_types <------
--
DROP SUBSCRIPTION hts_event_types_sl for hts_event_types_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_exchange <------
--
DROP SUBSCRIPTION hts_exchange_sl for hts_exchange_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_exchange_snap_status <------
--
DROP SUBSCRIPTION hts_exchange_snap_status_sl for hts_exchange_snap_status_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_exec_adj <------
--
DROP SUBSCRIPTION hts_exec_adj_sl for hts_exec_adj_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_exec_control <------
--
DROP SUBSCRIPTION hts_exec_control_sl for hts_exec_control_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_exer_notice <------
--
DROP SUBSCRIPTION hts_exer_notice_sl for hts_exer_notice_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_fi_sec_master <------
--
DROP SUBSCRIPTION hts_fi_sec_master_sl for hts_fi_sec_master_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_filter_columns <------
--
DROP SUBSCRIPTION hts_filter_columns_sl for hts_filter_columns_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_filter_detail <------
--
DROP SUBSCRIPTION hts_filter_detail_sl for hts_filter_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_filter_list <------
--
DROP SUBSCRIPTION hts_filter_list_sl for hts_filter_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_fiscal_calendar <------
--
DROP SUBSCRIPTION hts_fiscal_calendar_sl for hts_fiscal_calendar_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_fixings <------
--
DROP SUBSCRIPTION hts_fixings_sl for hts_fixings_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_formula_rule_detail <------
--
DROP SUBSCRIPTION hts_formula_rule_detail_sl for hts_formula_rule_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_formula_rule_list <------
--
DROP SUBSCRIPTION hts_formula_rule_list_sl for hts_formula_rule_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_funding_rates <------
--
DROP SUBSCRIPTION hts_funding_rates_sl for hts_funding_rates_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_fx_detail <------
--
DROP SUBSCRIPTION hts_fx_detail_sl for hts_fx_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_fx_list <------
--
DROP SUBSCRIPTION hts_fx_list_sl for hts_fx_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_gen_otc <------
--
DROP SUBSCRIPTION hts_gen_otc_sl for hts_gen_otc_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_gen_sec_types <------
--
DROP SUBSCRIPTION hts_gen_sec_types_sl for hts_gen_sec_types_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_genfilter_cells <------
--
DROP SUBSCRIPTION hts_genfilter_cells_sl for hts_genfilter_cells_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_genfilter_columns <------
--
DROP SUBSCRIPTION hts_genfilter_columns_sl for hts_genfilter_columns_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_genfilter_detail <------
--
DROP SUBSCRIPTION hts_genfilter_detail_sl for hts_genfilter_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_gotc_rebate_pay_types <------
--
DROP SUBSCRIPTION hts_gotc_rebate_pay_types_sl for hts_gotc_rebate_pay_types_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_gotc_schedule <------
--
DROP SUBSCRIPTION hts_gotc_schedule_sl for hts_gotc_schedule_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_gotc_trigger_types <------
--
DROP SUBSCRIPTION hts_gotc_trigger_types_sl for hts_gotc_trigger_types_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_group <------
--
DROP SUBSCRIPTION hts_group_sl for hts_group_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_group_control <------
--
DROP SUBSCRIPTION hts_group_control_sl for hts_group_control_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_historical_prices <------
--
DROP SUBSCRIPTION hts_historical_prices_sl for hts_historical_prices_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_hold_audit_trail_log <------
--
DROP SUBSCRIPTION hts_hold_audit_trail_log_sl for hts_hold_audit_trail_log_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_hold_map <------
--
DROP SUBSCRIPTION hts_hold_map_sl for hts_hold_map_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_hold_user_data <------
--
DROP SUBSCRIPTION hts_hold_user_data_sl for hts_hold_user_data_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_holding_greeks <------
--
DROP SUBSCRIPTION hts_holding_greeks_sl for hts_holding_greeks_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_holiday_detail <------
--
DROP SUBSCRIPTION hts_holiday_detail_sl for hts_holiday_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_holiday_list <------
--
DROP SUBSCRIPTION hts_holiday_list_sl for hts_holiday_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_industry <------
--
DROP SUBSCRIPTION hts_industry_sl for hts_industry_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_irate_source <------
--
DROP SUBSCRIPTION hts_irate_source_sl for hts_irate_source_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_issuer <------
--
DROP SUBSCRIPTION hts_issuer_sl for hts_issuer_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_issuer_related_view <------
--
DROP SUBSCRIPTION hts_issuer_related_view_sl for hts_issuer_related_view_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_legacy_stock_split <------
--
DROP SUBSCRIPTION hts_legacy_stock_split_sl for hts_legacy_stock_split_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_legal_entity <------
--
DROP SUBSCRIPTION hts_legal_entity_sl for hts_legal_entity_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_lim_cmb_type <------
--
DROP SUBSCRIPTION hts_lim_cmb_type_sl for hts_lim_cmb_type_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_limit_detail <------
--
DROP SUBSCRIPTION hts_limit_detail_sl for hts_limit_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_limit_field <------
--
DROP SUBSCRIPTION hts_limit_field_sl for hts_limit_field_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_limit_list <------
--
DROP SUBSCRIPTION hts_limit_list_sl for hts_limit_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_limit_monitor_event <------
--
DROP SUBSCRIPTION hts_limit_monitor_event_sl for hts_limit_monitor_event_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_location <------
--
DROP SUBSCRIPTION hts_location_sl for hts_location_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_lock <------
--
DROP SUBSCRIPTION hts_lock_sl for hts_lock_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_mark <------
--
DROP SUBSCRIPTION hts_mark_sl for hts_mark_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_mark_acct <------
--
DROP SUBSCRIPTION hts_mark_acct_sl for hts_mark_acct_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_market_price <------
--
DROP SUBSCRIPTION hts_market_price_sl for hts_market_price_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_mmkt_usec <------
--
DROP SUBSCRIPTION hts_mmkt_usec_sl for hts_mmkt_usec_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_monitor_limit <------
--
DROP SUBSCRIPTION hts_monitor_limit_sl for hts_monitor_limit_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_name_change_notice <------
--
DROP SUBSCRIPTION hts_name_change_notice_sl for hts_name_change_notice_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_nosplit <------
--
DROP SUBSCRIPTION hts_nosplit_sl for hts_nosplit_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_object_limit <------
--
DROP SUBSCRIPTION hts_object_limit_sl for hts_object_limit_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_opt_exer_event <------
--
DROP SUBSCRIPTION hts_opt_exer_event_sl for hts_opt_exer_event_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ord_control <------
--
DROP SUBSCRIPTION hts_ord_control_sl for hts_ord_control_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ordhdg_group_detail <------
--
DROP SUBSCRIPTION hts_ordhdg_group_detail_sl for hts_ordhdg_group_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_ordhdg_group_list <------
--
DROP SUBSCRIPTION hts_ordhdg_group_list_sl for hts_ordhdg_group_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_pc_codes <------
--
DROP SUBSCRIPTION hts_pc_codes_sl for hts_pc_codes_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_perm_control <------
--
DROP SUBSCRIPTION hts_perm_control_sl for hts_perm_control_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_pl_archive <------
--
DROP SUBSCRIPTION hts_pl_archive_sl for hts_pl_archive_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_port_control <------
--
DROP SUBSCRIPTION hts_port_control_sl for hts_port_control_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_price_detail <------
--
DROP SUBSCRIPTION hts_price_detail_sl for hts_price_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_price_env <------
--
DROP SUBSCRIPTION hts_price_env_sl for hts_price_env_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_price_list <------
--
DROP SUBSCRIPTION hts_price_list_sl for hts_price_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_profit_loss <------
--
DROP SUBSCRIPTION hts_profit_loss_sl for hts_profit_loss_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_quote_rule <------
--
DROP SUBSCRIPTION hts_quote_rule_sl for hts_quote_rule_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_quote_rule_spreads <------
--
DROP SUBSCRIPTION hts_quote_rule_spreads_sl for hts_quote_rule_spreads_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_registry <------
--
DROP SUBSCRIPTION hts_registry_sl for hts_registry_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_regulatory_agency <------
--
DROP SUBSCRIPTION hts_regulatory_agency_sl for hts_regulatory_agency_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_replication_status <------
--
DROP SUBSCRIPTION hts_replication_status_sl for hts_replication_status_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_restricted_sec <------
--
DROP SUBSCRIPTION hts_restricted_sec_sl for hts_restricted_sec_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_reuters_masks <------
--
DROP SUBSCRIPTION hts_reuters_masks_sl for hts_reuters_masks_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_rm_ccy_default <------
--
DROP SUBSCRIPTION hts_rm_ccy_default_sl for hts_rm_ccy_default_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_roll_detail <------
--
DROP SUBSCRIPTION hts_roll_detail_sl for hts_roll_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_roll_list <------
--
DROP SUBSCRIPTION hts_roll_list_sl for hts_roll_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_scenario_maps <------
--
DROP SUBSCRIPTION hts_scenario_maps_sl for hts_scenario_maps_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sched_list <------
--
DROP SUBSCRIPTION hts_sched_list_sl for hts_sched_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sec_comment <------
--
DROP SUBSCRIPTION hts_sec_comment_sl for hts_sec_comment_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sec_def_attribs <------
--
DROP SUBSCRIPTION hts_sec_def_attribs_sl for hts_sec_def_attribs_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sec_master <------
--
DROP SUBSCRIPTION hts_sec_master_sl for hts_sec_master_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_settle_rule <------
--
DROP SUBSCRIPTION hts_settle_rule_sl for hts_settle_rule_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sfailure_event <------
--
DROP SUBSCRIPTION hts_sfailure_event_sl for hts_sfailure_event_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_audit_trail_log <------
--
DROP SUBSCRIPTION hts_sm_audit_trail_log_sl for hts_sm_audit_trail_log_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_ba_detail <------
--
DROP SUBSCRIPTION hts_sm_ba_detail_sl for hts_sm_ba_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_binary_detail <------
--
DROP SUBSCRIPTION hts_sm_binary_detail_sl for hts_sm_binary_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_cfd <------
--
DROP SUBSCRIPTION hts_sm_cfd_sl for hts_sm_cfd_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_deriv_detail <------
--
DROP SUBSCRIPTION hts_sm_deriv_detail_sl for hts_sm_deriv_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_eqss_detail <------
--
DROP SUBSCRIPTION hts_sm_eqss_detail_sl for hts_sm_eqss_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_relation <------
--
DROP SUBSCRIPTION hts_sm_relation_sl for hts_sm_relation_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_repo <------
--
DROP SUBSCRIPTION hts_sm_repo_sl for hts_sm_repo_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_repo_sched <------
--
DROP SUBSCRIPTION hts_sm_repo_sched_sl for hts_sm_repo_sched_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_stripbond_detail <------
--
DROP SUBSCRIPTION hts_sm_stripbond_detail_sl for hts_sm_stripbond_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_user_data <------
--
DROP SUBSCRIPTION hts_sm_user_data_sl for hts_sm_user_data_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sm_usymbol_view <------
--
DROP SUBSCRIPTION hts_sm_usymbol_view_sl for hts_sm_usymbol_view_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_snap_status <------
--
DROP SUBSCRIPTION hts_snap_status_sl for hts_snap_status_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_sp_return_codes <------
--
DROP SUBSCRIPTION hts_sp_return_codes_sl for hts_sp_return_codes_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_split <------
--
DROP SUBSCRIPTION hts_split_sl for hts_split_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_split_log <------
--
DROP SUBSCRIPTION hts_split_log_sl for hts_split_log_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_split_status <------
--
DROP SUBSCRIPTION hts_split_status_sl for hts_split_status_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_spot_list <------
--
DROP SUBSCRIPTION hts_spot_list_sl for hts_spot_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_stock_merger <------
--
DROP SUBSCRIPTION hts_stock_merger_sl for hts_stock_merger_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_stock_merger_list <------
--
DROP SUBSCRIPTION hts_stock_merger_list_sl for hts_stock_merger_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_stock_spinoff <------
--
DROP SUBSCRIPTION hts_stock_spinoff_sl for hts_stock_spinoff_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_stock_spinoff_list <------
--
DROP SUBSCRIPTION hts_stock_spinoff_list_sl for hts_stock_spinoff_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_strategy <------
--
DROP SUBSCRIPTION hts_strategy_sl for hts_strategy_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_strategy_component <------
--
DROP SUBSCRIPTION hts_strategy_component_sl for hts_strategy_component_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_strategy_group <------
--
DROP SUBSCRIPTION hts_strategy_group_sl for hts_strategy_group_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap <------
--
DROP SUBSCRIPTION hts_swap_sl for hts_swap_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_basket_reset <------
--
DROP SUBSCRIPTION hts_swap_basket_reset_sl for hts_swap_basket_reset_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_detail <------
--
DROP SUBSCRIPTION hts_swap_detail_sl for hts_swap_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_div_sched <------
--
DROP SUBSCRIPTION hts_swap_div_sched_sl for hts_swap_div_sched_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_equity_leg <------
--
DROP SUBSCRIPTION hts_swap_equity_leg_sl for hts_swap_equity_leg_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_event_sched <------
--
DROP SUBSCRIPTION hts_swap_event_sched_sl for hts_swap_event_sched_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_floating_leg <------
--
DROP SUBSCRIPTION hts_swap_floating_leg_sl for hts_swap_floating_leg_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_leg <------
--
DROP SUBSCRIPTION hts_swap_leg_sl for hts_swap_leg_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_list <------
--
DROP SUBSCRIPTION hts_swap_list_sl for hts_swap_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_quanto_leg <------
--
DROP SUBSCRIPTION hts_swap_quanto_leg_sl for hts_swap_quanto_leg_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_swap_sched_filt <------
--
DROP SUBSCRIPTION hts_swap_sched_filt_sl for hts_swap_sched_filt_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_system_status <------
--
DROP SUBSCRIPTION hts_system_status_sl for hts_system_status_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tax_rules <------
--
DROP SUBSCRIPTION hts_tax_rules_sl for hts_tax_rules_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_template_detail <------
--
DROP SUBSCRIPTION hts_template_detail_sl for hts_template_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_template_list <------
--
DROP SUBSCRIPTION hts_template_list_sl for hts_template_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tick_size_list <------
--
DROP SUBSCRIPTION hts_tick_size_list_sl for hts_tick_size_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tick_sizes <------
--
DROP SUBSCRIPTION hts_tick_sizes_sl for hts_tick_sizes_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tickets <------
--
DROP SUBSCRIPTION hts_tickets_sl for hts_tickets_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_time_zone <------
--
DROP SUBSCRIPTION hts_time_zone_sl for hts_time_zone_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_trader <------
--
DROP SUBSCRIPTION hts_trader_sl for hts_trader_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_trader_security <------
--
DROP SUBSCRIPTION hts_trader_security_sl for hts_trader_security_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tvol_detail <------
--
DROP SUBSCRIPTION hts_tvol_detail_sl for hts_tvol_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_tvol_list <------
--
DROP SUBSCRIPTION hts_tvol_list_sl for hts_tvol_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_underlying <------
--
DROP SUBSCRIPTION hts_underlying_sl for hts_underlying_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_user <------
--
DROP SUBSCRIPTION hts_user_sl for hts_user_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_user_company <------
--
DROP SUBSCRIPTION hts_user_company_sl for hts_user_company_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_user_info <------
--
DROP SUBSCRIPTION hts_user_info_sl for hts_user_info_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_user_message <------
--
DROP SUBSCRIPTION hts_user_message_sl for hts_user_message_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_user_rt_default <------
--
DROP SUBSCRIPTION hts_user_rt_default_sl for hts_user_rt_default_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_users <------
--
DROP SUBSCRIPTION hts_users_sl for hts_users_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_valid_date_patterns <------
--
DROP SUBSCRIPTION hts_valid_date_patterns_sl for hts_valid_date_patterns_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_var_cross_ref <------
--
DROP SUBSCRIPTION hts_var_cross_ref_sl for hts_var_cross_ref_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_volatility_detail <------
--
DROP SUBSCRIPTION hts_volatility_detail_sl for hts_volatility_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_volatility_detail_arc <------
--
DROP SUBSCRIPTION hts_volatility_detail_arc_sl for hts_volatility_detail_arc_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_volatility_list <------
--
DROP SUBSCRIPTION hts_volatility_list_sl for hts_volatility_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_volatility_list_arc <------
--
DROP SUBSCRIPTION hts_volatility_list_arc_sl for hts_volatility_list_arc_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_xact_history <------
--
DROP SUBSCRIPTION hts_xact_history_sl for hts_xact_history_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_xrate_detail <------
--
DROP SUBSCRIPTION hts_xrate_detail_sl for hts_xrate_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_xrate_list <------
--
DROP SUBSCRIPTION hts_xrate_list_sl for hts_xrate_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_alg_risk <------
--
DROP SUBSCRIPTION hts_yc_alg_risk_sl for hts_yc_alg_risk_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_cred_agency <------
--
DROP SUBSCRIPTION hts_yc_cred_agency_sl for hts_yc_cred_agency_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_cred_i2s_map <------
--
DROP SUBSCRIPTION hts_yc_cred_i2s_map_sl for hts_yc_cred_i2s_map_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_cred_level <------
--
DROP SUBSCRIPTION hts_yc_cred_level_sl for hts_yc_cred_level_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_cred_matrix <------
--
DROP SUBSCRIPTION hts_yc_cred_matrix_sl for hts_yc_cred_matrix_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_curve <------
--
DROP SUBSCRIPTION hts_yc_curve_sl for hts_yc_curve_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_hdg_instr <------
--
DROP SUBSCRIPTION hts_yc_hdg_instr_sl for hts_yc_hdg_instr_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_hdg_strat <------
--
DROP SUBSCRIPTION hts_yc_hdg_strat_sl for hts_yc_hdg_strat_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_link_data <------
--
DROP SUBSCRIPTION hts_yc_link_data_sl for hts_yc_link_data_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_mkt_instr <------
--
DROP SUBSCRIPTION hts_yc_mkt_instr_sl for hts_yc_mkt_instr_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_mkt_instr_data <------
--
DROP SUBSCRIPTION hts_yc_mkt_instr_data_sl for hts_yc_mkt_instr_data_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_mkt_instr_hdr <------
--
DROP SUBSCRIPTION hts_yc_mkt_instr_hdr_sl for hts_yc_mkt_instr_hdr_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_model <------
--
DROP SUBSCRIPTION hts_yc_model_sl for hts_yc_model_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_risk_curve <------
--
DROP SUBSCRIPTION hts_yc_risk_curve_sl for hts_yc_risk_curve_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_risk_curves_view <------
--
DROP SUBSCRIPTION hts_yc_risk_curves_view_sl for hts_yc_risk_curves_view_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_risk_data <------
--
DROP SUBSCRIPTION hts_yc_risk_data_sl for hts_yc_risk_data_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_risk_scenar_view <------
--
DROP SUBSCRIPTION hts_yc_risk_scenar_view_sl for hts_yc_risk_scenar_view_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_risk_scenario <------
--
DROP SUBSCRIPTION hts_yc_risk_scenario_sl for hts_yc_risk_scenario_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_scenario <------
--
DROP SUBSCRIPTION hts_yc_scenario_sl for hts_yc_scenario_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_sp <------
--
DROP SUBSCRIPTION hts_yc_sp_sl for hts_yc_sp_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_sp_hdr <------
--
DROP SUBSCRIPTION hts_yc_sp_hdr_sl for hts_yc_sp_hdr_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_strip <------
--
DROP SUBSCRIPTION hts_yc_strip_sl for hts_yc_strip_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yc_swap_spec <------
--
DROP SUBSCRIPTION hts_yc_swap_spec_sl for hts_yc_swap_spec_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yield_detail <------
--
DROP SUBSCRIPTION hts_yield_detail_sl for hts_yield_detail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.hts_yield_list <------
--
DROP SUBSCRIPTION hts_yield_list_sl for hts_yield_list_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.lic_feature <------
--
DROP SUBSCRIPTION lic_feature_sl for lic_feature_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.lic_usage <------
--
DROP SUBSCRIPTION lic_usage_sl for lic_usage_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.mdl_portf_colnames_tb <------
--
DROP SUBSCRIPTION mdl_portf_colnames_tb_sl for mdl_portf_colnames_tb_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONCDRImport <------
--
DROP SUBSCRIPTION t_ICONCDRImport_sl for t_ICONCDRImport_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONCDRLookup <------
--
DROP SUBSCRIPTION t_ICONCDRLookup_sl for t_ICONCDRLookup_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONFeedControl <------
--
DROP SUBSCRIPTION t_ICONFeedControl_sl for t_ICONFeedControl_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONFilesInfo <------
--
DROP SUBSCRIPTION t_ICONFilesInfo_sl for t_ICONFilesInfo_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONPrepareTradeFile <------
--
DROP SUBSCRIPTION t_ICONPrepareTradeFile_sl for t_ICONPrepareTradeFile_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONTradesCompare <------
--
DROP SUBSCRIPTION t_ICONTradesCompare_sl for t_ICONTradesCompare_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONTradesSentDetail <------
--
DROP SUBSCRIPTION t_ICONTradesSentDetail_sl for t_ICONTradesSentDetail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_ICONTradesTemp <------
--
DROP SUBSCRIPTION t_ICONTradesTemp_sl for t_ICONTradesTemp_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_init_ICONPrepareTradeFile <------
--
DROP SUBSCRIPTION t_init_ICONPrepareTradeFile_sl for t_init_ICONPrepareTradeFile_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_init_ICONTradesSentDetail <------
--
DROP SUBSCRIPTION t_init_ICONTradesSentDetail_sl for t_init_ICONTradesSentDetail_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.t_init_ImportCDR <------
--
DROP SUBSCRIPTION t_init_ImportCDR_sl for t_init_ImportCDR_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.test1 <------
--
DROP SUBSCRIPTION test1_sl for test1_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.user_location <------
--
DROP SUBSCRIPTION user_location_sl for user_location_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
--
------> table its_ged_prod.world_clock <------
--
DROP SUBSCRIPTION world_clock_sl for world_clock_sd
WITH REPLICATE AT lon_gen_sql_tst1.its_ged_prod
WITHOUT PURGE
go
