set echo off
-- oc.sql
-- Purpose: Display open cursor information.
-- -----------------------------------------------------------------------------
column username  format a25
column program   format a35
column sid       format 999999
prompt
Prompt +--------------------------------------------------------+
Prompt | Open Cursor Info from v$session, v$open_cursor         |
Prompt +--------------------------------------------------------+

SELECT s.sid,s.username,s.program,count(oc.sid) open_cursors
FROM v$session s, v$open_cursor oc
WHERE oc.sid = s.sid
GROUP BY s.sid,s.username,s.program
ORDER BY open_cursors desc
/
exit
