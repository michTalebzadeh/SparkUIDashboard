 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ID										   NUMBER
 NAME										   VARCHAR2(64)
 NAME_NLS									   VARCHAR2(1024)
 CLSID										   NUMBER
 CLS_NAME									   VARCHAR2(15)
 FLAGS										   NUMBER
 INTERNAL_CHECK 								   VARCHAR2(1)
 OFFLINE_CAPABLE								   VARCHAR2(1)
 DESCRIPTION									   VARCHAR2(1024)

