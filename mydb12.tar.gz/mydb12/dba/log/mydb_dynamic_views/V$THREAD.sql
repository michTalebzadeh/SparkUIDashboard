 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 THREAD#									   NUMBER
 STATUS 									   VARCHAR2(6)
 ENABLED									   VARCHAR2(8)
 GROUPS 									   NUMBER
 INSTANCE									   VARCHAR2(80)
 OPEN_TIME									   DATE
 CURRENT_GROUP# 								   NUMBER
 SEQUENCE#									   NUMBER
 CHECKPOINT_CHANGE#								   NUMBER
 CHECKPOINT_TIME								   DATE
 ENABLE_CHANGE# 								   NUMBER
 ENABLE_TIME									   DATE
 DISABLE_CHANGE#								   NUMBER
 DISABLE_TIME									   DATE
 LAST_REDO_SEQUENCE#								   NUMBER
 LAST_REDO_BLOCK								   NUMBER
 LAST_REDO_CHANGE#								   NUMBER
 LAST_REDO_TIME 								   DATE

