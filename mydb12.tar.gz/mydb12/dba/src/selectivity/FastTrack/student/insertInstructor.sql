REM ******************************************************************
REM   file: insertInstructor.sql
REM  description: used for loading Instructor data
REM  created January 30, 2000
REM ******************************************************************

ALTER SESSION SET NLS_DATE_FORMAT = 'DD-MON-RR';

SET DEFINE OFF
SPOOL insertInstructor.log

INSERT INTO instructor VALUES (101,'Mr','Fernand','Hanks','100 East 87th','10015','2125551212','ESILVEST','02-JAN-99','ESILVEST','02-JAN-99');                                                          
INSERT INTO instructor VALUES (102,'Mr','Tom','Wojick','518 West 120th','10025','2125551212','ESILVEST','02-JAN-99','ESILVEST','02-JAN-99');                                                            
INSERT INTO instructor VALUES (103,'Ms','Nina','Schorin','210 West 101st','10025','2125551212','ESILVEST','02-JAN-99','ESILVEST','02-JAN-99');                                                          
INSERT INTO instructor VALUES (104,'Mr','Gary','Pertez','34 Sixth Ave','10035','2125551212','ESILVEST','02-JAN-99','ESILVEST','02-JAN-99');                                                             
INSERT INTO instructor VALUES (105,'Ms','Anita','Morris','34 Maiden Lane','10015','2125551212','ESILVEST','02-JAN-99','ESILVEST','02-JAN-99');                                                          
INSERT INTO instructor VALUES (106,'Rev','Todd','Smythe','210 West 101st','10025','2125551212','ESILVEST','02-JAN-99','ESILVEST','02-JAN-99');                                                          
INSERT INTO instructor VALUES (107,'Dr','Marilyn','Frantzen','254 Bleeker','10005','2125551212','ESILVEST','02-JAN-99','ESILVEST','02-JAN-99');                                                         
INSERT INTO instructor VALUES (108,'Mr','Charles','Lowry','518 West 120th','10025','2125551212','ESILVEST','02-JAN-99','ESILVEST','02-JAN-99');                                                         
INSERT INTO instructor VALUES (109,'Hon','Rick','Chow','56 10th Avenue','10015','2125551212','ESILVEST','02-JAN-99','ESILVEST','02-JAN-99');                                                            
INSERT INTO instructor VALUES (110,'Ms','Irene','Willig','415 West 101st',NULL,'2125551212','ARISCHER','11-MAR-99','ARISCHER','11-MAR-99');                                                             

COMMIT;

SPOOL OFF

