set quoted_identifier on
go
 CREATE TABLE  nulltest
 (
  OWNER           varchar(30)                  NULL,
  OBJECT_NAME     varchar(128)                 NULL,
  SUBOBJECT_NAME  varchar(30)                  NULL,
  OBJECT_ID       bigint                       NULL,
  DATA_OBJECT_ID  bigint                       NULL,
  OBJECT_TYPE     varchar(19)                  NULL,
  CREATED         datetime                     NULL,
  LAST_DDL_TIME   datetime                     NULL,
  TIMESTAMP       varchar(19)                  NULL,
  STATUS          varchar(7)                   NULL,
  "TEMPORARY"     varchar(1)                   NULL,
  GENERATED       varchar(1)                   NULL,
  SECONDARY       varchar(1)                   NULL,
  NAMESPACE       bigint                       NULL,
  EDITION_NAME    varchar(30)                  NULL
 )
go
