/********************************************/
/*------------ tablespace_fs -------------*/
/********************************************/
select 'Started creating tablespace_fs tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE SMALLFILE TABLESPACE "TABLESPACE_FS" DATAFILE '/ssddata2/oracle/mydb/tablespace_fs.dbf' SIZE 2000M AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED LOGGING
 EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO; 
select 'Finished  creating tablespace_fs tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
