 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 DEST_ID									   NUMBER
 DEST_NAME									   VARCHAR2(256)
 STATUS 									   VARCHAR2(9)
 TYPE										   VARCHAR2(14)
 DATABASE_MODE									   VARCHAR2(15)
 RECOVERY_MODE									   VARCHAR2(23)
 PROTECTION_MODE								   VARCHAR2(20)
 DESTINATION									   VARCHAR2(256)
 STANDBY_LOGFILE_COUNT								   NUMBER
 STANDBY_LOGFILE_ACTIVE 							   NUMBER
 ARCHIVED_THREAD#								   NUMBER
 ARCHIVED_SEQ#									   NUMBER
 APPLIED_THREAD#								   NUMBER
 APPLIED_SEQ#									   NUMBER
 ERROR										   VARCHAR2(256)
 SRL										   VARCHAR2(3)
 DB_UNIQUE_NAME 								   VARCHAR2(30)
 SYNCHRONIZATION_STATUS 							   VARCHAR2(22)
 SYNCHRONIZED									   VARCHAR2(3)
 GAP_STATUS									   VARCHAR2(24)

