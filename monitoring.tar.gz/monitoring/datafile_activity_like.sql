@$HOME/abc
SELECT file_name, phyrds, phywrts,
       decode(phyrds,0,0,phyblkrd/phyrds) AS "Blocks/Read",
       decode(phywrts,0,0,phyblkwrt/phywrts) AS "Blocks/Write"
FROM   dba_data_files, v$filestat
WHERE  dba_data_files.file_id =v$filestat.file#
/
exit

