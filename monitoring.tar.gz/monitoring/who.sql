set heading off;
select 'Logged sessions on database '||substr(name,1,8) || ' at '||to_char(sysdate,'yyyy/mm/dd hh24:mi') from v$database;
set heading on;
column spid heading "OS PID" format a6
column process heading "Client ProcID" format a13
--column SessionID format a9 heading "OraSessID"
select
substr(b.username,1,15) "Login",
substr(a.username,1,10)||'/'||substr(a.spid,1,9) "OS Proc/ID",
--substr(a.spid,1,9) spid,
--substr(b.osuser,1,15) AS "OS Login",
substr(b.osuser,1,10)||'/'||substr(b.process,1,9) "Client Proc/ID",
--substr(b.process,1,9) process,
substr(b.sid,1,5) "SID",
substr(b.serial#,1,5) ser#,
substr(b.machine,1,10) host,
substr(b.program,1,30) program,
ROUND((sysdate-b.logon_time)*24) AS "Logged/Hours"
from
v$session b,
v$process a
where
b.paddr = a.addr
--and
--b.type='USER'
and
a.background IS NULL
and 
b.sid NOT IN (select sid from v$mystat where rownum = 1)
order by
a.spid;
exit
