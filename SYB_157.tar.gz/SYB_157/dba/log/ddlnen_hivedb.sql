USE master
go


PRINT "<<<< CREATE DATABASE hivedb>>>>"
go


IF EXISTS (SELECT 1 FROM master.dbo.sysdatabases
	   WHERE name = 'hivedb')
	DROP DATABASE hivedb
go


IF (@@error != 0)
BEGIN
	PRINT "Error dropping database 'hivedb'"
	SELECT syb_quit()
END
go


CREATE DATABASE hivedb
	    ON datadev01_HDD = '100M' -- 12800 pages
	LOG ON logdev01_HDD = '50M' -- 6400 pages
WITH DURABILITY = FULL
go


use hivedb
go

exec sp_changedbowner 'mtalebz1', true 
go

exec master.dbo.sp_dboption hivedb, 'select into/bulkcopy/pllsort', true
go

exec master.dbo.sp_dboption hivedb, 'trunc log on chkpt', true
go

checkpoint
go


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.BUCKETING_COLS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.BUCKETING_COLS" >>>>>'
go

use hivedb
go 

setuser 'dbo'
go 

create table BUCKETING_COLS (
	SD_ID                           bigint                           not null,
	BUCKET_COL_NAME                 varchar(255)                         null,
	INTEGER_IDX                     int                              not null,
		CONSTRAINT BUCKETING_COLS_PK PRIMARY KEY CLUSTERED ( SD_ID, INTEGER_IDX )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'BUCKETING_COLS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "BUCKETING_COLS_N49" >>>>>'
go 

create nonclustered index BUCKETING_COLS_N49 
on hivedb.dbo.BUCKETING_COLS(SD_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.CDS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.CDS" >>>>>'
go

setuser 'dbo'
go 

create table CDS (
	CD_ID                           bigint                           not null,
		CONSTRAINT CDS_PK PRIMARY KEY CLUSTERED ( CD_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.COLUMNS_V2'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.COLUMNS_V2" >>>>>'
go

setuser 'dbo'
go 

create table COLUMNS_V2 (
	CD_ID                           bigint                           not null,
	COMMENT                         varchar(256)                         null,
	COLUMN_NAME                     varchar(128)                     not null,
	TYPE_NAME                       varchar(4000)                    not null,
	INTEGER_IDX                     int                              not null,
		CONSTRAINT COLUMNS_PK PRIMARY KEY CLUSTERED ( CD_ID, COLUMN_NAME )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'COLUMNS_V2_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "COLUMNS_V2_N49" >>>>>'
go 

create nonclustered index COLUMNS_V2_N49 
on hivedb.dbo.COLUMNS_V2(CD_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.COMPACTION_QUEUE'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.COMPACTION_QUEUE" >>>>>'
go

setuser 'dbo'
go 

create table COMPACTION_QUEUE (
	CQ_ID                           bigint                           not null,
	CQ_DATABASE                     varchar(128)                     not null,
	CQ_TABLE                        varchar(128)                     not null,
	CQ_PARTITION                    varchar(767)                         null,
	CQ_STATE                        char(1)                          not null,
	CQ_TYPE                         char(1)                          not null,
	CQ_WORKER_ID                    varchar(128)                         null,
	CQ_START                        bigint                               null,
	CQ_RUN_AS                       varchar(128)                         null,
 PRIMARY KEY CLUSTERED ( CQ_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.COMPLETED_TXN_COMPONENTS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.COMPLETED_TXN_COMPONENTS" >>>>>'
go

setuser 'dbo'
go 

create table COMPLETED_TXN_COMPONENTS (
	CTC_TXNID                       bigint                               null,
	CTC_DATABASE                    varchar(128)                     not null,
	CTC_TABLE                       varchar(128)                         null,
	CTC_PARTITION                   varchar(767)                         null 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.DATABASE_PARAMS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.DATABASE_PARAMS" >>>>>'
go

setuser 'dbo'
go 

create table DATABASE_PARAMS (
	DB_ID                           bigint                           not null,
	PARAM_KEY                       varchar(180)                     not null,
	PARAM_VALUE                     varchar(4000)                        null,
		CONSTRAINT DATABASE_PARAMS_PK PRIMARY KEY CLUSTERED ( DB_ID, PARAM_KEY )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'DATABASE_PARAMS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "DATABASE_PARAMS_N49" >>>>>'
go 

create nonclustered index DATABASE_PARAMS_N49 
on hivedb.dbo.DATABASE_PARAMS(DB_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.DBS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.DBS" >>>>>'
go

setuser 'dbo'
go 

set quoted_identifier on
go 

create table DBS (
	DB_ID                           bigint                           not null,
	"DESC"                          varchar(4000)                        null,
	DB_LOCATION_URI                 varchar(4000)                    not null,
	NAME                            varchar(128)                         null,
	OWNER_NAME                      varchar(128)                         null,
	OWNER_TYPE                      varchar(10)                          null,
		CONSTRAINT DBS_PK PRIMARY KEY CLUSTERED ( DB_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 
set quoted_identifier off
go 


-----------------------------------------------------------------------------
-- DDL for Index 'UNIQUEDATABASE'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "UNIQUEDATABASE" >>>>>'
go 

create unique nonclustered index UNIQUEDATABASE 
on hivedb.dbo.DBS(NAME)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.DB_PRIVS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.DB_PRIVS" >>>>>'
go

setuser 'dbo'
go 

create table DB_PRIVS (
	DB_GRANT_ID                     bigint                           not null,
	CREATE_TIME                     int                              not null,
	DB_ID                           bigint                               null,
	GRANT_OPTION                    smallint                         not null CHECK  (GRANT_OPTION IN (0,1))
,
	GRANTOR                         varchar(128)                         null,
	GRANTOR_TYPE                    varchar(128)                         null,
	PRINCIPAL_NAME                  varchar(128)                         null,
	PRINCIPAL_TYPE                  varchar(128)                         null,
	DB_PRIV                         varchar(128)                         null,
		CONSTRAINT DB_PRIVS_PK PRIMARY KEY CLUSTERED ( DB_GRANT_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'DBPRIVILEGEINDEX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "DBPRIVILEGEINDEX" >>>>>'
go 

create unique nonclustered index DBPRIVILEGEINDEX 
on hivedb.dbo.DB_PRIVS(DB_ID, PRINCIPAL_NAME, PRINCIPAL_TYPE, DB_PRIV, GRANTOR, GRANTOR_TYPE)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'DB_PRIVS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "DB_PRIVS_N49" >>>>>'
go 

create nonclustered index DB_PRIVS_N49 
on hivedb.dbo.DB_PRIVS(DB_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.DELEGATION_TOKENS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.DELEGATION_TOKENS" >>>>>'
go

setuser 'dbo'
go 

create table DELEGATION_TOKENS (
	TOKEN_IDENT                     varchar(767)                     not null,
	TOKEN                           varchar(767)                         null,
		CONSTRAINT DELEGATION_TOKENS_PK PRIMARY KEY CLUSTERED ( TOKEN_IDENT )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.FUNCS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.FUNCS" >>>>>'
go

setuser 'dbo'
go 

create table FUNCS (
	FUNC_ID                         bigint                           not null,
	CLASS_NAME                      varchar(4000)                        null,
	CREATE_TIME                     int                              not null,
	DB_ID                           bigint                               null,
	FUNC_NAME                       varchar(128)                         null,
	FUNC_TYPE                       int                              not null,
	OWNER_NAME                      varchar(128)                         null,
	OWNER_TYPE                      varchar(10)                          null,
		CONSTRAINT FUNCS_PK PRIMARY KEY CLUSTERED ( FUNC_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'UNIQUEFUNCTION'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "UNIQUEFUNCTION" >>>>>'
go 

create unique nonclustered index UNIQUEFUNCTION 
on hivedb.dbo.FUNCS(FUNC_NAME, DB_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'FUNCS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "FUNCS_N49" >>>>>'
go 

create nonclustered index FUNCS_N49 
on hivedb.dbo.FUNCS(DB_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.FUNC_RU'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.FUNC_RU" >>>>>'
go

setuser 'dbo'
go 

create table FUNC_RU (
	FUNC_ID                         bigint                           not null,
	RESOURCE_TYPE                   int                              not null,
	RESOURCE_URI                    varchar(4000)                        null,
	INTEGER_IDX                     int                              not null,
		CONSTRAINT FUNC_RU_PK PRIMARY KEY CLUSTERED ( FUNC_ID, INTEGER_IDX )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'FUNC_RU_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "FUNC_RU_N49" >>>>>'
go 

create nonclustered index FUNC_RU_N49 
on hivedb.dbo.FUNC_RU(FUNC_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.GLOBAL_PRIVS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.GLOBAL_PRIVS" >>>>>'
go

setuser 'dbo'
go 

create table GLOBAL_PRIVS (
	USER_GRANT_ID                   bigint                           not null,
	CREATE_TIME                     int                              not null,
	GRANT_OPTION                    smallint                         not null CHECK  (GRANT_OPTION IN (0,1))
,
	GRANTOR                         varchar(128)                         null,
	GRANTOR_TYPE                    varchar(128)                         null,
	PRINCIPAL_NAME                  varchar(128)                         null,
	PRINCIPAL_TYPE                  varchar(128)                         null,
	USER_PRIV                       varchar(128)                         null,
		CONSTRAINT GLOBAL_PRIVS_PK PRIMARY KEY CLUSTERED ( USER_GRANT_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'GLOBALPRIVILEGEINDEX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "GLOBALPRIVILEGEINDEX" >>>>>'
go 

create unique nonclustered index GLOBALPRIVILEGEINDEX 
on hivedb.dbo.GLOBAL_PRIVS(PRINCIPAL_NAME, PRINCIPAL_TYPE, USER_PRIV, GRANTOR, GRANTOR_TYPE)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.HIVE_LOCKS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.HIVE_LOCKS" >>>>>'
go

setuser 'dbo'
go 

create table HIVE_LOCKS (
	HL_LOCK_EXT_ID                  bigint                           not null,
	HL_LOCK_INT_ID                  bigint                           not null,
	HL_TXNID                        bigint                               null,
	HL_DB                           varchar(128)                     not null,
	HL_TABLE                        varchar(128)                         null,
	HL_PARTITION                    varchar(767)                         null,
	HL_LOCK_STATE                   char(1)                          not null,
	HL_LOCK_TYPE                    char(1)                          not null,
	HL_LAST_HEARTBEAT               bigint                           not null,
	HL_ACQUIRED_AT                  bigint                               null,
	HL_USER                         varchar(128)                     not null,
	HL_HOST                         varchar(128)                     not null,
 PRIMARY KEY CLUSTERED ( HL_LOCK_EXT_ID, HL_LOCK_INT_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.IDXS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.IDXS" >>>>>'
go

setuser 'dbo'
go 

create table IDXS (
	INDEX_ID                        bigint                           not null,
	CREATE_TIME                     int                              not null,
	DEFERRED_REBUILD                bit                              not null,
	INDEX_HANDLER_CLASS             varchar(4000)                        null,
	INDEX_NAME                      varchar(128)                         null,
	INDEX_TBL_ID                    bigint                               null,
	LAST_ACCESS_TIME                int                              not null,
	ORIG_TBL_ID                     bigint                               null,
	SD_ID                           bigint                               null,
		CONSTRAINT IDXS_PK PRIMARY KEY CLUSTERED ( INDEX_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'UNIQUEINDEX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "UNIQUEINDEX" >>>>>'
go 

create unique nonclustered index UNIQUEINDEX 
on hivedb.dbo.IDXS(INDEX_NAME, ORIG_TBL_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'IDXS_N51'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "IDXS_N51" >>>>>'
go 

create nonclustered index IDXS_N51 
on hivedb.dbo.IDXS(SD_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'IDXS_N50'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "IDXS_N50" >>>>>'
go 

create nonclustered index IDXS_N50 
on hivedb.dbo.IDXS(ORIG_TBL_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'IDXS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "IDXS_N49" >>>>>'
go 

create nonclustered index IDXS_N49 
on hivedb.dbo.IDXS(INDEX_TBL_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.INDEX_PARAMS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.INDEX_PARAMS" >>>>>'
go

setuser 'dbo'
go 

create table INDEX_PARAMS (
	INDEX_ID                        bigint                           not null,
	PARAM_KEY                       varchar(256)                     not null,
	PARAM_VALUE                     varchar(4000)                        null,
		CONSTRAINT INDEX_PARAMS_PK PRIMARY KEY CLUSTERED ( INDEX_ID, PARAM_KEY )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'INDEX_PARAMS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "INDEX_PARAMS_N49" >>>>>'
go 

create nonclustered index INDEX_PARAMS_N49 
on hivedb.dbo.INDEX_PARAMS(INDEX_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.MASTER_KEYS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.MASTER_KEYS" >>>>>'
go

setuser 'dbo'
go 

create table MASTER_KEYS (
	KEY_ID                          int                              not null,
	MASTER_KEY                      varchar(767)                         null,
		CONSTRAINT MASTER_KEYS_PK PRIMARY KEY CLUSTERED ( KEY_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.NEXT_COMPACTION_QUEUE_ID'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.NEXT_COMPACTION_QUEUE_ID" >>>>>'
go

setuser 'dbo'
go 

create table NEXT_COMPACTION_QUEUE_ID (
	NCQ_NEXT                        bigint                           not null 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.NEXT_LOCK_ID'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.NEXT_LOCK_ID" >>>>>'
go

setuser 'dbo'
go 

create table NEXT_LOCK_ID (
	NL_NEXT                         bigint                           not null 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.NEXT_TXN_ID'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.NEXT_TXN_ID" >>>>>'
go

setuser 'dbo'
go 

create table NEXT_TXN_ID (
	NTXN_NEXT                       bigint                           not null 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.PARTITIONS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.PARTITIONS" >>>>>'
go

setuser 'dbo'
go 

create table PARTITIONS (
	PART_ID                         bigint                           not null,
	CREATE_TIME                     int                              not null,
	LAST_ACCESS_TIME                int                              not null,
	PART_NAME                       nvarchar(767)                        null,
	SD_ID                           bigint                               null,
	TBL_ID                          bigint                               null,
		CONSTRAINT PARTITIONS_PK PRIMARY KEY CLUSTERED ( PART_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'PARTITIONS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PARTITIONS_N49" >>>>>'
go 

create nonclustered index PARTITIONS_N49 
on hivedb.dbo.PARTITIONS(SD_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'PARTITIONS_N50'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PARTITIONS_N50" >>>>>'
go 

create nonclustered index PARTITIONS_N50 
on hivedb.dbo.PARTITIONS(TBL_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'UNIQUEPARTITION'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "UNIQUEPARTITION" >>>>>'
go 

create unique nonclustered index UNIQUEPARTITION 
on hivedb.dbo.PARTITIONS(PART_NAME, TBL_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.PARTITION_EVENTS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.PARTITION_EVENTS" >>>>>'
go

setuser 'dbo'
go 

create table PARTITION_EVENTS (
	PART_NAME_ID                    bigint                           not null,
	DB_NAME                         varchar(128)                         null,
	EVENT_TIME                      bigint                           not null,
	EVENT_TYPE                      int                              not null,
	PARTITION_NAME                  varchar(767)                         null,
	TBL_NAME                        varchar(128)                         null,
		CONSTRAINT PARTITION_EVENTS_PK PRIMARY KEY CLUSTERED ( PART_NAME_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'PARTITIONEVENTINDEX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PARTITIONEVENTINDEX" >>>>>'
go 

create nonclustered index PARTITIONEVENTINDEX 
on hivedb.dbo.PARTITION_EVENTS(PARTITION_NAME)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.PARTITION_KEYS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.PARTITION_KEYS" >>>>>'
go

setuser 'dbo'
go 

create table PARTITION_KEYS (
	TBL_ID                          bigint                           not null,
	PKEY_COMMENT                    varchar(4000)                        null,
	PKEY_NAME                       varchar(128)                     not null,
	PKEY_TYPE                       varchar(767)                     not null,
	INTEGER_IDX                     int                              not null,
		CONSTRAINT PARTITION_KEY_PK PRIMARY KEY CLUSTERED ( TBL_ID, PKEY_NAME )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'PARTITION_KEYS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PARTITION_KEYS_N49" >>>>>'
go 

create nonclustered index PARTITION_KEYS_N49 
on hivedb.dbo.PARTITION_KEYS(TBL_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.PARTITION_KEY_VALS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.PARTITION_KEY_VALS" >>>>>'
go

setuser 'dbo'
go 

create table PARTITION_KEY_VALS (
	PART_ID                         bigint                           not null,
	PART_KEY_VAL                    nvarchar(255)                        null,
	INTEGER_IDX                     int                              not null,
		CONSTRAINT PARTITION_KEY_VALS_PK PRIMARY KEY CLUSTERED ( PART_ID, INTEGER_IDX )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'PARTITION_KEY_VALS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PARTITION_KEY_VALS_N49" >>>>>'
go 

create nonclustered index PARTITION_KEY_VALS_N49 
on hivedb.dbo.PARTITION_KEY_VALS(PART_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.PARTITION_PARAMS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.PARTITION_PARAMS" >>>>>'
go

setuser 'dbo'
go 

create table PARTITION_PARAMS (
	PART_ID                         bigint                           not null,
	PARAM_KEY                       varchar(256)                     not null,
	PARAM_VALUE                     varchar(4000)                        null,
		CONSTRAINT PARTITION_PARAMS_PK PRIMARY KEY CLUSTERED ( PART_ID, PARAM_KEY )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'PARTITION_PARAMS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PARTITION_PARAMS_N49" >>>>>'
go 

create nonclustered index PARTITION_PARAMS_N49 
on hivedb.dbo.PARTITION_PARAMS(PART_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.PART_COL_PRIVS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.PART_COL_PRIVS" >>>>>'
go

setuser 'dbo'
go 

create table PART_COL_PRIVS (
	PART_COLUMN_GRANT_ID            bigint                           not null,
	COLUMN_NAME                     varchar(128)                         null,
	CREATE_TIME                     int                              not null,
	GRANT_OPTION                    smallint                         not null CHECK  (GRANT_OPTION IN (0,1))
,
	GRANTOR                         varchar(128)                         null,
	GRANTOR_TYPE                    varchar(128)                         null,
	PART_ID                         bigint                               null,
	PRINCIPAL_NAME                  varchar(128)                         null,
	PRINCIPAL_TYPE                  varchar(128)                         null,
	PART_COL_PRIV                   varchar(128)                         null,
		CONSTRAINT PART_COL_PRIVS_PK PRIMARY KEY CLUSTERED ( PART_COLUMN_GRANT_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'PART_COL_PRIVS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PART_COL_PRIVS_N49" >>>>>'
go 

create nonclustered index PART_COL_PRIVS_N49 
on hivedb.dbo.PART_COL_PRIVS(PART_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'PARTITIONCOLUMNPRIVILEGEINDEX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PARTITIONCOLUMNPRIVILEGEINDEX" >>>>>'
go 

create nonclustered index PARTITIONCOLUMNPRIVILEGEINDEX 
on hivedb.dbo.PART_COL_PRIVS(PART_ID, COLUMN_NAME, PRINCIPAL_NAME, PRINCIPAL_TYPE, PART_COL_PRIV, GRANTOR, GRANTOR_TYPE)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.PART_COL_STATS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.PART_COL_STATS" >>>>>'
go

setuser 'dbo'
go 

create table PART_COL_STATS (
	CS_ID                           bigint                           not null,
	AVG_COL_LEN                     float(16)                            null,
	COLUMN_NAME                     varchar(128)                     not null,
	COLUMN_TYPE                     varchar(128)                     not null,
	DB_NAME                         varchar(128)                     not null,
	BIG_DECIMAL_HIGH_VALUE          varchar(255)                         null,
	BIG_DECIMAL_LOW_VALUE           varchar(255)                         null,
	DOUBLE_HIGH_VALUE               float(16)                            null,
	DOUBLE_LOW_VALUE                float(16)                            null,
	LAST_ANALYZED                   bigint                           not null,
	LONG_HIGH_VALUE                 bigint                               null,
	LONG_LOW_VALUE                  bigint                               null,
	MAX_COL_LEN                     bigint                               null,
	NUM_DISTINCTS                   bigint                               null,
	NUM_FALSES                      bigint                               null,
	NUM_NULLS                       bigint                           not null,
	NUM_TRUES                       bigint                               null,
	PART_ID                         bigint                               null,
	PARTITION_NAME                  varchar(767)                     not null,
	TABLE_NAME                      varchar(128)                     not null,
		CONSTRAINT PART_COL_STATS_PK PRIMARY KEY CLUSTERED ( CS_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'PCS_STATS_IDX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PCS_STATS_IDX" >>>>>'
go 

create nonclustered index PCS_STATS_IDX 
on hivedb.dbo.PART_COL_STATS(DB_NAME, TABLE_NAME, COLUMN_NAME, PARTITION_NAME)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'PART_COL_STATS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PART_COL_STATS_N49" >>>>>'
go 

create nonclustered index PART_COL_STATS_N49 
on hivedb.dbo.PART_COL_STATS(PART_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.PART_PRIVS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.PART_PRIVS" >>>>>'
go

setuser 'dbo'
go 

create table PART_PRIVS (
	PART_GRANT_ID                   bigint                           not null,
	CREATE_TIME                     int                              not null,
	GRANT_OPTION                    smallint                         not null CHECK  (GRANT_OPTION IN (0,1))
,
	GRANTOR                         varchar(128)                         null,
	GRANTOR_TYPE                    varchar(128)                         null,
	PART_ID                         bigint                               null,
	PRINCIPAL_NAME                  varchar(128)                         null,
	PRINCIPAL_TYPE                  varchar(128)                         null,
	PART_PRIV                       varchar(128)                         null,
		CONSTRAINT PART_PRIVS_PK PRIMARY KEY CLUSTERED ( PART_GRANT_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'PARTPRIVILEGEINDEX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PARTPRIVILEGEINDEX" >>>>>'
go 

create nonclustered index PARTPRIVILEGEINDEX 
on hivedb.dbo.PART_PRIVS(PART_ID, PRINCIPAL_NAME, PRINCIPAL_TYPE, PART_PRIV, GRANTOR, GRANTOR_TYPE)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'PART_PRIVS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "PART_PRIVS_N49" >>>>>'
go 

create nonclustered index PART_PRIVS_N49 
on hivedb.dbo.PART_PRIVS(PART_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.ROLES'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.ROLES" >>>>>'
go

setuser 'dbo'
go 

create table ROLES (
	ROLE_ID                         bigint                           not null,
	CREATE_TIME                     int                              not null,
	OWNER_NAME                      varchar(128)                         null,
	ROLE_NAME                       varchar(128)                         null,
		CONSTRAINT ROLES_PK PRIMARY KEY CLUSTERED ( ROLE_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'ROLEENTITYINDEX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "ROLEENTITYINDEX" >>>>>'
go 

create unique nonclustered index ROLEENTITYINDEX 
on hivedb.dbo.ROLES(ROLE_NAME)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.ROLE_MAP'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.ROLE_MAP" >>>>>'
go

setuser 'dbo'
go 

create table ROLE_MAP (
	ROLE_GRANT_ID                   bigint                           not null,
	ADD_TIME                        int                              not null,
	GRANT_OPTION                    smallint                         not null CHECK  (GRANT_OPTION IN (0,1))
,
	GRANTOR                         varchar(128)                         null,
	GRANTOR_TYPE                    varchar(128)                         null,
	PRINCIPAL_NAME                  varchar(128)                         null,
	PRINCIPAL_TYPE                  varchar(128)                         null,
	ROLE_ID                         bigint                               null,
		CONSTRAINT ROLE_MAP_PK PRIMARY KEY CLUSTERED ( ROLE_GRANT_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'ROLE_MAP_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "ROLE_MAP_N49" >>>>>'
go 

create nonclustered index ROLE_MAP_N49 
on hivedb.dbo.ROLE_MAP(ROLE_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'USERROLEMAPINDEX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "USERROLEMAPINDEX" >>>>>'
go 

create unique nonclustered index USERROLEMAPINDEX 
on hivedb.dbo.ROLE_MAP(PRINCIPAL_NAME, ROLE_ID, GRANTOR, GRANTOR_TYPE)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.SDS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.SDS" >>>>>'
go

setuser 'dbo'
go 

create table SDS (
	SD_ID                           bigint                           not null,
	CD_ID                           bigint                               null,
	INPUT_FORMAT                    varchar(4000)                        null,
	IS_COMPRESSED                   bit                              not null,
	IS_STOREDASSUBDIRECTORIES       bit                              not null,
	LOCATION                        nvarchar(4000)                       null,
	NUM_BUCKETS                     int                              not null,
	OUTPUT_FORMAT                   varchar(4000)                        null,
	SERDE_ID                        bigint                               null,
		CONSTRAINT SDS_PK PRIMARY KEY CLUSTERED ( SD_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'SDS_N50'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SDS_N50" >>>>>'
go 

create nonclustered index SDS_N50 
on hivedb.dbo.SDS(CD_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'SDS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SDS_N49" >>>>>'
go 

create nonclustered index SDS_N49 
on hivedb.dbo.SDS(SERDE_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.SD_PARAMS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.SD_PARAMS" >>>>>'
go

setuser 'dbo'
go 

create table SD_PARAMS (
	SD_ID                           bigint                           not null,
	PARAM_KEY                       varchar(256)                     not null,
	PARAM_VALUE                     varchar(4000)                        null,
		CONSTRAINT SD_PARAMS_PK PRIMARY KEY CLUSTERED ( SD_ID, PARAM_KEY )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'SD_PARAMS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SD_PARAMS_N49" >>>>>'
go 

create nonclustered index SD_PARAMS_N49 
on hivedb.dbo.SD_PARAMS(SD_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.SERDES'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.SERDES" >>>>>'
go

setuser 'dbo'
go 

create table SERDES (
	SERDE_ID                        bigint                           not null,
	NAME                            varchar(128)                         null,
	SLIB                            varchar(4000)                        null,
		CONSTRAINT SERDES_PK PRIMARY KEY CLUSTERED ( SERDE_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.SERDE_PARAMS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.SERDE_PARAMS" >>>>>'
go

setuser 'dbo'
go 

create table SERDE_PARAMS (
	SERDE_ID                        bigint                           not null,
	PARAM_KEY                       varchar(256)                     not null,
	PARAM_VALUE                     varchar(4000)                        null,
		CONSTRAINT SERDE_PARAMS_PK PRIMARY KEY CLUSTERED ( SERDE_ID, PARAM_KEY )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'SERDE_PARAMS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SERDE_PARAMS_N49" >>>>>'
go 

create nonclustered index SERDE_PARAMS_N49 
on hivedb.dbo.SERDE_PARAMS(SERDE_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.SKEWED_COL_NAMES'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.SKEWED_COL_NAMES" >>>>>'
go

setuser 'dbo'
go 

create table SKEWED_COL_NAMES (
	SD_ID                           bigint                           not null,
	SKEWED_COL_NAME                 varchar(255)                         null,
	INTEGER_IDX                     int                              not null,
		CONSTRAINT SKEWED_COL_NAMES_PK PRIMARY KEY CLUSTERED ( SD_ID, INTEGER_IDX )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'SKEWED_COL_NAMES_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SKEWED_COL_NAMES_N49" >>>>>'
go 

create nonclustered index SKEWED_COL_NAMES_N49 
on hivedb.dbo.SKEWED_COL_NAMES(SD_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.SKEWED_COL_VALUE_LOC_MAP'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.SKEWED_COL_VALUE_LOC_MAP" >>>>>'
go

setuser 'dbo'
go 

create table SKEWED_COL_VALUE_LOC_MAP (
	SD_ID                           bigint                           not null,
	STRING_LIST_ID_KID              bigint                           not null,
	LOCATION                        varchar(4000)                        null,
		CONSTRAINT SKEWED_COL_VALUE_LOC_MAP_PK PRIMARY KEY CLUSTERED ( SD_ID, STRING_LIST_ID_KID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'SKEWED_COL_VALUE_LOC_MAP_N50'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SKEWED_COL_VALUE_LOC_MAP_N50" >>>>>'
go 

create nonclustered index SKEWED_COL_VALUE_LOC_MAP_N50 
on hivedb.dbo.SKEWED_COL_VALUE_LOC_MAP(STRING_LIST_ID_KID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'SKEWED_COL_VALUE_LOC_MAP_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SKEWED_COL_VALUE_LOC_MAP_N49" >>>>>'
go 

create nonclustered index SKEWED_COL_VALUE_LOC_MAP_N49 
on hivedb.dbo.SKEWED_COL_VALUE_LOC_MAP(SD_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.SKEWED_STRING_LIST'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.SKEWED_STRING_LIST" >>>>>'
go

setuser 'dbo'
go 

create table SKEWED_STRING_LIST (
	STRING_LIST_ID                  bigint                           not null,
		CONSTRAINT SKEWED_STRING_LIST_PK PRIMARY KEY CLUSTERED ( STRING_LIST_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.SKEWED_STRING_LIST_VALUES'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.SKEWED_STRING_LIST_VALUES" >>>>>'
go

setuser 'dbo'
go 

create table SKEWED_STRING_LIST_VALUES (
	STRING_LIST_ID                  bigint                           not null,
	STRING_LIST_VALUE               varchar(255)                         null,
	INTEGER_IDX                     int                              not null,
		CONSTRAINT SKEWED_STRING_LIST_VALUES_PK PRIMARY KEY CLUSTERED ( STRING_LIST_ID, INTEGER_IDX )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'SKEWED_STRING_LIST_VALUES_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SKEWED_STRING_LIST_VALUES_N49" >>>>>'
go 

create nonclustered index SKEWED_STRING_LIST_VALUES_N49 
on hivedb.dbo.SKEWED_STRING_LIST_VALUES(STRING_LIST_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.SKEWED_VALUES'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.SKEWED_VALUES" >>>>>'
go

setuser 'dbo'
go 

create table SKEWED_VALUES (
	SD_ID_OID                       bigint                           not null,
	STRING_LIST_ID_EID              bigint                               null,
	INTEGER_IDX                     int                              not null,
		CONSTRAINT SKEWED_VALUES_PK PRIMARY KEY CLUSTERED ( SD_ID_OID, INTEGER_IDX )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'SKEWED_VALUES_N50'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SKEWED_VALUES_N50" >>>>>'
go 

create nonclustered index SKEWED_VALUES_N50 
on hivedb.dbo.SKEWED_VALUES(SD_ID_OID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'SKEWED_VALUES_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SKEWED_VALUES_N49" >>>>>'
go 

create nonclustered index SKEWED_VALUES_N49 
on hivedb.dbo.SKEWED_VALUES(STRING_LIST_ID_EID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.SORT_COLS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.SORT_COLS" >>>>>'
go

setuser 'dbo'
go 

set quoted_identifier on
go 

create table SORT_COLS (
	SD_ID                           bigint                           not null,
	COLUMN_NAME                     varchar(128)                         null,
	"ORDER"                         int                              not null,
	INTEGER_IDX                     int                              not null,
		CONSTRAINT SORT_COLS_PK PRIMARY KEY CLUSTERED ( SD_ID, INTEGER_IDX )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 
set quoted_identifier off
go 


-----------------------------------------------------------------------------
-- DDL for Index 'SORT_COLS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "SORT_COLS_N49" >>>>>'
go 

create nonclustered index SORT_COLS_N49 
on hivedb.dbo.SORT_COLS(SD_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.TABLE_PARAMS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.TABLE_PARAMS" >>>>>'
go

setuser 'dbo'
go 

create table TABLE_PARAMS (
	TBL_ID                          bigint                           not null,
	PARAM_KEY                       varchar(256)                     not null,
	PARAM_VALUE                     varchar(4000)                        null,
		CONSTRAINT TABLE_PARAMS_PK PRIMARY KEY CLUSTERED ( TBL_ID, PARAM_KEY )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'TABLE_PARAMS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "TABLE_PARAMS_N49" >>>>>'
go 

create nonclustered index TABLE_PARAMS_N49 
on hivedb.dbo.TABLE_PARAMS(TBL_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.TAB_COL_STATS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.TAB_COL_STATS" >>>>>'
go

setuser 'dbo'
go 

create table TAB_COL_STATS (
	CS_ID                           bigint                           not null,
	AVG_COL_LEN                     float(16)                            null,
	COLUMN_NAME                     varchar(128)                     not null,
	COLUMN_TYPE                     varchar(128)                     not null,
	DB_NAME                         varchar(128)                     not null,
	BIG_DECIMAL_HIGH_VALUE          varchar(255)                         null,
	BIG_DECIMAL_LOW_VALUE           varchar(255)                         null,
	DOUBLE_HIGH_VALUE               float(16)                            null,
	DOUBLE_LOW_VALUE                float(16)                            null,
	LAST_ANALYZED                   bigint                           not null,
	LONG_HIGH_VALUE                 bigint                               null,
	LONG_LOW_VALUE                  bigint                               null,
	MAX_COL_LEN                     bigint                               null,
	NUM_DISTINCTS                   bigint                               null,
	NUM_FALSES                      bigint                               null,
	NUM_NULLS                       bigint                           not null,
	NUM_TRUES                       bigint                               null,
	TBL_ID                          bigint                               null,
	TABLE_NAME                      varchar(128)                     not null,
		CONSTRAINT TAB_COL_STATS_PK PRIMARY KEY CLUSTERED ( CS_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'TAB_COL_STATS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "TAB_COL_STATS_N49" >>>>>'
go 

create nonclustered index TAB_COL_STATS_N49 
on hivedb.dbo.TAB_COL_STATS(TBL_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.TBLS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.TBLS" >>>>>'
go

setuser 'dbo'
go 

create table TBLS (
	TBL_ID                          bigint                           not null,
	CREATE_TIME                     int                              not null,
	DB_ID                           bigint                               null,
	LAST_ACCESS_TIME                int                              not null,
	OWNER                           varchar(767)                         null,
	RETENTION                       int                              not null,
	SD_ID                           bigint                               null,
	TBL_NAME                        varchar(128)                         null,
	TBL_TYPE                        varchar(128)                         null,
	VIEW_EXPANDED_TEXT              text                                 null,
	VIEW_ORIGINAL_TEXT              text                                 null,
		CONSTRAINT TBLS_PK PRIMARY KEY CLUSTERED ( TBL_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 

sp_placeobject 'default', 'dbo.TBLS.tTBLS'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'TBLS_N50'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "TBLS_N50" >>>>>'
go 

create nonclustered index TBLS_N50 
on hivedb.dbo.TBLS(SD_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'UNIQUETABLE'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "UNIQUETABLE" >>>>>'
go 

create unique nonclustered index UNIQUETABLE 
on hivedb.dbo.TBLS(TBL_NAME, DB_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'TBLS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "TBLS_N49" >>>>>'
go 

create nonclustered index TBLS_N49 
on hivedb.dbo.TBLS(DB_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.TBL_COL_PRIVS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.TBL_COL_PRIVS" >>>>>'
go

setuser 'dbo'
go 

create table TBL_COL_PRIVS (
	TBL_COLUMN_GRANT_ID             bigint                           not null,
	COLUMN_NAME                     varchar(128)                         null,
	CREATE_TIME                     int                              not null,
	GRANT_OPTION                    smallint                         not null CHECK  (GRANT_OPTION IN (0,1))
,
	GRANTOR                         varchar(128)                         null,
	GRANTOR_TYPE                    varchar(128)                         null,
	PRINCIPAL_NAME                  varchar(128)                         null,
	PRINCIPAL_TYPE                  varchar(128)                         null,
	TBL_COL_PRIV                    varchar(128)                         null,
	TBL_ID                          bigint                               null,
		CONSTRAINT TBL_COL_PRIVS_PK PRIMARY KEY CLUSTERED ( TBL_COLUMN_GRANT_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'TABLECOLUMNPRIVILEGEINDEX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "TABLECOLUMNPRIVILEGEINDEX" >>>>>'
go 

create nonclustered index TABLECOLUMNPRIVILEGEINDEX 
on hivedb.dbo.TBL_COL_PRIVS(TBL_ID, COLUMN_NAME, PRINCIPAL_NAME, PRINCIPAL_TYPE, TBL_COL_PRIV, GRANTOR, GRANTOR_TYPE)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'TBL_COL_PRIVS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "TBL_COL_PRIVS_N49" >>>>>'
go 

create nonclustered index TBL_COL_PRIVS_N49 
on hivedb.dbo.TBL_COL_PRIVS(TBL_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.TBL_PRIVS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.TBL_PRIVS" >>>>>'
go

setuser 'dbo'
go 

create table TBL_PRIVS (
	TBL_GRANT_ID                    bigint                           not null,
	CREATE_TIME                     int                              not null,
	GRANT_OPTION                    smallint                         not null CHECK  (GRANT_OPTION IN (0,1))
,
	GRANTOR                         varchar(128)                         null,
	GRANTOR_TYPE                    varchar(128)                         null,
	PRINCIPAL_NAME                  varchar(128)                         null,
	PRINCIPAL_TYPE                  varchar(128)                         null,
	TBL_PRIV                        varchar(128)                         null,
	TBL_ID                          bigint                               null,
		CONSTRAINT TBL_PRIVS_PK PRIMARY KEY CLUSTERED ( TBL_GRANT_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'TBL_PRIVS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "TBL_PRIVS_N49" >>>>>'
go 

create nonclustered index TBL_PRIVS_N49 
on hivedb.dbo.TBL_PRIVS(TBL_ID)
go 


-----------------------------------------------------------------------------
-- DDL for Index 'TABLEPRIVILEGEINDEX'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "TABLEPRIVILEGEINDEX" >>>>>'
go 

create nonclustered index TABLEPRIVILEGEINDEX 
on hivedb.dbo.TBL_PRIVS(TBL_ID, PRINCIPAL_NAME, PRINCIPAL_TYPE, TBL_PRIV, GRANTOR, GRANTOR_TYPE)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.TXNS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.TXNS" >>>>>'
go

setuser 'dbo'
go 

create table TXNS (
	TXN_ID                          bigint                           not null,
	TXN_STATE                       char(1)                          not null,
	TXN_STARTED                     bigint                           not null,
	TXN_LAST_HEARTBEAT              bigint                           not null,
	TXN_USER                        varchar(128)                     not null,
	TXN_HOST                        varchar(128)                     not null,
 PRIMARY KEY CLUSTERED ( TXN_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.TXN_COMPONENTS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.TXN_COMPONENTS" >>>>>'
go

setuser 'dbo'
go 

create table TXN_COMPONENTS (
	TC_TXNID                        bigint                               null,
	TC_DATABASE                     varchar(128)                     not null,
	TC_TABLE                        varchar(128)                         null,
	TC_PARTITION                    varchar(767)                         null 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.TYPES'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.TYPES" >>>>>'
go

setuser 'dbo'
go 

create table TYPES (
	TYPES_ID                        bigint                           not null,
	TYPE_NAME                       varchar(128)                         null,
	TYPE1                           varchar(767)                         null,
	TYPE2                           varchar(767)                         null,
		CONSTRAINT TYPES_PK PRIMARY KEY CLUSTERED ( TYPES_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'UNIQUETYPE'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "UNIQUETYPE" >>>>>'
go 

create unique nonclustered index UNIQUETYPE 
on hivedb.dbo.TYPES(TYPE_NAME)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.TYPE_FIELDS'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.TYPE_FIELDS" >>>>>'
go

setuser 'dbo'
go 

create table TYPE_FIELDS (
	TYPE_NAME                       bigint                           not null,
	COMMENT                         varchar(256)                         null,
	FIELD_NAME                      varchar(128)                     not null,
	FIELD_TYPE                      varchar(767)                     not null,
	INTEGER_IDX                     int                              not null,
		CONSTRAINT TYPE_FIELDS_PK PRIMARY KEY CLUSTERED ( TYPE_NAME, FIELD_NAME )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- DDL for Index 'TYPE_FIELDS_N49'
-----------------------------------------------------------------------------

print '<<<<< CREATING Index - "TYPE_FIELDS_N49" >>>>>'
go 

create nonclustered index TYPE_FIELDS_N49 
on hivedb.dbo.TYPE_FIELDS(TYPE_NAME)
go 


-----------------------------------------------------------------------------
-- DDL for Table 'hivedb.dbo.VERSION'
-----------------------------------------------------------------------------
print '<<<<< CREATING Table - "hivedb.dbo.VERSION" >>>>>'
go

setuser 'dbo'
go 

create table VERSION (
	VER_ID                          bigint                           not null,
	SCHEMA_VERSION                  varchar(127)                     not null,
	VERSION_COMMENT                 varchar(255)                     not null,
		CONSTRAINT VERSION_PK PRIMARY KEY CLUSTERED ( VER_ID )  on 'default' 
)
lock allpages
with dml_logging = full
 on 'default'
go 


setuser
go 

-----------------------------------------------------------------------------
-- Dependent DDL for Object(s)
-----------------------------------------------------------------------------
use hivedb
go 

sp_addthreshold hivedb, 'logsegment', 120, sp_thresholdaction
go 

Grant Select on dbo.sysobjects(name,id,uid,type,userstat,sysstat,indexdel,schemacnt,sysstat2,crdate,expdate,deltrig,instrig,updtrig,seltrig,ckfirst,cache,objspare,versionts,loginame,identburnmax,spacestate,erlchgts,sysstat3,lobcomp_lvl) to public Granted by dbo
go
Grant Select on dbo.sysindexes to public Granted by dbo
go
Grant Select on dbo.syscolumns to public Granted by dbo
go
Grant Select on dbo.systypes to public Granted by dbo
go
Grant Select on dbo.sysprocedures to public Granted by dbo
go
Grant Select on dbo.syscomments to public Granted by dbo
go
Grant Select on dbo.syssegments to public Granted by dbo
go
Grant Select on dbo.syslogs to public Granted by dbo
go
Grant Select on dbo.sysprotects to public Granted by dbo
go
Grant Select on dbo.sysusers to public Granted by dbo
go
Grant Select on dbo.sysalternates to public Granted by dbo
go
Grant Select on dbo.sysdepends to public Granted by dbo
go
Grant Select on dbo.syskeys to public Granted by dbo
go
Grant Select on dbo.sysusermessages to public Granted by dbo
go
Grant Select on dbo.sysreferences to public Granted by dbo
go
Grant Select on dbo.sysconstraints to public Granted by dbo
go
Grant Select on dbo.systhresholds to public Granted by dbo
go
Grant Select on dbo.sysroles to public Granted by dbo
go
Grant Select on dbo.sysattributes to public Granted by dbo
go
Grant Select on dbo.sysslices to public Granted by dbo
go
Grant Select on dbo.systabstats to public Granted by dbo
go
Grant Select on dbo.sysstatistics to public Granted by dbo
go
Grant Select on dbo.sysxtypes to public Granted by dbo
go
Grant Select on dbo.sysjars to public Granted by dbo
go
Grant Select on dbo.sysqueryplans to public Granted by dbo
go
Grant Select on dbo.syspartitions to public Granted by dbo
go
Grant Select on dbo.syspartitionkeys to public Granted by dbo
go
exec sp_addalias 'hiveuser', 'dbo'
go 

alter table hivedb.dbo.BUCKETING_COLS
add constraint BUCKETING_COLS_FK1 FOREIGN KEY (SD_ID) REFERENCES hivedb.dbo.SDS(SD_ID)
go

alter table hivedb.dbo.COLUMNS_V2
add constraint COLUMNS_V2_FK1 FOREIGN KEY (CD_ID) REFERENCES hivedb.dbo.CDS(CD_ID)
go

alter table hivedb.dbo.DATABASE_PARAMS
add constraint DATABASE_PARAMS_FK1 FOREIGN KEY (DB_ID) REFERENCES hivedb.dbo.DBS(DB_ID)
go

alter table hivedb.dbo.DB_PRIVS
add constraint DB_PRIVS_FK1 FOREIGN KEY (DB_ID) REFERENCES hivedb.dbo.DBS(DB_ID)
go

alter table hivedb.dbo.FUNCS
add constraint FUNCS_FK1 FOREIGN KEY (DB_ID) REFERENCES hivedb.dbo.DBS(DB_ID)
go

alter table hivedb.dbo.FUNC_RU
add constraint FUNC_RU_FK1 FOREIGN KEY (FUNC_ID) REFERENCES hivedb.dbo.FUNCS(FUNC_ID)
go

alter table hivedb.dbo.IDXS
add constraint IDXS_FK1 FOREIGN KEY (INDEX_TBL_ID) REFERENCES hivedb.dbo.TBLS(TBL_ID)
go

alter table hivedb.dbo.IDXS
add constraint IDXS_FK2 FOREIGN KEY (SD_ID) REFERENCES hivedb.dbo.SDS(SD_ID)
go

alter table hivedb.dbo.IDXS
add constraint IDXS_FK3 FOREIGN KEY (ORIG_TBL_ID) REFERENCES hivedb.dbo.TBLS(TBL_ID)
go

alter table hivedb.dbo.INDEX_PARAMS
add constraint INDEX_PARAMS_FK1 FOREIGN KEY (INDEX_ID) REFERENCES hivedb.dbo.IDXS(INDEX_ID)
go

alter table hivedb.dbo.PARTITIONS
add constraint PARTITIONS_FK1 FOREIGN KEY (TBL_ID) REFERENCES hivedb.dbo.TBLS(TBL_ID)
go

alter table hivedb.dbo.PARTITIONS
add constraint PARTITIONS_FK2 FOREIGN KEY (SD_ID) REFERENCES hivedb.dbo.SDS(SD_ID)
go

alter table hivedb.dbo.PARTITION_KEYS
add constraint PARTITION_KEYS_FK1 FOREIGN KEY (TBL_ID) REFERENCES hivedb.dbo.TBLS(TBL_ID)
go

alter table hivedb.dbo.PARTITION_KEY_VALS
add constraint PARTITION_KEY_VALS_FK1 FOREIGN KEY (PART_ID) REFERENCES hivedb.dbo.PARTITIONS(PART_ID)
go

alter table hivedb.dbo.PARTITION_PARAMS
add constraint PARTITION_PARAMS_FK1 FOREIGN KEY (PART_ID) REFERENCES hivedb.dbo.PARTITIONS(PART_ID)
go

alter table hivedb.dbo.PART_COL_PRIVS
add constraint PART_COL_PRIVS_FK1 FOREIGN KEY (PART_ID) REFERENCES hivedb.dbo.PARTITIONS(PART_ID)
go

alter table hivedb.dbo.PART_COL_STATS
add constraint PART_COL_STATS_FK1 FOREIGN KEY (PART_ID) REFERENCES hivedb.dbo.PARTITIONS(PART_ID)
go

alter table hivedb.dbo.PART_PRIVS
add constraint PART_PRIVS_FK1 FOREIGN KEY (PART_ID) REFERENCES hivedb.dbo.PARTITIONS(PART_ID)
go

alter table hivedb.dbo.ROLE_MAP
add constraint ROLE_MAP_FK1 FOREIGN KEY (ROLE_ID) REFERENCES hivedb.dbo.ROLES(ROLE_ID)
go

alter table hivedb.dbo.SDS
add constraint SDS_FK1 FOREIGN KEY (SERDE_ID) REFERENCES hivedb.dbo.SERDES(SERDE_ID)
go

alter table hivedb.dbo.SDS
add constraint SDS_FK2 FOREIGN KEY (CD_ID) REFERENCES hivedb.dbo.CDS(CD_ID)
go

alter table hivedb.dbo.SD_PARAMS
add constraint SD_PARAMS_FK1 FOREIGN KEY (SD_ID) REFERENCES hivedb.dbo.SDS(SD_ID)
go

alter table hivedb.dbo.SERDE_PARAMS
add constraint SERDE_PARAMS_FK1 FOREIGN KEY (SERDE_ID) REFERENCES hivedb.dbo.SERDES(SERDE_ID)
go

alter table hivedb.dbo.SKEWED_COL_NAMES
add constraint SKEWED_COL_NAMES_FK1 FOREIGN KEY (SD_ID) REFERENCES hivedb.dbo.SDS(SD_ID)
go

alter table hivedb.dbo.SKEWED_COL_VALUE_LOC_MAP
add constraint SKEWED_COL_VALUE_LOC_MAP_FK1 FOREIGN KEY (SD_ID) REFERENCES hivedb.dbo.SDS(SD_ID)
go

alter table hivedb.dbo.SKEWED_COL_VALUE_LOC_MAP
add constraint SKEWED_COL_VALUE_LOC_MAP_FK2 FOREIGN KEY (STRING_LIST_ID_KID) REFERENCES hivedb.dbo.SKEWED_STRING_LIST(STRING_LIST_ID)
go

alter table hivedb.dbo.SKEWED_STRING_LIST_VALUES
add constraint SKEWED_STRING_LIST_VALUES_FK1 FOREIGN KEY (STRING_LIST_ID) REFERENCES hivedb.dbo.SKEWED_STRING_LIST(STRING_LIST_ID)
go

alter table hivedb.dbo.SKEWED_VALUES
add constraint SKEWED_VALUES_FK1 FOREIGN KEY (SD_ID_OID) REFERENCES hivedb.dbo.SDS(SD_ID)
go

alter table hivedb.dbo.SKEWED_VALUES
add constraint SKEWED_VALUES_FK2 FOREIGN KEY (STRING_LIST_ID_EID) REFERENCES hivedb.dbo.SKEWED_STRING_LIST(STRING_LIST_ID)
go

alter table hivedb.dbo.SORT_COLS
add constraint SORT_COLS_FK1 FOREIGN KEY (SD_ID) REFERENCES hivedb.dbo.SDS(SD_ID)
go

alter table hivedb.dbo.TABLE_PARAMS
add constraint TABLE_PARAMS_FK1 FOREIGN KEY (TBL_ID) REFERENCES hivedb.dbo.TBLS(TBL_ID)
go

alter table hivedb.dbo.TAB_COL_STATS
add constraint TAB_COL_STATS_FK1 FOREIGN KEY (TBL_ID) REFERENCES hivedb.dbo.TBLS(TBL_ID)
go

alter table hivedb.dbo.TBLS
add constraint TBLS_FK2 FOREIGN KEY (SD_ID) REFERENCES hivedb.dbo.SDS(SD_ID)
go

alter table hivedb.dbo.TBLS
add constraint TBLS_FK1 FOREIGN KEY (DB_ID) REFERENCES hivedb.dbo.DBS(DB_ID)
go

alter table hivedb.dbo.TBL_COL_PRIVS
add constraint TBL_COL_PRIVS_FK1 FOREIGN KEY (TBL_ID) REFERENCES hivedb.dbo.TBLS(TBL_ID)
go

alter table hivedb.dbo.TBL_PRIVS
add constraint TBL_PRIVS_FK1 FOREIGN KEY (TBL_ID) REFERENCES hivedb.dbo.TBLS(TBL_ID)
go

alter table hivedb.dbo.TXN_COMPONENTS
add constraint TXN_COMPON_153048550 FOREIGN KEY (TC_TXNID) REFERENCES hivedb.dbo.TXNS(TXN_ID)
go

alter table hivedb.dbo.TYPE_FIELDS
add constraint TYPE_FIELDS_FK1 FOREIGN KEY (TYPE_NAME) REFERENCES hivedb.dbo.TYPES(TYPES_ID)
go

