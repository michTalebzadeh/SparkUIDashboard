CREATE OR REPLACE PROCEDURE populate_dummy_sp
(
	p_rows	IN		NUMBER
)
AS
  v_id				dummy.id%TYPE;
  v_next_rowid			next_rowid.nxr_next_rowid%TYPE;
  v_rowcount			NUMBER := 0;
  e_rows			EXCEPTION;	
  e_GET_NEXT_ROWID_dummy   	EXCEPTION;
  e_insert_dummy		EXCEPTION;
BEGIN
  BEGIN			-- Input parameter validation
    -- Check for inputs
    IF p_rows <= 0
    THEN
      RAISE e_rows;
    END IF;
  EXCEPTION
    WHEN e_rows THEN
      DBMS_OUTPUT.PUT_LINE('Cannot have null value for number of records to generate!');
  END; 
  BEGIN
    dbms_random.seed(0);
    SELECT NVL(MAX(id),0)+1 INTO v_id from dummy;
    for v_records IN 1..p_rows
    LOOP
      v_next_rowid := GET_NEXT_ROWID(p_table_name => 'DUMMY', p_nr => 1);
      IF v_next_rowid < 0
      THEN
        RAISE e_GET_NEXT_ROWID_dummy;
      END IF;
      INSERT INTO dummy
      (
        id,
        clustered,
	scattered,
	randomised,
	random_string,
	small_vc,
	padding
      )
      VALUES
      (
	v_next_rowid,
	trunc(v_next_rowid -1)/p_rows,
	mod(v_next_rowid - 1,p_rows),
        trunc(dbms_random.value(0,p_rows)),
	dbms_random.string('A',15),
        lpad(v_next_rowid,10),
        rpad('x',10,'x')
       );
      IF SQL%ROWCOUNT = 0 OR SQLCODE <> 0
      THEN
        RAISE e_insert_dummy;
      END IF;
      v_rowcount := v_rowcount + 1;
      IF MOD(v_rowcount, 10000) = 0 THEN
        --dbms_output.put_line('v_rowcount = '|| v_rowcount ||' ,committing!');
        COMMIT;
      END IF;
    END LOOP;
    COMMIT;
  EXCEPTION
    WHEN e_GET_NEXT_ROWID_dummy THEN
      DBMS_OUTPUT.PUT_LINE('Could not get next_rowid value for table dummy');
    WHEN e_insert_dummy THEN
      DBMS_OUTPUT.PUT_LINE('Could not insert into dummy');
    WHEN OTHERS THEN
      DBMS_OUTPUT.PUT_LINE(to_char(SQLCODE) || ' - ' || substr(SQLERRM,1,200));
  END;
END populate_dummy_sp;
/
show errors
exit
