@$HOME/dba/bin/login.sql
set echo off
set linesize 180
set pagesize 500
set heading on
col fname heading "Filename" format a90
col fnum heading "#" format 99
col ts heading "Tablespace|Name" format a15
col tb heading "Total|File Size" format 999,999,999,999
col used heading "Bytes Used" like tb
col free heading "Bytes Free" like tb
col autoext heading "Auto|Extend" format a6
break on ts skip 1 on report
compute sum of tb used free on ts report
select    substr(tablespace_name,1,15) ts
    ,d.file_id fnum
    ,d.bytes tb
    ,decode(d.bytes,0,0,d.bytes-nvl(freebytes,0)) used
    ,decode(d.bytes,0,0,nvl(freebytes,0)) free
    ,decode(e.file#,null,'No','Yes') autoext
    ,''''||substr(file_name,1,90)||'''' fname
from     sys.dba_data_files d
    ,(select file_id,sum(bytes) freebytes
        from sys.dba_free_space
        group by file_id) f
    ,sys.filext$ e
    ,v$datafile v
where    d.file_id=f.file_id(+)
  and    d.file_id=e.file#(+)
  and    v.file#=d.file_id
order by tablespace_name,creation_time
/
exit
