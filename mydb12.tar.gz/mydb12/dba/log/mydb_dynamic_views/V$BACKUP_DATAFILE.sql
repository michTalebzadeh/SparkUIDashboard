 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 RECID										   NUMBER
 STAMP										   NUMBER
 SET_STAMP									   NUMBER
 SET_COUNT									   NUMBER
 FILE#										   NUMBER
 CREATION_CHANGE#								   NUMBER
 CREATION_TIME									   DATE
 RESETLOGS_CHANGE#								   NUMBER
 RESETLOGS_TIME 								   DATE
 INCREMENTAL_LEVEL								   NUMBER
 INCREMENTAL_CHANGE#								   NUMBER
 CHECKPOINT_CHANGE#								   NUMBER
 CHECKPOINT_TIME								   DATE
 ABSOLUTE_FUZZY_CHANGE# 							   NUMBER
 MARKED_CORRUPT 								   NUMBER
 MEDIA_CORRUPT									   NUMBER
 LOGICALLY_CORRUPT								   NUMBER
 DATAFILE_BLOCKS								   NUMBER
 BLOCKS 									   NUMBER
 BLOCK_SIZE									   NUMBER
 OLDEST_OFFLINE_RANGE								   NUMBER
 COMPLETION_TIME								   DATE
 CONTROLFILE_TYPE								   VARCHAR2(1)
 USED_CHANGE_TRACKING								   VARCHAR2(3)
 BLOCKS_READ									   NUMBER
 USED_OPTIMIZATION								   VARCHAR2(3)
 FOREIGN_DBID									   NUMBER
 PLUGGED_READONLY								   VARCHAR2(3)
 PLUGIN_CHANGE# 								   NUMBER
 PLUGIN_RESETLOGS_CHANGE#							   NUMBER
 PLUGIN_RESETLOGS_TIME								   DATE
 SECTION_SIZE									   NUMBER
 UNDO_OPTIMIZED 								   VARCHAR2(3)
 BLOCKS_SKIPPED_IN_CELL 							   NUMBER

