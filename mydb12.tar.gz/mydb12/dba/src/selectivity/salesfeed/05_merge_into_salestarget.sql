alter system flush buffer_cache;
alter system flush shared_pool;
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'merge_ssdtester';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true, plan_stat=>'ALL_EXECUTIONS' );
MERGE INTO salestarget st
    USING (
           SELECT
                    sales.cust_id CUST_ID,
                    COUNT(sales.amount_sold+t.amount_sold) TotalAmountSold,
                    SUM(sales.amount_sold+t.amount_sold) TotalSales,
                    AVG(sales.amount_sold+t.amount_sold) AvgAmountSold,
                    STDDEV(sales.amount_sold+t.amount_sold) STDDEV
           FROM
                   TABLE(sales_array) t,
                   sales
          WHERE
                   t.PROD_ID = sales.PROD_ID
          AND
                   t.CUST_ID = sales.CUST_ID
          AND
                   t.TIME_ID > sales.TIME_ID
          GROUP BY
                   sales.CUST_ID
          HAVING
                   SUM(sales.amount_sold+t.amount_sold) > 100000
	  AND
		   COUNT(sales.amount_sold+t.amount_sold) > 1000
          AND
                   AVG(sales.amount_sold+t.amount_sold) < STDDEV(sales.amount_sold+t.amount_sold)
   ) rs
ON (st.CUST_ID = rs.CUST_ID)
WHEN NOT MATCHED THEN
  INSERT VALUES (rs.CUST_ID, rs.TotalAmountSold, rs.TotalSales, rs.AvgAmountSold,rs.STDDEV)
WHEN MATCHED THEN
  UPDATE SET st.TotalAmountSold = rs.TotalAmountSold, st.TotalSales = rs.TotalSales, st.AvgAmountSold = rs.AvgAmountSold, st.STDDEV = rs.STDDEV;
commit;
exit
