use master
go
dump database its_ged_prod to 'compress::4::/dbdumps/lon_gen_sql_tst5/dumps/lon_gen_sql_tst5.its_ged_prod.20060920_1517.01.cdmp' 
go
exit
