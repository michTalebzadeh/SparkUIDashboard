set echo off
-- whoson.sql
-- Purpose: Display stats on all users logged on to database.
-- -----------------------------------------------------------------------------   
set pagesize 9999
set linesize 200
col username        format a12
col sid             format 999
col serial#         format 99999
col process         format a13
col status          format a10
col machine         format a25
col login_time      format a20
col server_proc_pid format a15
col cmd             format 999
col last_call_min   format 999999.99
col log_time        format a14
col blksRead        format 999,999,999,999  
prompt
Prompt +---------------------------------------------------------+
Prompt | Stats on all users FROM v$session, v$process, v$sess_io |
Prompt +---------------------------------------------------------+

SELECT a.username, a.sid, a.serial#, a.process, a.status, a.machine, to_char(a.logon_time, 'mm/dd HH24:mi:SS') login_time,
       b.spid server_proc_pid, a.command cmd,a.last_call_et/60 "last_call_min",c.block_gets+c.consistent_gets blksRead
FROM  v$session a, v$process b, v$sess_io c 
WHERE a.paddr = b.addr
AND a.sid = c.sid
AND a.username IS NOT NULL
and a.sid NOT in (select sid from v$mystat where rownum = 1)
ORDER BY username
/ 
exit
