use imdb1_template
go
set quoted_identifier on
go
if exists(select 1 from sysobjects where type = 'U' and name = 'MYDB_V$ACCESS')
  drop table MYDB_V$ACCESS
go
create existing table MYDB_V$ACCESS
(
  SID		BIGINT  NULL,
  OWNER		VARCHAR(64)  NULL,
  OBJECT	VARCHAR(1000)  NULL,
  TYPE		VARCHAR(64)  NULL
)
at 'DCORACLE..sys.v_$access'
go
sp_help MYDB_V$ACCESS
go
