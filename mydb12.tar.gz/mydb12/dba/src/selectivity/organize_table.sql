/*
1) User asks for data
2) Data not in Oracle buffer cache
3) Request forwarded to disk
4) Here, disk cache checks for data. If not, go to disk
5) Get data, load file system cache
6) Now upload Oracle buffer Cache
7) Honour user's request

if we bypass disk cache

1) User asks for data
2) Data not in Oracle buffer cache
3) Request forwarded to disk
4) Read from disk
5) Now upload Oracle buffer Cache
6) Honour user's request
*/
alter table t enable row movement;
alter table t shrink space;
