 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 PRIMARY_XIDUSN 								   NUMBER
 PRIMARY_XIDSLT 								   NUMBER
 PRIMARY_XIDSQN 								   NUMBER
 PRIMARY_XID									   RAW(8)
 PRIMARY_START_SCN								   NUMBER
 PRIMARY_START_TIME								   DATE
 PRIMARY_PARENT_XIDUSN								   NUMBER
 PRIMARY_PARENT_XIDSLT								   NUMBER
 PRIMARY_PARENT_XIDSQN								   NUMBER
 PRIMARY_PARENT_XID								   RAW(8)
 TYPE										   VARCHAR2(32)
 MINING_STATUS									   VARCHAR2(32)
 APPLY_STATUS									   VARCHAR2(6)
 SID										   NUMBER
 SERIAL#									   NUMBER

