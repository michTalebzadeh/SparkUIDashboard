/********************************************/
/*------------ logfroup -------------*/
/********************************************/
select 'Started adding loggroup 4 at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
ALTER DATABASE ADD LOGFILE GROUP 4 SIZE 1024000K;
select 'Finished adding loggroup 4 at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
