CREATE OR REPLACE DIRECTORY sales_feeds AS '/backup/oracle/feeds';
exit
