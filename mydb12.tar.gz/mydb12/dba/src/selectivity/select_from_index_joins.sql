alter system flush buffer_cache;
alter system flush shared_pool;
--EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE( waits=>true );
--ALTER SESSION SET TRACEFILE_IDENTIFIER = 'query_T1_index';
set timing on
set autotrace on
SELECT c1, c2
FROM index_joins
where   c1 between 100 and 1000
and	c2 between 50 and 100
/
exit
