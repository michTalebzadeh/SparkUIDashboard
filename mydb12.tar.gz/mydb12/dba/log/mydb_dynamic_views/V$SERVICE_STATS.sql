 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SERVICE_NAME_HASH								   NUMBER
 SERVICE_NAME									   VARCHAR2(64)
 STAT_ID									   NUMBER
 STAT_NAME									   VARCHAR2(64)
 VALUE										   NUMBER

