 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 QUEUE_ID									   NUMBER
 QUEUE_SCHEMA									   VARCHAR2(30)
 QUEUE_NAME									   VARCHAR2(30)
 SUBSCRIBER_ID									   NUMBER
 SUBSCRIBER_NAME								   VARCHAR2(30)
 SUBSCRIBER_ADDRESS								   VARCHAR2(1024)
 PROTOCOL									   NUMBER
 SUBSCRIBER_TYPE								   VARCHAR2(30)
 FIRST_ACTIVITY_TIME								   TIMESTAMP(6)
 ENQUEUED_MSGS									   NUMBER
 DEQUEUED_MSGS									   NUMBER
 AVG_MSG_AGE									   NUMBER
 BROWSED_MSGS									   NUMBER
 EXPIRED_MSGS									   NUMBER
 DEQUEUED_MSG_LATENCY								   NUMBER
 LAST_ENQUEUE_TIME								   TIMESTAMP(6)
 LAST_DEQUEUE_TIME								   TIMESTAMP(6)
 ELAPSED_DEQUEUE_TIME								   NUMBER
 DEQUEUE_CPU_TIME								   NUMBER
 DEQUEUE_TRANSACTIONS								   NUMBER
 EXECUTION_COUNT								   NUMBER

