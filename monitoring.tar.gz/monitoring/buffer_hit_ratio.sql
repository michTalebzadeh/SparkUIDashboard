select 1 - ((p.value - l.value - d.value) / s.value) as " Buffer Cache Hit Ratio"
from v$sysstat s, v$sysstat l, v$sysstat d, v$sysstat p
where s.name='session logical reads'
and d.name='physical reads direct'
and l.name='physical reads direct (lob)'
and p.name='physical reads'
/
exit

