show parameter memory
SELECT
          component
        , current_size/1024/1024 AS "CURRENT size/MB"
        , min_size/1024/1024 AS "MIN size/MB"
        , max_size/1024/1024 AS "MAX size/MB"
FROM    v$memory_dynamic_components
WHERE   current_size/1024/1024 > 100 -- MB
order by current_size desc;
SELECT * FROM v$memory_target_advice ORDER BY memory_size;
exit
