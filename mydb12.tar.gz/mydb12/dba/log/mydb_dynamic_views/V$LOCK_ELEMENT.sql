 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 LOCK_ELEMENT_ADDR								   RAW(4)
 INDX										   NUMBER
 CLASS										   NUMBER
 LOCK_ELEMENT_NAME								   NUMBER
 MODE_HELD									   NUMBER
 BLOCK_COUNT									   NUMBER
 RELEASING									   NUMBER
 ACQUIRING									   NUMBER
 INVALID									   NUMBER
 FLAGS										   NUMBER

