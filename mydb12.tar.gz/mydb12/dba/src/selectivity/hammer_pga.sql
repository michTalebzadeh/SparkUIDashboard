declare 
type array is table of long index by binary_integer; 
l_data array; 
begin 
loop 
  l_data( l_data.count+1) := rpad('*',32000,'*'); 
end loop; 
end; 
/
exit
