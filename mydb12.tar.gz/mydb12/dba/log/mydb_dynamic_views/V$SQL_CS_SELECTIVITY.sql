 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ADDRESS									   RAW(4)
 HASH_VALUE									   NUMBER
 SQL_ID 									   VARCHAR2(13)
 CHILD_NUMBER									   NUMBER
 PREDICATE									   VARCHAR2(40)
 RANGE_ID									   NUMBER
 LOW										   VARCHAR2(10)
 HIGH										   VARCHAR2(10)

