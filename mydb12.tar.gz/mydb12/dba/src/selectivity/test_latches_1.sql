ALTER SESSION SET TRACEFILE_IDENTIFIER = 'latche_test_1';
set echo on
drop table t9;
clear screen
create table t9 ( x int, y int );
insert into t9 values (1,1);
commit;
EXEC DBMS_STATS.GATHER_TABLE_STATS( user, 'T9' );
select * from t9;
pause
clear screen


variable a refcursor
variable b refcursor
variable c refcursor

ALTER SESSION SET EVENTS '10046 TRACE NAME CONTEXT FOREVER, LEVEL 12';
begin
    open :a for select * from t9 a;
    open :b for select * from t9 b;
    open :c for select * from t9 c;
end;
/
pause
clear screen
print a
pause
clear screen

begin
    for i in 1 .. 10000
    loop
        update t9 set x = x+1;
        commit;
    end loop;
end;
/

pause
clear screen
print b
update t9 set x = x+1;
commit;

print c
pause
clear screen
