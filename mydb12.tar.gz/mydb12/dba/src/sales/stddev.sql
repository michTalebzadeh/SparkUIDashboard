   SELECT  SQRT((SUM(POWER(AMOUNT_SOLD,2))-(COUNT(1)*POWER(AVG(AMOUNT_SOLD),2)))/(COUNT(1)-1)) AS stddev
   from    sales;
select stddev(amount_sold) from sales;
exit
/
