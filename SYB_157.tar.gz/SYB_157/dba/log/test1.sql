use skeleton
go
drop table test1
go
create table test1
(
	test1_id		int					not null,
	test1_def1		varchar(30)	DEFAULT 'source'	null,
	test1_def2		varchar(255)	DEFAULT 'some crap here mate'	null,
	test1_dt_stamp		datetime	DEFAULT  getdate()  not null ,
	test1_user_stamp	varchar(30)	DEFAULT suser_name() not null
)
lock datarows
go
create unique clustered index test1_ind on test1 (test1_id)
go
sp_primarykey test1, test1_id
go
sp_help test1
go
drop table next_rowid
go
create table next_rowid (
        nxr_id                          int                             not null  ,
        nxr_name                        varchar(30)                     not null  ,
        nxr_next_rowid                  int                             not null
)
lock allpages
go
create  unique nonclustered index nxr_id_ind
on next_rowid ( nxr_id)
go
sp_primarykey next_rowid, nxr_id
go
sp_help next_rowid
go
exit
