 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SERIAL#									   NUMBER
 LOGSTDBY_ID									   NUMBER
 PID										   VARCHAR2(12)
 TYPE										   VARCHAR2(30)
 STATUS_CODE									   NUMBER
 STATUS 									   VARCHAR2(256)
 HIGH_SCN									   NUMBER

