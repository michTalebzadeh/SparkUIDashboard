truncate table sales;
insert into sales select * from sh.sales;
select count(1) from sales;
EXEC DBMS_STATS.GATHER_TABLE_STATS(OWNNAME=>USER,TABNAME=>'SALES',CASCADE=>TRUE)
exit
