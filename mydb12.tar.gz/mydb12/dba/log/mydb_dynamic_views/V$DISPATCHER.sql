 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 NAME										   VARCHAR2(4)
 NETWORK									   VARCHAR2(1024)
 PADDR										   RAW(4)
 STATUS 									   VARCHAR2(16)
 ACCEPT 									   VARCHAR2(3)
 MESSAGES									   NUMBER
 BYTES										   NUMBER
 BREAKS 									   NUMBER
 OWNED										   NUMBER
 CREATED									   NUMBER
 IDLE										   NUMBER
 BUSY										   NUMBER
 LISTENER									   NUMBER
 CONF_INDX									   NUMBER

