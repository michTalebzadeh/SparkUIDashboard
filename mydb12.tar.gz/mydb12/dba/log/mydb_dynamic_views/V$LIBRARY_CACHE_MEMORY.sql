 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 LC_NAMESPACE									   VARCHAR2(15)
 LC_INUSE_MEMORY_OBJECTS							   NUMBER
 LC_INUSE_MEMORY_SIZE								   NUMBER
 LC_FREEABLE_MEMORY_OBJECTS							   NUMBER
 LC_FREEABLE_MEMORY_SIZE							   NUMBER

