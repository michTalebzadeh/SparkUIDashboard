 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 ADDRESS									   RAW(4)
 HASH_VALUE									   NUMBER
 SQL_ID 									   VARCHAR2(13)
 COMMAND_TYPE									   NUMBER
 PIECE										   NUMBER
 SQL_TEXT									   VARCHAR2(64)

