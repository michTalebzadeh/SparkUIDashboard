CREATE DATABASE fiqrdb
      ON datadev03_HDD = 100
     LOG ON logdev04_HDD = 50
FOR LOAD
go
