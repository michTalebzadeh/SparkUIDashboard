DECLARE
CURSOR c IS
SELECT 1 from next_rowid WHERE nxr_name = 'T1';
l_int integer;
BEGIN
SET TRANSACTION READ WRITE;
OPEN c;
FETCH c INTO l_int;
IF c%found THEN
  DBMS_OUTPUT.PUT_LINE(chr(10) ||'Records for T1 exists, updating the record in NEXT_ROWID table' || chr(10));
  UPDATE next_rowid SET nxr_next_rowid = 50000000 WHERE nxr_name = 'T1';
ELSE
  DBMS_OUTPUT.PUT_LINE(chr(10) ||'Inserting new record for T1 in NEXT_ROWID table' || chr(10));
  INSERT INTO next_rowid values ((SELECT max(nxr_id)+1 FROM next_rowid),'T1',50000000);
END IF;
COMMIT;
CLOSE c;
EXCEPTION
WHEN OTHERS THEN
IF c%isopen THEN
close c;
RAISE;
END IF;
END;
/
DROP TABLE T1;
CREATE TABLE T1
		(
			n1 NUMBER(5)	NOT NULL,
			ind_pad VARCHAR2(40) NOT NULL,
			n2 NUMBER(5)	NOT NULL,
			small_vc VARCHAR2(10) NOT NULL,
			padding  VARCHAR2(200) NOT NULL
                 );
create index t1_i1 on t1(n1, ind_pad, n2)
nologging
pctfree 91
;
exit
