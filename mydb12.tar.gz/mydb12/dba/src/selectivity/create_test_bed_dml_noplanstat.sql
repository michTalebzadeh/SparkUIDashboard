alter system flush buffer_cache;
alter system flush shared_pool;
ALTER SESSION SET TRACEFILE_IDENTIFIER = 'tester_create_test_bed_dml_noplanstat';
EXEC DBMS_MONITOR.SESSION_TRACE_ENABLE ( waits=>true );
DECLARE
        type ObjIdArray is table of tdash.object_id%TYPE index by binary_integer;
        l_ids objIdArray;
        CURSOR c IS SELECT object_id FROM tdash;
BEGIN
        OPEN c;
        LOOP
                BEGIN
                        FETCH c BULK COLLECT INTO l_ids LIMIT 100;

                        FORALL rs in 1 .. l_ids.COUNT
                        	UPDATE testwrites
                        	  SET PADDING1 =  RPAD('y',4000,'y')
                        	WHERE object_id = l_ids(rs);
			commit;
                        FORALL rs in 1 .. l_ids.COUNT
				DELETE FROM testwrites
                        	WHERE object_id = l_ids(rs);
			commit;
                        FORALL rs in 1 .. l_ids.COUNT
				INSERT INTO testwrites
				SELECT * FROM tdash t WHERE t.object_id = l_ids(rs);	
			commit;
			EXIT WHEN C%NOTFOUND;
                EXCEPTION
                  WHEN NO_DATA_FOUND THEN
	            NULL;
		  WHEN OTHERS THEN
		    DBMS_OUTPUT.PUT_LINE('Transaction failed');
                END;
        END LOOP;
	CLOSE c;
END;
/
exit
