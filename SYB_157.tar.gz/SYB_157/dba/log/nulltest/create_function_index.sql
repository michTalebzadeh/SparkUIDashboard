create index func_index on nulltest(ISNULL(OBJECT_ID,-10))
go
update index statistics nulltest
go
