-- believe the root cause of the differences between the total elapsed time and the time for the full table scan step in the plan is due to the setting of STATISTICS_LEVEL. It appears the parameter is set to TYPICAL (the default). When set to TYPICAL, the rowsource/plan execution statistics are disabled. 
select value from v$parameter where upper(name) = 'STATISTICS_LEVEL' ;
--
SELECT
	session_status,
	system_status,
	activation_level,
        session_settable
FROM   v$statistics_level
WHERE  statistics_name = 'Plan Execution Statistics';
alter system set statistics_level = ALL;
exit
