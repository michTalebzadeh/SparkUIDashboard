/*
You need to watch EXTENDS. If you see excessive extends, you should consider rebuilding your rollback segments so they are sizes properly. Another parameter is WRITES, which is how many bytes have been written to that rollback segment overall since instance startup. If Waits is too high you need to add more segments.
*/
@$HOME/abc
select a.name, b.rssize, b.extents, b.writes, b.gets, b.waits, b.hwmsize, b.extents, b.status
  from v$rollname a, v$rollstat b
  where a.usn = b.usn
/
exit
