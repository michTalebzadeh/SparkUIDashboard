 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 FILE_MAP_IDX									   NUMBER
 FILE_CFGID									   VARCHAR2(256)
 FILE_STATUS									   VARCHAR2(7)
 FILE_NAME									   VARCHAR2(256)
 FILE_TYPE									   VARCHAR2(11)
 FILE_STRUCTURE 								   VARCHAR2(9)
 FILE_SIZE									   NUMBER
 FILE_NEXTS									   NUMBER
 LIB_IDX									   NUMBER

