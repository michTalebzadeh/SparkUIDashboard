select ''''||a.sid||','||a.serial#||'''' to_kill,
    a.username,a.machine, a.lockwait,a.osuser,
    a.program,b.owner,b.object_name,c.locked_mode
  from v$locked_object c, all_objects b, v$session a
  where b.object_id = c.object_id and a.sid = c.session_id
/
exit
