 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 INST_ID									   NUMBER
 LOBTSN 									   NUMBER
 LOBRDBA									   NUMBER
 LOBOBJID									   NUMBER
 LOBCURRTIME									   NUMBER
 LOBEXPMQL									   NUMBER
 LOBSQLMQL									   NUMBER
 LOBSPCANALTIME 								   NUMBER
 LOBUNDORETTIME 								   NUMBER

