/********************************************/
/*------------ users -------------*/
/********************************************/
select 'Started altering users tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
ALTER TABLESPACE "USERS" ADD DATAFILE '/ssddata2/oracle/mydb/users2.dbf' SIZE 500M REUSE AUTOEXTEND ON NEXT 50M MAXSIZE 32767M;
select 'Finished  altering users tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
