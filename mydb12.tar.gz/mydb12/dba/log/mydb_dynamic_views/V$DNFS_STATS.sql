 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 PNUM										   NUMBER
 NFS_NULL									   NUMBER
 NFS_GETATTR									   NUMBER
 NFS_SETATTR									   NUMBER
 NFS_LOOKUP									   NUMBER
 NFS_ACCESS									   NUMBER
 NFS_READLINK									   NUMBER
 NFS_READ									   NUMBER
 NFS_WRITE									   NUMBER
 NFS_CREATE									   NUMBER
 NFS_MKDIR									   NUMBER
 NFS_SYMLINK									   NUMBER
 NFS_MKNOD									   NUMBER
 NFS_REMOVE									   NUMBER
 NFS_RMDIR									   NUMBER
 NFS_RENAME									   NUMBER
 NFS_LINK									   NUMBER
 NFS_READDIR									   NUMBER
 NFS_READDIRPLUS								   NUMBER
 NFS_FSSTAT									   NUMBER
 NFS_FSINFO									   NUMBER
 NFS_PATHCONF									   NUMBER
 NFS_COMMIT									   NUMBER
 NFS_MOUNT									   NUMBER

