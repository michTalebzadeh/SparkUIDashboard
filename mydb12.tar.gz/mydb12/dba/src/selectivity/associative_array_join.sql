DROP FUNCTION array;
DROP FUNCTION regular_array;
DROP TYPE array_table_type;
DROP TYPE array_row_type;
--
--First define a row type that contains the columns we need
--
CREATE TYPE array_row_type
AS OBJECT
(
	n1	 NUMBER(5),
	padding	  VARCHAR2(200)
);
/
-- Create a table type
--
CREATE TYPE array_table_type AS TABLE OF array_row_type;
/
/*
   Now define a table function which returns a collection containing a subset of the columns from T1 table. Table function mimics the table and can be queried later
   using the TABLE function in from clause
*/
CREATE OR REPLACE FUNCTION array 
(
	p_n1		IN	NUMBER		DEFAULT 0,	
	p_padding	IN	VARCHAR2	DEFAULT '%'
)
RETURN array_table_type PIPELINED -- Pipelining negates the need to build huge collections by piping rows out of the function as they are created,
                                   -- saving memory and allowing subsequent processing to start before all the rows are generated
AS
BEGIN
  FOR rs IN (
		SELECT
			n1,
			padding
	     	FROM
		 	T1
	     	WHERE
			n1 is not null
	     	AND   
			padding LIKE p_padding
		AND
		 	ROWNUM <=100000
	    )
  LOOP
    PIPE ROW(array_row_type(rs.n1, rs.padding));
  END LOOP;
  RETURN;
END;
/
CREATE OR REPLACE FUNCTION regular_array
(
        p_n1            IN      NUMBER          DEFAULT 0,
        p_padding       IN      VARCHAR2        DEFAULT '%'
)
RETURN array_table_type 
AS
v_tab array_table_type := array_table_type();
BEGIN
  FOR rs IN (
                SELECT
                        n1,
                        padding
                FROM
                        T1
                WHERE
                        n1 is not null
                AND
                        padding LIKE p_padding
                -- AND
                         -- ROWNUM <=5
            )
  LOOP
    v_tab.extend;
    v_tab(v_tab.last) := array_row_type(rs.n1,rs.padding);
  END LOOP;
  RETURN v_tab;
END;
/
/*
SELECT * FROM
(
       SELECT
               T1.n1,
	       T1.small_vc,
               t.padding
        FROM
                -- table(regular_array) t,
                table(array) t,
                T1
        WHERE
                t.n1 = T1.n1
)
        WHERE
                ROWNUM <=10;
*/
exit
