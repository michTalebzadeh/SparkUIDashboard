drop index t1_i1;
create index t1_i1 on t1(n1, ind_pad, n2)
nologging
pctfree 91
;
exit
