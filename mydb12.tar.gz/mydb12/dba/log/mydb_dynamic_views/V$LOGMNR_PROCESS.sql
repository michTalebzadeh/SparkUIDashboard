 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 SESSION_ID									   NUMBER
 PID										   NUMBER
 SPID										   VARCHAR2(24)
 ROLE										   VARCHAR2(32)
 USERNAME									   VARCHAR2(15)
 SID										   NUMBER
 SERIAL#									   NUMBER
 LATCHWAIT									   VARCHAR2(8)
 LATCHSPIN									   VARCHAR2(8)
 WORK_MICROSEC									   VARCHAR2(21)
 OVERHEAD_MICROSEC								   VARCHAR2(21)

