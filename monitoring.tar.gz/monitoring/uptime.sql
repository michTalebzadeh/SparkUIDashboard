rem -----------------------------------------------------------------------
rem Filename:   uptime.sql
rem Purpose:    Display database uptime in days and hours
rem             to SYS or SYSTEM
rem Date:       12-Jan-2000
rem Author:     Frank Naude, Oracle FAQ
rem -----------------------------------------------------------------------

select SYSDATE-logon_time "Days", (SYSDATE-logon_time)*24 "Hours"
from   sys.v_$session
where  sid=1 /* this is PMON */
/
exit


