/********************************************/
/*------------ APP1_SSDUSER -------------*/
/********************************************/
select 'Started creating APP1_SSDUSER tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
CREATE TABLESPACE "APP1_SSDUSER" DATAFILE '/ssddata5/oracle/mydb12/oradata/MYDB12/datafile/APP01_SSDUSER.dbf' SIZE 5G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED LOGGING
 EXTENT MANAGEMENT LOCAL SEGMENT SPACE MANAGEMENT AUTO; 
select 'Finished  creating APP1_SSDUSER tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
