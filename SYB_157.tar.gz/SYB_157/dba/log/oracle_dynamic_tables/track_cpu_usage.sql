use imdb1
go
select
	 s.USERNAME "Oracle User"
	,s.OSUSER "OS User"
	,convert(numeric(10,0),i.CONSISTENT_GETS) "Consistent Gets"
	,convert(numeric(10,0),i.PHYSICAL_READS) "Physical Reads"
	,s.STATUS "Status"
	,convert(numeric(10,0),s.SID) "SID"
	,convert(numeric(10,0),s.SERIAL#) "Serial#"
	,substring(s.MACHINE,1,30) "Machine"
	,substring(s.PROGRAM,1,30) "Program"
	,convert(char(30),LOGON_TIME,109) "Logon Time"
	,w.SECONDS_IN_WAIT "Idle Time"
	,convert(numeric(10,0),p.SPID) "PROC"
	,NAME "Stat CPU"
	,convert(numeric(10,0),VALUE) "VALUE"
from	MYDB_V$SESSION s
	,MYDB_V$SESS_IO i
	,MYDB_V$SESSION_WAIT w
	,MYDB_V_$PROCESS p
	,MYDB_V$STATNAME n
	,MYDB_V$SESSTAT t
where s.SID = i.SID
and s.SID *= w.SID
and w.EVENT = 'SQL*Net message from client'
and s.OSUSER is not null
and s.USERNAME is not null
and s.PADDR=p.ADDR
and n.STATISTIC# = t.STATISTIC#
and n.NAME like '%cpu%'
and t.SID = s.SID
and s.PROGRAM NOT LIKE 'dcoracle%'
order by 6 asc, 3 desc, 4 desc
go
exit
