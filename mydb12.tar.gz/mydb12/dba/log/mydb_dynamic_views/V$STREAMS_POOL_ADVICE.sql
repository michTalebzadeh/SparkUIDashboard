 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 STREAMS_POOL_SIZE_FOR_ESTIMATE 						   NUMBER
 STREAMS_POOL_SIZE_FACTOR							   NUMBER
 ESTD_SPILL_COUNT								   NUMBER
 ESTD_SPILL_TIME								   NUMBER
 ESTD_UNSPILL_COUNT								   NUMBER
 ESTD_UNSPILL_TIME								   NUMBER

