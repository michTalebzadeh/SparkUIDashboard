online database its_ged_para
go
use its_ged_para
go
dbcc settrunc(ltm,ignore)
go
