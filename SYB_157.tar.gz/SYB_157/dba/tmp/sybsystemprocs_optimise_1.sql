set nocount on
go
use sybsystemprocs
go
select 'use sybsystemprocs
go'
go
select 'sp_recompile "' + user_name(uid) + '.' + name + '"
go' + '
update statistics ' + user_name(uid) + '.' + name + '
go'
from sysobjects where type = 'U'
and name not in ( select object_cinfo from sysattributes where class=9 and attribute=1)
order by name
go
	
