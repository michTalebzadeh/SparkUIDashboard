/********************************************/
/*------------ APP1_HDD -------------*/
/********************************************/
select 'Started altering APP1 tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
ALTER TABLESPACE "APP1_HDD" ADD DATAFILE '/data4/oracle/mydb12/MYDB12/datafile/APP08_HDD.dbf' SIZE 30G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
ALTER TABLESPACE "APP1_HDD" ADD DATAFILE '/data4/oracle/mydb12/MYDB12/datafile/APP09_HDD.dbf' SIZE 30G AUTOEXTEND ON NEXT 100M MAXSIZE UNLIMITED;
select 'Finished  altering APP1_HDD tablespace at '||to_char(sysdate, 'yyyy/mm/dd hh24:mi:ss')||chr(10) from dual;
exit
