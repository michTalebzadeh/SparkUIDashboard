 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 RECID										   NUMBER
 STAMP										   NUMBER
 SET_STAMP									   NUMBER
 SET_COUNT									   NUMBER
 BACKUP_TYPE									   VARCHAR2(1)
 CONTROLFILE_INCLUDED								   VARCHAR2(3)
 INCREMENTAL_LEVEL								   NUMBER
 PIECES 									   NUMBER
 START_TIME									   DATE
 COMPLETION_TIME								   DATE
 ELAPSED_SECONDS								   NUMBER
 BLOCK_SIZE									   NUMBER
 INPUT_FILE_SCAN_ONLY								   VARCHAR2(3)
 KEEP										   VARCHAR2(3)
 KEEP_UNTIL									   DATE
 KEEP_OPTIONS									   VARCHAR2(11)
 MULTI_SECTION									   VARCHAR2(3)

