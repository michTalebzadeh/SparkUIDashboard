drop table generator;
exec dbms_random.seed(0);
create table generator
as
select
		rownum id
from
		dual
connect by
		rownum <=10000
/
drop table dummy;
create table dummy
as
select
    rownum                                          id,
    trunc((rownum - 1) / 1000)                clustered,
    mod(rownum - 1,1000)                      scattered,
    trunc(dbms_random.value(0,1000))          randomised,
    substr(dbms_random.string('A',15),1,15)   random_string,
    lpad(rownum,10)                           small_vc,
    rpad('x',10,'x')                          padding
from
    generator   g1,
    generator   g2
/
exec dbms_stats.gather_table_stats( user, 'DUMMY');
select count(1) from dummy;
exit
