 select name,type,crdate from sysobjects where type in ('U', 'V','P') and crdate > ' Nov  1 2002 10:59AM'
