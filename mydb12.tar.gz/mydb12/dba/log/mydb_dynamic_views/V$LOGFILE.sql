 Name									  Null?    Type
 ------------------------------------------------------------------------ -------- -------------------------------------------------
 GROUP# 									   NUMBER
 STATUS 									   VARCHAR2(7)
 TYPE										   VARCHAR2(7)
 MEMBER 									   VARCHAR2(513)
 IS_RECOVERY_DEST_FILE								   VARCHAR2(3)

